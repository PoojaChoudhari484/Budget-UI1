import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { HttpClient } from '@angular/common/http';
import { AllFmpService } from '../all-fmp.service';
import { LocalStorageService } from 'src/app/core/services/local-storage.service';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { ToastrService } from 'ngx-toastr';
import { ReminderPayload } from '../model/reminder';

@Component({
  selector: 'app-reminders',
  templateUrl: './reminders.component.html',
  styleUrls: ['./reminders.component.scss'],
  standalone: false
})
export class RemindersComponent implements OnInit {


addReminderForm: FormGroup;
  


  customerGroups: any[] = [];
  remindersList: any[] = [];
  reminders: any[] = [];  // assuming reminders are loaded in a table

  showAddReminder = false;

  // For Drag and Drop

draggedTemplate: HTMLElement | null = null;


// Update Reminder

editingReminderId: number | null = null;
parsedFmpData: any = null;

// 


  constructor(    private fb: FormBuilder,
              private router: Router,
              private fmpService: AllFmpService,
              private localStorageService : LocalStorageService,
              private toastr: ToastrService
            
            ) { }

  ngOnInit() {

    // this.addReminderForm = this.fb.group({
    //       // email: ['', Validators.required],
    //       // field: ['', Validators.required],
    //       // relation: ['', Validators.required],
    //       // noofdays: ['', Validators.required],
    //       // message: ['', Validators.required],
    //       // mailtemplate: ['', Validators.required],
    //       // mailId: ['', Validators.required],
    //       ReminderName: ['', Validators.required],
    //       // adminEmail: ['', Validators.required],
    //       // customerId: ['', Validators.required],
    //       // Add other fields as needed
    //     });

  this.addReminderForm = this.fb.group({
      ReminderName: ['', Validators.required],
      customerGroup: ['']
    });

    this.loadReminders();



    this.getCustomerGroups();
    this.getFMPReminderList();

  }

// Update Part
private initReminderForm() {
    this.addReminderForm = this.fb.group({
      FMPData: [''],
      ReminderName: ['', Validators.required],
      adminEmail: ['fmp@bizlemdigital.com'],
      custgroup: [''],
      customerId: [''],
      description: [''],
      flag: ['0'],
      saveType: ['default']
    });
  }

  // end


  goToAddReminder() {
    this.showAddReminder = true;
  }

  
  getCustomerGroups() {
  const customerId = this.localStorageService.getCustomerId();
    this.fmpService.getCustomerGroups(customerId).subscribe(
      (response: any) => {
        console.log('API response:', response);
        this.customerGroups = response.Groups;
      },
      (error) => {
        console.error('Error fetching groups:', error);
      }
    );
  }


 deleteReminder(id: number) {
    this.fmpService.deleteReminder(id).subscribe({
      next: (res) => {
        console.log('Deleted successfully:', res);
        this.toastr.success('Reminder Deleted Successfully');
        
        // update UI by filtering out deleted row
        // this.reminders = this.reminders.filter(r => r.Id !== id);

          // ✅ remove the deleted reminder from the list immediately
      this.remindersList = this.remindersList.filter(r => r.Id !== id);


      },
      error: (err) => {
        console.error('Delete failed:', err);
      }
    });
  }


  getFMPReminderList() {
  const customerId = this.localStorageService.getCustomerId();
  console.log("Customer Id in Reminder List",customerId);
    this.fmpService.getFMPReminderList(customerId).subscribe(
      (response: any) => {
        console.log('FMP Reminder List API response:', response);
        if (response.ResponseCode === 1) {
          this.remindersList = response.FMPRemindersList.map((reminder: any) => {
            const fmpDataParsed = JSON.parse(reminder.FMPData);
            return {
              ...reminder,
              parsedData: fmpDataParsed
            };
          });
        }
      },
      (error) => {
        console.error('Error fetching FMP Reminder List:', error);
      }
    );
  }


  // For Drag and Drop
  onDragStart(event: DragEvent, template: HTMLElement) {
  this.draggedTemplate = template; // store full template card reference
}

onDragOver(event: DragEvent) {
  event.preventDefault(); // required to allow dropping
}

onDrop(event: DragEvent) {
  event.preventDefault();

  if (this.draggedTemplate) {
    const dropZone = (event.target as HTMLElement).closest('.drag-box');
    if (dropZone) {
      // clone full card
      const clone = this.draggedTemplate.cloneNode(true) as HTMLElement;
      dropZone.appendChild(clone);
    }
  }
}


// Drag and Drop Ends Here



// Add Reminder Form Submit

loadReminders() {
 const customerId = localStorage.getItem('customerId') || 'cus100856';
  this.fmpService.getFMPReminderList(customerId).subscribe({
    next: (res) => {
      if (res.ResponseCode === 1) {
        this.remindersList = res.FMPReminders || [];
      } else {
        this.remindersList = [];
        console.warn("No reminders found:", res.ResponseMessage);
      }
    },
    error: (err) => console.error("Error fetching reminders:", err)
  });
}
  onSubmit() {
    if (this.addReminderForm.invalid) return;

    const { ReminderName, customerGroup } = this.addReminderForm.value;

    // Build the payload like Postman
    const payload: ReminderPayload = {
      FMPData: JSON.stringify({
        email: "fmp@bizlemdigital.com",
        group: "",
        lgtype: "null",
        data: [
          {
            field: "Invoice Date",
            relation: "On",
            noofdays: 0,
            message: "Invoice ready",
            callId: 0,
            calltemplate: "",
            customerId: "cus100118",
            smstemplate: "",
            smsId: "",
            mailtemplate: "Demo",
            mailId: 370,
            whatsapptemplate: "",
            whatsappId: ""
          }
        ]
      }),
      ReminderName,
      adminEmail: "fmp@bizlemdigital.com",
      custgroup: customerGroup,
      customerId: "cus100856",
      description: "",
      flag: "0",
      saveType: "default"
    };

    this.fmpService.addReminder(payload).subscribe({
      next: (res) => {
        if (res.ResponseCode === 1) {
          this.toastr.success("Reminder added successfully!");
          this.addReminderForm.reset();
          this.loadReminders();
          this.showAddReminder = false;
        } else {
          alert("❌ Failed: " + res.ResponseMessage);
        }
      },
      error: (err) => console.error(err)
    });
  }

  // End of Add Reminder Form Submit



  // Update Reminder (Edit reminder)


  editReminder(reminder: any) {
  // open modal
  this.showAddReminder = true;

  // store editing id
  this.editingReminderId = reminder.Id ?? null;

  // patch form. FMPData is a JSON string in the backend; keep it as-is
  this.addReminderForm.patchValue({
    FMPData: reminder.FMPData || '',
    ReminderName: reminder.ReminderName || '',
    adminEmail: reminder.adminEmail || 'fmp@bizlemdigital.com',
    custgroup: reminder.custgroup || '',
    customerId: reminder.customerId || 'cus100856',
    description: reminder.description || '',
    flag: reminder.flag || '0',
    saveType: reminder.saveType || 'default'
  });

  // if you also want to visually show parsed templates,
  // you can parse FMPData here and populate UI template elements:
  // this.parsedFmpData = JSON.parse(reminder.FMPData || '{}');
}


buildReminderPayload(): ReminderPayload {
  const fv = this.addReminderForm.value;

  // If you manage templates in UI as an object, ensure you stringify it:
  const fmpDataStr = fv.FMPData || JSON.stringify(this.parsedFmpData || {});

  const payload: ReminderPayload = {
       Id: String(this.editingReminderId || 0),   // 👈 as string
    FMPData: fmpDataStr,
    ReminderName: fv.ReminderName,
    adminEmail: fv.adminEmail || "fmp@bizlemdigital.com",  // 👈 fallback
    custgroup: fv.custgroup || "",
    customerId: fv.customerId || "cus100856",              // 👈 fallback
    description: fv.description || "",
    flag: "0",
    saveType: fv.saveType || "default"
  };

  return payload;
}



onUpdate() {
  if (!this.editingReminderId) {
    this.toastr.warning('No reminder selected to update');
    return;
  }

  if (this.addReminderForm.invalid) {
    this.toastr.warning('Please fix the form');
    return;
  }

  const payload = this.buildReminderPayload();
  payload.Id = String(this.editingReminderId); // backend expects Id

  this.fmpService.updateFMPReminder(payload).subscribe({
    next: (res: any) => {
      if (res.ResponseCode === 1) {
        this.toastr.success('Reminder updated!');
        this.addReminderForm.reset();
        this.initReminderForm();
        this.editingReminderId = null;
        this.loadReminders();
        this.showAddReminder = false;
      } else {
        this.toastr.error('Update failed: ' + (res.ResponseMessage || 'Unknown'));
      }
    },
    error: (err) => {
      console.error('Update error', err);
      this.toastr.error('Update request failed');
    }
  });
}



  // Code By Manoj Sir

  // onSubmit() {
  //   if (this.addReminderForm.valid) {
  //     const formValues = this.addReminderForm.value;

  //     const requestData = {
  //       FMPData: JSON.stringify({
  //         email: formValues.email,
  //         group: "",
  //         lgtype: "null",
  //         data: [{
  //           field: formValues.field,
  //           relation: formValues.relation,
  //           noofdays: formValues.noofdays,
  //           message: formValues.message,
  //           callId: 0,
  //           calltemplate: "",
  //           customerId: formValues.customerId,
  //           smstemplate: "",
  //           smsId: "",
  //           mailtemplate: formValues.mailtemplate,
  //           mailId: formValues.mailId,
  //           whatsapptemplate: "",
  //           whatsappId: ""
  //         }]
  //       }),
  //       ReminderName: formValues.ReminderName,
  //       adminEmail: formValues.adminEmail,
  //       custgroup: "",
  //       customerId: formValues.customerId,
  //       description: "",
  //       flag: "0",
  //       saveType: "default"
  //     };

  //     this.fmpService.addFMPReminder(requestData).subscribe(
  //       (response) => {
  //         console.log('Reminder added successfully:', response);
  //         alert('Reminder added!');
  //       },
  //       (error) => {
  //         console.error('Error adding reminder:', error);
  //         alert('Failed to add reminder.');
  //       }
  //     );
  //   } else {
  //     alert('Please fill all required fields');
  //   }
  // }

  

// onSubmit() {
//   if (this.addReminderForm.invalid) return;

//   const { ReminderName, customerGroup } = this.addReminderForm.value;

//   const requestData = {
//     FMPData: {
//       ReminderName,
      
//       customerGroup
//     }
//   };

//   this.fmpService.addFMPReminder(requestData).subscribe({
//     next: (res) => {
//       console.log("Reminder added successfully:", res);
//       alert("✅ Reminder added successfully!");
//       this.addReminderForm.reset();
//     },
//     error: (err) => {
//       console.error("Error adding reminder:", err);
//     }
//   });
// }



}
