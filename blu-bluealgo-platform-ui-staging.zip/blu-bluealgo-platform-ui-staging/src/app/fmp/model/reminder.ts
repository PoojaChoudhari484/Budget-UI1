export interface ReminderPayload {
  Id?: number | string;
  FMPData: string;      // backend expects a JSON string here
  ReminderName: string;
  adminEmail?: string;
  custgroup?: string;   // note backend key is 'custgroup'
  customerId?: string;
  description?: string;
  flag?: string;
  saveType?: string;
}