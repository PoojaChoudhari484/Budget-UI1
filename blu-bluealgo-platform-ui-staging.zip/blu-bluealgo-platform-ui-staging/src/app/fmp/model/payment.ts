export interface PaymentModel {
  amount: string;
  bankBranch: string;
  bankCharge?: string;
  bankCode?: string;
  bankName: string;
  chequeNumber?: string;
  createdById: string;   // manager/customer id who creates the payment
  currency: string;
  customerId: string;
  invoiceNumber: string;
  name?: string;         // customer name
  paymentDate: string;   // "YYYY-MM-DD HH:mm:ss"
  paymentFrom?: string;  // e.g. "manual"
  paymentType?: string;  // e.g. "online", "credit"
  priority?: string;
  remarks?: string;
  status?: string;
  utrSwiftTransNumber?: string;
}
