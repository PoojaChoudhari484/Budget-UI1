export interface ProductModel {
  ProductName: string;
  Description?: string;
  Qty: number;
  UnitPrice: number;
  gst?: number;
  sgst?: number;
  igst?: number;
  vat?: number;
  Amount?: string;   // e.g. "$600.00"
  tax?: string;
}

export interface CustomerModel {
  Id?: number;
  Name?: string;
  CustomerId?: string;
  ProfileImage?: string;
  Email?: string;
  CompanyName?: string;
  TeamSpaceId?: string;
  TeamSpaceName?: string;
  customerAddresses?: any[];
  customerContacts?: any[];
  customerFinnanceSettings?: any;
}

export interface InvoiceModel {
  Id?: number  | null;   // make it optional
  Currency?: string;
  CustomerId: string;
  CustomerName?: string;
  DueDate?: string;        // backend expects "YYYY-MM-DD HH:mm:ss"
  InvoiceDate?: string;    // backend expects "YYYY-MM-DD HH:mm:ss"
  InvoiceNumber: string;
  Location?: string;
  Products: ProductModel[];
  Remarks?: string;
  Terms?: string;
  TotalAmount?: string;    // backend sample used string
  amountpaid?: number;
  subtotal?: number;
  total?: number;
  totaldiscount?: number;
  totaltax?: number;
  isDraft?: boolean;
  customer?: CustomerModel;
}
