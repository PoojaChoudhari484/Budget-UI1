import { Component, OnInit } from '@angular/core';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { AllFmpService } from '../all-fmp.service';

@Component({
  selector: 'app-add-reminder',
  templateUrl: './add-reminder.component.html',
  styleUrls: ['./add-reminder.component.scss'],
  standalone: false,
})
export class AddReminderComponent  implements OnInit{


   addReminderForm: FormGroup;

  constructor(
    private fb: FormBuilder,
    private fmpService: AllFmpService
  ) {}

  ngOnInit() {
    this.addReminderForm = this.fb.group({
      email: ['', Validators.required],
      field: ['', Validators.required],
      relation: ['', Validators.required],
      noofdays: ['', Validators.required],
      message: ['', Validators.required],
      mailtemplate: ['', Validators.required],
      mailId: ['', Validators.required],
      ReminderName: ['', Validators.required],
      adminEmail: ['', Validators.required],
      customerId: ['', Validators.required],
      // Add other fields as needed
    });
  }

  onSubmit() {
    if (this.addReminderForm.valid) {
      const formValues = this.addReminderForm.value;

      const requestData = {
        FMPData: JSON.stringify({
          email: formValues.email,
          group: "",
          lgtype: "null",
          data: [{
            field: formValues.field,
            relation: formValues.relation,
            noofdays: formValues.noofdays,
            message: formValues.message,
            callId: 0,
            calltemplate: "",
            customerId: formValues.customerId,
            smstemplate: "",
            smsId: "",
            mailtemplate: formValues.mailtemplate,
            mailId: formValues.mailId,
            whatsapptemplate: "",
            whatsappId: ""
          }]
        }),
        ReminderName: formValues.ReminderName,
        adminEmail: formValues.adminEmail,
        custgroup: "",
        customerId: formValues.customerId,
        description: "",
        flag: "0",
        saveType: "default"
      };

      this.fmpService.addFMPReminder(requestData).subscribe(
        (response) => {
          console.log('Reminder added successfully:', response);
          alert('Reminder added!');
        },
        (error) => {
          console.error('Error adding reminder:', error);
          alert('Failed to add reminder.');
        }
      );
    } else {
      alert('Please fill all required fields');
    }
  }

}
