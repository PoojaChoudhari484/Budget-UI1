import { Component, OnInit } from '@angular/core';

import { ChartData,ChartType, ChartOptions } from 'chart.js';
import DataLabelsPlugin from 'chartjs-plugin-datalabels';


@Component({
    selector: 'app-dashboard-fmp',
    templateUrl: './dashboard-fmp.component.html',
    styleUrls: ['./dashboard-fmp.component.scss'],
    standalone: false
})
export class DashboardFmpComponent  implements OnInit {
  isMonthlyDropdownOpen = false;

  toggleMonthlyDropdown() {
    this.isMonthlyDropdownOpen = !this.isMonthlyDropdownOpen;
  }

  isFilterDropdownOpen = false;

  toggleFilterDropdown() {
    this.isFilterDropdownOpen = !this.isFilterDropdownOpen;
  }

  isSentDropdownOpen = false;

  toggleSentDropdown() {
    this.isSentDropdownOpen = !this.isSentDropdownOpen;
  }

  constructor() {}

  ngOnInit() {}


  grouth_card = [
    {
      title: 'Opening',
      value: -588,
      icon: 'assets/images/data_growth.png'
    },
    {
      title: 'Invoiced',
      value: 0,
      icon: 'assets/images/data_growth.png'
    },
    {
      title: 'Collected',
      value: 588,
      icon: 'assets/images/data_growth.png'
    }
  ];

  onetableHeaders = [
    {
      label: 'AI Powered',
      iconColor: null
    },
    {
      label: 'On time payers',
      iconColor: 'bg-green-500'
    },
    {
      label: 'Late payers',
      iconColor: 'bg-yellow-400'
    },
    {
      label: 'Risk payers',
      iconColor: 'bg-red-500'
    }
  ];

  onetableRows = [
    {
      title: 'Customers',
      values: [800, 500, 200]
    },
    {
      title: 'Outstanding',
      values: [300, 700, 400]
    },
    {
      title: 'Percentage',
      values: [400, 700, 600]
    }
  ];

  twotableHeaders = ['Types', 'January', 'February', 'April'];

  twotableRows = [
    {
      type: 'Invoices',
      iconColor: 'bg-green-500',
      values: [800, 500, 200]
    }
  ];


  threetableHeaders = [
    'SR.NO',
    'CUSTOMER NAME',
    'AMOUNT',
    'DUE DATE',
    'OVER DAYS',
    'RECON',
    'PAID'
  ];

  threetableRows = [
    {
      srNo: 1,
      name: 'John Lupus',
      amount: '$200',
      dueDate: '21-04-2025',
      overDays: 3,
      recon: '-',
      paid: 'YES'
    }
    // Add more rows if needed
  ];


   // Chart type
   public doughnutChartType: 'doughnut' = 'doughnut';

   // Chart data
   public doughnutChartData: ChartData<'doughnut', number[], string | string[]> = {
     labels: ['On time payers', 'Late payers', 'Risk payers'],
     datasets: [
       {
         data: [350, 450, 100],
         backgroundColor: ['#27AE60', '#FFD200', '#FF3333'],
         hoverBackgroundColor: ['#27AE60', '#FFD200', '#FF3333'],
         borderWidth:0,
       },
     ],
   }; 
 
   public doughnutChartOptions: ChartOptions<'doughnut'> = {
    responsive: true,
    maintainAspectRatio: false,
    plugins: {
      legend: {
        display: false, // Hide default legend for custom legend below chart
        position: 'bottom',
        labels: {
          usePointStyle: true,
          pointStyle: 'circle',
          padding: 10,
          boxWidth: 8,
          font: {
            size: 12,        // Smaller text
          },
        },
      },
      tooltip: {
        enabled: true,
      },
    },
    cutout: '75%', 
  };

   // Second doughnut chart data
   public secondDoughnutChartData: ChartData<'doughnut', number[], string | string[]> = {
    labels: ['On time payers', 'Late payers', 'Risk payers'],
    datasets: [
      {
        data: [350, 450, 100],
        backgroundColor: ['#01A9F4', '#FFD200', '#FF3333'],
        hoverBackgroundColor: ['#01A9F4', '#FFD200', '#FF3333'],
        borderWidth:0,
      },
    ],
  };

  // Second doughnut chart options with fixed height
  public secondDoughnutChartOptions: ChartOptions<'doughnut'> = {
    responsive: true,
    maintainAspectRatio: false,
    plugins: {
      legend: {
        display: false,
        position: 'bottom',
        labels: {
          usePointStyle: true,
          pointStyle: 'circle',
          padding: 10,
          boxWidth: 8,
          font: {
            size: 12,
          },
        },
      },
      tooltip: {
        enabled: true,
      },
    },
    cutout: '75%',
  };

  get seconddoughnutChartColors(): string[] {
    const bg = this.doughnutChartData.datasets[0].backgroundColor;
    if (Array.isArray(bg)) {
      return bg as string[];
    }
    // fallback: repeat a default color array
    return ['#01A9F4', '#FFD200', '#FF3333'];
  }


  public barChartPlugins = [DataLabelsPlugin];

  // Chart type
  public barChartType: 'bar' = 'bar';

  // Chart data
  public barChartData: ChartData<'bar'> = {
    labels: ['Likely', 'Possible', 'Risk'],
    datasets: [
      {
        data: [6000, 5600, 4500],
        backgroundColor: ['#7AC142', '#FFD600', '#FF5A5F'],
        borderRadius: 10,
        barPercentage: 0.7,
        categoryPercentage: 0.6,
      },
    ],
  };

  public barChartOptions: ChartOptions<'bar'> = {
    indexAxis: 'y',
    responsive: true,
    plugins: {
      legend: { display: false },
      tooltip: { enabled: false },
      datalabels: {
        // anchor: 'center',
        align: 'end',
        offset: -30,
        color: '#000',
        // backgroundColor: 'white',
        borderRadius: 4,
        padding: 6,
        font: {
          size: 14,
          weight: 'bold',
        },
        formatter: (value, context) => {
          return `${context.chart.data.labels?.[context.dataIndex]}  ${value}`;
        },
        
      },
    },
    scales: {
      x: {
        display: false,
        grid: { display: false },
        min: 0,
      },
      y: {
        display: false,
        grid: { display: false },
        ticks: { display: false },
      },
    },
  };

  
  // Define the data array once
  private paymentTrendsData = [0.6, -0.2, 0.3, -0.6, 0.2, 0.4, -1, 0.6, -0.4];

  public paymentTrendsChartData: ChartData<'bar'> = {
    labels: ['Jan', 'Feb', 'Mar', 'April', 'May', 'June', 'July', 'Aug', 'Sep'],
    datasets: [
      {
        data: this.paymentTrendsData,
        backgroundColor: this.paymentTrendsData.map(v => v >= 0 ? '#4C89FF' : '#4C89FF66'),
        borderRadius: 8,
        barPercentage: 0.7,
        categoryPercentage: 0.7,
        borderSkipped: false,
      }
    ]
  };

  public paymentTrendsChartOptions: ChartOptions<'bar'> = {
    responsive: true,
    maintainAspectRatio: false,
    plugins: {
      legend: { display: false },
      tooltip: { enabled: true },
      datalabels:{
        font:{
          size: 14
        }
      }
    },
    scales: {
      x: {
        grid: { display: false },
        ticks: { font: { size: 14 } },
      },
      y: {
        min: -1,
        max: 1,
        grid: { display: false },
        ticks: { stepSize: 0.2, font: { size: 14 } },
      }
    }
  };

  
  public paymentStatusChartData: ChartData<'doughnut', number[], string | string[]> = {
    labels: ['Paid', 'Unpaid', 'Partial'],
    datasets: [
      {
        data: [40, 28, 12],
        backgroundColor: ['#27AE60', '#FFD200', '#F2994A'],
        hoverBackgroundColor: ['#27AE60', '#FFD200', '#F2994A'],
        borderWidth: 0,
        borderRadius:20,
        spacing:10
      },
    ],
  };

  public paymentStatusChartOptions: ChartOptions<'doughnut'> = {
    responsive: true,
    maintainAspectRatio: false,
    cutout: '90%',
    rotation: -90,
    circumference: 180,
    plugins: {
      legend: { display: false },
      tooltip: { enabled: true },
    },
  };
  
  get paymentStatusColors(): string[] {
    const bg = this.paymentStatusChartData.datasets[0].backgroundColor;
    // If it's an array, return as string array, else fallback to default colors
    if (Array.isArray(bg)) {
      return bg as string[];
    }
    // fallback: repeat a default color array
    return ['#27AE60', '#FFD200', '#F2994A'];
  }

  // Add a getter for safe background color access in the template
  get doughnutChartColors(): string[] {
    const bg = this.doughnutChartData.datasets[0].backgroundColor;
    if (Array.isArray(bg)) {
      return bg as string[];
    }
    // fallback: repeat a default color array
    return ['#27AE60', '#FFD200', '#FF3333'];
  }

  public paymentTrendsStackedChartData: ChartData<'bar'> = {
    labels: [
      'Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun',
      'Jul', 'Aug', 'Sep', 'Oct', 'Nov', 'Dec'
    ],
    datasets: [
      {
        label: 'Payment type1',
        data: [-0.6, -0.2, -0.7, -0.9, -0.3, -0.5, -0.7, -0.6, -0.7, -0.3, -1.0, -0.7],
        backgroundColor: '#3f83f8',
        borderRadius: 20,
        barPercentage: 0.7,
        categoryPercentage: 0.7,
        stack:'0'
      },
      {
        label: 'Payment type2',
        data: [0.6, 0.4, 0.7, 1.0, 0.2, 0.9, 0.6, 0.7, 0.6, 0.4, 0.5, 0.6],
        backgroundColor: '#1cc8ff',
        borderRadius: 20,
        barPercentage: 0.7,
        categoryPercentage: 0.7,
        stack:'0'
        
      }
      
    ]
  };

  public paymentTrendsStackedChartOptions: ChartOptions<'bar'> = {
    responsive: true,
    maintainAspectRatio: false,
    plugins: {
      legend: {
        display: false,
        position: 'right',
        align:'start',
        labels: {
          usePointStyle: true,
          font: { size: 16 }
        }
      },
      datalabels:{
        font:{
          size:14
        }
      },
      tooltip: { enabled: true },
    },
    interaction:{
      intersect:false,
    },
    scales: {
      x: {
        stacked: false,
        grid: { display: false },
        ticks: { font: { size: 14 } }
      },
      y: {
        stacked: false,
        min: -1.0,
        max: 1.0,
        grid: { display: false },
        ticks: { stepSize: 0.2, font: { size: 14 } }
      }
    }
  };

  get paymentTrendsStackedChartOptionsColors(): string[] {
    const bg = this.paymentTrendsStackedChartData.datasets[0].backgroundColor;
    if (Array.isArray(bg)) {
      return bg as string[];
    }
    // fallback: repeat a default color array
    return ['#3f83f8', '#1cc8ff',];
  }

  public cardList = [
    {
      image: 'assets/images/Avatar.png',
      user_name:'Arun Arora',
      user_email:'arun5454@gmail.com',
      title1: 'Total Amount',
      description1: '6000',
      title2: 'Paid Amount',
      description2: '6000',
      title3: 'Pending Amount',
      description3: '6000',
      title4: 'Due Date',
      description4: '15-7-2025',
    },
    {
      image: 'assets/images/Avatar.png',
      user_name:'Arun Arora',
      user_email:'arun5454@gmail.com',
      title1: 'Total Amount',
      description1: '6000',
      title2: 'Paid Amount',
      description2: '6000',
      title3: 'Pending Amount',
      description3: '6000',
      title4: 'Due Date',
      description4: '15-7-2025',
    },
    {
      image: 'assets/images/Avatar.png',
      user_name:'Arun Arora',
      user_email:'arun5454@gmail.com',
      title1: 'Total Amount',
      description1: '6000',
      title2: 'Paid Amount',
      description2: '6000',
      title3: 'Pending Amount',
      description3: '6000',
      title4: 'Due Date',
      description4: '15-7-2025',
    },
   
  ];
}
