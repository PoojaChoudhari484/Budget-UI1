import { ComponentFixture, TestBed } from '@angular/core/testing';

import { DashboardFmpComponent } from './dashboard-fmp.component';

describe('DashboardFmpComponent', () => {
  let component: DashboardFmpComponent;
  let fixture: ComponentFixture<DashboardFmpComponent>;

  beforeEach(() => {
    TestBed.configureTestingModule({
      declarations: [DashboardFmpComponent]
    });
    fixture = TestBed.createComponent(DashboardFmpComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
