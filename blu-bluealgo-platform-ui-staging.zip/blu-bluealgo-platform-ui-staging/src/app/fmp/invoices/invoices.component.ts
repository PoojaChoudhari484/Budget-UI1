import { Component } from '@angular/core';
import { Router } from '@angular/router';
import { ChartOptions, ChartData } from 'chart.js';
import { AllFmpService } from '../all-fmp.service';
import { FormArray, FormBuilder, FormGroup, ReactiveFormsModule, Validators } from '@angular/forms';
import { LocalStorageService } from 'src/app/core/services/local-storage.service';
import { ToastrService } from 'ngx-toastr';
import { CustomerModel, InvoiceModel, ProductModel } from '../model/Invoice';
import { HttpClient } from '@angular/common/http';


@Component({
  selector: 'app-invoices',
  templateUrl: './invoices.component.html',
  styleUrls: ['./invoices.component.scss'],
  standalone: false
})
export class InvoicesComponent {

  showInvoiceDashboard = false;
  showInvoiceForm = false;
  showAddInvoice = false;

  // Invoice Crud (Display)

  invoiceList : any[] = [];

    // For Add Invoice
  invoiceForm!: FormGroup;

  // For Fetching Customer Details in Add Invoice Form
  customersList: Array<CustomerModel> = [];

  // For Update Invoice
  editingInvoiceId: number | null = null; // to track which invoice is being edited

    // Manager Id (from localStorage)
  managerId: string | null = null;



  constructor(private router : Router,
    private fmpService : AllFmpService,
    private reactive : ReactiveFormsModule,
    private localStorage : LocalStorageService,
    private toastr : ToastrService,
    private fb : FormBuilder,
    private http: HttpClient
  ){}


  ngOnInit(){

 // ✅ read it once and store on the component
  this.managerId = this.localStorage.getCustomerId() || localStorage.getItem('customerId');
  console.log("🔎 managerId (from localStorage):", this.managerId);

  if (!this.managerId) {
    console.error("❌ No managerId found in localStorage");
  } else {
    this.loadCustomers(this.managerId);
  }

    if(this.router.url.includes('invoice-dashboard')){

      this.showInvoiceDashboard = true;
    }

    this.getInvoiceList();
     this.toastr.info('Invoices displayed successfully\u00A0📄', 'Info', {
      timeOut: 3000,
      progressBar: true,
      closeButton: true,
      positionClass: 'toast-top-right'
      
    });

    // For Add Invoice
    this.initForm();

    // this.loadCustomers();   // 👈 call here


  
  }



  // Invoice Crud 

  // Display (Get) Invoice List

  getInvoiceList(){

      const customerId = this.localStorage.getCustomerId();
      console.log("Customer Id in Invoice List",customerId);
      this.fmpService.getInvoiceList(customerId).subscribe(
  (response: any) => {
    console.log('FMP Invoice List API response:', response);
    if (response.ResponseCode === 1 || response.ResponseCode === 0) {
      this.invoiceList = response.invoiceDetailses.map((invoice: any) => {
        let parsedData: any = {};
        try {
          parsedData = JSON.parse(invoice.invoiceRecord); // parse JSON string
        } catch (e) {
          console.warn("Error parsing invoiceRecord", e);
        }

         console.log("Flat invoice object:", invoice);
  console.log("Parsed invoiceRecord:", parsedData);

        return {
          ...invoice,
          parsedData // attach parsed record so frontend can use it
        };
      });
    }
  },
  (error) => {
    console.error('Error fetching FMP Invoice List:', error);
  }
);

  }



  // Delete Invoice

  deleteInvoice(invoice: any) {
  console.log("Deleting invoice:", invoice);

  this.fmpService.deleteInvoice(invoice.Id, invoice.invoiceNumber, invoice.customerId)
    .subscribe(
      (res: any) => {
        console.log('Invoice deleted successfully:', res);
        this.getInvoiceList();
        this.toastr.success('Invoice deleted successfully ✅');
      },
      (err) => {
        console.error('Error deleting invoice:', err);
        this.toastr.error('Failed to delete invoice ❌');
      }
    );
}


  // Add Invoice

  private initForm() {
    this.invoiceForm = this.fb.group({
      Currency: ['Dollar'],
      CustomerId: [''],
      CustomerName: [''],
      InvoiceNumber: ['', ],
      InvoiceDate: [null],
      DueDate: [null],
      Location: [''],
      Products: this.fb.array([ this.createProductGroup() ]),
      Remarks: [''],
      Terms: ['Net30'],
      subtotal: [0],
      totaltax: [0],
      TotalAmount: ['0'],
      amountpaid: [0],
      total: [0],
      totaldiscount: [0],
      isDraft: [true],
      customer: this.fb.group({
        Id: [null],
        Name: [''],
        CustomerId: [''],
        ProfileImage: [''],
        Email: [''],
        CompanyName: ['']
      })
    });
  }

  createProductGroup(): FormGroup {
    return this.fb.group({
      ProductName: [''],
      Description: [''],
      Qty: [1],
      UnitPrice: [0],
      gst: [0],
      sgst: [0],
      igst: [0],
      vat: [0],
      Amount: ['0'],
      tax: ['']
    });
  }

  get products(): FormArray {
    return this.invoiceForm.get('Products') as FormArray;
  }

  addProduct() {
    this.products.push(this.createProductGroup());
  }

  removeProduct(index: number) {
    if (this.products.length > 1) {
      this.products.removeAt(index);
      this.recalculateTotals();
    }
  }

  onProductChange(index: number) {
    const pg = this.products.at(index);
    const qty = Number(pg.get('Qty')?.value || 0);
    const price = Number(pg.get('UnitPrice')?.value || 0);
    const amount = qty * price;
    pg.get('Amount')?.setValue(`$${amount.toFixed(2)}`, { emitEvent: false });
    this.recalculateTotals();
  }

  recalculateTotals() {
    const products = this.products.controls;
    let subtotal = 0;
    let totalTax = 0;

    products.forEach(p => {
      const qty = Number(p.get('Qty')?.value || 0);
      const price = Number(p.get('UnitPrice')?.value || 0);
      const gst = Number(p.get('gst')?.value || 0);
      const line = qty * price;
      subtotal += line;
      // example GST calculation (adjust per your rules)
      totalTax += (line * gst) / 100;
    });

    const total = subtotal + totalTax;
    this.invoiceForm.patchValue({
      subtotal,
      totaltax: totalTax,
      total,
      TotalAmount: total.toString()
    }, { emitEvent: false });
  }

  private formatDateForBackend(value: string | Date | null): string {
    if (!value) return '';
    const d = value instanceof Date ? value : new Date(value);
    const pad = (n: number) => n.toString().padStart(2, '0');
    return `${d.getFullYear()}-${pad(d.getMonth()+1)}-${pad(d.getDate())} ${pad(d.getHours())}:${pad(d.getMinutes())}:${pad(d.getSeconds())}`;
  }

  buildPayload(): InvoiceModel {
    // map form value to payload with backend's key casing
    const fv = this.invoiceForm.value;

    const products: ProductModel[] = fv.Products.map((p: any) => ({
      ProductName: p.ProductName,
      Description: p.Description,
      Qty: Number(p.Qty),
      UnitPrice: Number(p.UnitPrice),
      gst: Number(p.gst || 0),
      sgst: Number(p.sgst || 0),
      igst: Number(p.igst || 0),
      vat: Number(p.vat || 0),
      Amount: p.Amount,
      tax: p.tax
    }));

    const customer: CustomerModel = {
      Id: fv.customer?.Id,
      Name: fv.customer?.Name,
      CustomerId: fv.customer?.CustomerId,
      ProfileImage: fv.customer?.ProfileImage,
      Email: fv.customer?.Email,
      CompanyName: fv.customer?.CompanyName
    };

    const payload: InvoiceModel = {
      Currency: fv.Currency,
      CustomerId: fv.CustomerId,
      CustomerName: fv.CustomerName,
      DueDate: this.formatDateForBackend(fv.DueDate),
      InvoiceDate: this.formatDateForBackend(fv.InvoiceDate),
      InvoiceNumber: fv.InvoiceNumber,
      Location: fv.Location,
      Products: products,
      Remarks: fv.Remarks,
      Terms: fv.Terms,
      TotalAmount: String(fv.TotalAmount),
      amountpaid: Number(fv.amountpaid || 0),
      subtotal: Number(fv.subtotal || 0),
      total: Number(fv.total || 0),
      totaldiscount: Number(fv.totaldiscount || 0),
      totaltax: Number(fv.totaltax || 0),
      isDraft: Boolean(fv.isDraft),
      customer
    };

    return payload;
  }

  onSubmit() {
    if (this.invoiceForm.invalid) {
      this.invoiceForm.markAllAsTouched();
      this.toastr.warning('Please fill required fields');
      return;
    }

    // ensure final totals are calculated
    this.recalculateTotals();

    const payload = this.buildPayload();
    console.log('Add Invoice payload:', payload);

    this.fmpService.addInvoice(payload).subscribe(
      (res: any) => {
        console.log('Add invoice success', res);
        this.toastr.success('Invoice created successfully');
        this.invoiceForm.reset();
        this.initForm(); // re-init if you want default rows

         // 🔑 re-enable disabled fields
      this.invoiceForm.get('customer.Email')?.enable();

            this.loadInvoices();   // 👈 refresh after add

        this.closeAddInvoice();
      },
      (err) => {
        console.error('Add invoice error', err);
        this.toastr.error('Failed to create invoice');
      }
    );
  }

  // Add Invoice Ends Here


  // For Fetching Customer Details in Add Invoice Form

loadCustomers(managerId: string) {
  const formData = new FormData();
  formData.append('managerId', managerId); // ✅ API expects managerId

  this.http.post('customer/getManagerCustomerList', formData)
    .subscribe({
      next: (res: any) => {
        console.log("✅ Raw customer response:", res);
        this.customersList = res.customers || []; 
        console.log("📌 customersList for dropdown:", this.customersList);
      },
      error: (err) => {
        console.error("❌ Error fetching customers:", err);
      }
    });
}



// When customer is selected
onCustomerChange(event: any) {
  const customerId = event.target.value;
  const selectedCustomer = this.customersList.find(c => c.CustomerId === customerId);

  if (selectedCustomer) {
    this.invoiceForm.patchValue({
      customer: {
        Id: selectedCustomer.Id,
        Name: selectedCustomer.Name,
        CustomerId: selectedCustomer.CustomerId,
        ProfileImage: selectedCustomer.ProfileImage,
        Email: selectedCustomer.Email,
        CompanyName: selectedCustomer.CompanyName
      }
    });

        this.invoiceForm.get('customer.Email')?.disable();

  }
}


// Update Invoice

editInvoice(invoice: any) {
  const record = JSON.parse(invoice.invoiceRecord);

  this.editingInvoiceId = invoice.Id;   // ✅ capture ID

   // open the modal immediately
  this.showAddInvoice = true;   

  this.invoiceForm.patchValue({
    // ✅ top-level fields
    CustomerId: record.CustomerId || record.customer?.CustomerId || '',
    CustomerName: record.CustomerName || record.customer?.Name || '',
    Location: record.Location || '',

    InvoiceNumber: record.InvoiceNumber,
    Terms: record.Terms,

    // if your API date is "YYYY-MM-DD HH:mm:ss", keep only the date part for <input type="date">
    InvoiceDate: (record.InvoiceDate || '').split(' ')[0],
    DueDate: (record.DueDate || '').split(' ')[0],

    subtotal: record.subtotal,
    total: record.total,
    totaltax: record.totaltax,
    amountpaid: record.amountpaid,
    TotalAmount: record.TotalAmount,

    // ✅ correct control name is 'Remarks' (capital R)
    Remarks: record.Remarks,

    // ✅ ONLY the fields that exist in the 'customer' form group
    customer: {
      Id: record.customer?.Id ?? null,
      Name: record.customer?.Name || '',
      CustomerId: record.customer?.CustomerId || '',
      ProfileImage: record.customer?.ProfileImage || '',
      Email: record.customer?.Email || '',
      CompanyName: record.customer?.CompanyName || ''
    }
  });

  // rebuild products
  this.products.clear();
  (record.Products || []).forEach((p: any) => {
    this.products.push(this.fb.group({
      ProductName: [p.ProductName],
      Description: [p.Description],
      Qty: [p.Qty],
      UnitPrice: [p.UnitPrice],
      Amount: [p.Amount]   // keep as-is; you convert on submit
    }));
  });
}


onUpdate() {
  if (this.invoiceForm.invalid) {
    this.toastr.warning("Please fill required fields");
    return;
  }
  


  const payload = this.buildPayload();  // reuse same builder as addInvoice
  payload.Id = this.editingInvoiceId;   // attach the invoice ID for update

   if (!payload.Currency || typeof payload.Currency !== 'string') {
    payload.Currency = "Dollar"; // or your default currency
  }


  this.fmpService.updateInvoice(payload).subscribe(
    (res) => {
      this.toastr.success("Invoice updated successfully");
      this.closeAddInvoice();
      this.loadInvoices();
    },
    (err) => {
      this.toastr.error("Failed to update invoice");
      console.error(err);
    }
  );
}


// For Both Add & Update Invoice (to refresh list after either operation)
loadInvoices() {
  this.getInvoiceList();   // ✅ delegate to the already-working method


}






// Routing
  goToInvoiceDashboard(){

    this.router.navigate(['/fmp/invoice-dashboard'])
  
  }

   goToAddInvoice(){
    this.showAddInvoice = true;
    console.log("Add Invoice is Called")
    
  }

  closeAddInvoice(){

    this.showAddInvoice = false;
     this.invoiceForm.reset();
  this.editingInvoiceId = null; 
  }



  goToShowInvoice(){
     this.showInvoiceForm = true;
  }

  closeShowInvoice(){
     this.showInvoiceForm = false;
  }








  // Extra Code
isMonthlyDropdownOpen = false;
  showOptionsMenu = false;
  isFilterDropdownOpen = false;

  isOn: boolean = false;

  toggle() {
    this.isOn = !this.isOn;
  }

  toggleMonthlyDropdown() {
    this.isMonthlyDropdownOpen = !this.isMonthlyDropdownOpen;
  }


  togglleOptionsMenu() {
    this.showOptionsMenu = !this.showOptionsMenu;
  }

  onEditt() {
    this.showOptionsMenu = false;
  }

  onDeletee() {
    this.showOptionsMenu = false;
  }

  onSettingss() {
    this.showOptionsMenu = false;
  }
  


  toggleFilterDropdown() {
    this.isFilterDropdownOpen = !this.isFilterDropdownOpen;
  }



  // public invoices = [
  //   {
  //     name: 'Arun Arora',
  //     number: 'Invc0001',
  //     invoiceDate: '21-04-2025',
  //     dueDate: '25-04-2025',
  //     terms: 'Net30',
  //     location: 'Location 1',
  //     item: 1,
  //     total: 200,
  //     status: 'Pending'
  //   },
  //   {
  //     name: 'Bryan Biz',
  //     number: 'Invc0002',
  //     invoiceDate: '21-04-2025',
  //     dueDate: '25-04-2025',
  //     terms: 'Net30',
  //     location: 'Location 1',
  //     item: 1,
  //     total: 400,
  //     status: 'Paid'
  //   },
  //   {
  //     name: 'Arun Arora',
  //     number: 'Invc0003',
  //     invoiceDate: '21-04-2025',
  //     dueDate: '25-04-2025',
  //     terms: 'Net30',
  //     location: 'Location 1',
  //     item: 1,
  //     total: 200,
  //     status: 'Pending'
  //   },
  // ];


  public openMenuIndex: number | null = null;

toggleOptionsMenu(index: number) {
  if (this.openMenuIndex === index) {
    this.openMenuIndex = null; // close if same row clicked
  } else {
    this.openMenuIndex = index;
  }
}

onEdit() {
  this.openMenuIndex = null;
}

onDelete() {
  this.openMenuIndex = null;
}

onSettings() {
  this.openMenuIndex = null;
}

public barChartType: 'bar' = 'bar';

public paymentTrendsStackedChartData: ChartData<'bar'> = {
  labels: [
    'Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun',
    'Jul', 'Aug', 'Sep', 'Oct', 'Nov', 'Dec'
  ],
  datasets: [
    {
      label: 'Collected',
      data: [40000, 50000, 35000, 32000, 30000, 31000, 35000, 25000, 30000, 34000, 32000, 40000],
      backgroundColor: ['#CCCCCC','#CCCCCC','#CCCCCC','#CCCCCC','#CCCCCC','#CCCCCC','#CCCCCC','#CCCCCC','#4C89FF','#3AC43D', '#FF7F50','#CCCCCC' 
      ],
      borderRadius: 20,
      barPercentage: 0.4,
      categoryPercentage: 0.4,
    },
  ]
};

public paymentTrendsStackedChartOptions: ChartOptions<'bar'> = {
  responsive: true,
  maintainAspectRatio: false,
  plugins: {
    legend: {
      display: false
    },
    tooltip: {
      enabled: true
    }
  },
  scales: {
    x: {
      grid: { display: false },
      ticks: { font: { size: 14 } }
    },
    y: {
      min: 0,
      max: 55000,
      grid: { display: false },
      ticks: { stepSize: 10000, font: { size: 14 } }
    }
  }
};


public paymentTrendsStackedChartOptionsColors: string[] = ['#3f83f8', '#22c55e', '#fb923c'];

  activeTab: string = 'actively';

  tabs = [
    { key: 'actively', label: 'Actively' },
    { key: 'log', label: 'Log a call' },
    { key: 'event', label: 'New event' }
  ];

  tasks = [
    { name: 'TASK' }
  ];

  createTask() {
    alert('Create a task clicked!');
  }

  activeTab2: string = 'aianalysis';

  tabs2 = [
    { key: 'aianalysis', label: 'AI Analysis' },
    { key: 'a/raging', label: 'A/R Aging' },
    { key: 'planvsactuals', label: 'Plan vs Actuals' }
  ];

  maintabs = [
    'Overview',
    'Details',
    'Invoices',
    'Reminders & Actions',
    'Notes & Files',
    'Disputes'
  ];

  mainactiveTab = 'Overview';

  selectTab(tab: string) {
    this.activeTab = tab;
  }
}
