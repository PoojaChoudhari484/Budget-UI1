import { ComponentFixture, TestBed } from '@angular/core/testing';

import { FmpComponent } from './fmp.component';

describe('FmpComponent', () => {
  let component: FmpComponent;
  let fixture: ComponentFixture<FmpComponent>;

  beforeEach(() => {
    TestBed.configureTestingModule({
      declarations: [FmpComponent]
    });
    fixture = TestBed.createComponent(FmpComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
