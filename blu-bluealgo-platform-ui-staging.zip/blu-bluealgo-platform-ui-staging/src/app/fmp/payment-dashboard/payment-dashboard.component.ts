import { Component } from '@angular/core';
import { Router } from '@angular/router';
import { AllFmpService } from '../all-fmp.service';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { ToastrService } from 'ngx-toastr';
import { LocalStorageService } from 'src/app/core/services/local-storage.service';
import { PaymentModel } from '../model/payment';


@Component({
    selector: 'app-payment-dashboard',
    templateUrl: './payment-dashboard.component.html',
    styleUrls: ['./payment-dashboard.component.scss'],
    standalone: false
})
export class PaymentDashboardComponent {

// 
  showAddPayment = false;
  showReconciliation=false;

  showOptionsMenu = false;
  isFilterDropdownOpen = false;
  issortDropdownOpen = false;
// 


// For ShowPayments (Display Payment)

  paymentsList: any[] = [];


  // Add Payment
  paymentForm!: FormGroup;
  customersList: any[] = [];
  invoicesForCustomer: any[] = [];
  managerId: string | null = null;



  constructor(private router : Router,
              private allFmpService: AllFmpService,
                private fb: FormBuilder,
                 private localStorage: LocalStorageService,
    private toastr: ToastrService
  ){}

  goToAddPayment(){
  this.showAddPayment = true;
  }

  ngOnInit(){
    if(this.router.url.includes('/add-payment')){
      this.showAddPayment=true;
    }

    if(this.router.url.includes('/reconciliation')){
      this.showReconciliation = true;
    }

//  Load Payments on init
        this.loadPayments();


        // add part

      this.managerId = this.localStorage?.getCustomerId ? this.localStorage.getCustomerId() : localStorage.getItem('customerId');
    this.initForm();
    if (this.managerId) {
      this.loadCustomers(this.managerId);
    } else {
      console.warn('Manager id not found in localStorage');
    }

    // default paymentDate to now
    const nowISODate = this.formatDateForBackend(new Date());
    this.paymentForm.patchValue({ paymentDate: nowISODate });
  }



  // Display Payment List (Show Payments)
 // Display Payment List (Show Payments)
loadPayments() {
  const customerId = localStorage.getItem('customerId') || 'cus100856'; // fallback if null

  // Get current date
  const currentDate = new Date();

  // 1 month ago
  const oneMonthAgo = new Date();
  oneMonthAgo.setMonth(oneMonthAgo.getMonth() - 1);

  // Format dates as YYYY-MM-DD
  const formatDate = (date: Date) => {
    const year = date.getFullYear();
    const month = String(date.getMonth() + 1).padStart(2, '0');
    const day = String(date.getDate()).padStart(2, '0');
    return `${year}-${month}-${day}`;
  };


    const payload = {
    customerId: customerId,
    startDate: formatDate(oneMonthAgo),
    endDate: formatDate(currentDate),
    status: 'All'
  };

    this.allFmpService.showPayments(payload).subscribe(
      (res: any) => {
        if (res.ResponseCode === 1) {
          this.paymentsList = res.payments || [];
          console.log('✅ Payments loaded:', this.paymentsList);
        }
      },
      (err) => {
        console.error('❌ Error fetching payments', err);
      }
    );
  }

  // Delete Payment

  onDeletePayment(paymentId: number) {
  if (confirm("Are you sure you want to delete this payment?")) {
    this.allFmpService.deletePayment(paymentId).subscribe({
      next: (res) => {
        if (res.ResponseCode === 1) {
          alert("Payment deleted successfully!");
          this.loadPayments(); // reload your list
        } else {
          alert("Failed to delete payment.");
        }
      },
      error: (err) => {
        console.error("Delete payment error:", err);
        alert("Something went wrong while deleting.");
      }
    });
  }
}


// Add Payment

private initForm() {
    this.paymentForm = this.fb.group({
      customerId: ['', ],   // selected customer
      invoiceNumber: ['',], // selected invoice
      currency: ['INR', ],
      amount: ['', ],
      bankName: [{ value: '',  }],
      bankBranch: [{ value: '', }],
      utrSwiftTransNumber: [''],
      chequeNumber: [''],
      paymentDate: ['',],
      paymentFrom: ['manual'],
      paymentType: ['online',],
      priority: [''],
      remarks: ['']
    });
  }

  // helper to format date to backend "YYYY-MM-DD HH:mm:ss"
  private formatDateForBackend(value: string | Date | null): string {
    if (!value) return '';
    const d = value instanceof Date ? value : new Date(value);
    const pad = (n: number) => n.toString().padStart(2, '0');
    return `${d.getFullYear()}-${pad(d.getMonth()+1)}-${pad(d.getDate())} ${pad(d.getHours())}:${pad(d.getMinutes())}:${pad(d.getSeconds())}`;
  }

  // Load customers for manager
  loadCustomers(managerId: string) {
    const fd = new FormData();
    fd.append('managerId', managerId);
    this.allFmpService.getManagerCustomerList(managerId) // if your service method expects formData, adapt accordingly
      .subscribe({
        next: (res: any) => {
          // backend returns {customers: [...] } or similar; check console and adapt
          this.customersList = res?.customers || res || [];
          console.log('Customers:', this.customersList);
        },
        error: (err) => {
          console.error('Error loading customers', err);
        }
      });
  }

  // when customer is selected in UI
onCustomerChange(event: Event) {
  const customerId = (event.target as HTMLSelectElement).value;
  const selected = this.customersList.find(c => c.CustomerId === customerId);

  if (!selected) {
    this.invoicesForCustomer = [];
    return;
  }

  // autofill bank details
  const finance = selected.customerFinanceSettings || {};
  const bankName = finance.BankName || selected.BankName || '';
  const bankBranch = finance.BankBranch || selected.BankBranch || '';

  this.paymentForm.patchValue({ bankName, bankBranch });
  this.paymentForm.get('bankName')?.disable();
  this.paymentForm.get('bankBranch')?.disable();

  // load invoices
  const managerId = this.managerId || (localStorage.getItem('customerId') || '');
  if (managerId) {
    this.allFmpService.getInvoiceList(managerId).subscribe({
      next: (res: any) => {
        const allInv = res?.invoiceDetailses || [];
        this.invoicesForCustomer = allInv.filter((inv: any) => inv.customerId === customerId);
      },
      error: (err) => console.error('Error fetching invoices', err)
    });
  }
}

  // when an invoice is selected, autofill amount & currency if available
onInvoiceChange(event: Event) {
  const invoiceNumber = (event.target as HTMLSelectElement).value;
  const inv = this.invoicesForCustomer.find((i: any) => i.invoiceNumber === invoiceNumber);
  if (!inv) return;

  const amount = inv.amount || this.parseInvoiceAmount(inv.invoiceRecord) || '';
  const currency = this.parseInvoiceCurrency(inv.invoiceRecord) || 'INR';

  this.paymentForm.patchValue({ amount, currency });
}

// handle datetime-local change safely in TS
onPaymentDateChange(event: Event) {
  const value = (event.target as HTMLInputElement)?.value || '';
  // store the raw value (which will be like "2025-09-10T15:00")
  this.paymentForm.get('paymentDate')?.setValue(value);
}


parseInvoiceAmount(record: string): string {
  try {
    return JSON.parse(record).TotalAmount || '';
  } catch {
    return '';
  }
}

parseInvoiceCurrency(record: string): string {
  try {
    return JSON.parse(record).Currency || 'INR';
  } catch {
    return 'INR';
  }
}

  // final submit
  onSubmit() {
    if (this.paymentForm.invalid) {
      this.paymentForm.markAllAsTouched();
      this.toastr.warning('Please fill required fields');
      return;
    }

    const fv = this.paymentForm.getRawValue(); // raw gets disabled fields too
    const payload: PaymentModel = {
      amount: String(fv.amount),
      bankBranch: fv.bankBranch || '',
      bankCharge: '',
      bankCode: fv.bankBranch || '', // set to what you use; API expects bankCode sometimes
      bankName: fv.bankName || '',
      chequeNumber: fv.chequeNumber || '',
      createdById: this.managerId || (localStorage.getItem('customerId') || ''),
      currency: fv.currency,
      customerId: fv.customerId,
      invoiceNumber: fv.invoiceNumber,
      name: (this.customersList.find(c=>c.CustomerId===fv.customerId)?.Name) || '',
      paymentDate: this.formatDateForBackend(fv.paymentDate),
      paymentFrom: fv.paymentFrom || 'manual',
      paymentType: fv.paymentType || 'online',
      priority: fv.priority || '',
      remarks: fv.remarks || '',
      status: fv.status || '',
      utrSwiftTransNumber: fv.utrSwiftTransNumber || ''
    };

    console.log('Add Payment payload:', payload); // check in console before send

    this.allFmpService.addPayment(payload).subscribe({
      next: (res: any) => {
        console.log('addPayment response', res);
        if (res.ResponseCode === 1) {
          this.toastr.success('Payment added successfully');
          this.paymentForm.reset();
          this.initForm(); // re-init to restore disabled/enabled logic
        } else {
          this.toastr.error('Failed: ' + (res.ResponseMessage || 'Unknown'));
        }
      },
      error: (err) => {
        console.error('addPayment error', err);
        this.toastr.error('Failed to add payment');
      }
    });
  }
// 






  // Routing
  
  goToReconciliation(){
    this.router.navigate(['/fmp/reconciliation'])
  }

  togglleOptionsMenu() {
    this.showOptionsMenu = !this.showOptionsMenu;
  }

  onEditt() {
    this.showOptionsMenu = false;
  }

  onDeletee() {
    this.showOptionsMenu = false;
  }

  onSettingss() {
    this.showOptionsMenu = false;
  }

  toggleFilterDropdown() {
    this.isFilterDropdownOpen = !this.isFilterDropdownOpen;
  }

  togglesortDropdown() {
    this.issortDropdownOpen = !this.issortDropdownOpen;
  }


  // public invoices = [
  //   {
  //     avatar: 'assets/images/Avatar.png',
  //     name: 'Arun Arora',
  //     receivable: '32.75',
  //     received: '500',
  //     outstanding: '0.00',
  //     bank: 'ICIC',
  //     inv_no: 'INV0001',
  //     date: '25-04-2025',
  //     currency: 'USD',
  //     proof_of_payment: 'assets/images/plan-view.png',
  //     verified_icon: 'assets/images/head.png'
  //   },
  //   {
  //     avatar: 'assets/images/Avatar.png',
  //     name: 'Bryan Brown',
  //     receivable: '44',
  //     received: '44',
  //     outstanding: '-44',
  //     bank: 'Bank of America',
  //     inv_no: 'INV0002',
  //     date: '25-04-2025',
  //     currency: 'INR',
  //     proof_of_payment: 'assets/images/plan-view.png',
  //   },
  //   {
  //     avatar: 'assets/images/Avatar.png',
  //     name: 'Arun Arora',
  //     receivable: '44',
  //     received: '44',
  //     outstanding: '0',
  //     bank: 'Bank of America',
  //     inv_no: 'INV0003',
  //     date: '25-04-2025',
  //     currency: 'INR',
  //     proof_of_payment: 'assets/images/plan-view.png',
  //     verified_icon: 'assets/images/head.png'
  //   }
  // ];

  
  public openMenuIndex: number | null = null;

  toggleOptionsMenu(index: number) {
    this.openMenuIndex = this.openMenuIndex === index ? null : index;
  }

onEdit() {
  this.openMenuIndex = null;
}

onDelete() {
  this.openMenuIndex = null;
}

onSettings() {
  this.openMenuIndex = null;
}


statistics = [
  {
    title: 'DSO',
    value: 0,
    growth: '10% from this last week',
    icon: 'assets/images/down_growth.png',
  },
  {
    title: 'CEI',
    value: 0,
    growth: '10% from this last week',
    icon: 'assets/images/down_growth.png',
  },
  {
    title: 'Avg. days delinquent',
    value: 0,
    growth: '10% from this last week',
    icon: 'assets/images/down_growth.png',
  },
  {
    title: 'High risk account',
    value: 0,
    growth: '10% from this last week',
    icon: 'assets/images/down_growth.png',
  },
  {
    title: 'ART',
    value: 0,
    growth: '10% from this last week',
    icon: 'assets/images/down_growth.png',
  },
];


summaryCards = [
  {
    title: 'Total',
    value: '$120.75',
    icon: 'total',
  },
  {
    title: 'Overdue',
    value: '$44',
    icon: 'overdue',
  },
  {
    title: 'Received',
    value: '$588',
    icon: 'received',
  },
  {
    title: 'Open invoice',
    value: '1',
    icon: 'open_invoice',
  },
  {
    title: 'Severely delayed',
    value: '0',
    icon: 'severely_delayed',
  },
];

}
