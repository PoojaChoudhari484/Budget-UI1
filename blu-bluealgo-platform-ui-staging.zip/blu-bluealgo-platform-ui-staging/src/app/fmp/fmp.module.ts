import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';

import { FmpRoutingModule } from './fmp-routing.module';
import { NgChartsModule } from 'ng2-charts';
import { CustomersComponent } from './customers/customers.component';
import { InvoicesComponent } from './invoices/invoices.component';
import { RemindersComponent } from './reminders/reminders.component';
import { PaymentDashboardComponent } from './payment-dashboard/payment-dashboard.component';
import { DashboardFmpComponent } from './dashboard-fmp/dashboard-fmp.component';
import { HomeComponent } from './home/home.component';
import { ContractComponent } from './contract/contract.component';
import { UploadComponent } from './upload/upload.component';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { DragDropModule } from '@angular/cdk/drag-drop';



@NgModule({
  declarations: [
    
    CustomersComponent,
    InvoicesComponent,
    RemindersComponent,
    PaymentDashboardComponent,
    DashboardFmpComponent,
    HomeComponent,
    ContractComponent,
    UploadComponent,
  
  ],
  imports: [
    CommonModule,
    FmpRoutingModule,
    NgChartsModule,
    FormsModule,
    ReactiveFormsModule,
    DragDropModule
  ]
})
export class FmpModule { }
