import { Component, ElementRef, OnInit, ViewChild } from '@angular/core';
import { Router } from '@angular/router';
import { ChartOptions, ChartData } from 'chart.js';
import { AllFmpService } from '../all-fmp.service';
import { HttpClient } from '@angular/common/http';
import { LocalStorageService } from 'src/app/core/services/local-storage.service';
import { FormArray, FormBuilder, FormGroup, Validators } from '@angular/forms';
import { ToastrService } from 'ngx-toastr';



@Component({
  selector: 'app-customers',
  templateUrl: './customers.component.html',
  styleUrls: ['./customers.component.scss'],
  standalone: false
})
export class CustomersComponent {


  showCustomerDashboard = false;
  showAddCustomerModal = false;
  customerObj : any ;


  addCustomerForm!: FormGroup;

  imageBase64 = '';
  imageName = '';

  managerId: any = '';   // ✅ class property


  customerList: any[] = [];

    editingCustomerId: number | null = null;

      selectedCustomerId: number | null = null;   // <--- Add this line

isEditMode: boolean = false;

  currentCustomerId: number | null = null;  // <-- Add this line


  




  // Template reference variables
  @ViewChild('name') nameRef!: ElementRef;
  @ViewChild('companyName') companyNameRef!: ElementRef;
  @ViewChild('customerType') customerTypeRef!: ElementRef;
  @ViewChild('team') teamRef!: ElementRef;
  @ViewChild('uploadImage') uploadImageRef!: ElementRef;


  

  constructor(
    private router: Router,
    private fmpService: AllFmpService,
    private http : HttpClient,
    private localStorageService : LocalStorageService,
    private fb: FormBuilder,
    private toastr: ToastrService,


  ) {
     this.buildForm();
  }

  ngOnInit() {
    if (this.router.url.includes('customer-dashboard')) {
      this.showCustomerDashboard = true;
    }

     this.fetchCustomers();

         this.loadCustomers();
  this.managerId = localStorage.getItem('managerId'); // or wherever you store it


  }


// Tab Switch
  activeTab3: string = 'accountDetails';  // default tab

  setActiveTab(tabId: string, event: Event) {
    event.preventDefault();  // prevent page reload
    this.activeTab3 = tabId;
  }

  // End

  // Tab DropDown
  accordionStates: { [key: string]: boolean } = {
  customerDetails: true ,
  customerContact: true , // by default open
  businessAddress : true,
  bankDetails : true 
};

toggleAccordion(section: string) {
  this.accordionStates[section] = !this.accordionStates[section];
}
// End


// Image Upload & Storing Image

uploadedImageFile: File | null = null;
uploadedImageUrl: string | null = null;
uploadedImageName: string | null = null;

onFileSelected(event: Event) {
  const input = event.target as HTMLInputElement;

  if (input.files && input.files[0]) {
    this.uploadedImageFile = input.files[0];
    this.uploadedImageName = this.uploadedImageFile.name;

    // Preview URL
    const reader = new FileReader();
    reader.onload = () => {
      this.uploadedImageUrl = reader.result as string;
    };
    reader.readAsDataURL(this.uploadedImageFile);
  }
}



  
// When user clicks on Add Customer button
openAddCustomerModal() {
  this.isEditMode = false;
  this.editingCustomerId = null;
    console.log('isEditMode in Add:', this.isEditMode);


    this.currentCustomerId = null;  // reset


  this.addCustomerForm.reset(); // fresh form
  this.showAddCustomerModal = true; // your modal open function
}

// When user clicks on Edit in the table
openEditCustomerModal(customer: any) {
  this.isEditMode = true;
  this.currentCustomerId = Number(customer.Id); // backend uses `Id`
  this.customerObj = customer ;  // store the entire customer object
  console.log(this.customerObj);
  
    console.log('isEditMode in Add:', this.isEditMode);



  this.addCustomerForm.patchValue({
    Name: customer.Name,
    CompanyName: customer.CompanyName,
    Email: customer.Email,
    TeamSpaceId: customer.TeamSpaceId,
    TeamSpaceName: customer.TeamSpaceName,
    customerAddresses: customer.customerAddresses || [],
    customerContacts: customer.customerContacts || [],
    customerFinnanceSettings: customer.customerFinnanceSettings || {}
  });

  this.showAddCustomerModal = true;
}




  
 loadCustomers() {
    // Call API to get customer list
    this.fmpService.getManagerCustomerList(this.managerId).subscribe((res: any) => {
      this.customerList = res; 
    });
  }

  // editCustomer(customer: any) {
  //   this.editingCustomerId = customer.Id; // enable edit mode
  // }

  onEditCustomer(customer: any) {
  this.selectedCustomerId = customer.id;   // keep track of which customer we are editing
  debugger;
  this.customerObj = customer ;  // store the entire customer object
  console.log("Customer Object:", this.customerObj);


  // Patch existing values into the form
  this.addCustomerForm.patchValue({
    Name: customer.name,
    CompanyName: customer.companyName,
    Email: customer.email,
    customerContacts: customer.customerContacts || [],
    customerAddresses: customer.customerAddresses || []
  });

  // Open the modal (same as add customer modal)
this.showAddCustomerModal = true;
}


// 
submitUpdateCustomer(): void {
  if (!this.addCustomerForm.valid) {
    this.toastr.error('Please fill all required fields before updating.');
    return;
  }

  // build payload (ensure Id is included)
  const payload = {
    ...this.customerObj,
    //...this.addCustomerForm.value,
    Name : this.addCustomerForm.controls['Name'].value,
    CompanyName : this.addCustomerForm.controls['CompanyName'].value,
    customerAddresses : this.addCustomerForm.controls['customerAddresses'].value,
    customerContacts : this.addCustomerForm.controls['customerContacts'].value, 

    
    // Id: this.currentCustomerId,  // backend expects "Id"
    // CustomerId: this.customerObj["CustomerId"], // keep existing CustomerId
  };

  this.fmpService.updateCustomer(payload).subscribe({
    next: (res) => {
      this.toastr.success('Customer updated successfully');

      // ✅ Update customerList locally (replace updated one)
      const index = this.customerList.findIndex(c => c.Id === this.currentCustomerId);
      if (index !== -1 && res.customer) {
        this.customerList[index] = res.customer;
      }

      this.addCustomerForm.reset();
      this.isEditMode = false;
      this.currentCustomerId = null;
      this.closeAddCustomerModal();
    },
    error: (err) => {
      console.error('Update customer failed:', err);
      const msg = err?.error?.ResponseMessage || 'Failed to update customer';
      this.toastr.error(msg);
    }
  });
}




// Update Customer
//   updateCustomer(customer: any) {

//       const managerId = localStorage.getItem('managerId');

//     const payload = {
//       Id: customer.Id,
//       Name: customer.Name,
//       Email: customer.Email,
//       ManagerId: this.managerId, // ✅ include ManagerId
//       CompanyName: customer.CompanyName || '',
//       CustomerId: customer.CustomerId,
//       TeamSpaceId: customer.TeamSpaceId || '',
//       TeamSpaceName: customer.TeamSpaceName || '',
//       AtDate: customer.AtDate,
//       ImageData: customer.ImageData || '',
//       customerAddresses: customer.customerAddresses || [],
//       customerContacts: customer.customerContacts || [],
//       customerFinnanceSettings: customer.customerFinnanceSettings || {}
//     };

//  if (!customer.ManagerId) {
//     customer.ManagerId = this.managerId || localStorage.getItem('managerId');
//   }


//     console.log('Sending payload:', payload);

    

//     this.fmpService.updateCustomer(payload).subscribe(
//       (res: any) => {
//         if (res.ResponseCode === 1) {
//           alert('Customer updated successfully ✅');
//           this.editingCustomerId = null; // exit edit mode
//           this.loadCustomers(); // refresh from backend
//         } else {
//           alert('Update failed: ' + res.ResponseMessage);
//         }
//       },
//       (err) => {
//         console.error('Error updating customer:', err);
//       }
//     );
//   }



  goToAddCustomer() {
    this.showAddCustomerModal = true;
  }

  closeAddCustomerModal() {
    this.showAddCustomerModal = false;
     this.addCustomerForm.reset();
    this.buildForm(); // rebuild defaults
    this.imageBase64 = '';
    this.imageName = '';
  }

  goToCustomerDashboard() {
    this.router.navigate(['/fmp/customer-dashboard']);
  }

  


  // YYYY-MM-DD HH:mm:ss to match your backend
  private formatDateTime(d: Date = new Date()): string {
    const pad = (n: number) => n.toString().padStart(2, '0');
    const yyyy = d.getFullYear();
    const mm   = pad(d.getMonth() + 1);
    const dd   = pad(d.getDate());
    const hh   = pad(d.getHours());
    const mi   = pad(d.getMinutes());
    const ss   = pad(d.getSeconds());
    return `${yyyy}-${mm}-${dd} ${hh}:${mi}:${ss}`;
  }

  private buildForm() {
    const now = this.formatDateTime();

    this.addCustomerForm = this.fb.group({
      Name: [''],
      CompanyName: [''],
      Email: [''],
      TeamSpaceId: [''],
      TeamSpaceName: [''],
      // image handled separately, but keep controls so they serialize cleanly
      ImageData: [''],
      ImageName: [''],

      // Arrays
      customerAddresses: this.fb.array([this.createAddressGroup(now)]),
      customerContacts: this.fb.array([
        this.createPersonalContactGroup(),    // Personal
        // this.createBusinessContactGroup()     // Business
      ]),

      // Finance
      customerFinnanceSettings: this.fb.group({
        BankAccount: [''],
        BankName: [''],

      }),

      // Top-level AtDate (required by payload)
      AtDate: [now]
    });
  }

  private createAddressGroup(atDate: string): FormGroup {
    return this.fb.group({
      Address1: [''],
      Address2: [''],
      City: [''],
      Country: [''],
      PinCode: [''],
      AtDate: [atDate]
    });
  }

  private createPersonalContactGroup(): FormGroup {
    return this.fb.group({
      ContactType: ['Personal'],
      PhoneNumber: [''],
      ContactAddress: ['']   // present in your sample payload
    });
  }

  private createBusinessContactGroup(): FormGroup {
    return this.fb.group({
      ContactType: ['Business'],
      PhoneNumber: [''],
      City: [''],
      Website: ['']
    });
  }

  get addresses(): FormArray {
    return this.addCustomerForm.get('customerAddresses') as FormArray;
  }

  get contacts(): FormArray {
    return this.addCustomerForm.get('customerContacts') as FormArray;
  }

  addAddressRow() {
    this.addresses.push(this.createAddressGroup(this.formatDateTime()));
  }

  removeAddressRow(i: number) {
    if (this.addresses.length > 1) this.addresses.removeAt(i);
  }

  onImageSelected(evt: Event) {
    const input = evt.target as HTMLInputElement;
    const file = input?.files?.[0];
    if (!file) return;

    const reader = new FileReader();
    reader.onload = () => {
      const base64 = (reader.result as string).split(',')[1] || '';
      this.imageBase64 = base64;
      this.imageName = file.name;
      this.addCustomerForm.patchValue({
        ImageData: base64,
        ImageName: file.name
      });
    };
    reader.readAsDataURL(file);
  }


// Add Customer

submitAddCustomer() {
  if (this.addCustomerForm.invalid) {
    this.addCustomerForm.markAllAsTouched();
    this.toastr.error('Please fill required fields');
    return;
  }

  const managerId = this.localStorageService.getCustomerId();
  if (!managerId) {
    this.toastr.error('ManagerId not found in session');
    return;
  }

  const v = this.addCustomerForm.value;
  console.log('Form Value:', v);
  const payload: any = {
    // Id: this.currentCustomerId || 0,   // <-- important for update
    // Payload for add customer
    Name: v.Name,
    CompanyName: v.CompanyName,
    Email: v.Email,
    ManagerId: managerId,
    TeamSpaceId: v.TeamSpaceId || '',
    TeamSpaceName: v.TeamSpaceName || '',
    // AtDate: v.AtDate,
    ImageData: v.ImageData || '',
    ImageName: v.ImageName || '',
    customerAddresses: v.customerAddresses,
    customerContacts: v.customerContacts,
    customerFinnanceSettings: v.customerFinnanceSettings
  };

  // 🔹 Add Customer
  if (!this.isEditMode) {
    this.fmpService.addCustomer(payload).subscribe({
      next: (res) => {
        this.toastr.success('Customer added successfully');
        if (res.customer) {
          this.customerList.unshift(res.customer);
        }
        this.closeAddCustomerModal();
      },
      error: (err) => {
        console.error('Add failed:', err);
        this.toastr.error(err?.error?.ResponseMessage || 'Failed to add customer');
      }
    });
  } 
  // 🔹 Update Customer
else {
  payload.Id = this.currentCustomerId;   // attach Id in body

  this.fmpService.updateCustomer(payload).subscribe({
    next: (res) => {
      if (res.ResponseCode === 0) {
        this.toastr.success('Customer updated successfully');
        const idx = this.customerList.findIndex(c => c.Id === payload.Id);
        if (idx > -1 && res.customer) {
          this.customerList[idx] = res.customer;
        }
        this.closeAddCustomerModal();
        this.isEditMode = false;
        this.currentCustomerId = null;
      } else {
        this.toastr.error(res.ResponseMessage || 'Failed to update customer');
      }
    },
    error: (err) => {
      console.error('Update failed:', err);
      this.toastr.error('Failed to update customer');
    }
  });
}


}



  // 
  get customerContacts(): FormArray {
  return this.addCustomerForm.get('customerContacts') as FormArray;
}




// 
// Update existing customer






// Display Customer Data

fetchCustomers(): void {
  const managerId = this.localStorageService.getCustomerId();

  this.fmpService.getManagerCustomerList(managerId).subscribe({
    next: (res: any) => {
      this.customerList = res.customers || [];
      console.log('Customer List:', this.customerList);
    },
    error: (err) => {
      console.error('Error fetching customer list:', err);
    }
  });
}

// Delete Customer

deleteCustomer(id: number) {
  this.fmpService.deleteCustomer(id).subscribe({
    next: (res) => {
      console.log('Customer deleted successfully:', res);
      this.customerList = this.customerList.filter(c => c.Id !== id); // update UI
      this.toastr.success('Customer deleted successfully');
    },
    error: (err) => {
      console.error('Delete failed:', err);
    }
  });
}


// 
  
    isOn: boolean = false;
  
    toggle() {
      this.isOn = !this.isOn;
    }
  
    public barChartType: 'bar' = 'bar';
  
  
    public paymentTrendsStackedChartData: ChartData<'bar'> = {
      labels: [
        'Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun',
        'Jul', 'Aug', 'Sep', 'Oct', 'Nov', 'Dec'
      ],
      datasets: [
        {
          label: 'Collected',
          data: [40000, 50000, 35000, 32000, 30000, 31000, 35000, 25000, 30000, 34000, 32000, 40000],
          backgroundColor: ['#CCCCCC','#CCCCCC','#CCCCCC','#CCCCCC','#CCCCCC','#CCCCCC','#CCCCCC','#CCCCCC','#4C89FF','#3AC43D', '#FF7F50','#CCCCCC' 
          ],
          borderRadius: 20,
          barPercentage: 0.4,
          categoryPercentage: 0.4,
        },
      ]
    };
  
    public paymentTrendsStackedChartOptions: ChartOptions<'bar'> = {
      responsive: true,
      maintainAspectRatio: false,
      plugins: {
        legend: {
          display: false
        },
        tooltip: {
          enabled: true
        }
      },
      scales: {
        x: {
          grid: { display: false },
          ticks: { font: { size: 14 } }
        },
        y: {
          min: 0,
          max: 55000,
          grid: { display: false },
          ticks: { stepSize: 10000, font: { size: 14 } }
        }
      }
    };
  
    public paymentTrendsStackedChartOptionsColors: string[] = ['#3f83f8', '#22c55e', '#fb923c'];
  
    activeTab: string = 'actively';
  
    tabs = [
      { key: 'actively', label: 'Actively' },
      { key: 'log', label: 'Log a call' },
      { key: 'event', label: 'New event' }
    ];
  
    tasks = [
      { name: 'TASK' }
    ];
  
    createTask() {
      alert('Create a task clicked!');
    }
  
    activeTab2: string = 'aianalysis';
  
    tabs2 = [
      { key: 'aianalysis', label: 'AI Analysis' },
      { key: 'a/raging', label: 'A/R Aging' },
      { key: 'planvsactuals', label: 'Plan vs Actuals' }
    ];
  
    maintabs = [
      'Overview',
      'Details',
      'Invoices',
      'Reminders & Actions',
      'Notes & Files',
      'Disputes'
    ];
  
    mainactiveTab = 'Overview';
  
    selectTab(tab: string) {
      this.activeTab = tab;
    }


}
