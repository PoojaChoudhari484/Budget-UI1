import { Component } from '@angular/core';

@Component({
    selector: 'app-fmp',
    templateUrl: './fmp.component.html',
    styleUrls: ['./fmp.component.scss'],
    standalone: false
})
export class FmpComponent {

}
