import { HttpClient, HttpHeaders, HttpParams } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { FormGroup } from '@angular/forms';
import { Observable, throwError } from 'rxjs';
import { ReminderPayload } from './model/reminder';
import { PaymentModel } from './model/payment';

@Injectable({
  providedIn: 'root'
})
export class AllFmpService {


  constructor(private http: HttpClient) { }

  getCustomerGroups(customerId: string): Observable<any> {
    const url = `/customer/showGroup?customerId=${customerId}`;
    return this.http.get(url);
  }


  // FOR REMINDERS


// Display Reminder Data
  getFMPReminderList(customerId: string): Observable<any> {
    const url = '/FMPReminder/getFMPReminderList';
    return this.http.post(url, { "customerId": customerId });
  }

// Add Reminder Data

//   addFMPReminder(data: any) {
//   const url = 'FMPReminder/AddFMPReminderData';
//   return this.http.post(url, data);
// }

  addReminder(reminder: ReminderPayload): Observable<any> {
    return this.http.post(`/FMPReminder/AddFMPReminderData`, reminder);
  }



// Delete Reminder Data Using Id

deleteReminder(id: number) {
  const url = 'FMPReminder/deleteFMPReminder';
  return this.http.post(url, { Id: id });  // POST with body {Id:182}
}


// Update Reminder

updateFMPReminder(payload: ReminderPayload) {
  return this.http.post(
    "/FMPReminder/UpdateFMPReminder",
    payload,
    { headers: { 'Content-Type': 'application/json' } }
  );
}

// FOR CUSTOMERS

// Add Customer

  /** POST /customer/addCustomer with JSON body */
  addCustomer(payload: any): Observable<any> {
    return this.http.post('customer/addCustomer', payload); // baseURL handled by interceptor/environment
  }


// Display Customer Data

getManagerCustomerList(managerId: string) {
  const formData = new FormData();
  formData.append('managerId', managerId); // match exactly as Postman

  return this.http.post<any>('customer/getManagerCustomerList', formData);

}

// Delete Customer

deleteCustomer(id: number) {
  const url = `customer/deleteCustomer/${id}`;
  return this.http.post(url, {}); // POST with empty body
}

// Edit Customer

// updateCustomer(data: any) {
//   const url = 'customer/updateCustomer';
//   return this.http.post<any>(url, data);
// }
updateCustomer(payload: any): Observable<any> {
  return this.http.post('customer/updateCustomer', payload);
}



// FOR INVOICES

// Display Invoice Data

getInvoiceList(managerId: string): Observable<any> {
  const url = 'invoice/getCustomerInvoiceList';

  // Backend expects form-data
  const formData = new FormData();
  formData.append('managerId', managerId);

  return this.http.post(url, formData);
}

// Delete Invoice
// fmp.service.ts
deleteInvoice(id: number, invoiceNumber: string, customerId: string) {
  if (!id || !invoiceNumber || !customerId) {
    console.error("❌ Missing delete params:", { id, invoiceNumber, customerId });
    return throwError(() => new Error("Invalid invoice data"));
  }

  const body = new URLSearchParams();
  body.set('id', id.toString());  // ✅ Add ID
  body.set('invoiceNumber', invoiceNumber);
  body.set('customerId', customerId);

  const headers = { 'Content-Type': 'application/x-www-form-urlencoded' };

  return this.http.post(
    'invoice/deleteInvoice',   // ✅ relative path (baseUrl from environment)
    body.toString(),
    { headers }
  );
}


// Add Invoice


addInvoice(invoicePayload: any): Observable<any> {
  // API expects raw JSON body (as you showed). Use relative path if baseUrl is auto-handled.
  return this.http.post('invoice/addInvoice', invoicePayload);
}


// Update Invoice

updateInvoice(invoicePayload: any): Observable<any> {
  return this.http.post('invoice/updateInvoice', invoicePayload); // relative path    
}


// End Invoice


// FOR PAYMENTS

// Display Payment Data 

showPayments(payload: any) {
  const headers = new HttpHeaders({
    'Content-Type': 'application/x-www-form-urlencoded'
  });

  // Convert JSON → form-urlencoded
  const body = new HttpParams()
    .set('customerId', payload.customerId)
    .set('startDate', payload.startDate)
    .set('endDate', payload.endDate)
    .set('status', payload.status);

  return this.http.post(`/payment/showPayments`, body, { headers });
}


// Delete Payment

deletePayment(id: number): Observable<any> {
  const url = `/payment/deletePayment`;
  return this.http.post<any>(url, { id });
}


// Add Payment

addPayment(payload: PaymentModel): Observable<any> {
  const url = 'payment/addPayment';
  const headers = new HttpHeaders({ 'Content-Type': 'application/json' });
  return this.http.post<any>(url, payload, { headers });
}

// 
// getInvoicesByCustomer(managerId: string, customerId: string): Observable<any> {
//   return this.getInvoiceList(managerId).pipe(
//     map((res: any) => {
//       const invoices = res?.invoiceDetailses || [];
//       return invoices.filter((i: any) => i.customerId === customerId);
//     })
//   );
// }

}
