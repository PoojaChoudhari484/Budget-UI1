import { TestBed } from '@angular/core/testing';

import { AllFmpService } from './all-fmp.service';

describe('AllFmpService', () => {
  let service: AllFmpService;

  beforeEach(() => {
    TestBed.configureTestingModule({});
    service = TestBed.inject(AllFmpService);
  });

  it('should be created', () => {
    expect(service).toBeTruthy();
  });
});
