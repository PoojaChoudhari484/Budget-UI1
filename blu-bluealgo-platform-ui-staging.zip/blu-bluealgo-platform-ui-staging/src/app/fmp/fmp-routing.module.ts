import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { FmpComponent } from './fmp.component';
import { DashboardComponent } from '../dashboard/dashboard.component';
import { CustomersComponent } from './customers/customers.component';
import { InvoicesComponent } from './invoices/invoices.component';
import { RemindersComponent } from './reminders/reminders.component';
import { PaymentDashboardComponent } from './payment-dashboard/payment-dashboard.component';
import { DashboardFmpComponent } from './dashboard-fmp/dashboard-fmp.component';
import { HomeComponent } from './home/home.component';
import { ContractComponent } from './contract/contract.component';
import { UploadComponent } from './upload/upload.component';

const routes: Routes = [


 {
    path: '',
    component: FmpComponent,
    
    children: [
      // { path: '', redirectTo: 'maplet-tool', pathMatch: 'full' },
      //  {
      //   path: '',
      //   redirectTo : 'maplet-edit',
      //   pathMatch: 'full'
      // },
      {path:'home',component: HomeComponent},
      {path:'gotocustomer',component: HomeComponent},
      {path: 'dashboard-fmp', component: DashboardFmpComponent}, 
      {path:'contract', component: ContractComponent },
      {path: 'customers', component: CustomersComponent},
      {path:'customer-dashboard',component:CustomersComponent},
      {path: 'invoices', component: InvoicesComponent},
       {path: 'invoice-dashboard', component: InvoicesComponent},
      {path: 'reminders', component: RemindersComponent}, 
      {path: 'payment-dashboard', component: PaymentDashboardComponent},
      {path: 'add-payment', component: PaymentDashboardComponent},
      {path:'reconciliation',component:PaymentDashboardComponent},
      {path:'uploadorg', component: UploadComponent}
     
    ],
  },



];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule]
})
export class FmpRoutingModule { }
