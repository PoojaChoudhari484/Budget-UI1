import { Component } from '@angular/core';
import { Router } from '@angular/router';

@Component({
  selector: 'app-home',
  templateUrl: './home.component.html',
  styleUrls: ['./home.component.scss'],
  standalone: false,
})
export class HomeComponent {

  showCustomerContent = false;

  constructor(private router : Router){}


  ngOnInit() {
  if (this.router.url.includes('gotocustomer')) {
    this.showCustomerContent = true;
  }
}

gotocustomer(){
  this.router.navigate(['/fmp/customers']);
}

  //  isHomePage(): boolean {
  //   return this.router.url === '/fmp/home';
  // }

  // isGoToCustomerPage() : boolean {

  //   return this.router.url == '/fmp/gotocustomer';
  // }

  goToCustomer(){
    this.router.navigate(['/fmp/gotocustomer']);
    this.showCustomerContent = true;

  }

}
