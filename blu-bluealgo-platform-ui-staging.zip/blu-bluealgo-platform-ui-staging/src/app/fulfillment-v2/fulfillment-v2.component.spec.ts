import { ComponentFixture, TestBed } from '@angular/core/testing';

import { FulfillmentV2Component } from './fulfillment-v2.component';

describe('FulfillmentV2Component', () => {
  let component: FulfillmentV2Component;
  let fixture: ComponentFixture<FulfillmentV2Component>;

  beforeEach(() => {
    TestBed.configureTestingModule({
      declarations: [FulfillmentV2Component],
    });
    fixture = TestBed.createComponent(FulfillmentV2Component);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
