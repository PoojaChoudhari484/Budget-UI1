import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { RouterModule, Routes } from '@angular/router';
import { FulfillmentV2Component } from './fulfillment-v2.component';
import { ProductComponent } from './product/product.component';
import { ProductModelComponent } from './product-model/product-model.component';
import { ReactiveFormsModule } from '@angular/forms';
import { ServiceComponent } from './service/service.component';
import { PermissionComponent } from './permission/permission.component';
import { DeleteModelComponent } from './delete-model/delete-model.component';
// import { provideEnvironmentNgxMask } from 'ngx-mask'
import { AccountsComponent } from './account/accounts/accounts.component';
import { NewAccountsModelComponent } from './account/new-accounts-model/new-accounts-model.component';
import { NgSelectModule } from '@ng-select/ng-select';
import { DeleteAccountsModelComponent } from './account/delete-accounts-model/delete-accounts-model.component';
import { UpdateAccountsModelComponent } from './account/update-accounts-model/update-accounts-model.component';
import { AccountProductsComponent } from './account/account-products/account-products.component';
import { NewProductModelComponent } from './account/new-product-model/new-product-model.component';
import { UpdateProductModelComponent } from './account/update-product-model/update-product-model.component';
import { DeleteProductModelComponent } from './account/delete-product-model/delete-product-model.component';
import { AccountServicesComponent } from './account/account-services/account-services.component';
import { NewServiceModelComponent } from './account/new-service-model/new-service-model.component';
import { UpdateServicesModelComponent } from './account/update-services-model/update-services-model.component';
import { DeleteServiceModelComponent } from './account/delete-service-model/delete-service-model.component';
import { AccountPermissionsComponent } from './account/account-permissions/account-permissions.component';
import { DeletePermissionsModelComponent } from './account/delete-permissions-model/delete-permissions-model.component';
import { AddSubModulePermissionsModelComponent } from './account/add-sub-module-permissions-model/add-sub-module-permissions-model.component';
import { UpdateSubModulePermissionsModelComponent } from './account/update-sub-module-permissions-model/update-sub-module-permissions-model.component';
import { PermissionUpdateModelComponent } from './permission/permission-update-model/permission-update-model.component';
import { ServiceModeMComponent } from './service/service-model/serviceM-model.component';
import { PermissionModelComponent } from './permission/permission-model/permission-model.component';
import { MatMenuModule } from '@angular/material/menu';
import { SharedModule } from '../shared/shared.module';
import { LastTwoWordsFromArrayWithStringPipe } from '../shared/pipes/last-two-words-from-array-with-string.pipe';
import { ObjectArrayToStringArrayPipe } from '../shared/pipes/object-array-to-string-array.pipe';

const routes: Routes = [
  {
    path: '',
    children: [
      { path: '', redirectTo: 'product', pathMatch: 'full' },
      { path: '', redirectTo: 'accounts', pathMatch: 'full' },
      { path: '', redirectTo: 'accountsProducts', pathMatch: 'full' },
      { path: '', redirectTo: 'accountsServices', pathMatch: 'full' },
      { path: '', redirectTo: 'accountsPermission', pathMatch: 'full' },
      { path: 'product', component: ProductComponent },
      { path: 'services', component: ServiceComponent },
      { path: 'permission', component: PermissionComponent },
      { path: 'accounts', component: AccountsComponent },
      { path: 'accountsProducts', component: AccountProductsComponent },
      { path: 'productServices', component: AccountServicesComponent },
      { path: 'accountsPermission', component: AccountPermissionsComponent },
    ],
  },
];

@NgModule({
  declarations: [
    FulfillmentV2Component,
    ProductComponent,
    ProductModelComponent,
    ServiceComponent,
    PermissionComponent,
    DeleteModelComponent,
    AccountsComponent,
    NewAccountsModelComponent,
    DeleteAccountsModelComponent,
    UpdateAccountsModelComponent,
    AccountProductsComponent,
    NewProductModelComponent,
    UpdateProductModelComponent,
    DeleteProductModelComponent,
    AccountServicesComponent,
    NewServiceModelComponent,
    UpdateServicesModelComponent,
    DeleteServiceModelComponent,
    AccountPermissionsComponent,
    DeletePermissionsModelComponent,
    AddSubModulePermissionsModelComponent,
    UpdateSubModulePermissionsModelComponent,
    PermissionUpdateModelComponent,
    ServiceModeMComponent,
    PermissionModelComponent,
    LastTwoWordsFromArrayWithStringPipe,
    ObjectArrayToStringArrayPipe
  ],
  imports: [
    CommonModule,
    RouterModule.forChild(routes),
    ReactiveFormsModule,
    NgSelectModule,
    MatMenuModule,
  ],
  exports: [RouterModule],
  // providers:[
  //   provideEnvironmentNgxMask()
  // ]
})
export class FulfillmentV2Module { }
