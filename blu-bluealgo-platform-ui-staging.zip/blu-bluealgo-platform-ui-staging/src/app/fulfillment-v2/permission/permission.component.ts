import {
  Component,
  ElementRef,
  HostListener,
  Input,
  ViewChild,
} from '@angular/core';
import { MatDialog } from '@angular/material/dialog';
import { FulfillmentV2Service } from '../services/fulfillment-v2.service';
import { DeleteModelComponent } from '../delete-model/delete-model.component';
import { PermissionModelComponent } from './permission-model/permission-model.component';
import { CommonFCService } from '../services/common-fc.service';

@Component({
    selector: 'app-permission',
    templateUrl: './permission.component.html',
    styleUrls: ['./permission.component.scss'],
    standalone: false
})
export class PermissionComponent {
  selectedUserId: any | null = null;
  allPermissions: any[];
  isProductModel: boolean = false;
  currentPage: number = 1;
  totalPages: number = 1;
  pagesToShow: any[] = [];
  pageSize: number = 10;
  selectedProduct: any = null;
  public initialData: any = [];
  @Input() data: Array<any> = [];
  @Input() pagination: boolean = true;
  @ViewChild('dropdownRef') dropdownRef!: ElementRef;
  dropdownDirection: { [key: number]: 'up' | 'down' } = {};
  dropdownPosition = { top: 0, left: 0 };

  constructor(
    private dialog: MatDialog,
    private fulFillmentApiServices: FulfillmentV2Service,
    private commonFCService: CommonFCService,
  ) {}

  // CLICK ELSEWHERE THEN CLOSE MODEL ---------------------
  @HostListener('document:click', ['$event'])
  onDocumentClick(event: MouseEvent): void {
    const target = event.target as HTMLElement;

    // If click is outside the dropdown and toggle button
    const clickedInsideDropdown =
      target.closest('.dropdown-close') || target.closest('.dropdown-menu');

    if (!clickedInsideDropdown) {
      this.selectedUserId = null;
    }
  }

  // GET ALL PRODUCTS DATA ----------------------
  getPermissionData(): void {
    this.commonFCService.getPermissionData();

    // Subscribe to shared observable
    this.commonFCService.allPermissions$.subscribe((data) => {
      this.allPermissions = data;
      this.initialData = data;
      this.totalPages = Math.ceil(this.initialData.length / this.pageSize);
      this.calculatePagesToShow();
      this.updateTableData();
    });
  }

  ngOnInit(): void {
    this.getPermissionData();
  }

  // CALCULATE PAGES TO SHOW ----------------------

  calculatePagesToShow() {
    const maxPages = 3; // Maximum pages to display at a time
    const pages = [];
    let startPage: number, endPage: number;

    if (this.totalPages <= maxPages) {
      // Total pages less than max so show all pages
      startPage = 1;
      endPage = this.totalPages;
    } else {
      // More pages than max so calculate start and end pages
      const maxPagesBeforeCurrentPage = Math.floor(maxPages / 2);
      const maxPagesAfterCurrentPage = Math.ceil(maxPages / 2) - 1;
      if (this.currentPage <= maxPagesBeforeCurrentPage) {
        // Close to the beginning; only show first pages
        startPage = 1;
        endPage = maxPages;
      } else if (
        this.currentPage + maxPagesAfterCurrentPage >=
        this.totalPages
      ) {
        // Close to the end; only show last pages
        startPage = this.totalPages - maxPages + 1;
        endPage = this.totalPages;
      } else {
        // Somewhere in the middle; show some pages before and after current page
        startPage = this.currentPage - maxPagesBeforeCurrentPage;
        endPage = this.currentPage + maxPagesAfterCurrentPage;
      }
    }

    // Create an array of pages to ng-repeat in the pager control
    for (let i = startPage; i <= endPage; i++) {
      pages.push(i);
    }

    this.pagesToShow = pages;
  }

  // UPDATE TABLE DATA -----------------------

  updateTableData() {
    const startIndex = (this.currentPage - 1) * this.pageSize;
    this.allPermissions = this.initialData.slice(
      startIndex,
      startIndex + this.pageSize,
    );
  }

  // SET CURRENT PAGE ---------------------

  setCurrentPage(page: number) {
    this.currentPage = page;
    this.calculatePagesToShow();
    this.updateTableData();
  }

  toggleDropdown(id: number, index: number): void {
    const targetEl = document.getElementById('item' + index);
    this.selectedProduct = this.allPermissions[index];
    if (targetEl) {
      const rect = targetEl.getBoundingClientRect();
      const viewportHeight = window.innerHeight;
      const dropdownHeight = 50;

      const shouldOpenUpward = rect.bottom + dropdownHeight > viewportHeight;

      this.dropdownDirection[index] = shouldOpenUpward ? 'up' : 'down';

      this.dropdownPosition = {
        top: shouldOpenUpward
          ? rect.top + window.scrollY - dropdownHeight
          : rect.top + window.scrollY + 30,
        left: rect.left + rect.width - 240,
      };
    }

    this.selectedUserId = this.selectedUserId === id ? null : id;
  }

  // ADD AND UPDATE MODEL -----------------------
  openPermissionDialog(product?: any, action?: any) {
    this.selectedUserId = null;

    this.dialog
      .open(PermissionModelComponent, {
        panelClass: 'custom-dialog-container',
        width: '498px',
        height: 'auto',
        disableClose: true,
        data: { data: product, action: action },
      })
      .afterClosed()
      .subscribe((result) => {
        if (
          result &&
          result.ResponseCode >= 0 &&
          result.ResponseMessage === 'Successfully'
        ) {
          this.getPermissionData();
        }
      });
  }

  // DELETE MODEL ----------------------------

  openDeleteModel(productId: any, permission: string) {
    const dialogRef = this.dialog.open(DeleteModelComponent, {
      width: '500px',
      // panelClass: 'custom-dialog-container',
      disableClose: true,
      data: {
        Id: productId,
        modelName: permission,
        url: 'delete_srv_permission_master',
      },
    });

    dialogRef.afterClosed().subscribe((result) => {
      if (result === 'deleted') {
        this.currentPage = 1;
        this.getPermissionData();
      }
    });
  }
  //  DISPLY LEVEL---------------------
  getLevelDisplay(levels: any[]): string {
    if (!levels || levels.length === 0) return '';
    const levelNames = levels.map((l) => l.level);
    return levels.length <= 2
      ? levelNames.join(', ')
      : `${levelNames.slice(0, 2).join(', ')}, ...`;
  }
}
