import { Component, Inject } from '@angular/core';
import { FormArray, FormBuilder, FormGroup, Validators } from '@angular/forms';
import { PermissionModelComponent } from '../permission-model/permission-model.component';
import {
  MAT_DIALOG_DATA,
  MatDialog,
  MatDialogRef,
} from '@angular/material/dialog';
import { FulfillmentV2Service } from '../../services/fulfillment-v2.service';
import { ToastrService } from 'ngx-toastr';

@Component({
    selector: 'app-permission-update-model',
    templateUrl: './permission-update-model.component.html',
    styleUrls: ['./permission-update-model.component.scss'],
    standalone: false
})
export class PermissionUpdateModelComponent {
  permissionForm!: FormGroup;

  constructor(
    private fb: FormBuilder,
    public dialogRef: MatDialogRef<PermissionModelComponent>,
    @Inject(MAT_DIALOG_DATA) public data: any,
    private fulfillmentService: FulfillmentV2Service,
    private toastr: ToastrService,
    private dialog: MatDialog,
  ) {}

  ngOnInit(): void {
    this.permissionForm = this.fb.group({
      subModule: [this.data?.subModule || '', Validators.required],
      permissions: this.fb.array([]),
    });

    // Only push checked (true) permissions
    if (this.data?.levels?.length > 0) {
      this.data.levels.forEach((perm: any) => {
        if (perm.checked) {
          this.permissions.push(
            this.fb.group({
              id: perm.Id,
              value: [perm.value],
              checked: [true],
            }),
          );
        }
      });
    }
  }

  populateUpdatePermissions() {
    const levels = this.data.levels || [];

    levels.forEach((perm: any) => {
      // const isChecked = levels.includes(perm);
      this.permissions.push(
        this.fb.group({
          id: perm.Id,
          value: [perm.value || perm, Validators.required],
          checked: [perm.checked || false],
        }),
      );
    });
  }

  get permissions(): FormArray {
    return this.permissionForm.get('permissions') as FormArray;
  }

  createPermissionField(
    value: string = '',
    checked: boolean = false,
  ): FormGroup {
    return this.fb.group({
      value: [value, Validators.required],
      checked: [checked],
    });
  }

  // SAVE PERMISSION -----------------------

  savePermission(): void {
    if (this.permissionForm.valid) {
      const formData = this.permissionForm.value;

      const allPermissions = this.data.allPermission.value;
      const editedPermissions = formData.permissions;

      const finalPermissions = allPermissions.map((perm: any) => {
        const edited = editedPermissions.find((p: any) => p.id === perm.id);
        return {
          id: perm.id,
          module: 'Doctiger',
          subModule: formData.subModule,
          component: 'Doctiger',
          enterprise: 'TRUE',
          freeTrail: 'TRUE',
          skuStandard: 'TRUE',
          standardSetup: '',
          lavel: edited ? edited.value : perm.value,
        };
      });

      // Save (no update logic as per request)
      this.fulfillmentService
        .updatePermission(finalPermissions)
        .subscribe((res) => {
          if (
            res?.ResponseCode >= 0 &&
            res?.ResponseMessage === 'Successfully'
          ) {
            this.toastr.success('Permission Updated Successfully', 'Success');
            this.dialogRef.close(res);
          } else {
            this.toastr.error('Error while updating Permission', 'Error');
          }
        });
    } else {
      this.permissionForm.markAllAsTouched();
    }
  }

  closeProductModel(): void {
    this.dialogRef.close();
  }
}
