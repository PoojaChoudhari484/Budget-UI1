import { ComponentFixture, TestBed } from '@angular/core/testing';

import { PermissionUpdateModelComponent } from './permission-update-model.component';

describe('PermissionUpdateModelComponent', () => {
  let component: PermissionUpdateModelComponent;
  let fixture: ComponentFixture<PermissionUpdateModelComponent>;

  beforeEach(() => {
    TestBed.configureTestingModule({
      declarations: [PermissionUpdateModelComponent],
    });
    fixture = TestBed.createComponent(PermissionUpdateModelComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
