import { Component, Inject } from '@angular/core';
import { FormArray, FormBuilder, FormGroup, Validators } from '@angular/forms';
import {
  MAT_DIALOG_DATA,
  MatDialog,
  MatDialogRef,
} from '@angular/material/dialog';
import { FulfillmentV2Service } from '../../services/fulfillment-v2.service';
import { ToastrService } from 'ngx-toastr';
import { DeleteModelComponent } from '../../delete-model/delete-model.component';
import { PermissionUpdateModelComponent } from '../permission-update-model/permission-update-model.component';
import { CommonFCService } from '../../services/common-fc.service';

@Component({
    selector: 'app-permission-model',
    templateUrl: './permission-model.component.html',
    styleUrls: ['./permission-model.component.scss'],
    standalone: false
})
export class PermissionModelComponent {
  permissionForm!: FormGroup;

  constructor(
    private fb: FormBuilder,
    public dialogRef: MatDialogRef<PermissionModelComponent>,
    @Inject(MAT_DIALOG_DATA) public data: any,
    private fulfillmentService: FulfillmentV2Service,
    private toastr: ToastrService,
    private dialog: MatDialog,
    private commonFCService: CommonFCService,
  ) {}

  ngOnInit(): void {
    this.permissionForm = this.fb.group({
      subModule: [
        {
          value: this.data?.data?.subModule || '',
          disabled: !this.data?.action || this.data?.action == 'add',
        },
        Validators.required,
      ],
      permissions: this.fb.array([]),
    });

    if (this.data?.data && !this.data?.action) {
      this.permissionForm.get('subModule')?.disable();
      this.populateUpdatePermissions();
    } else if (this.data?.previousPermissions?.length) {
      // this.data.previousPermissions.forEach((perm: any) => {
      //   this.permissions.push(
      //     this.fb.group({
      //       value: [perm.value, Validators.required],
      //       checked: [perm.checked || false],
      //     }),
      //   );
      // });
      this.addPermission();
    } else {
      this.addPermission(); // fallback if no previous
    }
  }

  populateUpdatePermissions() {
    const levels = this.data.data.levels || [];
    levels.forEach((perm: any) => {
      this.permissions.push(
        this.fb.group({
          id: perm.Id,
          value: [perm.level, Validators.required],
          checked: [perm.checked || false],
        }),
      );
    });
  }

  get permissions(): FormArray {
    return this.permissionForm.get('permissions') as FormArray;
  }

  createPermissionField(
    value: string = '',
    checked: boolean = false,
  ): FormGroup {
    return this.fb.group({
      value: [value, Validators.required],
      checked: [checked],
    });
  }

  addPermission(): void {
    this.permissions.push(this.createPermissionField());
  }

  removePermission(index: number): void {
    if (this.permissions.length > 1) {
      this.permissions.removeAt(index);
    }
  }

  // SAVE PRODUCT -----------------------

  saveProduct(): void {
    if (this.permissionForm.valid) {
      const formData = this.permissionForm.getRawValue();

      const currentPermissions = formData.permissions || [];

      // Only include permissions where value has changed from original
      const selectedPermissions = currentPermissions.map(
        (perm: any, index: number) => {
          return {
            module: 'Doctigerytty',
            subModule: formData.subModule,
            component: 'Doctiger',
            lavel: perm.value,
          };
        },
      );
      const payload: any = {
        serviceCode: 'srv006',
        servicePermissions: selectedPermissions,
      };

      this.fulfillmentService.createPermission(payload).subscribe((res) => {
        if (res?.ResponseCode >= 0 && res?.ResponseMessage === 'Successfully') {
          this.toastr.success('New Permission Added Successfully', 'Success');
          this.dialogRef.close(res);
        } else {
          this.toastr.error('Error while saving Permission', 'Error');
        }
      });
    } else {
      this.permissionForm.markAllAsTouched();
    }
  }

  closeProductModel(): void {
    this.dialogRef.close();
  }
  // ADD AND UPDATE MODEL -----------------------
  openPermissionDialog(product?: any, action?: string): void {
    const currentPermissions = this.permissionForm.value.permissions;

    this.dialogRef.close();
    this.dialog
      .open(PermissionModelComponent, {
        panelClass: 'custom-dialog-container',
        width: '498px',
        height: 'auto',
        disableClose: true,
        data: {
          data: product,
          action,
          previousPermissions: currentPermissions,
        },
      })
      .afterClosed()
      .subscribe((result) => {
        if (
          result &&
          result.ResponseCode >= 0 &&
          result.ResponseMessage === 'Successfully'
        ) {
          this.commonFCService.getPermissionData();
        }
      });
  }

  // ADD AND UPDATE MODEL -----------------------
  openUpdatePermissionDialog(product?: any, action?: string): void {
    const selectedPermissions = this.permissionForm.value.permissions
      .filter((perm: any) => perm.checked)
      .map((perm: any) => ({
        Id: perm?.id,
        value: perm.value,
        checked: true,
      }));
    if (selectedPermissions.length === 0) {
      this.toastr.warning('Please select at least one permission');
      return;
    }
    const payload = {
      ...product,
      levels: selectedPermissions,
      allPermission: this.permissions,
    };

    this.dialogRef.close();

    this.dialog
      .open(PermissionUpdateModelComponent, {
        panelClass: 'custom-dialog-container',
        width: '498px',
        height: 'auto',
        disableClose: true,
        data: payload,
      })
      .afterClosed()
      .subscribe((result) => {
        if (
          result &&
          result.ResponseCode >= 0 &&
          result.ResponseMessage === 'Successfully'
        ) {
          this.commonFCService.getPermissionData();
        }
      });
  }

  // DELETE MODEL ----------------------------

  openDeleteModel(productId: any, permission: string) {
    const selectedPermissions = this.permissionForm.value.permissions
      .filter((perm: any) => perm.checked)
      .map((perm: any) => ({
        Id: perm?.id,
        value: perm.value,
        checked: perm.checked,
      }));
    if (selectedPermissions.length === 0) {
      this.toastr.warning('Please select at least one permission');
      return;
    }
    this.dialogRef.close();

    const dialogRef = this.dialog.open(DeleteModelComponent, {
      width: '500px',
      // panelClass: 'custom-dialog-container',
      disableClose: true,
      data: {
        Id: selectedPermissions,
        modelName: permission,
        url: 'delete_srv_permission_master',
      },
    });

    dialogRef.afterClosed().subscribe((result) => {
      if (result === 'deleted') {
        this.commonFCService.getPermissionData();
      }
    });
  }

  // TOGGLE CHECKBOX ----------------------

  toggleCheckbox(index: number) {
    const control = this.permissions.at(index).get('checked');
    control?.setValue(!control.value);
  }
}
