import { TestBed } from '@angular/core/testing';

import { CommonFCService } from './common-fc.service';

describe('CommonFCService', () => {
  let service: CommonFCService;

  beforeEach(() => {
    TestBed.configureTestingModule({});
    service = TestBed.inject(CommonFCService);
  });

  it('should be created', () => {
    expect(service).toBeTruthy();
  });
});
