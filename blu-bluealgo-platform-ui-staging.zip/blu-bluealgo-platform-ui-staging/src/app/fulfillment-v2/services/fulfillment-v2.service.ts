import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { map, Observable, of } from 'rxjs';
import { IBluFulfillmentProduct, IFulfillmentProduct, IFulfillmentProductPermission, IFulfillmentService, IFulfillmentServicePermission } from '../models/FulFillment.model';
import { bluProductToProduct, productToBluProduct } from '../models/FulFillment.utilities';
import { IUser, IFullfillmentAPIRES } from 'src/app/core/models/global.models';
import { ToastrService } from 'ngx-toastr';
import { ERROR_MESSAGES } from 'src/app/core/constants/global.constants';
@Injectable({
  providedIn: 'root',
})
export class FulfillmentV2Service {
  constructor(
    private http: HttpClient,
    private toaster: ToastrService
  ) { }

  // CREATE AND UPDATE PRODUCT ------------------------

  createProduct(bluProduct: IBluFulfillmentProduct) {
    const product = bluProductToProduct(bluProduct);
    return this.http.post<IFullfillmentAPIRES<any>>(`fullfilment/add_service`, product);
  }

  // GET ALL PRODUCT DATA ------------------------

  getProducts(accountId: string): Observable<IFullfillmentAPIRES<IBluFulfillmentProduct>> {
    return this.http
      .post<IFullfillmentAPIRES<IFulfillmentProduct>>(`fullfilment/show_ac_service`, { accountId })
      .pipe(
        map(x => ({ ...x, list: x.list.map(x => productToBluProduct(x)), }))
      );
  }

  updateProduct(product: IBluFulfillmentProduct) {
    const updatedProduct = bluProductToProduct(product);
    return this.http
      .post<IFullfillmentAPIRES<IFulfillmentProduct>>(`fullfilment/update_srv`, updatedProduct);
  }

  getAllProducts() {
    return this.http.get<string[]>('fullfilment/show_srv_product');
  }

  getAllPlanTypes() {
    return this.http.get<Record<string, string>>('fullfilment/show_plan');
  }

  getAllProductTypes(productName: string) {
    return this.http.get<string[]>(`fullfilment/show_srv_type/${productName}`);
  }

  deleteProduct(rowId: number) {
    return this.http.post<IFullfillmentAPIRES<any>>(`fullfilment/delete_service`, { Id: rowId });
  }

  // DELETE  DATA --------------------

  deleteData(productId: any, url: string): Observable<any> {
    const payload =
      url === 'delete_srv_permission_master'
        ? productId.map((item: any) => ({ id: item.Id }))
        : url === 'delete_uses_master'
          ? { Id: productId }
          : { Id: productId };

    return this.http.post(`fullfilment/${url}`, payload);
  }

  // CREATE AND UPDATE SERVICE ------------------------

  createService(payload: any): Observable<any> {
    return this.http.post(`fullfilment/add_uses_master`, payload);
  }

  updateService(product: IFulfillmentProduct) {
    return this.http.post<IFullfillmentAPIRES<any>>(`fullfilment/update_service`, product);
  }

  addNewService(productRowId: number, serviceToAdd: IFulfillmentService) {
    const payload = { Id: productRowId, serviceUses: [serviceToAdd] };
    return this.http.post<IFullfillmentAPIRES<any>>(`fullfilment/add_service_uses`, payload);
  }

  deleteService(rowId: number) {
    return this.http.post<IFullfillmentAPIRES<any>>(`fullfilment/delete_service_uses`, { id: rowId });
  }

  getProductServices(accountId: string, productId: string) {
    const payload = { accountId, serviceCode: productId };
    return this.http.post<IFullfillmentAPIRES<IFulfillmentProduct>>(`fullfilment/show_customer_srvuses`, payload)
      .pipe(
        map(res => ({ ...res, list: res.list?.at(0)?.serviceUses ?? [] }))
      )
  }

  getProductWithServices(accountId: string, productId: string) {
    const payload = { accountId, serviceCode: productId };
    return this.http.post<IFullfillmentAPIRES<IFulfillmentProduct>>(`fullfilment/show_customer_srvuses`, payload)
  }

  // GET ALL SERVICE DATA ------------------------

  getServicesData(): Observable<any> {
    return this.http.post<any>('fullfilment/show_uses_master', {});
  }

  // CREATE AND UPDATE PERMISSION ------------------------

  createPermission(payload: any): Observable<any> {
    return this.http.post(`fullfilment/add_srv_tag`, payload);
  }

  updatePermission(payload: any): Observable<any> {
    return this.http.post(`fullfilment/update_srv_permission_master`, payload);
  }

  // GET ALL SERVICE DATA ------------------------

  getPermissionData(): Observable<IFullfillmentAPIRES<IFulfillmentServicePermission>> {
    return this.http.get<IFullfillmentAPIRES<IFulfillmentServicePermission>>(
      `fullfilment/show_srvs_permissions`,
    );
  }

  getProductPermissions(accountId: string, productId: string) {
    return this.http.post<IFullfillmentAPIRES<IFulfillmentProductPermission>>(`entp_v1/role/show_customer_master_permission_by_srvCode`, { acId: accountId, service_code: productId });
  }

  // Account Data --------
  getAccountByEmailId(email: string) {
    return this.http.get<IUser>(`fullfilment/show_user_by_userId/${email}`);
  }

  hanleAPIResponse(message: string, response: IFullfillmentAPIRES<any>) {
    if (response.ResponseCode === 1) {
      this.toaster.success(message, 'Success');
      return of(true); // success
    } else {
      this.toaster.error(response.ResponseMessage || ERROR_MESSAGES.GENERIC, 'Error');
      return of(false); // error
    }
  }
}


