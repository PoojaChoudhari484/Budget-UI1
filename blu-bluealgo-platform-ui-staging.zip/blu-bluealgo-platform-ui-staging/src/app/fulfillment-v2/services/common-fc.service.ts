import { HttpClient, HttpParams } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { BehaviorSubject, Observable } from 'rxjs';
import { FulfillmentV2Service } from './fulfillment-v2.service';

@Injectable({
  providedIn: 'root',
})
export class CommonFCService {
  private allPermissionsSubject = new BehaviorSubject<any[]>([]);
  allPermissions$ = this.allPermissionsSubject.asObservable();

  constructor(
    private http: HttpClient,
    private fulFillmentApiServices: FulfillmentV2Service,
  ) {}

  getPermissionData(): void {
    this.fulFillmentApiServices.getPermissionData().subscribe({
      next: (res: any) => {
        const groupedPermissions = res.reduce((acc: any, item: any) => {
          const key = item.subModule;
          if (!acc[key]) {
            acc[key] = {
              Id: item.id,
              subModule: key,
              levels: [],
            };
          }
          acc[key].levels.push({ level: item.lavel, Id: item.id });
          return acc;
        }, {});
        const allPermissions = Object.values(groupedPermissions);
        this.allPermissionsSubject.next(allPermissions);
      },
      error: (error) => {
        console.error(error);
      },
    });
  }

  getAllPlanData(): Observable<any> {
    const params = new HttpParams().set('ignoreLoader', 'yes');
    return this.http.get<any>('fullfilment/show_plan', { params });
  }
}
