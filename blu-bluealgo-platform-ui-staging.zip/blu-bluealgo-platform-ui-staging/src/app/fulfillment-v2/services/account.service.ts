import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';

class ProductRES<T> {
  ResponseCode!: number;
  ResponseMessage: string = '';
  list!: Array<T>;
}
class ProductRESData {
  Id: number | string = 0;
  name: string = '';
  productName: string = '';
  serviceCode: string = '';
  servicePermissions: any[];
  validForDay: number;
}

@Injectable({
  providedIn: 'root',
})
export class AccountService {
  constructor(private http: HttpClient) {}

  // CREATE AND UPDATE ACCOUNT ------------------------

  createAccount(payload: any): Observable<any> {
    return this.http.post(`auth/create_ac`, payload);
  }

  updateAccount(payload: any): Observable<any> {
    return this.http.post(`fullfilment/update_account`, payload);
  }

  // GET ALL ACCOUNT DATA ------------------------

  getAccountData(): Observable<ProductRES<ProductRESData>> {
    return this.http.get<ProductRES<ProductRESData>>(`fullfilment/show_users`);
  }

  // DELETE ACCOUNT DATA --------------------

  deleteAccount(productId: number): Observable<any> {
    return this.http.post(`fullfilment/delete_account`, {
      accountId: productId,
    });
  }
}
