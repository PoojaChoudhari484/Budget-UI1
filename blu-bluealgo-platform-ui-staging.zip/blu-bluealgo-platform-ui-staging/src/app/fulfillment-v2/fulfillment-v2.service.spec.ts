import { TestBed } from '@angular/core/testing';

import { FulfillmentV2Service } from './services/fulfillment-v2.service';

describe('FulfillmentV2Service', () => {
  let service: FulfillmentV2Service;

  beforeEach(() => {
    TestBed.configureTestingModule({});
    service = TestBed.inject(FulfillmentV2Service);
  });

  it('should be created', () => {
    expect(service).toBeTruthy();
  });
});
