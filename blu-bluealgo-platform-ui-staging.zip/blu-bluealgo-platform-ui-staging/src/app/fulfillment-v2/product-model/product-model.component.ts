import { Component, Inject } from '@angular/core';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { MAT_DIALOG_DATA, MatDialogRef } from '@angular/material/dialog';
import { FulfillmentV2Service } from '../services/fulfillment-v2.service';
import { ToastrService } from 'ngx-toastr';

@Component({
    selector: 'app-product-model',
    templateUrl: './product-model.component.html',
    styleUrls: ['./product-model.component.scss'],
    standalone: false
})
export class ProductModelComponent {
  productForm!: FormGroup;

  constructor(
    private fb: FormBuilder,
    public dialogRef: MatDialogRef<ProductModelComponent>,
    @Inject(MAT_DIALOG_DATA) public data: any,
    private fulfillmentService: FulfillmentV2Service,
    private toastr: ToastrService,
  ) {}

  ngOnInit(): void {
    console.log('this.data', this.data);

    this.productForm = this.fb.group({
      productName: [this.data?.productName || '', Validators.required],
      productPlan: [this.data?.name || '', Validators.required],
      validity: [
        this.data?.validForDay || '',
        [Validators.required, Validators.min(1)],
      ],
    });
  }

  // SAVE PRODUCT -----------------------

  saveProduct() {
    if (this.productForm.valid) {
      const formData = this.productForm.value;

      const payload: any = {
        serviceCode: 'srv0018',
        name: formData.productPlan,
        productName: formData.productName,
        validForDay: formData.validity,
      };

      if (this.data) {
        payload.Id = this.data.Id;

        this.fulfillmentService.updateProduct(payload).subscribe((res) => {
          let msg = 'Product Updated Successfully';

          if (res?.ResponseCode >= 0) {
            this.toastr.success(msg, 'Success');
            this.dialogRef.close(res);
          } else {
            this.toastr.error('Error while saving Product', 'Error');
          }
        });
      } else {
        this.fulfillmentService.createProduct(payload).subscribe((res) => {
          if (res?.ResponseCode >= 0) {
            this.toastr.success('New Product Added Successfully', 'Success');
            this.dialogRef.close(res);
          } else {
            this.toastr.error('Error while saving Product', 'Error');
          }
        });
      }
    } else {
      this.productForm.markAllAsTouched();
    }
  }

  closeProductModel() {
    this.dialogRef.close();
  }
}
