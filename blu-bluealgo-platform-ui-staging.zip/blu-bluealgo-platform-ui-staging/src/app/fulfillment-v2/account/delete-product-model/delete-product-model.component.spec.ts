import { ComponentFixture, TestBed } from '@angular/core/testing';

import { DeleteProductModelComponent } from './delete-product-model.component';

describe('DeleteProductModelComponent', () => {
  let component: DeleteProductModelComponent;
  let fixture: ComponentFixture<DeleteProductModelComponent>;

  beforeEach(() => {
    TestBed.configureTestingModule({
      declarations: [DeleteProductModelComponent],
    });
    fixture = TestBed.createComponent(DeleteProductModelComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
