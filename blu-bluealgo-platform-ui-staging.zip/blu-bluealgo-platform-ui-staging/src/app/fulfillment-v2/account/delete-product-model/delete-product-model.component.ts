import { Component } from '@angular/core';
import { MatDialogRef } from '@angular/material/dialog';

@Component({
    selector: 'app-delete-product-model',
    templateUrl: './delete-product-model.component.html',
    styleUrls: ['./delete-product-model.component.scss'],
    standalone: false
})
export class DeleteProductModelComponent {
  constructor(private dialogRef: MatDialogRef<DeleteProductModelComponent>) {}

  confirmDelete() {
    this.dialogRef.close('confirm');
  }

  closeDialog() {
    this.dialogRef.close('close');
  }
}
