import { ComponentFixture, TestBed } from '@angular/core/testing';

import { DeletePermissionsModelComponent } from './delete-permissions-model.component';

describe('DeletePermissionsModelComponent', () => {
  let component: DeletePermissionsModelComponent;
  let fixture: ComponentFixture<DeletePermissionsModelComponent>;

  beforeEach(() => {
    TestBed.configureTestingModule({
      declarations: [DeletePermissionsModelComponent],
    });
    fixture = TestBed.createComponent(DeletePermissionsModelComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
