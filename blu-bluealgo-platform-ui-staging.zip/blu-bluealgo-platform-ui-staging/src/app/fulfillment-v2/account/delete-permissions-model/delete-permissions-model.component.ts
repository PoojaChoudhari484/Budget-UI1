import { Component } from '@angular/core';
import { MatDialogRef } from '@angular/material/dialog';

@Component({
    selector: 'app-delete-permissions-model',
    templateUrl: './delete-permissions-model.component.html',
    styleUrls: ['./delete-permissions-model.component.scss'],
    standalone: false
})
export class DeletePermissionsModelComponent {
  constructor(
    private dialogRef: MatDialogRef<DeletePermissionsModelComponent>,
  ) {}

  confirmDelete() {
    this.dialogRef.close('confirm');
  }

  closeDialog() {
    this.dialogRef.close('close');
  }
}
