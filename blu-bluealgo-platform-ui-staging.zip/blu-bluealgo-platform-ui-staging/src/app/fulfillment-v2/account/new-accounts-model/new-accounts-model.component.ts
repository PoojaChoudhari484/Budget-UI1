import { Component, Inject } from '@angular/core';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { MAT_DIALOG_DATA, MatDialogRef } from '@angular/material/dialog';
import { AccountService } from '../../services/account.service';
import { ToastrService } from 'ngx-toastr';

@Component({
    selector: 'app-new-accounts-model',
    templateUrl: './new-accounts-model.component.html',
    styleUrls: ['./new-accounts-model.component.scss'],
    standalone: false
})
export class NewAccountsModelComponent {
  productForm!: FormGroup;

  productList = [
    { value: 'product1', label: 'Product 1' },
    { value: 'product2', label: 'Product 2' },
    { value: 'product3', label: 'Product 3' },
  ];

  productPlanList = [
    { value: 'productPlan1', label: 'Product Plan 1' },
    { value: 'productPlan2', label: 'Product Plan 2' },
    { value: 'productPlan3', label: 'Product Plan 3' },
  ];

  dropdownOpen = false;

  rolesList = ['Role-1', 'Role-2', 'Role-3', 'Role-4'];
  selectedRole: string = '';

  toggleDropdown() {
    this.dropdownOpen = !this.dropdownOpen;
  }

  closeDropdown() {
    this.dropdownOpen = false;
  }

  onRoleSelect(role: string) {
    this.selectedRole = role;
    this.productForm.get('TeamSpaceRoleAllocations')?.setValue(role);
    this.productForm.get('TeamSpaceRoleAllocations')?.markAsTouched();
    this.dropdownOpen = false;
  }

  constructor(
    private fb: FormBuilder,
    public dialogRef: MatDialogRef<NewAccountsModelComponent>,
    @Inject(MAT_DIALOG_DATA) public data: any,
    private fulfillmentService: AccountService,
    private toastr: ToastrService,
  ) {}
  ngOnInit(): void {
    this.productForm = this.fb.group({
      Name: ['', Validators.required],
      LastName: ['', Validators.required],
      EmailId: ['', Validators.required],
      Company: ['', Validators.required],
      Password: ['', Validators.required],
      ConfrimPassword: ['', Validators.required],
      ModuleType: ['', Validators.required],
      ServiceType: ['', Validators.required],
      // MobileNumber: ['', Validators.required],

      MobilePrefix: ['+91'], // default prefix
      MobileNumberOnly: ['', Validators.required],
      TeamSpaceRoleAllocations: ['', Validators.required],
    });
  }

  // SAVE ACCOUNT -----------------------

  saveProduct() {
    console.log('calling add api.....');

    if (this.productForm.valid) {
      const fullMobileNumber =
        this.productForm.value.MobilePrefix +
        this.productForm.value.MobileNumberOnly;

      const formData = this.productForm.value;

      const payload: any = {
        // serviceCode: 'srv0018',
        Name: formData.Name,
        LastName: formData.LastName,
        EmailId: formData.EmailId,
        Company: formData.Company,
        Password: formData.Password,
        ConfrimPassword: formData.ConfrimPassword,
        ModuleType: formData.ModuleType,
        ServiceType: formData.ServiceType,
        MobileNumber: fullMobileNumber,
        TeamSpaceRoleAllocations: formData.TeamSpaceRoleAllocations,
      };

      console.log('Success validation..... ');

      this.fulfillmentService.createAccount(payload).subscribe((res) => {
        if (res?.ResponseCode >= 0) {
          this.toastr.success('New Account Added Successfully', 'Success');
          this.dialogRef.close(res);
        } else {
          this.toastr.error('Error while saving Account', 'Error');
        }
      });
    } else {
      this.productForm.markAllAsTouched();
    }
  }

  closeProductModel() {
    this.dialogRef.close();
  }
}
