import { ComponentFixture, TestBed } from '@angular/core/testing';

import { NewAccountsModelComponent } from './new-accounts-model.component';

describe('NewAccountsModelComponent', () => {
  let component: NewAccountsModelComponent;
  let fixture: ComponentFixture<NewAccountsModelComponent>;

  beforeEach(() => {
    TestBed.configureTestingModule({
      declarations: [NewAccountsModelComponent],
    });
    fixture = TestBed.createComponent(NewAccountsModelComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
