import { ComponentFixture, TestBed } from '@angular/core/testing';

import { UpdateServicesModelComponent } from './update-services-model.component';

describe('UpdateServicesModelComponent', () => {
  let component: UpdateServicesModelComponent;
  let fixture: ComponentFixture<UpdateServicesModelComponent>;

  beforeEach(() => {
    TestBed.configureTestingModule({
      declarations: [UpdateServicesModelComponent],
    });
    fixture = TestBed.createComponent(UpdateServicesModelComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
