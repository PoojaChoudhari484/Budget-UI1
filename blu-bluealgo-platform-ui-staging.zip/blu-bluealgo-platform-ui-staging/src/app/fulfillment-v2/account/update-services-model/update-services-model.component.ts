import { Component, Inject } from '@angular/core';
import { FormBuilder, FormControl, FormGroup, Validators } from '@angular/forms';
import { MAT_DIALOG_DATA, MatDialogRef } from '@angular/material/dialog';
import { FulfillmentV2Service } from '../../services/fulfillment-v2.service';
import { IFulfillmentProduct, IFulfillmentService } from '../../models/FulFillment.model';
import { CustomOnDestoryComponent } from 'src/app/shared/custom-on-destory/custom-on-destory.component';
import { catchError, EMPTY, forkJoin, switchMap, takeUntil, throwError } from 'rxjs';
import { ParamsService } from 'src/app/services/params.service';
import { ToastrService } from 'ngx-toastr';
import { DialogOpenMode } from 'src/app/core/enums/global.enum';
import { ERROR_MESSAGES } from 'src/app/core/constants/global.constants';
import { IFullfillmentAPIRES } from 'src/app/core/models/global.models';

@Component({
  selector: 'app-update-services-model',
  templateUrl: './update-services-model.component.html',
  styleUrls: ['./update-services-model.component.scss'],
  standalone: false
})
export class UpdateServicesModelComponent extends CustomOnDestoryComponent {
  serviceForm!: FormGroup<IServiceForm>;
  planTypes: Record<string, string> = {};
  product: IFulfillmentProduct | null;
  params: IFulFillmentServiceQueryParams;
  dialogOpenMode: DialogOpenMode;
  DIALOG_OPEN_MODE = DialogOpenMode;

  constructor(
    private fb: FormBuilder,
    private fulfillmentService: FulfillmentV2Service,
    private paramsService: ParamsService,
    private dialogRef: MatDialogRef<UpdateServicesModelComponent>,
    private toaster: ToastrService,
    @Inject(MAT_DIALOG_DATA) public data: { service: IFulfillmentService, dialogOpenMode: DialogOpenMode },
  ) { super(); }

  ngOnInit(): void {
    this.dialogOpenMode = this.data.dialogOpenMode;
    this.params = this.paramsService.getAllQueryParams() as IFulFillmentServiceQueryParams;
    this.serviceForm = this.fb.nonNullable.group({
      serviceName: ['', Validators.required],
      usageType: ['', Validators.required],
      quantity: [100, Validators.required],
    });

    forkJoin([
      this.fulfillmentService.getProductWithServices(this.params.accountId, this.params.productId),
      this.fulfillmentService.getAllPlanTypes(),
    ])
      .pipe(
        takeUntil(this.destroy$),
        catchError(this.handleError),
      )
      .subscribe(([product, planTypes]) => {
        this.product = product.list?.at(0) ?? null;
        this.planTypes = planTypes;
        if (this.dialogOpenMode === DialogOpenMode.Edit) {
          this.serviceForm.patchValue({
            serviceName: this.data.service.name,
            usageType: this.data.service.planType,
            quantity: this.data.service.totalQuantity,
          });
        }
      })
  }

  saveService() {
    if (this.serviceForm.valid) {
      if (this.dialogOpenMode === DialogOpenMode.Add) {
        this.ceateNewService(this.product!);
      }
      else {
        this.updateService(this.product!);
      }
    } else {
      this.serviceForm.markAllAsTouched();
    }
  }

  private newService(serviceName: string, usageType: string, quantity: number, product: IFulfillmentProduct): IFulfillmentService {
    return {
      customerId: product.customerId,
      name: serviceName,
      usesCount: 0,
      totalQuantity: quantity,
      serviceCode: product.serviceCode,
      email: product.email,
      planType: usageType,
    } as any as IFulfillmentService
  }

  private updateService(product: IFulfillmentProduct) {
    const idx = product?.serviceUses.findIndex(x => x.id === this.data.service.id);
    const { serviceName, usageType, quantity } = this.serviceForm.value;
    if (idx != -1) {
      const updatedService = {
        ...product.serviceUses.at(idx),
        name: serviceName || '',
        planType: usageType || '',
        totalQuantity: quantity || 0,
      } as IFulfillmentService
      product.serviceUses[idx] = { ...updatedService };

      this.fulfillmentService.updateService(product)
        .pipe(
          takeUntil(this.destroy$),
          catchError(this.handleError.bind(this)),
          switchMap(res => this.fulfillmentService.hanleAPIResponse('Service updated successfully', res))
        )
        .subscribe(success => {
          if (success) this.closeDialog(true);
        })
    }
  }

  private handleError(error: Error) {
    this.toaster.error(ERROR_MESSAGES.GENERIC, 'Error');
    return EMPTY;
  }

  private ceateNewService(product: IFulfillmentProduct) {
    const { serviceName, usageType, quantity } = this.serviceForm.value;
    const service = this.newService(serviceName!, usageType!, quantity!, product);
    this.fulfillmentService.addNewService(product.Id, service)
      .pipe(
        takeUntil(this.destroy$),
        catchError(this.handleError),
        switchMap(res => this.fulfillmentService.hanleAPIResponse('Service added successfully', res))
      )
      .subscribe(success => {
        if (success) this.closeDialog(true);
      })
  }

  closeDialog(value = false) {
    this.dialogRef.close(value);
  }
}
interface IFulFillmentServiceQueryParams {
  accountId: string;
  productId: string;
}

interface IServiceForm {
  serviceName: FormControl<string>;
  usageType: FormControl<string>;
  quantity: FormControl<number>;
}