import { Component, Inject } from '@angular/core';
import {
  FormBuilder,
  FormControl,
  FormGroup,
  Validators,
} from '@angular/forms';
import { MAT_DIALOG_DATA, MatDialogRef } from '@angular/material/dialog';
import { FulfillmentV2Service } from '../../services/fulfillment-v2.service';
import { IBluFulfillmentProduct } from '../../models/FulFillment.model';
import { forkJoin, switchMap, takeUntil } from 'rxjs';
import { CustomOnDestoryComponent } from 'src/app/shared/custom-on-destory/custom-on-destory.component';
import { ParamsService } from 'src/app/services/params.service';
import { IUser } from 'src/app/core/models/global.models';
import { ToastrService } from 'ngx-toastr';
import { DialogOpenMode } from 'src/app/core/enums/global.enum';

@Component({
  selector: 'app-update-product-model',
  templateUrl: './update-product-model.component.html',
  styleUrls: ['./update-product-model.component.scss'],
  standalone: false
})
export class UpdateProductModelComponent extends CustomOnDestoryComponent {
  productForm!: FormGroup;
  statusControl = new FormControl(true);
  products: string[] = [];
  productTypes: string[] = [];
  product: IBluFulfillmentProduct;
  DIALOG_OPEN_MODE = DialogOpenMode;
  dialogOpenMode: DialogOpenMode;
  queryParams: IFulFillmentProductModalQueryParams;

  constructor(
    private fb: FormBuilder,
    private fullfillmentService: FulfillmentV2Service,
    private paramsService: ParamsService,
    private toaster: ToastrService,
    public dialogRef: MatDialogRef<UpdateProductModelComponent>,
    @Inject(MAT_DIALOG_DATA) public data: { product: IBluFulfillmentProduct, dialogOpenMode: DialogOpenMode },
  ) {
    super();
    this.productForm = this.fb.group({
      productName: [this.product?.productName ?? '', Validators.required],
      planType: [this.product?.productPlan ?? '', Validators.required],
    });
  }

  ngOnInit(): void {
    this.dialogOpenMode = this.data.dialogOpenMode;
    this.product = this.data.product;
    this.queryParams = this.paramsService.getAllQueryParams() as IFulFillmentProductModalQueryParams;
    this.fetchProducts();
    this.productForm.get('productName')?.valueChanges
      .pipe(
        takeUntil(this.destroy$),
        switchMap(productName => this.fullfillmentService.getAllProductTypes(productName))
      ).subscribe(res => {
        this.productTypes = res;
        if (!this.planType?.value && this.dialogOpenMode === DialogOpenMode.Edit) {
          if (this.productTypes.includes(this.product.productPlan))
            this.planType?.setValue(this.product.productPlan);
          else
            this.planType?.setValue('');
        }
      });
  }

  fetchProducts() {
    this.fullfillmentService.getAllProducts()
      .pipe(takeUntil(this.destroy$))
      .subscribe(res => {
        this.products = res;
        if (this.dialogOpenMode === DialogOpenMode.Edit) {
          if (this.products.includes(this.product.productName))
            this.productName?.setValue(this.product.productName);
          else
            this.productName?.setValue('');
        }
      });
  }

  get planType() {
    return this.productForm.get('planType');
  }

  get productName() {
    return this.productForm.get('productName');
  }


  saveProduct() {
    if (this.productForm.valid) {
      if (this.dialogOpenMode === DialogOpenMode.Add)
        this.createProduct();
      else
        this.updateProduct();
    } else {
      this.productForm.markAllAsTouched();
    }
  }

  updateProduct() {
    const formData = this.productForm.value;
    const updatedProduct = {
      ...this.product,
      productName: formData.productName,
      productPlan: formData.planType,
      status: this.statusControl.value ? 'active' : 'inactive',
    }
    this.fullfillmentService.updateProduct(updatedProduct)
      .subscribe(res => {
        if (res.ResponseCode === 1) {
          this.dialogRef.close(true);
        }
      });
  }

  createProduct() {
    const { productName, planType, status } = this.productForm.value;
    this.fullfillmentService.getAccountByEmailId(this.queryParams.email)
      .pipe(
        takeUntil(this.destroy$),
        switchMap(user => {
          const newProduct = this.newProduct(user, productName, planType, status);
          return this.fullfillmentService.createProduct(newProduct)
        }),
      )
      .subscribe({
        next: res => {
          if (res.ResponseCode === 1)
            this.dialogRef.close(true);
          else
            this.toaster.error(res.ResponseMessage, 'Error');
        }, error: err => this.toaster.error('Something went wrong at our end', 'Error')
      });
  }

  closeProductModel() {
    this.dialogRef.close();
  }

  newProduct(user: IUser, productName: string, productPlan: string, status = false): IBluFulfillmentProduct {
    return {
      customerId: user.CustomerId,
      productPlan,
      email: user.EmailId,
      accountId: user.AccountId,
      productName,
    } as any as IBluFulfillmentProduct;
  }
}

interface IFulFillmentProductModalQueryParams {
  accountId: string;
  productId: string;
  email: string;
}