import { Component, Inject } from '@angular/core';
import { FormArray, FormBuilder, FormGroup, Validators } from '@angular/forms';
import {
  MAT_DIALOG_DATA,
  MatDialog,
  MatDialogRef,
} from '@angular/material/dialog';
import { DeleteModelComponent } from '../../delete-model/delete-model.component';
import { PermissionModelComponent } from '../../permission/permission-model/permission-model.component';
import { FulfillmentV2Service } from '../../services/fulfillment-v2.service';

@Component({
    selector: 'app-add-sub-module-permissions-model',
    templateUrl: './add-sub-module-permissions-model.component.html',
    styleUrls: ['./add-sub-module-permissions-model.component.scss'],
    standalone: false
})
export class AddSubModulePermissionsModelComponent {
  permissionForm!: FormGroup;

  constructor(
    private fb: FormBuilder,
    public dialogRef: MatDialogRef<PermissionModelComponent>,
    @Inject(MAT_DIALOG_DATA) public data: any,
    private fulfillmentService: FulfillmentV2Service,
    // private toastr: ToastrService,
    private dialog: MatDialog,
  ) {}

  ngOnInit(): void {
    this.permissionForm = this.fb.group({
      productName: [this.data?.productName || '', Validators.required],
      productPlan: [this.data?.name || '', Validators.required],
      validity: [
        this.data?.validForDay || '',
        [Validators.required, Validators.min(1)],
      ],
      permissions: this.fb.array([]),
    });

    // Populate existing permissions or add one by default
    if (this.data?.permissions?.length) {
      this.data.permissions.forEach((perm: string) => {
        this.permissions.push(
          this.fb.group({ value: [perm, Validators.required] }),
        );
      });
    } else {
      this.addPermission(); // Add a default empty permission field
    }
  }

  get permissions(): FormArray {
    return this.permissionForm.get('permissions') as FormArray;
  }

  createPermissionField(): FormGroup {
    return this.fb.group({
      value: ['', Validators.required],
    });
  }

  addPermission(): void {
    this.permissions.push(this.createPermissionField());
  }

  removePermission(index: number): void {
    if (this.permissions.length > 1) {
      this.permissions.removeAt(index);
    }
  }

  // SAVE PRODUCT -----------------------

  saveProduct(): void {
    if (this.permissionForm.valid) {
      const formData = this.permissionForm.value;

      const payload: any = {
        serviceCode: 'srv0018',
        name: formData.productPlan,
        productName: formData.productName,
        validForDay: formData.validity,
        permissions: formData.permissions.map((perm: any) => perm.value),
      };

      if (this.data?.Id) {
        payload.Id = this.data.Id;

        this.fulfillmentService.updateProduct(payload).subscribe((res) => {
          if (res?.ResponseCode >= 0) {
            // this.toastr.success('Product Updated Successfully', 'Success');
            this.dialogRef.close(res);
          } else {
            // this.toastr.error('Error while saving Product', 'Error');
          }
        });
      } else {
        this.fulfillmentService.createProduct(payload).subscribe((res) => {
          if (res?.ResponseCode >= 0) {
            // this.toastr.success('New Product Added Successfully', 'Success');
            this.dialogRef.close(res);
          } else {
            // this.toastr.error('Error while saving Product', 'Error');
          }
        });
      }
    } else {
      this.permissionForm.markAllAsTouched();
    }
  }

  closeProductModel(): void {
    this.dialogRef.close();
  }
  // ADD AND UPDATE MODEL -----------------------
  openPermissionDialog(product?: any): void {
    this.dialogRef.close();

    setTimeout(() => {
      this.dialog.open(PermissionModelComponent, {
        panelClass: 'custom-dialog-container',
        width: '498px',
        height: 'auto',
        disableClose: true,
        data: product || null,
      });
    }, 100);
  }

  // DELETE MODEL ----------------------------

  openDeleteModel(productId: any, permission: string) {
    this.dialogRef.close();

    const dialogRef = this.dialog.open(DeleteModelComponent, {
      width: '500px',
      // panelClass: 'custom-dialog-container',
      disableClose: true,
      data: { Id: productId, modelName: permission },
    });

    dialogRef.afterClosed().subscribe((result) => {
      if (result === 'confirm') {
        // call delete API or handle logic
        console.log('Product deleted');
      }
    });
  }
}
