import { ComponentFixture, TestBed } from '@angular/core/testing';

import { AddSubModulePermissionsModelComponent } from './add-sub-module-permissions-model.component';

describe('AddSubModulePermissionsModelComponent', () => {
  let component: AddSubModulePermissionsModelComponent;
  let fixture: ComponentFixture<AddSubModulePermissionsModelComponent>;

  beforeEach(() => {
    TestBed.configureTestingModule({
      declarations: [AddSubModulePermissionsModelComponent],
    });
    fixture = TestBed.createComponent(AddSubModulePermissionsModelComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
