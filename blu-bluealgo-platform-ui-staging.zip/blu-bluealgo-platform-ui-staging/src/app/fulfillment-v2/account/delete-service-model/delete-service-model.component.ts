import { Component } from '@angular/core';
import { MatDialogRef } from '@angular/material/dialog';

@Component({
    selector: 'app-delete-service-model',
    templateUrl: './delete-service-model.component.html',
    styleUrls: ['./delete-service-model.component.scss'],
    standalone: false
})
export class DeleteServiceModelComponent {
  constructor(private dialogRef: MatDialogRef<DeleteServiceModelComponent>) {}

  confirmDelete() {
    this.dialogRef.close('confirm');
  }

  closeDialog() {
    this.dialogRef.close('close');
  }
}
