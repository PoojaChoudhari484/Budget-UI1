import { ComponentFixture, TestBed } from '@angular/core/testing';

import { DeleteServiceModelComponent } from './delete-service-model.component';

describe('DeleteServiceModelComponent', () => {
  let component: DeleteServiceModelComponent;
  let fixture: ComponentFixture<DeleteServiceModelComponent>;

  beforeEach(() => {
    TestBed.configureTestingModule({
      declarations: [DeleteServiceModelComponent],
    });
    fixture = TestBed.createComponent(DeleteServiceModelComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
