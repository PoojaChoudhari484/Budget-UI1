import { ComponentFixture, TestBed } from '@angular/core/testing';

import { UpdateSubModulePermissionsModelComponent } from './update-sub-module-permissions-model.component';

describe('UpdateSubModulePermissionsModelComponent', () => {
  let component: UpdateSubModulePermissionsModelComponent;
  let fixture: ComponentFixture<UpdateSubModulePermissionsModelComponent>;

  beforeEach(() => {
    TestBed.configureTestingModule({
      declarations: [UpdateSubModulePermissionsModelComponent],
    });
    fixture = TestBed.createComponent(UpdateSubModulePermissionsModelComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
