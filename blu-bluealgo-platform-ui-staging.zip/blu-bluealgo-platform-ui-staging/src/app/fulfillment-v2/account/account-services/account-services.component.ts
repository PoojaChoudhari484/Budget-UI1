import { Component } from '@angular/core';
import { ProductModelComponent } from '../../product-model/product-model.component';
import { FulfillmentV2Service } from '../../services/fulfillment-v2.service';
import { MatDialog } from '@angular/material/dialog';
import { NewServiceModelComponent } from '../new-service-model/new-service-model.component';
import { UpdateServicesModelComponent } from '../update-services-model/update-services-model.component';
import { DeleteServiceModelComponent } from '../delete-service-model/delete-service-model.component';
import { ParamsService } from 'src/app/services/params.service';
import { IFulfillmentService } from '../../models/FulFillment.model';
import { filter, switchMap, takeUntil } from 'rxjs';
import { CustomOnDestoryComponent } from 'src/app/shared/custom-on-destory/custom-on-destory.component';
import { DialogOpenMode } from 'src/app/core/enums/global.enum';

@Component({
  selector: 'app-account-services',
  templateUrl: './account-services.component.html',
  styleUrls: ['./account-services.component.scss'],
  standalone: false
})
export class AccountServicesComponent extends CustomOnDestoryComponent{
  selectedUserId: number | null = null;
  allServices: IFulfillmentService[] = [];
  isProductModel: boolean = false;
  queryParams: IFulFillmentServiceQueryParams;
  constructor(
    private dialog: MatDialog,
    private fulFillmentApiServices: FulfillmentV2Service,
    private paramsService: ParamsService
  ) { super();}

  ngOnInit(): void {
    this.initilizeComponent();
  }

  private initilizeComponent() {
    this.queryParams = this.paramsService.getAllQueryParams() as IFulFillmentServiceQueryParams;
    this.fulFillmentApiServices
      .getProductServices(this.queryParams.accountId, this.queryParams.productId)
      .subscribe(res => this.allServices = res.list.reverse());
  }

  toggleDropdown(userId: number) {
    this.selectedUserId = this.selectedUserId === userId ? null : userId;
  }

  getLastTwoIds(): number[] {
    const lastTwo = this.allServices.slice(-2);
    return lastTwo.map((service) => service.id);
  }

  openUpdateServiceDialog(service:IFulfillmentService | null = null, createFromScratch = true) {
    this.dialog
      .open(UpdateServicesModelComponent, {
        panelClass: 'custom-dialog-container',
        width: '498px',
        height: 'auto',
        disableClose: true,
        data: {
          service,
          dialogOpenMode: createFromScratch? DialogOpenMode.Add: DialogOpenMode.Edit
        },
      })
      .afterClosed()
      .pipe(filter(x=>x))
      .subscribe(_=>this.initilizeComponent());
  }

  openDeleteModel(rowId: number) {
    const dialogRef = this.dialog.open(DeleteServiceModelComponent, {
      width: 'auto',
      panelClass: 'custom-dialog-container',
      disableClose: true,
    });

    dialogRef.afterClosed()
    .pipe(
      takeUntil(this.destroy$),
      filter(x=>x === 'confirm'),
      switchMap(_=>this.fulFillmentApiServices.deleteService(rowId))
    )
    .subscribe(res=>{
      if(res.ResponseCode === 1){
        this.initilizeComponent();
      }
    });
    
  }
}

interface IFulFillmentServiceQueryParams {
  accountId: string;
  productId: string;
}