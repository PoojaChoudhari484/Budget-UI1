import { Component, Inject } from '@angular/core';
import { MAT_DIALOG_DATA, MatDialogRef } from '@angular/material/dialog';
import { ToastrService } from 'ngx-toastr';
import { AccountService } from '../../services/account.service';

@Component({
    selector: 'app-delete-accounts-model',
    templateUrl: './delete-accounts-model.component.html',
    styleUrls: ['./delete-accounts-model.component.scss'],
    standalone: false
})
export class DeleteAccountsModelComponent {
  constructor(
    private dialogRef: MatDialogRef<DeleteAccountsModelComponent>,
    private fulfillmentService: AccountService,
    @Inject(MAT_DIALOG_DATA)
    public data: { AccountId: number },
    private toastr: ToastrService,
  ) {}

  // Confirm Delete API

  confirmDelete() {
    if (this.data?.AccountId) {
      this.fulfillmentService.deleteAccount(this.data.AccountId).subscribe({
        next: (res) => {
          if (res?.ResponseCode >= 0) {
            this.toastr.success('Deleted Successfully', 'Success');
            this.dialogRef.close('deleted');
          }
        },
        error: (err) => {
          this.toastr.error('Error while deleting', 'Error');
          this.dialogRef.close('error');
        },
      });
    } else {
      console.warn('No Id provided!');
      this.dialogRef.close('error');
    }
  }

  closeDialog() {
    this.dialogRef.close('close');
  }
}
