import { ComponentFixture, TestBed } from '@angular/core/testing';

import { DeleteAccountsModelComponent } from './delete-accounts-model.component';

describe('DeleteAccountsModelComponent', () => {
  let component: DeleteAccountsModelComponent;
  let fixture: ComponentFixture<DeleteAccountsModelComponent>;

  beforeEach(() => {
    TestBed.configureTestingModule({
      declarations: [DeleteAccountsModelComponent],
    });
    fixture = TestBed.createComponent(DeleteAccountsModelComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
