import { Component, Inject } from '@angular/core';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { MAT_DIALOG_DATA, MatDialogRef } from '@angular/material/dialog';

@Component({
    selector: 'app-new-service-model',
    templateUrl: './new-service-model.component.html',
    styleUrls: ['./new-service-model.component.scss'],
    standalone: false
})
export class NewServiceModelComponent {
  productForm!: FormGroup;

  usageType = [
    { value: 'Unique Quality', label: 'Unique Quality' },
    { value: 'Quantity', label: 'Quantity' },
    { value: 'Duration', label: 'Duration' },
  ];

  constructor(
    private fb: FormBuilder,
    public dialogRef: MatDialogRef<NewServiceModelComponent>,
    @Inject(MAT_DIALOG_DATA) public data: any,
  ) {}
  ngOnInit(): void {
    this.productForm = this.fb.group({
      serviceName: [this.data?.serviceName || '', Validators.required],

      usageType: ['', Validators.required],
      quantity: [this.data?.quantity || '', Validators.required],
    });
  }

  saveProduct() {
    if (this.productForm.valid) {
      console.log('Form Data:', this.productForm.value);
      // this.dialogRef.close(this.productForm.value);
    } else {
      this.productForm.markAllAsTouched();
    }
  }

  closeProductModel() {
    this.dialogRef.close();
  }
}
