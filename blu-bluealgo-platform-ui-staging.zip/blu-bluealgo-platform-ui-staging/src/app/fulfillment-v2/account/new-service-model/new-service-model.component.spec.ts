import { ComponentFixture, TestBed } from '@angular/core/testing';

import { NewServiceModelComponent } from './new-service-model.component';

describe('NewServiceModelComponent', () => {
  let component: NewServiceModelComponent;
  let fixture: ComponentFixture<NewServiceModelComponent>;

  beforeEach(() => {
    TestBed.configureTestingModule({
      declarations: [NewServiceModelComponent],
    });
    fixture = TestBed.createComponent(NewServiceModelComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
