import { Component } from '@angular/core';
import { ProductModelComponent } from '../../product-model/product-model.component';
import { MatDialog } from '@angular/material/dialog';
import { FulfillmentV2Service } from '../../services/fulfillment-v2.service';
import { NewProductModelComponent } from '../new-product-model/new-product-model.component';
import { UpdateProductModelComponent } from '../update-product-model/update-product-model.component';
import { DeleteProductModelComponent } from '../delete-product-model/delete-product-model.component';
import { ParamsService } from 'src/app/services/params.service';
import { IBluFulfillmentProduct } from '../../models/FulFillment.model';
import { filter, takeUntil } from 'rxjs';
import { DialogOpenMode } from 'src/app/core/enums/global.enum';

@Component({
    selector: 'app-account-products',
    templateUrl: './account-products.component.html',
    styleUrls: ['./account-products.component.scss'],
    standalone: false
})
export class AccountProductsComponent {
  selectedUserId: number | null = null;
  allProducts: IBluFulfillmentProduct[];
  isProductModel: boolean = false;
  params: IFulFillmentProductQueryParams;
  constructor(
    private dialog: MatDialog,
    private fulFillmentApiServices: FulfillmentV2Service,
    private paramsService: ParamsService
  ) {}
  // GET ALL PRODUCTS DATA ----------------------

  ngOnInit(): void {
    this.initializeComponent();
  }

  initializeComponent(){
    this.params = this.paramsService.getAllQueryParams() as IFulFillmentProductQueryParams;
    this.fulFillmentApiServices.getProducts(this.params.accountId).subscribe({
      next: (res) => {
        this.allProducts = res?.list.reverse();
      },
      error: (error) => {
        console.log(error);
      },
    });
  }

  toggleDropdown(userId: number) {
    this.selectedUserId = this.selectedUserId === userId ? null : userId;
  }

  getLastTwoIds(): number[] {
    const lastTwo = this.allProducts.slice(-2);
    return lastTwo.map((product) => product.Id);
  }

  openUpdateProductDialog(product?: any, createFromScratch = true) {
    this.dialog
      .open(UpdateProductModelComponent, {
        panelClass: 'custom-dialog-container',
        width: '498px',
        height: 'auto',
        disableClose: true,
        data: {
          product: product || null,
          dialogOpenMode: createFromScratch? DialogOpenMode.Add: DialogOpenMode.Edit
        },
      })
      .afterClosed()
      .pipe(
        filter(x=>x)
      ).subscribe(_=>this.initializeComponent());
  }

  // DELETE MODEL ----------------------------
  openDeleteModel(rowId: number) {
    const dialogRef = this.dialog.open(DeleteProductModelComponent, {
      width: 'auto',
      panelClass: 'custom-dialog-container',
      disableClose: true,
    });

    dialogRef.afterClosed().subscribe((result) => {
      if (result === 'confirm') {
        this.fulFillmentApiServices.deleteProduct(rowId).subscribe(res=>{
          if(res.ResponseCode === 1){
            this.initializeComponent();
          }
        });
      }
    });
  }
}

interface IFulFillmentProductQueryParams{
  accountId: string;
}