import { ComponentFixture, TestBed } from '@angular/core/testing';

import { UpdateAccountsModelComponent } from './update-accounts-model.component';

describe('UpdateAccountsModelComponent', () => {
  let component: UpdateAccountsModelComponent;
  let fixture: ComponentFixture<UpdateAccountsModelComponent>;

  beforeEach(() => {
    TestBed.configureTestingModule({
      declarations: [UpdateAccountsModelComponent],
    });
    fixture = TestBed.createComponent(UpdateAccountsModelComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
