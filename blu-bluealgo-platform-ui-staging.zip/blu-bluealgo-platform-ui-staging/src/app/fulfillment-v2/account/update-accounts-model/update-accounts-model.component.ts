import { Component, Inject } from '@angular/core';
import {
  FormBuilder,
  FormControl,
  FormGroup,
  Validators,
} from '@angular/forms';
import { MAT_DIALOG_DATA, MatDialogRef } from '@angular/material/dialog';
import { AccountService } from '../../services/account.service';
import { ToastrService } from 'ngx-toastr';

@Component({
    selector: 'app-update-accounts-model',
    templateUrl: './update-accounts-model.component.html',
    styleUrls: ['./update-accounts-model.component.scss'],
    standalone: false
})
export class UpdateAccountsModelComponent {
  productForm!: FormGroup;
  statusControl = new FormControl(true);

  constructor(
    private fb: FormBuilder,
    public dialogRef: MatDialogRef<UpdateAccountsModelComponent>,
    @Inject(MAT_DIALOG_DATA) public data: any,
    private fulfillmentService: AccountService,
    private toastr: ToastrService,
  ) {}

  ngOnInit(): void {
    this.statusControl = new FormControl(this.data?.UserStatus); // true or false

    this.productForm = this.fb.group({
      Name: [this.data?.Name || '', Validators.required],
      LastName: [this.data?.LastName || '', Validators.required],
      EmailId: [this.data?.EmailId || '', Validators.required],
      Company: [this.data?.Company || '', Validators.required],
      CountryCode: [
        this.data?.CountryCode || '',
        [
          Validators.required,
          Validators.pattern('^[0-9]{1,3}$'), // allow 1 to 3-digit numbers
        ],
      ],
      MobileNumber: [
        this.data?.MobileNumber?.replace(/^\+\d{1,3}/, '') || '', // Remove country code if included
        [
          Validators.required,
          Validators.pattern('^[0-9]{10}$'), // 10-digit mobile number
        ],
      ],
    });
  }

  updateAccount() {
    if (this.productForm.valid) {
      const formData = this.productForm.value;

      const fullMobile = `+${formData.CountryCode}${formData.MobileNumber}`;
      const statusValue = this.statusControl.value ? 'Enable' : 'Disable';

      const payload: any = {
        Name: formData.Name,
        LastName: formData.LastName,
        EmailId: formData.EmailId,
        Company: formData.Company,
        MobileNumber: fullMobile,
        UserStatus: statusValue,
      };

      if (this.data) {
        payload.accountId = this.data.AccountId;
        payload.CustomerId = this.data.CustomerId;

        this.fulfillmentService.updateAccount(payload).subscribe((res) => {
          let msg = 'Account Updated Successfully';

          if (res?.ResponseCode >= 0) {
            this.toastr.success(msg, 'Success');
            this.dialogRef.close(res);
          } else {
            this.toastr.error('Error while saving Account', 'Error');
          }
        });
      }
    } else {
      this.productForm.markAllAsTouched();
    }
  }

  closeProductModel() {
    this.dialogRef.close();
  }
}
