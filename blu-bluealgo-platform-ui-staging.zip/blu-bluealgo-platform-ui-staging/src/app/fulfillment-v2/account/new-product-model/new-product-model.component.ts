import { Component, Inject } from '@angular/core';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { MAT_DIALOG_DATA, MatDialogRef } from '@angular/material/dialog';

@Component({
    selector: 'app-new-product-model',
    templateUrl: './new-product-model.component.html',
    styleUrls: ['./new-product-model.component.scss'],
    standalone: false
})
export class NewProductModelComponent {
  productForm!: FormGroup;

  productList = [
    { value: 'FMP', label: 'FMP' },
    { value: 'Doctiger', label: 'Doctiger' },
    { value: 'Smart-Form', label: 'Smart-Form' },
    { value: 'Design-Calculus', label: 'Design-Calculus' },
    { value: 'Budget-Automation', label: 'Budget-Automation' },
  ];

  planTypeList = [
    { value: 'Free Trial', label: 'Free Trial' },
    { value: 'Standard', label: 'Standard' },
    { value: 'Teams', label: 'Teams' },
    { value: 'Enterprise', label: 'Enterprise' },
  ];

  constructor(
    private fb: FormBuilder,
    public dialogRef: MatDialogRef<NewProductModelComponent>,
    @Inject(MAT_DIALOG_DATA) public data: any,
  ) {}
  ngOnInit(): void {
    this.productForm = this.fb.group({
      product: ['', Validators.required],
      planType: ['', Validators.required],
    });
  }

  saveProduct() {
    if (this.productForm.valid) {
      console.log('Form Data:', this.productForm.value);
      // this.dialogRef.close(this.productForm.value);
    } else {
      this.productForm.markAllAsTouched();
    }
  }

  closeProductModel() {
    this.dialogRef.close();
  }
}
