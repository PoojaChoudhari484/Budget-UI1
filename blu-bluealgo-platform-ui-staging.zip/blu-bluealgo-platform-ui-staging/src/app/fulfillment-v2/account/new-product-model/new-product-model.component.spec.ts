import { ComponentFixture, TestBed } from '@angular/core/testing';

import { NewProductModelComponent } from './new-product-model.component';

describe('NewProductModelComponent', () => {
  let component: NewProductModelComponent;
  let fixture: ComponentFixture<NewProductModelComponent>;

  beforeEach(() => {
    TestBed.configureTestingModule({
      declarations: [NewProductModelComponent],
    });
    fixture = TestBed.createComponent(NewProductModelComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
