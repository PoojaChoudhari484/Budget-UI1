import {
  Component,
  ElementRef,
  HostListener,
  Input,
  ViewChild,
} from '@angular/core';
import { MatDialog } from '@angular/material/dialog';
import { FulfillmentV2Service } from '../../services/fulfillment-v2.service';
import { DeleteModelComponent } from '../../delete-model/delete-model.component';
import { NewAccountsModelComponent } from '../new-accounts-model/new-accounts-model.component';
import { DeleteAccountsModelComponent } from '../delete-accounts-model/delete-accounts-model.component';
import { UpdateAccountsModelComponent } from '../update-accounts-model/update-accounts-model.component';
import { AccountService } from '../../services/account.service';
import moment from 'moment';
import { IFulfillmentAccount } from '../../models/FulFillment.model';

@Component({
    selector: 'app-accounts',
    templateUrl: './accounts.component.html',
    styleUrls: ['./accounts.component.scss'],
    standalone: false
})
export class AccountsComponent {
  selectedUserId: number | null = null;
  selectedAccountId: string | null = null;
  allAccounts: IFulfillmentAccount[];
  isProductModel: boolean = false;
  currentPage: number = 1;
  totalPages: number = 1;
  pagesToShow: any[] = [];
  pageSize: number = 10;
  selectedProduct: any = null;
  public initialData: any = [];
  @Input() data: Array<any> = [];
  @Input() pagination: boolean = true;
  @ViewChild('dropdownRef') dropdownRef!: ElementRef;
  dropdownDirection: { [key: number]: 'up' | 'down' } = {};
  dropdownPosition = { top: 0, left: 0 };
  constructor(
    private dialog: MatDialog,
    private fulFillmentApiServices: AccountService,
  ) {}

  // CLICK ELSEWHERE THEN CLOSE MODEL ---------------------
  @HostListener('document:click', ['$event'])
  onDocumentClick(event: MouseEvent): void {
    const target = event.target as HTMLElement;

    // If click is outside the dropdown and toggle button
    const clickedInsideDropdown =
      target.closest('.dropdown-close') || target.closest('.dropdown-menu');

    if (!clickedInsideDropdown) {
      this.selectedUserId = null;
    }
  }

  // Date Formate

  formatDate(dateString: string): string {
    return moment(dateString).format('DD-MM-YYYY');
  }

  // GET ALL ACCOUNTS DATA ----------------------
  getAccountData(): void {
    this.fulFillmentApiServices.getAccountData().subscribe({
      next: (res) => {
        console.log(res);
        // this.allProducts = res?.list;
        this.initialData = res;
        this.totalPages = Math.ceil(this.initialData.length / this.pageSize);
        this.calculatePagesToShow();
        this.updateTableData();
      },
      error: (error) => {
        console.log(error);
      },
    });
  }

  ngOnInit(): void {
    console.log('this.selectedUserId', this.selectedUserId);
    this.getAccountData();
  }

  // CALCULATE PAGES TO SHOW ----------------------

  calculatePagesToShow() {
    const maxPages = 3; // Maximum pages to display at a time
    const pages = [];
    let startPage: number, endPage: number;

    if (this.totalPages <= maxPages) {
      // Total pages less than max so show all pages
      startPage = 1;
      endPage = this.totalPages;
    } else {
      // More pages than max so calculate start and end pages
      const maxPagesBeforeCurrentPage = Math.floor(maxPages / 2);
      const maxPagesAfterCurrentPage = Math.ceil(maxPages / 2) - 1;
      if (this.currentPage <= maxPagesBeforeCurrentPage) {
        // Close to the beginning; only show first pages
        startPage = 1;
        endPage = maxPages;
      } else if (
        this.currentPage + maxPagesAfterCurrentPage >=
        this.totalPages
      ) {
        // Close to the end; only show last pages
        startPage = this.totalPages - maxPages + 1;
        endPage = this.totalPages;
      } else {
        // Somewhere in the middle; show some pages before and after current page
        startPage = this.currentPage - maxPagesBeforeCurrentPage;
        endPage = this.currentPage + maxPagesAfterCurrentPage;
      }
    }

    // Create an array of pages to ng-repeat in the pager control
    for (let i = startPage; i <= endPage; i++) {
      pages.push(i);
    }

    this.pagesToShow = pages;
  }

  // UPDATE TABLE DATA -----------------------

  updateTableData() {
    const startIndex = (this.currentPage - 1) * this.pageSize;
    this.allAccounts = this.initialData.slice(
      startIndex,
      startIndex + this.pageSize,
    );
  }

  // SET CURRENT PAGE ---------------------

  setCurrentPage(page: number) {
    this.currentPage = page;
    this.calculatePagesToShow();
    this.updateTableData();
  }

  toggleDropdown(id: number, index: number, accountId?: any): void {
    const targetEl = document.getElementById('item' + index);
    this.selectedProduct = this.allAccounts[index];
    if (targetEl) {
      const rect = targetEl.getBoundingClientRect();
      const viewportHeight = window.innerHeight;
      const dropdownHeight = 120; // adjust based on dropdown size

      const shouldOpenUpward = rect.bottom + dropdownHeight > viewportHeight;

      this.dropdownDirection[index] = shouldOpenUpward ? 'up' : 'down';

      this.dropdownPosition = {
        top: shouldOpenUpward
          ? rect.top + window.scrollY - dropdownHeight
          : rect.top + window.scrollY + 30,
        left: rect.left + rect.width - 210,
      };
    }

    this.selectedUserId = this.selectedUserId === id ? null : id;
    this.selectedAccountId =
      this.selectedAccountId === accountId ? null : accountId;
    console.log('this.selectedUserId', this.selectedUserId);
  }

  getLastTwoIds(): number[] {
    const lastTwo = this.allAccounts.slice(-2);
    return lastTwo.map((product) => product.Id);
  }

  // ADD NEW ACCOUNT MODEL -----------------------
  openProductDialog(product?: any) {
    this.selectedUserId = null;
    this.dialog
      .open(NewAccountsModelComponent, {
        panelClass: 'custom-dialog-container',
        width: 'auto',
        height: 'auto',
        disableClose: true,
        data: product || null,
      })

      .afterClosed()
      .subscribe((result) => {
        if (result && result.ResponseCode >= 0) {
          // Call your list API again to refresh products
          this.getAccountData();
        }
      });
  }

  // Update ACCOUNT MODEL -----------------------

  openUpdateAccountDialog(product?: any) {
    console.log('Account Update Data.....', product.MobileNumber);

    this.dialog
      .open(UpdateAccountsModelComponent, {
        panelClass: 'custom-dialog-container',
        width: 'auto',
        height: 'auto',
        disableClose: true,
        data: product || null,
      })

      .afterClosed()
      .subscribe((result) => {
        if (result && result.ResponseCode >= 0) {
          // Call your list API again to refresh products
          this.getAccountData();
        }
      });
  }

  // DELETE MODEL ----------------------------
  openDeleteModel(productId: any) {
    console.log(productId);

    const dialogRef = this.dialog.open(DeleteAccountsModelComponent, {
      width: 'auto',
      panelClass: 'custom-dialog-container',
      disableClose: true,
      data: { AccountId: productId },
    });

    dialogRef.afterClosed().subscribe((result) => {
      if (result === 'deleted') {
        this.currentPage = 1;
        console.log('calling get api...');

        this.getAccountData();
      }
    });
  }
}
