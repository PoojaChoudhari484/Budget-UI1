import { Component } from '@angular/core';
import { MatDialog } from '@angular/material/dialog';
import { FulfillmentV2Service } from '../../services/fulfillment-v2.service';
import { DeletePermissionsModelComponent } from '../delete-permissions-model/delete-permissions-model.component';
import { AddSubModulePermissionsModelComponent } from '../add-sub-module-permissions-model/add-sub-module-permissions-model.component';
import { UpdateSubModulePermissionsModelComponent } from '../update-sub-module-permissions-model/update-sub-module-permissions-model.component';
import { ParamsService } from 'src/app/services/params.service';
import { IFulfillmentProductPermission } from '../../models/FulFillment.model';

@Component({
  selector: 'app-account-permissions',
  templateUrl: './account-permissions.component.html',
  styleUrls: ['./account-permissions.component.scss'],
  standalone: false
})
export class AccountPermissionsComponent {
  selectedUserId: number | null = null;
  permissions: IFulfillmentProductPermission[] = [];
  moduleWisePermissions: IformattedPermission[];
  isProductModel: boolean = false;
  queryParams: IFulFillmentPermissionsQueryParams;
  constructor(
    private dialog: MatDialog,
    private fulFillmentApiServices: FulfillmentV2Service,
    private paramsService: ParamsService,
  ) { }

  ngOnInit(): void {
    this.queryParams = this.paramsService.getAllQueryParams() as IFulFillmentPermissionsQueryParams;
    this.fulFillmentApiServices.getProductPermissions(this.queryParams.accountId, this.queryParams.productId).subscribe({
      next: (res) => {
        this.permissions = res?.list;
        this.moduleWisePermissions = this.formatPermissionDataArray(this.permissions);
        console.log(this.moduleWisePermissions);
      },
      error: (error) => {
        console.log(error);
      },
    });
  }

  formatPermissionDataArray(permissions: IFulfillmentProductPermission[]): IformattedPermission[] {
    return Array.from(new Set(permissions.map(x => x.perm_header)))
      .map(x => ({ subModule: x, permissions: permissions.filter(perm => perm.perm_header === x) }));
  }

  toggleDropdown(userId: number) {
    this.selectedUserId = this.selectedUserId === userId ? null : userId;
  }

  openAddSubModuleDialog() {
    this.dialog
      .open(AddSubModulePermissionsModelComponent, {
        panelClass: 'custom-dialog-container',
        width: '498px',
        height: 'auto',
        disableClose: true,
        data: null,
      })
      .afterClosed()
      .subscribe((result) => {
        console.log(result);
      });
  }

  openUpdateSubModuleDialog() {
    this.dialog
      .open(UpdateSubModulePermissionsModelComponent, {
        panelClass: 'custom-dialog-container',
        width: '498px',
        height: 'auto',
        disableClose: true,
        data: null,
      })
      .afterClosed()
      .subscribe((result) => {
        console.log(result);
      });
  }

  // DELETE MODEL ----------------------------
  openDeleteModel() {
    const dialogRef = this.dialog.open(DeletePermissionsModelComponent, {
      width: 'auto',
      panelClass: 'custom-dialog-container',
      disableClose: true,
    });

    dialogRef.afterClosed().subscribe((result) => {
      if (result === 'confirm') {
        // call delete API or handle logic
        console.log('Product deleted');
      }
    });
  }
}

interface IFulFillmentPermissionsQueryParams {
  accountId: string;
  productId: string;
}

interface IformattedPermission {
  subModule: string,
  permissions: IFulfillmentProductPermission[]
}
