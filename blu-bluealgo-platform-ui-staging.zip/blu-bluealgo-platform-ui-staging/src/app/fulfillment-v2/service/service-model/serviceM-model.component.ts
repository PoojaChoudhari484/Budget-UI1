import { Component, Inject } from '@angular/core';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { MAT_DIALOG_DATA, MatDialogRef } from '@angular/material/dialog';
import { FulfillmentV2Service } from '../../services/fulfillment-v2.service';
import { ToastrService } from 'ngx-toastr';
import { CommonFCService } from '../../services/common-fc.service';

@Component({
    selector: 'app-service-model',
    templateUrl: './serviceM-model.component.html',
    styleUrls: ['./serviceM-model.component.scss'],
    standalone: false
})
export class ServiceModeMComponent {
  serviceForm!: FormGroup;
  qualityTypeList: any[] = [];

  constructor(
    private fb: FormBuilder,
    public dialogRef: MatDialogRef<ServiceModeMComponent>,
    @Inject(MAT_DIALOG_DATA) public data: any,
    private fulfillmentService: FulfillmentV2Service,
    private commonFCService: CommonFCService,
    private toastr: ToastrService,
  ) {}

  ngOnInit(): void {
    this.getPlanDataForDropdown();
    this.serviceForm = this.fb.group({
      name: [
        {
          value: this.data?.name || '',
          disabled: this.data?.name,
        },
        Validators.required,
      ],
      usageQuality: [this.data?.subscription || '', Validators.required],
      validity: [
        this.data?.validForDay || '',
        [Validators.required, Validators.min(1)],
      ],
    });
  }
  getPlanDataForDropdown(): void {
    this.commonFCService.getAllPlanData().subscribe((res) => {
      if (res) {
        this.qualityTypeList = Object.keys(res).map((key) => ({
          value: key,
          label: res[key],
        }));
      }
    });
  }

  // SAVE PRODUCT -----------------------

  saveProduct() {
    if (this.serviceForm.valid) {
      const formData = this.serviceForm.getRawValue();
      const payload: any = {
        serviceCode: 'srv0018',
        name: formData.name,
        subscription: formData.usageQuality,
        validForDay: formData.validity,
      };

      if (this.data) {
        payload.Id = this.data.Id;

        this.fulfillmentService.updateService(payload).subscribe((res) => {
          let msg = 'Product Updated Successfully';

          if (res?.ResponseCode >= 0) {
            this.toastr.success(msg, 'Success');
            this.dialogRef.close(res);
          } else {
            this.toastr.error(res.ResponseMessage);
          }
        });
      } else {
        this.fulfillmentService.createService(payload).subscribe((res) => {
          if (res?.ResponseCode >= 0) {
            this.toastr.success('New Product Added Successfully', 'Success');
            this.dialogRef.close(res);
          } else {
            this.toastr.error(res.ResponseMessage);
          }
        });
      }
    } else {
      this.serviceForm.markAllAsTouched();
    }
  }

  closeProductModel() {
    this.dialogRef.close();
  }
}
