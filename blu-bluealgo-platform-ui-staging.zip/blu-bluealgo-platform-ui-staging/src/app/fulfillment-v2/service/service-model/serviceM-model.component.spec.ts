import { ComponentFixture, TestBed } from '@angular/core/testing';

import { ServiceModelComponent } from './serviceM-model.component';

describe('ServiceModelComponent', () => {
  let component: ServiceModelComponent;
  let fixture: ComponentFixture<ServiceModelComponent>;

  beforeEach(() => {
    TestBed.configureTestingModule({
      declarations: [ServiceModelComponent],
    });
    fixture = TestBed.createComponent(ServiceModelComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
