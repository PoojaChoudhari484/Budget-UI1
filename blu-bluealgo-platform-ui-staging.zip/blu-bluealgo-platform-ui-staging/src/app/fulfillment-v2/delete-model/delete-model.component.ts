import { Component, Inject } from '@angular/core';
import { MAT_DIALOG_DATA, MatDialogRef } from '@angular/material/dialog';
import { FulfillmentV2Service } from '../services/fulfillment-v2.service';
import { ToastrService } from 'ngx-toastr';

@Component({
    selector: 'app-delete-model',
    templateUrl: './delete-model.component.html',
    styleUrls: ['./delete-model.component.scss'],
    standalone: false
})
export class DeleteModelComponent {
  constructor(
    private dialogRef: MatDialogRef<DeleteModelComponent>,
    private fulfillmentService: FulfillmentV2Service,
    @Inject(MAT_DIALOG_DATA)
    public data: { Id: number; modelName: string; url: string },
    private toastr: ToastrService,
  ) {}

  confirmDelete() {
    if (this.data?.Id) {
      this.fulfillmentService
        .deleteData(this.data.Id, this.data.url)
        .subscribe({
          next: (res) => {
            if (res?.ResponseCode >= 0) {
              this.toastr.success(
                `${this.data.modelName} Deleted Successfully`,
                'Success',
              );
              this.dialogRef.close('deleted');
            }
          },
          error: (err) => {
            this.toastr.error(
              `Error while deleting ${this.data.modelName}`,
              'Error',
            );
            this.dialogRef.close('error');
          },
        });
    } else {
      console.warn('No Id provided!');
      this.dialogRef.close('error');
    }
  }

  closeDialog() {
    this.dialogRef.close('close');
  }
}
