import {
  Component,
  ElementRef,
  HostListener,
  Input,
  QueryList,
  ViewChild,
  ViewChildren,
} from '@angular/core';
import { FulfillmentV2Service } from '../services/fulfillment-v2.service';
import { ProductModelComponent } from '../product-model/product-model.component';
import { MatDialog } from '@angular/material/dialog';
import { DeleteModelComponent } from '../delete-model/delete-model.component';

@Component({
    selector: 'app-product',
    templateUrl: './product.component.html',
    styleUrls: ['./product.component.scss'],
    standalone: false
})
export class ProductComponent {
  selectedUserId: any | null = null;
  allProducts: any[];
  isProductModel: boolean = false;
  currentPage: number = 1;
  totalPages: number = 1;
  pagesToShow: any[] = [];
  pageSize: number = 10;
  selectedProduct: any = null;
  public initialData: Array<any> = [];
  @Input() data: Array<any> = [];
  @Input() pagination: boolean = true;
  @ViewChild('dropdownRef') dropdownRef!: ElementRef;
  dropdownDirection: { [key: number]: 'up' | 'down' } = {};
  dropdownPosition = { top: 0, left: 0 };

  constructor(
    private dialog: MatDialog,
    private fulFillmentApiServices: FulfillmentV2Service,
  ) {}

  // CLICK ELSEWHERE THEN CLOSE MODEL ---------------------
  @HostListener('document:click', ['$event'])
  onDocumentClick(event: MouseEvent): void {
    const target = event.target as HTMLElement;

    // If click is outside the dropdown and toggle button
    const clickedInsideDropdown =
      target.closest('.dropdown-close') || target.closest('.dropdown-menu');

    if (!clickedInsideDropdown) {
      this.selectedUserId = null;
    }
  }

  // GET ALL PRODUCTS DATA ----------------------
  getProductsData(): void {
    this.fulFillmentApiServices.getProducts('TODO').subscribe({
      next: (res) => {
        // this.allProducts = res?.list;
        this.initialData = res?.list;
        this.totalPages = Math.ceil(this.initialData.length / this.pageSize);
        this.calculatePagesToShow();
        this.updateTableData();
      },
      error: (error) => {
        console.log(error);
      },
    });
  }

  ngOnInit(): void {
    this.getProductsData();
  }

  // CALCULATE PAGES TO SHOW ----------------------

  calculatePagesToShow() {
    const maxPages = 3; // Maximum pages to display at a time
    const pages = [];
    let startPage: number, endPage: number;

    if (this.totalPages <= maxPages) {
      // Total pages less than max so show all pages
      startPage = 1;
      endPage = this.totalPages;
    } else {
      // More pages than max so calculate start and end pages
      const maxPagesBeforeCurrentPage = Math.floor(maxPages / 2);
      const maxPagesAfterCurrentPage = Math.ceil(maxPages / 2) - 1;
      if (this.currentPage <= maxPagesBeforeCurrentPage) {
        // Close to the beginning; only show first pages
        startPage = 1;
        endPage = maxPages;
      } else if (
        this.currentPage + maxPagesAfterCurrentPage >=
        this.totalPages
      ) {
        // Close to the end; only show last pages
        startPage = this.totalPages - maxPages + 1;
        endPage = this.totalPages;
      } else {
        // Somewhere in the middle; show some pages before and after current page
        startPage = this.currentPage - maxPagesBeforeCurrentPage;
        endPage = this.currentPage + maxPagesAfterCurrentPage;
      }
    }

    // Create an array of pages to ng-repeat in the pager control
    for (let i = startPage; i <= endPage; i++) {
      pages.push(i);
    }

    this.pagesToShow = pages;
  }

  // UPDATE TABLE DATA -----------------------

  updateTableData() {
    const startIndex = (this.currentPage - 1) * this.pageSize;
    this.allProducts = this.initialData.slice(
      startIndex,
      startIndex + this.pageSize,
    );
  }

  // SET CURRENT PAGE ---------------------

  setCurrentPage(page: number) {
    this.currentPage = page;
    this.calculatePagesToShow();
    this.updateTableData();
  }

  toggleDropdown(id: number, index: number): void {
    const targetEl = document.getElementById('item' + index);
    this.selectedProduct = this.allProducts[index];
    if (targetEl) {
      const rect = targetEl.getBoundingClientRect();
      const viewportHeight = window.innerHeight;
      const dropdownHeight = 120; // adjust based on dropdown size

      const shouldOpenUpward = rect.bottom + dropdownHeight > viewportHeight;

      this.dropdownDirection[index] = shouldOpenUpward ? 'up' : 'down';

      this.dropdownPosition = {
        top: shouldOpenUpward
          ? rect.top + window.scrollY - dropdownHeight
          : rect.top + window.scrollY + 30,
        left: rect.left + rect.width - 210,
      };
    }

    this.selectedUserId = this.selectedUserId === id ? null : id;
  }

  getLastTwoIds(): number[] {
    const lastTwo = this.allProducts.slice(-2);
    return lastTwo.map((product) => product.Id);
  }

  // ADD AND UPDATE MODEL -----------------------
  openProductDialog(product?: any) {
    this.selectedUserId = null;

    this.dialog
      .open(ProductModelComponent, {
        panelClass: 'custom-dialog-container',
        width: '498px',
        height: 'auto',
        disableClose: true,
        data: product || null,
      })
      .afterClosed()
      .subscribe((result) => {
        if (result && result.ResponseCode >= 0) {
          // Call your list API again to refresh products
          this.getProductsData();
        }
      });
  }

  // DELETE MODEL ----------------------------
  openDeleteModel(productId: any, product: string) {
    const dialogRef = this.dialog.open(DeleteModelComponent, {
      width: '500px',
      // panelClass: 'custom-dialog-container',
      disableClose: true,
      data: { Id: productId, modelName: product, url: 'delete_srv_master' },
    });

    dialogRef.afterClosed().subscribe((result) => {
      if (result === 'deleted') {
        this.currentPage = 1;
        this.getProductsData();
      }
    });
  }
}
