import { IBluFulfillmentProduct, IFulfillmentProduct } from "./FulFillment.model";

export function productToBluProduct(product: IFulfillmentProduct): IBluFulfillmentProduct{
    return{
        Id: product.Id,
        customerId: product.customerId,
        productId: product.serviceCode, 
        status: product.status,
        usesThreshold: product.usesThreshold, 
        productPlan: product.serviceName,
        fromDate: product.fromDate,   
        expiryDate: product.expiryDate,
        email: product.email,
        accountId: product.accountId,
        productName: product.moduleName,
        serviceUses: product.serviceUses,
    }
}

export function bluProductToProduct(product: IBluFulfillmentProduct): IFulfillmentProduct{
    return{
        Id: product.Id,
        customerId: product.customerId,
        serviceCode: product.productId,
        status: product.status,
        usesThreshold: product.usesThreshold, 
        serviceName: product.productPlan,
        fromDate: product.fromDate,   
        expiryDate: product.expiryDate,
        email: product.email,
        accountId: product.accountId,
        moduleName: product.productName,
        serviceUses: product.serviceUses,
    }
}