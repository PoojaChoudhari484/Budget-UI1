export interface IFulfillmentAccount {
  Id: number;
  AccountId: string;
  Username: string;
  TeamSpaceRoleAllocation?: any;
  Roles: string[];
  ViewPermission?: any;
  OtherPermission?: any;
  TeamSpaceRoleAllocations?: any;
  LastLogin: string;
  FailedAttempt: number;
  AccountNonLocked: boolean | string;
  LockTime?: string | null;
  EncPwd: string;
  Name: string;
  Password: string;
  CustomerId: string;
  ManagerId?: string | null;
  UserStatus: "Enable" | "Disable";
  AtDate: string;
  UserId: string;
  EmailId: string;
  MobileNumber: string;
  ConfrimPassword?: string | null;
  LastConnectionDate: string;
  UserType: "Customer" | "Admin" | string;
  ServiceType?: string | null;
  ModuleType?: string | null;
  LastName: string;
  Company: string;
}

export interface IFulfillmentServicePermission {
  id: number;
  module: string;
  subModule: string;
  component?: string;
  lavel: string;
  freeTrail: "TRUE" | "FALSE" | "";
  skuStandard: "TRUE" | "FALSE" | "";
  standardSetup?: "TRUE" | "FALSE" | "";
  enterprise: "TRUE" | "FALSE" | "";
}

export interface IFulfillmentProduct {
  Id: number;  // Row Id
  customerId: string;
  serviceCode: string;  // Product Id
  status: string;  // Product Status
  usesThreshold: string;
  serviceName: string;  // Product Plan
  fromDate: string;
  expiryDate: string;
  email: string;
  accountId: string;
  moduleName: string; // Product Name
  serviceUses: IFulfillmentService[];
}

export interface IBluFulfillmentProduct {
  Id: number;  // Row Id
  customerId: string;
  productId: string;  // Product Id
  status: string;  // Product Status
  usesThreshold: string;
  productPlan: string;  // Product Plan
  fromDate: string;
  expiryDate: string;
  email: string;
  accountId: string;
  productName: string; // Product Name
  serviceUses: IFulfillmentService[];
}


export interface IFulfillmentService {
  id: number;
  customerId: string;
  name: string;
  usesCount: number;
  totalQuantity: number;
  serviceCode: string;
  atDate: string;
  email: string;
  customer_srv_pk: number;
  fromDate: string;
  endDate: string;
  planType: string;
}

export interface IFulfillmentProductPermission {
  acId: string;
  customerId: string;
  id: string;
  name: string;
  perm_header: string;
  service_code: string;
}