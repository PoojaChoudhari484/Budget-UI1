import { Component } from '@angular/core';

@Component({
    selector: 'app-fulfillment-v2',
    templateUrl: './fulfillment-v2.component.html',
    styleUrls: ['./fulfillment-v2.component.scss'],
    standalone: false
})
export class FulfillmentV2Component {}
