import { Component, OnInit } from '@angular/core';
import { CommonModule } from '@angular/common';
import { RouterLink } from '@angular/router';
import { NgApexchartsModule } from 'ng-apexcharts';
import * as Highcharts from 'highcharts';
import 'highcharts/highcharts-3d';
import { HighchartsChartModule } from 'highcharts-angular';
import { DesignAutomationCommonService } from '../services/design-automation-common.service';

@Component({
    selector: 'app-homedash',
    imports: [
        CommonModule,
        RouterLink,
        NgApexchartsModule,
        HighchartsChartModule,
    ],
    templateUrl: './homedash.component.html',
    styleUrls: ['./homedash.component.scss']
})
export class HomedashComponent implements OnInit {
  Highcharts = Highcharts;
  costChartOptions: Highcharts.Options;
  marginChartOptions: Highcharts.Options;
  revenueChartOptions: Highcharts.Options;
  utilisedChartOptions: Highcharts.Options;
  towerChartOptions: Highcharts.Options;
  totalObj: {
    totalRevenue: number;
    totalUtilised: number;
    totalHeight: number;
    totalMargin: number;
    totalCost: number;
    feasible: string;
  } = {
    totalRevenue: 0,
    totalUtilised: 0,
    totalHeight: 0,
    totalMargin: 0,
    totalCost: 0,
    feasible: '',
  };
  response: any = {};
  cost: any = {};
  utilised: any = {};
  revenue: any = {};
  height: any = {};
  margin: any = {};
  total: any = {};

  constructor(private daCommonService: DesignAutomationCommonService) {
    this.initCostChart();
    this.initMarginChart();
    this.initRevenueChart();
    this.initUtilisedChart();
    this.initTowerChart();
  }

  ngOnInit(): void {
    this.getDashboardData();
  }

  getDashboardData() {
    this.daCommonService.getDashboardData().subscribe(
      (res) => {
        this.response = res;
        this.calTotal();
        this.initCostChart();
        this.initMarginChart();
        this.initRevenueChart();
        this.initUtilisedChart();
        this.initTowerChart();
      },
      (error) => {
        console.log(error);
      },
    );
  }

  calTotal() {
    this.cost = this.response?.Cost;
    this.utilised = this.response?.['FSI Utilised'];
    this.revenue = this.response?.Revenue;
    this.height = this.response?.['Tower Height'];
    this.margin = this.response?.Margin;
    this.total = this.response?.Total;

    this.totalObj.totalCost = this.total?.['Cost(Cr)'];
    this.totalObj.totalUtilised = this.total?.['FSI Utilized'];
    this.totalObj.totalRevenue = this.total?.['Revenue'];
    this.totalObj.totalHeight = this.total?.['Height(Mtr)'];
    this.totalObj.totalMargin = this.total?.['Margin%'];
    this.totalObj.feasible = this.total?.['Feasible'];
  }

  initCostChart() {
    this.costChartOptions = {
      chart: {
        // marginTop: 45,
        type: 'pie',
        backgroundColor: 'transparent',
        options3d: {
          enabled: true,
          alpha: 55,
          beta: 0,
        },
      },
      title: {
        text: '',
      },
      legend: {
        enabled: true,
        // align: 'center',
        // verticalAlign: 'top',
        y: 0,
        itemStyle: {
          color: '#333',
        },
      },
      plotOptions: {
        pie: {
          showInLegend: true,
          // colors: ['#19FB8B', '#FF645B'],
          innerSize: 100,
          depth: 40,
          dataLabels: {
            enabled: true,
            // format: '{point.name}: {point.percentage:.1f}%',
            style: {
              // color: 'white',
              fontWeight: 'bold',
            },
          },
        },
      },
      series: [
        {
          type: 'pie',
          name: 'Cost',
          data: [
            {
              name: `Administrative`,
              y: this.cost?.['Administrative_Cost'] ?? 0,
            },
            { name: `Construction`, y: this.cost?.['Construction_Cost'] ?? 0 },
            { name: `Land`, y: this.cost?.['Land_Cost'] ?? 0 },
          ],
        },
      ],
      credits: {
        enabled: false,
      },
    };
  }

  initMarginChart() {
    this.marginChartOptions = {
      chart: {
        // marginTop: 45,
        type: 'pie',
        backgroundColor: 'transparent',
        options3d: {
          enabled: true,
          alpha: 55,
          beta: 0,
        },
      },
      title: {
        text: '',
      },
      legend: {
        enabled: true,
        // align: 'center',
        // verticalAlign: 'top',
        y: 0,
        itemStyle: {
          color: '#333',
        },
      },
      plotOptions: {
        pie: {
          showInLegend: true,
          // colors: ['#19FB8B', '#FF645B'],
          innerSize: 100,
          depth: 40,
          dataLabels: {
            enabled: true,
            // format: '{point.name}: {point.percentage:.1f}%',
            style: {
              // color: 'white',
              fontWeight: 'bold',
            },
          },
        },
      },
      series: [
        {
          type: 'pie',
          name: 'Margin',
          data: [
            { name: `Cost`, y: this.margin?.['Cost'] ?? 0 },
            { name: `Flats`, y: this.margin?.['Flats'] ?? 0 },
            { name: `Revenue`, y: this.margin?.['Revenue'] ?? 0 },
            { name: `Total Revenue`, y: this.margin?.['Total revenue'] ?? 0 },
            { name: `Retail Revenue`, y: this.margin?.['retail revenue'] ?? 0 },
          ],
          // tooltip: {
          //   pointFormat: '{point.name}: {point.y}',
          // },
        },
      ],
      credits: {
        enabled: false,
      },
    };
  }

  initRevenueChart() {
    this.revenueChartOptions = {
      chart: {
        // marginTop: 45,
        type: 'pie',
        backgroundColor: 'transparent',
        options3d: {
          enabled: true,
          alpha: 55,
          beta: 0,
        },
      },
      title: {
        text: '',
      },
      legend: {
        enabled: true,
        // align: 'center',
        // verticalAlign: 'top',
        y: 0,
        itemStyle: {
          color: '#333',
        },
      },
      plotOptions: {
        pie: {
          showInLegend: true,
          depth: 40,
          dataLabels: {
            enabled: true,
            // format: '{point.name}: {point.percentage:.1f}%',
            style: {
              // color: 'white',
              fontWeight: 'bold',
            },
          },
        },
      },
      series: [
        {
          type: 'pie',
          // name: 'Waste',
          data: [
            { name: `Revenue 3BHKL`, y: this.revenue?.['Revenue 3BHKL'] ?? 0 },
            { name: `Revenue 3BHKS`, y: this.revenue?.['Revenue 3BHKS'] ?? 0 },
            {
              name: `Revenue 4.5BHK`,
              y: this.revenue?.['Revenue 4.5BHK'] ?? 0,
            },
            { name: `Revenue 4BHK`, y: this.revenue?.['Revenue 4BHK'] ?? 0 },
            {
              name: `Revenue Retail`,
              y: this.revenue?.['Revenue Retail'] ?? 0,
            },
          ],
          // tooltip: {
          //   pointFormat: '{point.name}: {point.percentage:.1f}%',
          // },
        },
      ],
      credits: {
        enabled: false,
      },
    };
  }

  initUtilisedChart() {
    this.utilisedChartOptions = {
      chart: {
        type: 'column', // Chart type
        backgroundColor: 'transparent',
        options3d: {
          enabled: true,
          alpha: 15,
          beta: 15,
          depth: 50,
          viewDistance: 25,
        },
      },
      title: {
        text: '', // Chart title
      },
      legend: {
        enabled: true,
        itemStyle: {
          color: '#333',
        },
      },
      xAxis: {
        categories: [
          '2% Allowance',
          'Amenity Area',
          'Carpet Area',
          'Consumption',
          'Efficiency',
          'FSI',
          'FSI Area',
          'Plot Area',
          'Saleable Area',
          'Total FSI Area',
          'Tower Builtup Area',
        ],
        labels: {
          style: {
            color: '#333',
          },
        },
      },
      yAxis: {
        title: {
          // text: 'Percentage (%)',
          style: {
            color: '#333',
          },
        },
        labels: {
          style: {
            color: '#333',
          },
        },
      },
      plotOptions: {
        column: {
          depth: 40,
          dataLabels: {
            enabled: true,
            // format: '{point.name}: {point.y:.1f}%',
            style: {
              color: '#333',
              fontWeight: 'bold',
            },
          },
        },
      },
      series: [
        {
          type: 'column', // Add the required type property here
          name: 'FSI Utilised',
          data: [
            {
              name: '2% Allowance',
              y: this.utilised?.['2% Allowance'] ?? 0,
              color: '#FF5733',
            },
            {
              name: 'Amenity Area',
              y: this.utilised?.['Amenity Area'] ?? 0,
              color: '#33FF57',
            },
            {
              name: 'Carpet Area',
              y: this.utilised?.['Carpet Area'] ?? 0,
              color: '#3357FF',
            },
            {
              name: 'Consumption',
              y: this.utilised?.['Consumption'] ?? 0,
              color: '#FFC300',
            },
            {
              name: 'Efficiency',
              y: this.utilised?.['Efficiency'] ?? 0,
              color: '#8E44AD',
            },
            { name: 'FSI', y: this.utilised?.['FSI'] ?? 0, color: '#44AD4D' },
            {
              name: 'FSI Area',
              y: this.utilised?.['FSI Area'] ?? 0,
              color: '#AD448C',
            },
            {
              name: 'Plot Area',
              y: this.utilised?.['Plot Area'] ?? 0,
              color: '#AD8C44',
            },
            {
              name: 'Saleable Area',
              y: this.utilised?.['Saleable Area'] ?? 0,
              color: '#44B3AD',
            },
            {
              name: 'Total FSI Area',
              y: this.utilised?.['Total FSI Area'] ?? 0,
              color: '#7E57C2',
            },
            {
              name: 'Tower Buildup Area',
              y: this.utilised?.['Tower Builtup Area'] ?? 0,
              color: '#E67E22',
            },
          ],
          // tooltip: {
          //   pointFormat: '{point.name}: {point.y:.1f}%',
          // },
        },
      ],
      credits: {
        enabled: false,
      },
    };
  }

  initTowerChart() {
    this.towerChartOptions = {
      chart: {
        type: 'column', // Chart type
        backgroundColor: 'transparent',
        options3d: {
          enabled: true,
          alpha: 15,
          beta: 15,
          depth: 50,
          viewDistance: 25,
        },
      },
      title: {
        text: '', // Chart title
      },
      legend: {
        enabled: true,
        itemStyle: {
          color: '#333',
        },
      },
      xAxis: {
        categories: [
          'Amenity',
          'Balance Height',
          'Floor to Floor Height',
          'Permitted Height',
          'Podium height',
          'Refuge',
          'Total no. of Floors',
          'Tower Height',
        ],
        labels: {
          style: {
            color: '#333',
          },
        },
      },
      yAxis: {
        title: {
          // text: 'Percentage (%)',
          style: {
            color: '#333',
          },
        },
        labels: {
          style: {
            color: '#333',
          },
        },
      },
      plotOptions: {
        column: {
          depth: 40,
          dataLabels: {
            enabled: true,
            // format: '{point.name}: {point.y:.1f}%',
            style: {
              color: '#333',
              fontWeight: 'bold',
            },
          },
        },
      },
      series: [
        {
          type: 'column', // Add the required type property here
          name: 'Tower Height',
          data: [
            {
              name: 'Amenity',
              y: this.height?.['Amenity'] ?? 0,
              color: '#FF5733',
            },
            {
              name: 'Balance Height',
              y: this.height?.['Balance_Height'] ?? 0,
              color: '#33FF57',
            },
            {
              name: 'Floor to Floor Height',
              y: this.height?.['Floor to Floor Height'] ?? 0,
              color: '#3357FF',
            },
            {
              name: 'Permitted Height',
              y: this.height?.['Permitted Height'] ?? 0,
              color: '#FFC300',
            },
            {
              name: 'Podium Height',
              y: this.height?.['Podium height'] ?? 0,
              color: '#8E44AD',
            },
            {
              name: 'Refuge',
              y: this.height?.['Refuge'] ?? 0,
              color: '#1ABC9C',
            },
            {
              name: 'Total no. of Floors',
              y: this.height?.['Total no. of Floors'] ?? 0,
              color: '#3498DB',
            },
            {
              name: 'Tower Height',
              y: this.height?.['TowerHeight'] ?? 0,
              color: '#9B59B6',
            },
          ],
          // tooltip: {
          //   pointFormat: '{point.name}: {point.y:.1f}%',
          // },
        },
      ],
      credits: {
        enabled: false,
      },
    };
  }
}
