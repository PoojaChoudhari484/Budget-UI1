export const DESIGN_BASE_URL = 'https://dev-designautomation.bluealgo.com/';
