import { Injectable } from '@angular/core';
import { HttpClient, HttpParams } from '@angular/common/http';
import { DESIGN_BASE_URL } from './design-base-url';

@Injectable({
  providedIn: 'root',
})
export class DesignAutomationCommonService {
  constructor(private http: HttpClient) {}

  submitInputs(model: any) {
    const params = new HttpParams().set('isWithoutBase', 'yes');
    return this.http.post<any>(DESIGN_BASE_URL + 'calculate', model, {
      params,
    });
  }

  getImageByShape(model: any) {
    const params = new HttpParams().set('isWithoutBase', 'yes');
    return this.http.post<any>(DESIGN_BASE_URL + 'get_image', model, {
      params,
    });
  }

  getDashboardData() {
    const params = new HttpParams().set('isWithoutBase', 'yes');
    return this.http.post<any>(
      DESIGN_BASE_URL + 'get_dashboard_data',
      {},
      { params },
    );
  }
}
