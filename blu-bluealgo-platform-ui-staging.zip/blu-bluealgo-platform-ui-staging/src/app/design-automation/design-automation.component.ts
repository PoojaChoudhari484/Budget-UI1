import { Component } from '@angular/core';

@Component({
    selector: 'app-design-automation',
    templateUrl: './design-automation.component.html',
    styleUrls: ['./design-automation.component.scss'],
    standalone: false
})
export class DesignAutomationComponent {}
