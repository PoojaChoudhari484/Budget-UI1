import {
  AfterViewInit,
  ChangeDetectorRef,
  Component,
  OnInit,
} from '@angular/core';
import { CommonModule } from '@angular/common';
import { RouterLink } from '@angular/router';
import * as maplibregl from 'maplibre-gl';
import { GoogleMap } from '@angular/google-maps';

@Component({
    selector: 'app-project-details',
    imports: [CommonModule, RouterLink, GoogleMap],
    templateUrl: './project-details.component.html',
    styleUrls: ['./project-details.component.scss']
})
export class ProjectDetailsComponent implements OnInit {
  center: google.maps.LatLngLiteral = {
    lat: 23.685,
    lng: 90.3563,
  };

  zoom = 4;
  display: any;

  constructor(private cd: ChangeDetectorRef) {}

  ngOnInit(): void {}

  // maplibre map
  // ngAfterViewInit(): void {
  //   const map = new maplibregl.Map({
  //     container: 'map',
  //     style: 'https://demotiles.maplibre.org/style.json', // Free MapLibre tiles
  //     center: [90.4125, 23.8103], // Example: Dhaka
  //     zoom: 4,
  //   });
  //
  //   map.on('load', () => {
  //     map.resize();
  //   });
  //   this.cd.detectChanges();
  // }

  moveMap(event: google.maps.MapMouseEvent) {
    if (event.latLng != null) this.center = event.latLng.toJSON();
  }
  move(event: google.maps.MapMouseEvent) {
    if (event.latLng != null) this.display = event.latLng.toJSON();
  }
}
