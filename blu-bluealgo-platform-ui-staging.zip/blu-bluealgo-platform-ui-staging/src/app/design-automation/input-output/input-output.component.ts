import { Component, OnInit } from '@angular/core';
import { CommonModule } from '@angular/common';
import { Router, RouterLink } from '@angular/router';
import {
  FormBuilder,
  FormGroup,
  FormsModule,
  ReactiveFormsModule,
  Validators,
} from '@angular/forms';
import { DesignAutomationCommonService } from '../services/design-automation-common.service';
import { direction } from 'html2canvas/dist/types/css/property-descriptors/direction';

@Component({
    selector: 'app-input-output',
    imports: [CommonModule, RouterLink, ReactiveFormsModule, FormsModule],
    templateUrl: './input-output.component.html',
    styleUrls: ['./input-output.component.scss']
})
export class InputOutputComponent implements OnInit {
  isOpenPopUp: boolean = false;
  frmGroup: FormGroup;
  responseObj: any = {};
  selectedFacing: string = 'sea';
  selectedPlan: string = '2d';
  selectedShape: string;
  tooltipPosition: string = '0px';
  sliderFillColor: string = 'linear-gradient(to right, #A5E979 0%, #E5E5E5 0%)';
  labels = [0, 3, 6, 9, 12, 15, 18];
  totalConfigurations: number = 0;

  constructor(
    private formBuilder: FormBuilder,
    private router: Router,
    private daCommonService: DesignAutomationCommonService,
  ) {}

  ngOnInit(): void {
    this.populateForm();
  }

  updateTooltipPosition(): void {
    const min = 0;
    const max = 18;
    const sliderValue = this.frmGroup.value.setbacks;
    const percentage = ((sliderValue - min) / (max - min)) * 100;
    this.tooltipPosition = `calc(${percentage}% - 15px)`; // Center align tooltip
    this.sliderFillColor = `linear-gradient(to right, #A5E979 ${percentage}%, #E5E5E5 ${percentage}%)`;
  }

  populateForm() {
    this.frmGroup = this.formBuilder.group({
      // fsi: [1.2],
      // towerHeight: [50],
      // acres: [''],
      // sqm: [''],
      // sqft: [92138],
      // carpetArea: [12000],
      // typeOfProject: ['Luxury'],
      // facing: ['mountain'],
      // setbacks: [3, [Validators.required, Validators.min(0), Validators.max(18)]],
      // rgArea: [0.1],
      // retailArea: [28000],
      // '3bhks': [20],
      // '3bhkl': [20],
      // '4bhk': [30],
      // '4.5bhk': [30],

      fsi: [''],
      towerHeight: [''],
      acres: [''],
      sqm: [''],
      sqft: [''],
      // carpetArea: [''],
      typeOfProject: [''],
      facing: [''],
      setbacks: [
        0,
        [Validators.required, Validators.min(0), Validators.max(18)],
      ],
      rgArea: [''],
      retailArea: [''],
      '3bhks': [0],
      '3bhkl': [0],
      '4bhk': [0],
      '4.5bhk': [0],
      landCost: [''],
      constructionCost: [''],
      administrativeCost: [''],
    });
  }

  openPopUp() {
    this.isOpenPopUp = true;
  }

  closePopUp() {
    this.isOpenPopUp = false;
  }

  generateModel(): any {
    console.log(this.getConfigurations());
    let frmValue = this.frmGroup.value;
    return {
      FSI: frmValue.fsi,
      'Tower Height': frmValue.towerHeight,
      'Plot area': frmValue.sqft,
      // 'Carpet area': frmValue.carpetArea,
      Configurations: this.getConfigurations(),
      'Type of project': frmValue.typeOfProject,
      Facing: this.selectedFacing ?? '',
      'Setbacks(m)': frmValue.setbacks,
      'RG Area(fraction)': frmValue.rgArea,
      'Retail Area': frmValue.retailArea,
      Coordinates: '19.07',
      'Rate(AI)': 45000,
      'Land Cost': frmValue.landCost,
      'Construction Cost': frmValue.constructionCost,
      'Administrative Cost': frmValue.administrativeCost,
    };
  }

  getConfigurations() {
    let frmValue = this.frmGroup.value;
    return {
      '3BHKS': frmValue['3bhks'],
      '3BHKL': frmValue['3bhkl'],
      '4BHK': frmValue['4bhk'],
      '4.5BHK': frmValue['4.5bhk'],
    };
  }

  submit() {
    let payload: any = { ...this.generateModel() };
    this.daCommonService.submitInputs(payload).subscribe((res) => {
      this.responseObj = res;
    });
  }

  goToMapVisualization() {
    this.router.navigateByUrl('/design-automation/map-visualization', {
      state: { shape: this.selectedShape },
    });
  }

  sliderValidation() {
    let setbacks = this.frmGroup.value.setbacks;
    if (setbacks > 18) this.frmGroup.patchValue({ setbacks: 18 });
    if (setbacks < 0 || !setbacks) this.frmGroup.patchValue({ setbacks: 0 });
  }

  unitConvert(inputType: string) {
    let frmValue = this.frmGroup.value;
    let acres: number = frmValue.acres;
    let sqm: number = frmValue.sqm;
    let sqft: number = frmValue.sqft;
    if (inputType === 'acres') {
      sqm = acres * 4046.856422;
      sqft = sqm * 10.7639104;
    } else if (inputType === 'sqm') {
      acres = sqm / 4046.856422;
      sqft = sqm * 10.7639104;
    } else if (inputType === 'sqft') {
      sqm = sqft / 10.7639104;
      acres = sqm / 4046.856422;
    }
    this.frmGroup.patchValue({
      acres: acres,
      sqm: sqm,
      sqft: sqft,
    });
  }

  calTotalConfiguration(type: string) {
    let frmvalue = this.frmGroup.value;

    this.totalConfigurations =
      frmvalue?.['3bhkl'] +
      frmvalue?.['3bhks'] +
      frmvalue?.['4bhk'] +
      frmvalue?.['4.5bhk'];

    if (this.totalConfigurations > 100) {
      let difference = this.totalConfigurations - 100;
      this.frmGroup.patchValue({ [type]: frmvalue[type] - difference });
      frmvalue = this.frmGroup.value;
      this.totalConfigurations =
        frmvalue?.['3bhkl'] +
        frmvalue?.['3bhks'] +
        frmvalue?.['4bhk'] +
        frmvalue?.['4.5bhk'];
    }
  }
}
