import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';

import { DesignAutomationRoutingModule } from './design-automation-routing.module';
import { DesignAutomationComponent } from './design-automation.component';
import { HeaderComponent } from './header/header.component';
import { GoogleMapsModule } from '@angular/google-maps';
import { PaintTestComponent } from './paint-test/paint-test.component';
import { FormsModule } from '@angular/forms';

@NgModule({
  declarations: [DesignAutomationComponent, PaintTestComponent],
  imports: [
    CommonModule,
    DesignAutomationRoutingModule,
    HeaderComponent,
    GoogleMapsModule,
    FormsModule,
  ],
})
export class DesignAutomationModule {}
