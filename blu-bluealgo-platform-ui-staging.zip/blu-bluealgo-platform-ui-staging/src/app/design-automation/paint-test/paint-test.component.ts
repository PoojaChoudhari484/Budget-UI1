import { Component, ElementRef, OnInit, ViewChild } from '@angular/core';

@Component({
    selector: 'app-paint-test',
    templateUrl: './paint-test.component.html',
    styleUrls: ['./paint-test.component.scss'],
    standalone: false
})
export class PaintTestComponent implements OnInit {
  @ViewChild('svgIframe') svgIframe: ElementRef | undefined;
  design: any = {};
  svgJson: any[] = [];

  ngOnInit(): void {}

  getDesign() {
    if (this.svgIframe) {
      const iframe: HTMLIFrameElement = this.svgIframe.nativeElement;
      iframe.contentWindow?.location.reload();
    }
    const svgString = localStorage.getItem('svgedit-default');
    if (svgString) {
      console.log('SVG:', svgString);
      this.svgToJson();
      const encodedSvg = encodeURIComponent(svgString).replace(
        /%([0-9A-F]{2})/g,
        (match, p1) => String.fromCharCode(parseInt(p1, 16)),
      );
      const svgBase64 = btoa(encodedSvg); // Encode to Base64
      this.design = `data:image/svg+xml;base64,${svgBase64}`; // Convert to Data URL
      console.log('Base64:', this.design);
    }
  }

  svgToJson() {
    const svgString = localStorage.getItem('svgedit-default') || ''; // Get SVG from localStorage
    if (svgString) {
      const parser = new DOMParser();
      const svgDoc = parser.parseFromString(svgString, 'image/svg+xml');
      let jsonDesign: any[] = [];
      svgDoc.querySelectorAll('*').forEach((element) => {
        const elementJson: {
          type: string;
          attributes: { [key: string]: string };
        } = {
          type: element.tagName,
          attributes: Array.from(element.attributes).reduce(
            (acc, attr) => {
              acc[attr.name] = attr.value;
              return acc;
            },
            {} as { [key: string]: string },
          ),
        };
        // if (elementJson?.type !== 'svg' && elementJson?.type !== 'g' && elementJson?.type !== 'title') {
        // }
        jsonDesign.push(elementJson);
      });
      this.svgJson = jsonDesign;
      console.log('JSON:', this.svgJson);
    }
  }
}
