import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { AuthGuard } from '../core/guard/auth.guard';
import { DesignAutomationComponent } from './design-automation.component';
import { MapVisualisationComponent } from './map-visualisation/map-visualisation.component';
import { PlanOptionComponent } from './plan-option/plan-option.component';
import { InputOutputComponent } from './input-output/input-output.component';
import { ProjectDetailsComponent } from './project-details/project-details.component';
import { HomedashComponent } from './homedash/homedash.component';
import { PaintTestComponent } from './paint-test/paint-test.component';

const routes: Routes = [
  {
    path: '',
    component: DesignAutomationComponent,
    canActivate: [AuthGuard],
    children: [
      { path: '', redirectTo: 'project-details', pathMatch: 'full' },
      {
        path: 'dashboard',
        canActivate: [AuthGuard],
        component: HomedashComponent,
      },
      {
        path: 'map-visualization',
        canActivate: [AuthGuard],
        component: MapVisualisationComponent,
      },
      {
        path: 'plan-option',
        canActivate: [AuthGuard],
        component: PlanOptionComponent,
      },
      {
        path: 'input-output',
        canActivate: [AuthGuard],
        component: InputOutputComponent,
      },
      {
        path: 'project-details',
        canActivate: [AuthGuard],
        component: ProjectDetailsComponent,
      },
      {
        path: 'paint-test',
        canActivate: [AuthGuard],
        component: PaintTestComponent,
      },
    ],
  },
];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule],
})
export class DesignAutomationRoutingModule {}
