import { Component } from '@angular/core';
import { CommonModule } from '@angular/common';
import { RouterLink } from '@angular/router';

@Component({
    selector: 'app-plan-option',
    imports: [CommonModule, RouterLink],
    templateUrl: './plan-option.component.html',
    styleUrls: ['./plan-option.component.scss']
})
export class PlanOptionComponent {}
