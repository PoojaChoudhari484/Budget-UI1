export const TEMPLATE_FUNCTIONS = {
  coverImage: 'Cover Image',
  qrCode: 'QR Code',
  logo: 'Logo',
  images: 'Images',
  amountInWordIndia: 'Amount (India)',
  amountInWord: 'Amount (World)',
  calculation: 'Calculation',
  dateFormat: 'Date Format',
  commaIndia: 'Comma (India)',
  comma: 'Comma (World)',
  numberFormat: 'Number Format',
  textValidation: 'Text Validation',
  eSign: 'E-Sign',
  approval: 'Approval',
};

export const TAB_TITLES = {
  dataFields: 'Data',
  template: 'Template',
  mainClause: 'Clause',
  rule: 'Rule',
  mainFunction: 'Function',
};
