import { Injectable } from '@angular/core';
import { Subject } from 'rxjs';
import { TemplateRuleEngine } from 'src/app/template/entities/template-rule-engine';

@Injectable({
  providedIn: 'root', // Ensures a single shared instance across the app
})
export class StateManagementService {
  currentStateSub: Subject<string>;
  currentEditingTemplate: any = null;
  currentEditingState: any = null;
  templateFunction: Subject<string>;
  refreshTemplates: Subject<any>;
  editTemplateTriggered: Subject<any>;
  templateRuleEditor: Subject<TemplateRuleEngine | null>;
  assetListOptions: Subject<{
    type: string;
    list: any[];
    isCoverQrcodeLogo?: boolean;
  } | null>;
  addPlaceHolderToCurrentTemplate = new Subject<string>();

  constructor() {
    this.currentStateSub = new Subject<string>();
    this.templateFunction = new Subject<string>();
    this.refreshTemplates = new Subject<any>();
    this.editTemplateTriggered = new Subject<any>();
    this.templateRuleEditor = new Subject<TemplateRuleEngine | null>();
    this.assetListOptions = new Subject<{
      type: string;
      list: any[];
      isCoverQrcodeLogo?: boolean;
    } | null>();
  }

  setCurrentState(value: string) {
    this.currentStateSub.next(value);
    this.currentEditingState = value;
  }

  onTemplateFunctionChange(value: string) {
    this.templateFunction.next(value);
  }

  emitTemplateRefresh(value: any) {
    this.refreshTemplates.next(value);
  }

  emitTemplateEdit(value: any) {
    this.editTemplateTriggered.next(value);
  }

  emitAssetListOptions(
    value: { type: string; list: any[]; isCoverQrcodeLogo?: boolean } | null,
  ) {
    this.assetListOptions.next(value);
  }
}
