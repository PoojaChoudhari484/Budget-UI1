import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { AuthenticationComponent } from './authentication.component';
import { LntAuthRedirectComponent } from './lnt-auth-redirect/lnt-auth-redirect.component';
import { AuthenticationRoutingModule } from './authentication-routing.module';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';

@NgModule({
  imports: [
    FormsModule,
    ReactiveFormsModule,
    CommonModule,
    AuthenticationRoutingModule,
  ],
  declarations: [AuthenticationComponent, LntAuthRedirectComponent],
})
export class AuthenticationModule {}
