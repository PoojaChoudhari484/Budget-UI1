/* eslint-disable @typescript-eslint/naming-convention */
import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';

@Injectable({
  providedIn: 'root', // Ensures a single shared instance across the app
})
export class AuthenticationService {
  constructor(private http: HttpClient) {}

  ADlogin(payload: any): any {
    return this.http.post(`auth/ad_group_sign_in`, payload).toPromise();
  }

  login(payload: any) {
    return this.http.post(`auth/group_sign_in`, payload).toPromise();
  }


  


}
