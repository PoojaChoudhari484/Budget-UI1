import { Component, OnInit } from '@angular/core';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { ToastrService } from 'ngx-toastr';
import { LocalStorageService } from '../core/services/local-storage.service';
import { ERROR_MSGS } from '../core/constants';
import { AuthenticationService } from './authentication.service';
import { Router, RouterStateSnapshot } from '@angular/router';
import { environment } from 'src/environments/environment';

@Component({
    selector: 'app-authentication',
    templateUrl: './authentication.component.html',
    styleUrls: ['./authentication.component.scss'],
    standalone: false
})
export class AuthenticationComponent implements OnInit {
  signInForm!: FormGroup;
  showPass = false;
  askPassword = false;

  constructor(
    private fb: FormBuilder,
    private toastr: ToastrService,
    private localStorageService: LocalStorageService,
    private authService: AuthenticationService,
    private router: Router,
  ) {}

  ngOnInit() {
    this.createForm();
  }

  createForm() {
    this.signInForm = this.fb.group({
      username: ['', [Validators.required, Validators.email]],
      password: [{ value: '', disabled: true }, Validators.required],
    });
  }

  onSubmit() {
    console.log('Submit called');
    const usernameControl = this.signInForm.get('username');
    const passwordControl = this.signInForm.get('password');

    // Validate username first
    if (!usernameControl?.valid) {
      this.toastr.error('Please provide a valid email address.', 'Error');
      return;
    }

    const username = usernameControl.value;

    // Check if Microsoft login is required
    if (username?.includes('@larsentoubro.com')) {
      this.microsoftLogin();
    } else {
      // Enable password field if not already enabled
      if (!this.askPassword) {
        console.log('Enabling password input...');
        this.enablePasswordInput();
        return;
      }

      // Validate and proceed with normal login
      if (passwordControl?.value) {
        console.log('Proceeding with normal login...');
        // this.tempDataSet(); //TODO for login bypass
        // this.router.navigate(['/']); //TODO for login bypass
        this.normalLogin();
      } else {
        this.toastr.error('Password is required.', 'Error');
      }
    }
  }

  tempDataSet() {
    localStorage.setItem(
      'currentLocation',
      'eyJpZCI6MjE3LCJncm91cElkIjo2OCwiY3VzdG9tZXJJZCI6ImN1czEwMDgxMiIsIm1hc3RlcklkIjoiY3VzMTAwMTE4LmdycDY4IiwiZ3JvdXBOYW1lIjoiVGVzdEdyb3VwIn0=',
    );
    localStorage.setItem('customerId', 'cus100812');
    localStorage.setItem(
      'token',
      'eyJhbGciOiJIUzUxMiJ9.eyJzdWIiOiJiaXpsZW10ZXN0QGdtYWlsLmNvbSIsImlhdCI6MTczODYwMzY5OCwiZXhwIjoxNzM4NjkwMDk4fQ.-6hhZk8Y9vxteipiWbHdSmytdjj5HwIOxHePYYXCzF8YlXZ3V04xxw6BvZrZEbkbTls9DhJ6mJyLwxyE9ZE44A',
    );
    localStorage.setItem(
      'user',
      'eyJ1c2VybmFtZSI6ImJpemxlbXRlc3RAZ21haWwuY29tIiwiZW1haWwiOiJiaXpsZW10ZXN0QGdtYWlsLmNvbSIsInJvbGVzIjpbXSwidmlld1Blcm1pc3Npb24iOlt7IklkIjowLCJWaWV3TGFiZWwiOiJsZWZ0LXBhbmVsLWhvbWUiLCJWaWV3VmFsdWUiOiJ0cnVlIiwiVmlld1NjcmVlbiI6bnVsbCwiQ3VzdG9tZXJJZCI6ImN1czEwMDgxMiJ9LHsiSWQiOjAsIlZpZXdMYWJlbCI6ImxlZnQtcGFuZWwtdGVtcGxhdGVCdWlsZGVyIiwiVmlld1ZhbHVlIjoidHJ1ZSIsIlZpZXdTY3JlZW4iOm51bGwsIkN1c3RvbWVySWQiOiJjdXMxMDA4MTIifSx7IklkIjowLCJWaWV3TGFiZWwiOiJsZWZ0LXBhbmVsLWRlc2lnbkNhbGN1bGF1cyIsIlZpZXdWYWx1ZSI6InRydWUiLCJWaWV3U2NyZWVuIjpudWxsLCJDdXN0b21lcklkIjoiY3VzMTAwODEyIn0seyJJZCI6MCwiVmlld0xhYmVsIjoibGVmdC1wYW5lbC1kZXBhcnRtZW50RGFzaEJvYXJkIiwiVmlld1ZhbHVlIjoidHJ1ZSIsIlZpZXdTY3JlZW4iOm51bGwsIkN1c3RvbWVySWQiOiJjdXMxMDA4MTIifSx7IklkIjowLCJWaWV3TGFiZWwiOiJsZWZ0LXBhbmVsLWFzc3RlTGlicmFyeSIsIlZpZXdWYWx1ZSI6InRydWUiLCJWaWV3U2NyZWVuIjpudWxsLCJDdXN0b21lcklkIjoiY3VzMTAwODEyIn0seyJJZCI6MCwiVmlld0xhYmVsIjoibGVmdC1wYW5lbC10b29scyIsIlZpZXdWYWx1ZSI6InRydWUiLCJWaWV3U2NyZWVuIjpudWxsLCJDdXN0b21lcklkIjoiY3VzMTAwODEyIn0seyJJZCI6MCwiVmlld0xhYmVsIjoibGVmdC1wYW5lbC1zZkNvbmZpZ3VyYXRpb25Ub29sIiwiVmlld1ZhbHVlIjoidHJ1ZSIsIlZpZXdTY3JlZW4iOm51bGwsIkN1c3RvbWVySWQiOiJjdXMxMDA4MTIifSx7IklkIjowLCJWaWV3TGFiZWwiOiJsZWZ0LXBhbmVsLWludGVncmF0aW9uIiwiVmlld1ZhbHVlIjoidHJ1ZSIsIlZpZXdTY3JlZW4iOm51bGwsIkN1c3RvbWVySWQiOiJjdXMxMDA4MTIifSx7IklkIjowLCJWaWV3TGFiZWwiOiJsZWZ0LXBhbmVsLXNldHRpbmdzIiwiVmlld1ZhbHVlIjoidHJ1ZSIsIlZpZXdTY3JlZW4iOm51bGwsIkN1c3RvbWVySWQiOiJjdXMxMDA4MTIifSx7IklkIjowLCJWaWV3TGFiZWwiOiJsZWZ0LXBhbmVsLWZ1bGZpbGxtZW50IiwiVmlld1ZhbHVlIjoidHJ1ZSIsIlZpZXdTY3JlZW4iOm51bGwsIkN1c3RvbWVySWQiOiJjdXMxMDA4MTIifSx7IklkIjowLCJWaWV3TGFiZWwiOiJsZWZ0LXBhbmVsLXN1cnZleSIsIlZpZXdWYWx1ZSI6InRydWUiLCJWaWV3U2NyZWVuIjpudWxsLCJDdXN0b21lcklkIjoiY3VzMTAwODEyIn0seyJJZCI6MCwiVmlld0xhYmVsIjoibGVmdC1wYW5lbC13b3Jrc3BhY2UiLCJWaWV3VmFsdWUiOiJ0cnVlIiwiVmlld1NjcmVlbiI6bnVsbCwiQ3VzdG9tZXJJZCI6ImN1czEwMDgxMiJ9XSwib3RoZXJQZXJtaXNzaW9uIjp7ImRpdl9lZGl0IjpmYWxzZSwiZGl2X2N1c3RvbWVyIjp0cnVlfSwidXNlciI6eyJVc2VybmFtZSI6ImJpemxlbXRlc3RAZ21haWwuY29tIiwiVGVhbVNwYWNlUm9sZUFsbG9jYXRpb24iOm51bGwsIlJvbGVzIjpbXSwiVmlld1Blcm1pc3Npb24iOm51bGwsIk90aGVyUGVybWlzc2lvbiI6bnVsbCwiVGVhbVNwYWNlUm9sZUFsbG9jYXRpb25zIjpudWxsLCJMYXN0TG9naW4iOiIyMDI1LTAyLTAzVDE3OjI4OjE5LjIzNyswMDowMCIsIkZhaWxlZEF0dGVtcHQiOjAsIkFjY291bnROb25Mb2NrZWQiOiJ0cnVlIiwiTG9ja1RpbWUiOm51bGwsIkFjY291bnRJZCI6bnVsbCwiRW5jUHdkIjoic0Y5ZjBxREU5RW0vZ2VxblZYVTJjd3g5ZnlaUWFvVENmZ3I1UHZYSGQ5dExTTnJIbUNuMXkydE0wblVKTU4rZCIsIk5hbWUiOiJCaXpsZW1UZWFtIiwiSWQiOjgxMiwiUGFzc3dvcmQiOiIkMmEkMTAkRy9ObTdhWVY4VGlTUTZxclJnQ1V3ZXJJelZXU2tBMVhaNi5uUTkzUGNEakdxcUtUWXI1eEciLCJBdERhdGUiOiIyMDI0LTA4LTI5VDA5OjM2OjQxLjAwMCswMDowMCIsIkNvbXBhbnkiOm51bGwsIkxhc3RDb25uZWN0aW9uRGF0ZSI6bnVsbCwiTGFzdE5hbWUiOiJMYXN0TmFtZSIsIkNvbmZyaW1QYXNzd29yZCI6bnVsbCwiU2VydmljZVR5cGUiOm51bGwsIk1vZHVsZVR5cGUiOm51bGwsIkN1c3RvbWVySWQiOiJjdXMxMDA4MTIiLCJFbWFpbElkIjoiYml6bGVtdGVzdEBnbWFpbC5jb20iLCJNb2JpbGVOdW1iZXIiOiIiLCJVc2VyU3RhdHVzIjoiRW5hYmxlIiwiVXNlclR5cGUiOiJOb3JtYWxVc2VyIiwiVXNlcklkIjoiYml6bGVtdGVzdEBnbWFpbC5jb20iLCJNYW5hZ2VySWQiOiJjdXMxMDAxMTgifSwicHJvZmlsZUltZyI6Imh0dHBzOi8vaW1nLmljb25zOC5jb20vY29sb3IvMngvYWRtaW5pc3RyYXRvci1tYWxlLnBuZyIsImN1c3RvbWVySWQiOiJjdXMxMDA4MTIiLCJhY2Nlc3NUb2tlbiI6ImV5SmhiR2NpT2lKSVV6VXhNaUo5LmV5SnpkV0lpT2lKaWFYcHNaVzEwWlhOMFFHZHRZV2xzTG1OdmJTSXNJbWxoZENJNk1UY3pPRFl3TXpZNU9Dd2laWGh3SWpveE56TTROamt3TURrNGZRLi02aGhaazhZOXZ4dGVpcGlXYkhkU215dGRqajVId0lPeEhlUFlZWEN6RjhZbFhaM1YwNHh4dzZCdlpyWkVia2JUbHM5RGhKNm1KeUx3eHlFOVpFNDRBIiwidG9rZW5UeXBlIjoiQmVhcmVyIiwiSWQiOjgxMiwiQ3VzdG9tZXJJZCI6ImN1czEwMDgxMiIsIlVzZXJJZCI6ImJpemxlbXRlc3RAZ21haWwuY29tIn0=',
    );
    localStorage.setItem('username', 'bizlemtest@gmail.com');
  }

  enablePasswordInput() {
    this.askPassword = true;
    this.signInForm.get('password')?.enable();
  }

  microsoftLogin() {
    if (!environment.microsoftLoginUrl) {
      this.toastr.error('Microsoft login URL is not configured.', 'Error');
      return;
    }
    window.location.href = environment.microsoftLoginUrl;
  }

  async normalLogin() {
    const passwordControl = this.signInForm.get('password');

    // Validate password
    if (!passwordControl?.valid) {
      this.toastr.error('Password is required.', 'Error');
      return;
    }

    const payload = this.signInForm.value;
    try {
      const response: any = await this.authService.login(payload);
      if (response) {
        this.handleLoginSuccess(response);
      } else {
        this.toastr.error('Error while logging in.', 'Error');
      }
    } catch (ex: any) {
      this.handleLoginError(ex);
    }
  }

  handleLoginSuccess(response: any) {
    this.signInForm.reset();
    this.toastr.success(
      `${response.user.Name}${response.user.LastName ? ' ' + response.user.LastName : ''}`,
      'Welcome:',
    );
    this.localStorageService.loginUser(response);
    this.router.navigate(['/']);
  }

  handleLoginError(ex: any) {
    const errorMessage = ex?.error?.message || ERROR_MSGS.internalError;
    this.toastr.error(errorMessage, 'Error');
  }
}
