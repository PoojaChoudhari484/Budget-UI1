import { ComponentFixture, TestBed } from '@angular/core/testing';

import { LntAuthRedirectComponent } from './lnt-auth-redirect.component';

describe('LntAuthRedirectComponent', () => {
  let component: LntAuthRedirectComponent;
  let fixture: ComponentFixture<LntAuthRedirectComponent>;

  beforeEach(() => {
    TestBed.configureTestingModule({
      declarations: [LntAuthRedirectComponent],
    });
    fixture = TestBed.createComponent(LntAuthRedirectComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
