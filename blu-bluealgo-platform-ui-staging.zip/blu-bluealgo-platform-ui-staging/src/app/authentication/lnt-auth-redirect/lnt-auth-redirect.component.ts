import { Component, OnInit } from '@angular/core';
import { ToastrService } from 'ngx-toastr';
import { LocalStorageService } from '../../core/services/local-storage.service';
import { ERROR_MSGS } from '../../core/constants';
import { AuthenticationService } from '../authentication.service';
import { ActivatedRoute, Router, RouterStateSnapshot } from '@angular/router';

@Component({
    selector: 'app-lnt-auth-redirect',
    templateUrl: './lnt-auth-redirect.component.html',
    styleUrls: ['./lnt-auth-redirect.component.scss'],
    standalone: false
})
export class LntAuthRedirectComponent implements OnInit {
  constructor(
    private toastr: ToastrService,
    private localStorageService: LocalStorageService,
    private authService: AuthenticationService,
    private router: Router,
    private route: ActivatedRoute,
  ) {}

  async ngOnInit() {
    try {
      const token = this.route.snapshot.queryParamMap.get('id_token');
      const email = this.route.snapshot.queryParamMap.get('email');
      localStorage.setItem('AD_token', token ? token : '');

      if (email) {
        const payload: {} = {
          username: email,
        };
        const response: any = await this.authService.ADlogin(payload);
        if (response) {
          this.router.navigate(['/home']);
          this.toastr.success(
            `${response.user.Name}${response.user.LastName ? ' ' + response.user.LastName : ''}`,
            'Welcome:',
          );

          this.localStorageService.loginUser(response);
        } else {
          this.toastr.error('Error while login', 'Error');
        }
      }
    } catch (ex: any) {
      if (ex && ex.error && ex.error.message) {
        this.toastr.error(ex.error.message, 'Error');
        return;
      }
      this.toastr.error(ERROR_MSGS.internalError, 'Error');
    }
  }
}
