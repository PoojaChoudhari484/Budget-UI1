import { NgModule } from '@angular/core';
import { BrowserAnimationsModule } from '@angular/platform-browser/animations';
import { BrowserModule } from '@angular/platform-browser';

import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import {
  NgxUiLoaderConfig,
  NgxUiLoaderModule,
  PB_DIRECTION,
  POSITION,
  SPINNER,
} from 'ngx-ui-loader';
import { HTTP_INTERCEPTORS, provideHttpClient, withInterceptorsFromDi } from '@angular/common/http';
import { RequestInterceptor } from './core/interceptor/request-interceptor';
import { AuthGuard } from './core/guard/auth.guard';
import { ToastrModule } from 'ngx-toastr';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { CommonModule } from '@angular/common';
import { ResponseInterceptor } from './core/interceptor/response.interceptor';
import { SearchPipe } from './search.pipe';
import { DocumentSetupDialogComponent } from './smartformconfig/dialog/document-setup-dialog/document-setup-dialog.component';
import { PheModule } from './phe/phe.module';
import { HydrantHighZoneComponent } from './firefighting/hydrant-high-zone/hydrant-high-zone.component';
import { SprinklerHighZoneComponent } from './firefighting/sprinkler-high-zone/sprinkler-high-zone.component';
import { HydrantJockeyComponent } from './firefighting/hydrant-jockey/hydrant-jockey.component';
import { SprinklerJockeyComponent } from './firefighting/sprinkler-jockey/sprinkler-jockey.component';
import { FFSummaryComponent } from './firefighting/ff-summary/ff-summary.component';
import { SummaryCalculationFfComponent } from './firefighting/ff-summary/tabs/summary-calculation-ff/summary-calculation-ff.component';
import { DesignCalculusSubpageComponent } from './firefighting/design-calculus-subpage/design-calculus-subpage.component';
import { FireFightingModule } from './firefighting/firefighting.module';
import { IgbcModule } from './igbc/igbc.module';
import { ElectricalModule } from './electrical/electrical.module';
import { HvacModule } from './hvac/hvac.module';
import { NgSelectModule } from '@ng-select/ng-select';
import { TutorialModule } from './tutorial/tutorial.module';
import { MatButtonModule } from '@angular/material/button';
import { MatIconModule } from '@angular/material/icon';
import { MatTooltipModule } from '@angular/material/tooltip';
import { SharedCCModule } from "./shared-cc/shared-cc.module";
import { VersionControlComponent } from './version-control/version-control.component';
import { VersionItemsComponent } from './version-control/version-items/version-items.component';
import { FmpComponent } from './fmp/fmp.component';
import { NZ_ICONS, NzIconModule } from 'ng-zorro-antd/icon';
import {
  PlusSquareOutline,
  MinusSquareOutline,
  FileOutline
} from '@ant-design/icons-angular/icons';
import { BudgetAllocationModule } from './budget-allocation/budget-automation.module';
import { RouterModule } from '@angular/router';


const ngxUiLoaderConfig: NgxUiLoaderConfig = {
  bgsColor: 'red',
  bgsPosition: POSITION.bottomCenter,
  bgsSize: 40,
  bgsType: SPINNER.rectangleBounce, // background spinner type
  fgsType: SPINNER.rectangleBounce, // foreground spinner type
  pbDirection: PB_DIRECTION.leftToRight, // progress bar direction
  pbThickness: 5, // progress bar thickness
};

@NgModule({
  declarations: [
    AppComponent,
    SearchPipe,
    DocumentSetupDialogComponent,
    HydrantHighZoneComponent,
    SprinklerHighZoneComponent,
    HydrantJockeyComponent,
    SprinklerJockeyComponent,
    DesignCalculusSubpageComponent,
    FFSummaryComponent,
    VersionControlComponent,
    VersionItemsComponent,
    FmpComponent,
  ],
  bootstrap: [AppComponent],
  imports: [
    FormsModule,
    ReactiveFormsModule,
    CommonModule,
    BrowserModule,
    BrowserAnimationsModule,
    RouterModule,
    AppRoutingModule,
    NgxUiLoaderModule.forRoot(ngxUiLoaderConfig),
    ToastrModule.forRoot(),
    IgbcModule,
    FireFightingModule,
    HvacModule,
    ElectricalModule,
    BudgetAllocationModule,
    TutorialModule,
    MatButtonModule,
    MatIconModule,
    MatTooltipModule,
    NgSelectModule,
    SharedCCModule,
    NzIconModule,
    NgxUiLoaderModule,
  ],
  providers: [
    {
      provide: HTTP_INTERCEPTORS,
      useClass: RequestInterceptor,
      multi: true,
    },
    {
      provide: HTTP_INTERCEPTORS,
      useClass: ResponseInterceptor,
      multi: true,
    },
    AuthGuard,
    provideHttpClient(withInterceptorsFromDi()),
  ]
})
export class AppModule { }
