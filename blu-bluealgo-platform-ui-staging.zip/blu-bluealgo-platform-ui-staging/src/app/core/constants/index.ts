export const ERROR_MSGS = {
  internalError: 'Internal server error',
};

export const REQUEST_TO_API = {
  blueAlgo: 'ba',
  fetchMyPayments: 'fmp',
  file: 'file',
  local: 'local',
  none: 'none',
};

export const DOCUMENT_TYPES_KEY = {
  template: 'template',
  communication: 'communication-template',
  dynamic: 'dynamic-template',
};

export const DOCUMENT_TYPES = [
  {
    id: 'template',
    name: 'Template Liabrary',
  },
  {
    id: 'communication-template',
    name: 'Communication Template',
  },
  {
    id: 'dynamic-template',
    name: 'Dynamic Template',
  },
];
