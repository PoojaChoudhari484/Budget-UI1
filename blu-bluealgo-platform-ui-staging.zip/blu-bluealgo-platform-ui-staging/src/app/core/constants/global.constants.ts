export const ERROR_MESSAGES = {
  GENERIC: 'Something went wrong at our end. Please try again later.',
  NETWORK: 'Unable to reach the server. Check your internet connection.',
  UNAUTHORIZED: 'You are not authorized to perform this action.',
  FORBIDDEN: 'You don’t have permission to access this resource.',
  NOT_FOUND: 'The requested resource could not be found.',
  VALIDATION: 'Some fields are invalid. Please check and try again.',
};
