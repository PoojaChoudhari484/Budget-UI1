export enum DialogOpenMode {
    Add = 0,
    Edit = 1,
}