/* eslint-disable @typescript-eslint/naming-convention */
import { HttpClient, HttpHeaders } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';
import {
  AccessPlan,
  AccessPlanResponse,
} from 'src/app/fulfillment-table/entity/access-plan';

@Injectable({
  providedIn: 'root', // Ensures a single shared instance across the app
})
export class FulfillmentApiService {
  fulfillmentRow!: AccessPlan | undefined;

  constructor(private http: HttpClient) {}

  getUsers() {
    return this.http.get(`fullfilment/show_users_srvs`).toPromise();
  }

  getServices() {
    return this.http.get(`fullfilment/show_service`).toPromise();
  }

  updateData(payload: any) {
    return this.http.post(`fullfilment/extnd_srv`, payload).toPromise();
  }

  addToken(payload: any) {
    return this.http.post(`fullfilment/add_ui_tag`, payload).toPromise();
  }

  addUser(payload: any, values: any) {
    const httpOptions = {
      headers: new HttpHeaders({
        'Content-Type': 'application/json',
        ServiceType: values.serviceType,
        ModuleType: values.module,
      }),
    };

    return this.http.post(`auth/create_ac`, payload, httpOptions).toPromise();
  }

  getShowAcService(accountId: string): Observable<AccessPlanResponse> {
    return this.http.post<AccessPlanResponse>('fullfilment/show_ac_service', {
      accountId,
    });
  }

  deleteAccessplan(id: number): Observable<AccessPlanResponse> {
    return this.http.post<AccessPlanResponse>(
      'fullfilment/delete_service_uses',
      { id },
    );
  }

  addAccessplan(payload: AccessPlan): Observable<any> {
    return this.http.post<any>('fullfilment/add_service', payload);
  }

  updateAccessplan(payload: AccessPlan): Observable<any> {
    return this.http.post<any>('fullfilment/update_service', payload);
  }

  getShowPlan(): Observable<any> {
    return this.http.get('fullfilment/show_plan');
  }

  getShowAllServcie(): Observable<any> {
    return this.http.get('fullfilment/show_all_service');
  }
}
