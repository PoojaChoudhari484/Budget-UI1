import { Injectable } from '@angular/core';
import { FormArray, FormControl, FormGroup } from '@angular/forms';
declare var $: any;

@Injectable({
  providedIn: 'root', // Ensures a single shared instance across the app
})
export class LocalStorageService {
  static readonly CURRENT_EDITING_TEMPLATE = 'CURRENT_EDITING_TEMPLATE';
  static readonly CHANGED_CURRENT_STATE = 'CHANGED_CURRENT_STATE';

  constructor() {}

  validateAllFormFields(formGroup: any) {
    Object.keys(formGroup.controls).forEach((field) => {
      const control = formGroup.get(field);
      if (control instanceof FormControl) {
        control.markAsTouched({ onlySelf: true });
      } else if (control instanceof FormGroup || control instanceof FormArray) {
        this.validateAllFormFields(control);
      }
    });
  }

  loginUser(userObj: any) {
    localStorage.setItem('user', this.encodeData(userObj));
    localStorage.setItem('token', userObj.accessToken);
    localStorage.setItem('username', userObj.username);
    localStorage.setItem('customerId', userObj.CustomerId);
    localStorage.setItem('loginTime', new Date().toISOString());
  }

  logoutUser() {
    localStorage.clear();
  }

  getUser() {
    const user = localStorage.getItem('user');
    if (user) {
      return this.decodeString(user);
    }
    return null;
  }

  getToken() {
    const u = localStorage.getItem('token');
    return u || '';
  }

  getUserName() {
    const userObj = this.getUser();
    return userObj ? userObj.Name + ' ' + userObj.LastName : null;
  }

  getAdminEmail() {
    const userObj = this.getUser();
    return userObj.username ?? '';
  }


  getProfilePicture() {
    const user = this.getUser();
    return user ? user.profileImg : null;
  }

  getCustomerId() {
    const user = this.getUser();
    return user ? user.customerId : null;
  }

  isLoggedInWithin24Hours(): boolean {
    const loginTimeStr = localStorage.getItem('loginTime');
    if (!loginTimeStr) {
      return false;
    }

    const loginTime = new Date(loginTimeStr).getTime();
    const now = Date.now();
    const diffInMs = now - loginTime;
    const twentyFourHoursInMs = 24 * 60 * 60 * 1000;

    return diffInMs < twentyFourHoursInMs;
  }

  getAccountId() {
    const user = this.getUser();
    return user ? user.user.AccountId : null;
  }

  hasUserLoggedIn() {
    return this.getUser();
  }

  encodeData(obj: any) {
    return btoa(JSON.stringify(obj));
  }

  decodeString(obj: any) {
    return JSON.parse(atob(obj));
  }

  setLocation(payload: any) {
    localStorage.setItem('currentLocation', this.encodeData(payload));
  }

  getLocation() {
    const loc = localStorage.getItem('currentLocation');
    return loc ? this.decodeString(loc) : null;
  }

  getMasterId() {
    const selectedLocation = this.getLocation();
    return selectedLocation.masterId
      ? selectedLocation.masterId
      : this.getCustomerId();
  }

  toggleSideMenu() {
    $('.sidebar-main').toggleClass('minibar');
    $('.sidebar-main .side-menu-main .side-menu').removeClass('show');
    $('.sidebar-main .side-menu-main .side-menu .sub-menu').slideUp();
  }

  // region static methods
  getLocalStorage(key: string) {
    return localStorage.getItem(key);
  }
  setLocalStorage(key: string, value: any) {
    // if (typeof value != 'string') value = JSON.stringify(value);
    return localStorage.setItem(key, value);
  }
  removeLocalStorage(key: string) {
    return localStorage.removeItem(key);
  }

  // endregion

  setMapletParentJsonKeys(json : string){
    return localStorage.setItem("mapletParentJsonKeys", json);
  }

  setMapletReferenceJsonKeys(json : string){
    return localStorage.setItem("mapletReferenceJsonKeys", json);
  }
}
