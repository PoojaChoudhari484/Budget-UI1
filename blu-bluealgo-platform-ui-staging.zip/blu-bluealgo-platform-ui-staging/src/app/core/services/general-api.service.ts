/* eslint-disable @typescript-eslint/naming-convention */
import { HttpClient, HttpHeaders } from '@angular/common/http';
import { Injectable } from '@angular/core';

@Injectable({
  providedIn: 'root',
})
export class GeneralApiService {
  private loggedInUserEnc: string = localStorage.getItem('user') ?? '';
  private loggedInUser: any = JSON.parse(atob(this.loggedInUserEnc));

  constructor(private http: HttpClient) {}

  getGroups(payload: any) {
    const token = this.loggedInUser.accessToken;

    const headers = new HttpHeaders({
      Authorization: `Bearer ${token}`,
      'Content-Type': 'application/json',
    });
    return this.http
      .post(`entp_v1/role/show_loign_assign_group_permission`, payload, {
        headers: headers,
      })
      .toPromise();
  }
}
