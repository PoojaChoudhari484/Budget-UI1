/* eslint-disable @typescript-eslint/naming-convention */
import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';

@Injectable({
  providedIn: 'root', // Ensures a single shared instance across the app
})
export class VersionApiService {
  constructor(private http: HttpClient) {}

  getEventLogs(customerId: string) {
    return this.http
      .get(`doctiger/show_doctiger_logs?customerId=${customerId}`)
      .toPromise();
  }

  getTemplateHistory(customerId: string) {
    return this.http
      .post(`doctiger/templatelibrary/TemplateList`, {
        customerId: customerId,
      })
      .toPromise();
  }

  getClauseHistory(customerId: string) {
    return this.http
      .post(`doctiger/clauselibrary/ClauseGalleryList`, {
        customerId: customerId,
      })
      .toPromise();
  }

  getChildClauseHistory(id: string) {
    return this.http.get(`doctiger/show_template_logs/${id}`).toPromise();
  }

  getChildTemplateHistory(id: string) {
    return this.http.get(`doctiger/show_template_logs/${id}`).toPromise();
  }
}
