import { Injectable } from '@angular/core';
import { HttpClient, HttpParams } from '@angular/common/http';
import { Observable } from 'rxjs';
import { REQUEST_TO_API } from '../constants';

@Injectable({
  providedIn: 'root',
})
export class LocalApiService {
  constructor(private http: HttpClient) {}

  // Generic GET request method
  get<T>(endpoint: string, params?: HttpParams): Observable<T> {
    return this.http.get<T>(`${endpoint}`, {
      params: { sentTo: REQUEST_TO_API.local, ignoreLoader: 'yes' },
    });
  }

  // Generic POST request method
  post<T>(endpoint: string, body: any): Observable<T> {
    return this.http.post<T>(`${endpoint}`, body, {
      params: { sentTo: REQUEST_TO_API.local, ignoreLoader: 'yes' },
    });
  }

  // Generic PUT request method
  put<T>(endpoint: string, body: any): Observable<T> {
    return this.http.put<T>(`${endpoint}`, body);
  }

  // Generic DELETE request method
  delete<T>(endpoint: string): Observable<T> {
    return this.http.delete<T>(`${endpoint}`);
  }
}
