import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { environment } from '../../../environments/environment';
import { BudgetInformationDialogComponent } from '../../budget-allocation/common/budget-information-dialog/budget-information-dialog.component';
import { LocalApiService } from './local-api.service';
import { MatDialog } from '@angular/material/dialog';

@Injectable({
  providedIn: 'root',
})
export class CalculusCommonService {
  base_url = environment.localBase + 'reports_page';

  constructor(
    private http: HttpClient,
    private apiService: LocalApiService,
    private dialog: MatDialog,
  ) {}

  getReport(payload: any) {
    let param: any = { params: { isWithoutBase: 'yes' }, responseType: 'text' };
    this.http.post(this.base_url, payload, param).subscribe((response) => {
      window.location.href = this.base_url;
    });
  }

  openInfoPopUp(buttonElement: HTMLElement, subModule: string) {
    this.apiService
      .post('get_info', { subModule: subModule })
      .subscribe((res: any) => {
        let info = { message: res?.demo };
        const rect = buttonElement.getBoundingClientRect();
        this.dialog.open(BudgetInformationDialogComponent, {
          data: info,
          position: {
            top: `${rect.top}px`,
            left: `${rect.left + 50}px`,
          },
          minWidth: '70vh',
          maxWidth: '110vh',
        });
      });
  }
}
