export interface Summary {
  name: string;
  value: string;
  icon: string;
  domesticLPD?: number;
  flushingLPD?: number;
  grossWaterDemand?: number;
  totalPopulation?: number;
  noOfUnits?: number;
  totalVolume?: number;
  domesticWaterRequired?: number;
  flushingWaterLPD?: number;
}
