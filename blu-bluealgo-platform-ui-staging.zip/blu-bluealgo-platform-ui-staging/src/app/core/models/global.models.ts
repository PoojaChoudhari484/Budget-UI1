import { DialogOpenMode } from "../enums/global.enum";

export interface ClauseTreeNode {
  name: string;
  children?: ClauseTreeNode[];
  expanded?: boolean;
}

export interface IClause {
  Id: number;
  clausename: string;
  displayname: string;
  clauseno: string;
  level: string;
  metadata: string;
  description?: string;
  content: string;
  language: string;
  languages?: any;
  lang?: string;
  level1clause: string;
  level2clause: string;
  level3clause: string;
  rulebased: string; 
  ruleId: number;
  approvalused: string; 
  datasourceid: number;
  datadourcename: string;
  adminEmail: string;
  custgroup: string;
  customerId: string;
  splClauseInfo: string;
  splClauseFileName: string;
  docVersion: string;
  fileBucketPath: string;
  child: IClause[], 
}

export interface IUserDetails {
  username: string;
  email: string;
  roles: any[];
  viewPermission: any[];
  otherPermission: {
    div_edit: boolean;
    div_customer: boolean;
    [key: string]: boolean;
  };
  user: IUser;
  profileImg: string;
  tokenType: string;
  accessToken: string;
  customerId: string;
  Id: number;
  CustomerId: string;
  UserId: string;
}

export interface IUser {
  Username: string;
  TeamSpaceRoleAllocation: any;
  Roles: any[];
  ViewPermission: any;
  OtherPermission: any;
  TeamSpaceRoleAllocations: any;
  LastLogin: string;
  FailedAttempt: number;
  AccountNonLocked: string;
  LockTime: string | null;
  AccountId: string;
  EncPwd: string;
  Name: string;
  Id: number;
  Password: string;
  ConfrimPassword: string | null;
  ServiceType: string | null;
  ModuleType: string | null;
  CustomerId: string;
  ManagerId: string | null;
  UserStatus: string;
  AtDate: string;
  UserId: string;
  EmailId: string;
  MobileNumber: string;
  LastConnectionDate: string;
  UserType: string;
  LastName: string;
  Company: string;
}

export interface IDataSource {
  Id: number;
  Name: string;
  Type: string;
  AtDate: string;
  CustomerId: string;
}

export interface IClauseDialogData {
  dialogOpenMode: DialogOpenMode;
  Id: number;
  level: string;
  level1clause: string;
  level2clause: string;
  level3clause: string;
}

export interface IClauseApiResponse{
  ResponseCode: number;
  ResponseMessage: string;
  clauseLibrary: any;
  ClauseLibrary: any;
}

export interface IFunctionMetaData{
  Id: number;
  TemplateId: number;
  customerId: string;
  field: string;
  language: string;
  pattern: string;
}

export class IFullfillmentAPIRES<T> {
  ResponseCode!: number;
  ResponseMessage: string = '';
  list!: Array<T>;
}