import { Injectable } from '@angular/core';
import { Observable, throwError } from 'rxjs';
import { tap } from 'rxjs/operators';

import { HttpEvent, HttpHandler, HttpHeaders, HttpInterceptor, HttpParams, HttpRequest } from '@angular/common/http';
import { LocalStorageService } from '../services/local-storage.service';
import { environment } from 'src/environments/environment';
import { NgxUiLoaderService } from 'ngx-ui-loader';
import { REQUEST_TO_API } from '../constants';

@Injectable()
export class RequestInterceptor implements HttpInterceptor {
  private baseUrl: string = environment.apiBase;
  constructor(
    private localStorageSerivce: LocalStorageService,
    private ngxService: NgxUiLoaderService,
  ) {}

  intercept<T>(
    req: HttpRequest<T>,
    next: HttpHandler,
  ): Observable<HttpEvent<T>> {
    const params: HttpParams = req.params;
    let headers: HttpHeaders = req.headers;

    headers = headers.set('Access-Control-Allow-Origin', '*');
    headers = headers.set('X-Client-Url', window.location.host);
    headers = headers.set('X-User-Type', 'vero-portal');
    if (this.localStorageSerivce.hasUserLoggedIn()) {
      headers = headers.set(
        'Authorization',
        'Bearer ' + this.localStorageSerivce.getToken(),
      );
    }

    return this.sendRequest<T>(next, req, headers, params);
  }

  sendRequest<T>(
    next: HttpHandler,
    req: HttpRequest<T>,
    headers: HttpHeaders,
    params: HttpParams,
  ): Observable<HttpEvent<T>> {
    this.baseUrl = environment.apiBase;
    if (req.params.get('sentTo') === REQUEST_TO_API.fetchMyPayments) {
      this.baseUrl = environment.fetchMyPaymentApi;
    }
    if (req.params.get('sentTo') === REQUEST_TO_API.file) {
      this.baseUrl = environment.apiFileBase;
      headers.append('Access-Control-Allow-Origin', '*');
    }
    if (req.params.get('sentTo') === REQUEST_TO_API.local) {
      this.baseUrl = environment.localBase;
    }

    if (req.params.get('sentTo') === REQUEST_TO_API.none) {
      this.baseUrl = '';
    }

    const apiUrl =
      req.params.get('isWithoutBase') === 'yes'
        ? `${req.url}`
        : `${this.baseUrl}${req.url}`;

    const ignoreLoader = req.params.get('ignoreLoader') === 'yes';
    if (!ignoreLoader) {
      this.ngxService.start();
    }
    req = req.clone({
      url: apiUrl,
      headers,
      params,

      withCredentials: (apiUrl.includes('designcalculus') || (apiUrl.includes('127.0.0.1:5000') && !apiUrl.includes('/auth/sign-in')))    
       });

    return next.handle(req).pipe(
      tap(
        (event: HttpEvent<T>) => {},
        (err: Error) => {
          if (err) {
            throwError(err);
          }
        },
      ),
    );
  }
}
