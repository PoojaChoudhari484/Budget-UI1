import { Injectable } from '@angular/core';
import { Observable, throwError } from 'rxjs';
import { Router } from '@angular/router';
import { tap } from 'rxjs/operators';

import { HttpErrorResponse, HttpEvent, HttpHandler, HttpInterceptor, HttpRequest } from '@angular/common/http';
import { NgxUiLoaderService } from 'ngx-ui-loader';
import { ToastrService } from 'ngx-toastr';

@Injectable()
export class ResponseInterceptor implements HttpInterceptor {
  constructor(
    private router: Router,
    private loaderService: NgxUiLoaderService,
    private toastrService: ToastrService,
  ) {}

  intercept<T>(
    req: HttpRequest<T>,
    next: HttpHandler,
  ): Observable<HttpEvent<T>> {
    return next.handle(req).pipe(
      tap(
        (event: HttpEvent<T>) => {
          const ignoreLoader = req.params.get('ignoreLoader') === 'yes';
          if (!ignoreLoader && event.type !== 0) {
            this.loaderService.stop();
          }
          // do stuff on success
        },
        (error: HttpErrorResponse) => {
          this.loaderService.stop();
          const errorIgnorList: string[] = [];
          // If url does not exist in errorIgnorList then show error toast.
          if (errorIgnorList.indexOf(req.url) === -1) {
            if (error.status === 401 || error.status === 403) {
              this.router.navigate(['/auth/sign-in']);
            }
            if (typeof error.error === 'string') {
              this.toastrService.error('Error', error.error);
            } else {
              this.toastrService.error('Error', error.error?.Message);
            }
          }
          return throwError(error);
        },
      ),
    );
  }
}
