import {
  ChangeDetectorRef,
  Component,
  HostListener,
  OnInit,
  TemplateRef,
  ViewChild,
} from '@angular/core';
import {
  FormBuilder,
  FormControl,
  FormGroup,
  Validators,
  AbstractControl,
} from '@angular/forms';
import { MatDialog } from '@angular/material/dialog';
import { FulfillmentApiService } from '../../../core/services/fulfillment-api.service';
import { Subject } from 'rxjs';
import { debounceTime, distinctUntilChanged } from 'rxjs/operators';
import { Router } from '@angular/router';

@Component({
    selector: 'app-fulfillment-table-container',
    templateUrl: './fulfillment-table-container.component.html',
    styleUrls: ['./fulfillment-table-container.component.scss'],
    standalone: false
})
export class FulfillmentTableContainerComponent implements OnInit {
  columns: {
    id: string;
    title: string;
    actions: boolean;
    template: any;
    isSortable: boolean;
  }[] = [];
  relativeColumns: {
    id: string;
    title: string;
    actions: boolean;
    template: any;
    isSortable: boolean;
  }[] = [];

  nestedData = '';
  info: any[] = [];
  searchText = '';

  show: boolean = false;
  activeDropdown: number | null = null;
  @ViewChild('name', { static: true })
  name!: TemplateRef<any>;
  @ViewChild('more', { static: true }) more!: TemplateRef<any>;
  @ViewChild('from_date', { static: true }) from_date!: TemplateRef<any>;
  @ViewChild('expiry_date', { static: true }) expiry_date!: TemplateRef<any>;

  @ViewChild('suspendDialogTemplate') suspendDialogTemplate!: TemplateRef<any>;
  @ViewChild('servicesDialogTemplate')
  servicesDialogTemplate!: TemplateRef<any>;
  @ViewChild('copyAssetDialogTemplate')
  copyAssetDialogTemplate!: TemplateRef<any>;
  @ViewChild('tokenDialogTemplate') tokenDialogTemplate!: TemplateRef<any>;
  @ViewChild('restoreDialogTemplate') restoreDialogTemplate!: TemplateRef<any>;
  @ViewChild('userDialogTemplate') userDialogTemplate!: TemplateRef<any>;

  isExpandable: boolean = false;
  servicesForm!: FormGroup;
  assetsForm!: FormGroup;
  tokenForm!: FormGroup;
  restoreForm!: FormGroup;
  userForm!: FormGroup;
  services: any;
  selectedUser: any;

  originalInfo: any[] = [];

  private searchTerms = new Subject<string>();
  sortAscending: boolean = true; // A flag to track sorting order

  constructor(
    private cdr: ChangeDetectorRef,
    public dialog: MatDialog,
    private fb: FormBuilder,
    private fulfillmentSvc: FulfillmentApiService,
    private router: Router,
  ) {
    this.servicesForm = new FormGroup({
      service: new FormControl(''),
    });

    this.assetsForm = new FormGroup({
      group: new FormControl(''),
      asset: new FormControl(''),
    });

    this.tokenForm = new FormGroup({
      token: new FormControl(''),
    });
    this.restoreForm = new FormGroup({
      date: new FormControl(''),
    });

    // Define your form group with validators
    this.userForm = new FormGroup(
      {
        name: new FormControl('', Validators.required),
        email: new FormControl('', [Validators.required, Validators.email]),
        password: new FormControl('', Validators.required),
        cnfPassword: new FormControl('', Validators.required),
        company: new FormControl(''), // Optional, no validators
        mobile: new FormControl('', [
          Validators.required,
          Validators.pattern('^\\d{10}$'),
        ]),
        module: new FormControl('', Validators.required),
        serviceType: new FormControl('', Validators.required),
      },
      { validators: this.passwordMatcher },
    ); // Note: Now using a corrected custom validator for password matching
  }

  ngOnInit() {
    this.columns = [
      {
        id: '',
        title: 'NAME',
        actions: true,
        template: this.name,
        isSortable: false,
      },
      {
        id: 'serviceName',
        title: 'SERVICE NAME',
        actions: false,
        template: '',
        isSortable: false,
      },
      {
        id: '',
        title: 'START DATE',
        actions: true,
        template: this.from_date,
        isSortable: false,
      },
      {
        id: '',
        title: 'EXPIRY DATE',
        actions: true,
        template: this.expiry_date,
        isSortable: false,
      },
      {
        id: '',
        title: 'QUANTITY',
        actions: false,
        template: '',
        isSortable: false,
      },
      {
        id: '',
        title: 'QUANTITY USED',
        actions: false,
        template: '',
        isSortable: false,
      },
      {
        id: '',
        title: 'BALANCE',
        actions: false,
        template: '',
        isSortable: false,
      },
      {
        id: '',
        title: '',
        actions: true,
        template: this.more,
        isSortable: false,
      },
    ];
    this.getUsers();
    this.getServices();
    this.searchTerms
      .pipe(
        debounceTime(300), // Wait for 300ms pause in events
        distinctUntilChanged(), // Only search if the term has changed
      )
      .subscribe((term) => this.search(term));
  }

  // Custom validator for password matching
  passwordMatcher(control: AbstractControl): { [key: string]: boolean } | null {
    const form = control as FormGroup; // Type assertion
    const password = form.get('password');
    const cnfPassword = form.get('cnfPassword');
    if (password && cnfPassword && password.value !== cnfPassword.value) {
      return { mismatch: true };
    }
    return null;
  }

  async getUsers() {
    const response: any = await this.fulfillmentSvc.getUsers();
    if (response) {
      this.info = response;
      this.originalInfo = response;
      this.nestedData = 'user';
      this.info.forEach((user: any) => {
        user.show = false;
      });
    }
  }

  public search(term: string): void {
    if (!term) {
      this.info = this.originalInfo;
      return;
    }

    term = term.toLowerCase(); // Convert term to lowercase once for efficiency

    this.info = this.originalInfo.filter((item) => this.deepSearch(item, term));
  }

  private deepSearch(value: any, term: string): boolean {
    if (value === null || value === undefined) {
      return false; // If value is null or undefined, it doesn't contain the search term
    }

    if (typeof value === 'object') {
      // If it's an object (including arrays), iterate through its properties/values
      return Object.values(value).some((subValue) =>
        this.deepSearch(subValue, term),
      );
    } else {
      // For basic data types, convert to string and check if it includes the search term
      return value.toString().toLowerCase().includes(term);
    }
  }

  // Call this method on each keyup event
  searchInputChanged(term: string): void {
    this.searchTerms.next(term);
  }

  filter(term: string): void {
    if (!term || term == 'none') {
      this.info = this.originalInfo; // No search term means no filtering needed
      return;
    }

    term = term.toLowerCase(); // Lowercase the search term to make the search case-insensitive

    this.info = this.originalInfo.filter((item) =>
      item.serviceName.toLowerCase().includes(term),
    );
  }

  toggleSort(): void {
    // Toggle the sorting order
    this.sortAscending = !this.sortAscending;
    this.sortInfoByUserName();
  }

  sortInfoByUserName(): void {
    this.info.sort((a, b) => {
      // Handle nulls separately to ensure they are sorted as per the current direction
      if (!a.user && b.user) return this.sortAscending ? -1 : 1;
      if (a.user && !b.user) return this.sortAscending ? 1 : -1;
      if (!a.user && !b.user) return 0;

      const nameA = a.user.Name.toLowerCase();
      const nameB = b.user.Name.toLowerCase();

      // Sort based on the current direction
      if (this.sortAscending) {
        return nameA.localeCompare(nameB);
      } else {
        return nameB.localeCompare(nameA);
      }
    });

    // Force update for Angular to detect changes
    this.info = [...this.info];
  }

  async getServices() {
    const response: any = await this.fulfillmentSvc.getServices();
    if (response) {
      this.services = response;
    }
  }

  async saveService() {
    this.selectedUser.serviceName = this.servicesForm.controls['service'].value;
    const item = this.services.find(
      (item: any) => item.name == this.servicesForm.controls['service'].value,
    );
    this.selectedUser.serviceCode = item.serviceCode;

    this.serveTill(this.selectedUser);
    // const response: any = await this.fulfillmentSvc.updateData(
    //   this.selectedUser,
    // );
    // if (response) {
    //   this.closeDialog();
    //   this.getUsers();
    // }
  }

  async suspend() {
    let today = new Date();
    // Subtract one day and get the timestamp
    let timestamp = today.setDate(today.getDate() - 1);
    // Create a new date object for yesterday
    let yesterday = new Date(timestamp);
    // Formatting yesterday's date to a readable format (optional)
    // let formattedDate = yesterday.toDateString(); // or use toISOString(), etc., depending on your needs
    this.selectedUser.expiryDate = yesterday;
    this.serveTill(this.selectedUser);
  }

  async extend() {
    this.selectedUser.expiryDate = this.restoreForm.controls['date'].value;
    this.serveTill(this.selectedUser);
  }

  async serveTill(data: any) {
    const { id, ...rest } = data;
    const modifiedData = { Id: id, ...rest };
    const response: any = await this.fulfillmentSvc.updateData(modifiedData);
    if (response) {
      this.closeDialog();
      this.getUsers();
    }
  }

  async addToken() {
    let payload = {
      Permissions: this.tokenForm.controls['token'].value,
      CustomerId: this.selectedUser.customerId,
    };
    const response: any = await this.fulfillmentSvc.addToken(payload);
    if (response) {
      this.closeDialog();
      this.getUsers();
    }
  }

  async addUser(values: any) {
    if (this.userForm.invalid) {
      this.markAllAsTouched(this.userForm);
      return;
    } else {
      let payload = {
        Name: values.name,
        EmailId: values.email,
        Password: values.password,
        ConfrimPassword: values.cnfPassword,
        Company: values.company,
        MobileNumber: values.mobile,
        UserId: values.email,
        Username: values.email,
      };
      const response: any = await this.fulfillmentSvc.addUser(payload, values);
      if (response) {
        this.closeDialog();
        this.getUsers();
      }
    }
  }

  // Utility method to mark all form controls as touched recursively
  markAllAsTouched(formGroup: FormGroup) {
    Object.values(formGroup.controls).forEach((control) => {
      control.markAsTouched();

      if (control instanceof FormGroup) {
        this.markAllAsTouched(control);
      }
    });
  }

  rowIconClicked() {
    this.isExpandable = !this.isExpandable;
  }

  rowClicked(e: any) {
    this.isExpandable = false;
  }

  openSuspendDialog(data: any): void {
    this.selectedUser = data;
    const dialogRef = this.dialog.open(this.suspendDialogTemplate, {
      panelClass: 'extend-services-dialog-container',
    });

    dialogRef.afterClosed().subscribe((result) => {
      console.log('The dialog was closed');
      // handle dialog close if necessary
    });
  }

  openServicesDialog(data: any): void {
    this.selectedUser = data;
    this.getServices();
    const dialogRef = this.dialog.open(this.servicesDialogTemplate, {
      panelClass: 'extend-services-dialog-container',
    });

    dialogRef.afterClosed().subscribe((result) => {
      console.log('The dialog was closed');
      // handle dialog close if necessary
    });
  }

  openCopyAssetDialog(data: any): void {
    this.selectedUser = data;
    const dialogRef = this.dialog.open(this.copyAssetDialogTemplate, {
      panelClass: 'extend-services-dialog-container',
    });

    dialogRef.afterClosed().subscribe((result) => {
      console.log('The dialog was closed');
      // handle dialog close if necessary
    });
  }

  openTokenDialog(data: any): void {
    this.selectedUser = data;
    const dialogRef = this.dialog.open(this.tokenDialogTemplate, {
      panelClass: 'extend-services-dialog-container',
    });

    dialogRef.afterClosed().subscribe((result) => {
      console.log('The dialog was closed');
      // handle dialog close if necessary
    });
  }

  openRestoreDialog(data: any): void {
    this.selectedUser = data;
    const dialogRef = this.dialog.open(this.restoreDialogTemplate, {
      panelClass: 'extend-services-dialog-container',
    });

    dialogRef.afterClosed().subscribe((result) => {
      console.log('The dialog was closed');
      // handle dialog close if necessary
    });
  }

  navigateToAcessPlan(data: any): void {
    console.log('data', data);
    if (data?.accountId) {
      this.fulfillmentSvc.fulfillmentRow = data;
      localStorage.setItem('fulfillmentRow', JSON.stringify(data));
      this.router.navigateByUrl(
        `/fulfillment-table/${data.accountId}/access-plans`,
      );
    } else {
      alert('accountId not found');
    }
  }

  openUserDialog(): void {
    const dialogRef = this.dialog.open(this.userDialogTemplate, {
      panelClass: 'extend-services-dialog-container',
    });

    dialogRef.afterClosed().subscribe((result) => {
      console.log('The dialog was closed');
      // handle dialog close if necessary
    });
  }

  onDateSelect(event: any) {
    // event is the selected date
    // Perform your actions here, like setting the dateValue or preparing the payload
  }

  closeDialog(): void {
    this.dialog.closeAll();
  }
}
