import { ComponentFixture, TestBed } from '@angular/core/testing';

import { FulfillmentTableContainerComponent } from './fulfillment-table-container.component';

describe('FulfillmentTableContainerComponent', () => {
  let component: FulfillmentTableContainerComponent;
  let fixture: ComponentFixture<FulfillmentTableContainerComponent>;

  beforeEach(() => {
    TestBed.configureTestingModule({
      declarations: [FulfillmentTableContainerComponent],
    });
    fixture = TestBed.createComponent(FulfillmentTableContainerComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
