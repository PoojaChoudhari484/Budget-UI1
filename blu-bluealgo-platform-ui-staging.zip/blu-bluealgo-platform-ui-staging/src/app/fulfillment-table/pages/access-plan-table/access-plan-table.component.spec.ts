import { ComponentFixture, TestBed } from '@angular/core/testing';

import { AccessPlanTableComponent } from './access-plan-table.component';

describe('AccessPlanTableComponent', () => {
  let component: AccessPlanTableComponent;
  let fixture: ComponentFixture<AccessPlanTableComponent>;

  beforeEach(() => {
    TestBed.configureTestingModule({
      declarations: [AccessPlanTableComponent],
    });
    fixture = TestBed.createComponent(AccessPlanTableComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
