import {
  Component,
  OnDestroy,
  TemplateRef,
  ViewChild,
  OnInit,
} from '@angular/core';
import { AccessPlan, AccessPlanServiceUse } from '../../entity/access-plan';
import { FulfillmentApiService } from 'src/app/core/services/fulfillment-api.service';
import { MatDialog } from '@angular/material/dialog';
import { ToastrService } from 'ngx-toastr';
import { ActivatedRoute, Router } from '@angular/router';
import { TableColumn } from 'src/app/shared/entities/table-column';
import { FormControl, FormGroup, Validators } from '@angular/forms';
import { Observable } from 'rxjs';

@Component({
    selector: 'app-access-plan-table',
    templateUrl: './access-plan-table.component.html',
    styleUrls: ['./access-plan-table.component.scss'],
    standalone: false
})
export class AccessPlanTableComponent implements OnInit, OnDestroy {
  @ViewChild('accessAddDialogTemplate')
  addAccessDialogTemplate!: TemplateRef<any>;
  @ViewChild('more', { static: true }) more!: TemplateRef<any>;
  @ViewChild('from_date', { static: true }) from_date!: TemplateRef<any>;
  @ViewChild('endDate', { static: true }) endDate!: TemplateRef<any>;
  dialogRef: any;

  // TABLE
  columns: TableColumn[] = [];
  accessPlanData: AccessPlanServiceUse[] = [];

  // Data for dropdowns
  services = ['doctiger', 'smartform', 'reminder', 'addusers'];
  usageTypes: any[] = [];
  accountId: string = '';
  row!: AccessPlan;
  isEditMode: boolean = false;

  // Dialog Form
  assessPlanGroup: FormGroup = new FormGroup({
    name: new FormControl('doctiger', Validators.required),
    planType: new FormControl('', Validators.required),
    totalQuantity: new FormControl(0, Validators.required),
  });

  constructor(
    public dialog: MatDialog,
    private fullfilmentApiService: FulfillmentApiService,
    private toastr: ToastrService,
    private route: ActivatedRoute,
    private router: Router,
  ) {
    this.route.params.subscribe((params) => {
      this.accountId = params['accountId'];
    });
  }

  ngOnInit(): void {
    const row = localStorage.getItem('fulfillmentRow');
    if (row) this.row = JSON.parse(row);
    this.loadConfig();
  }

  ngOnDestroy() {
    localStorage.removeItem('fulfillmentRow');
    this.fullfilmentApiService.fulfillmentRow = undefined;
  }

  loadConfig() {
    this.loadTableColumns();
    this.fetchUsageTypeOptions();
    this.fetchTableData();
  }

  loadTableColumns() {
    this.columns = [
      { id: 'name', title: 'Service Name', actions: false },
      { id: 'usesCount', title: 'Usage Type', actions: false },
      { id: 'unq_id_with_qty', title: 'Consumed Quantity', actions: false },
      { id: 'totalQuantity', title: 'Total Quantity', actions: false },
      {
        id: 'fromDate',
        title: 'Start Date',
        actions: true,
        template: this.from_date,
      },
      {
        id: 'endDate',
        title: 'End Date',
        actions: true,
        template: this.endDate,
      },
      { id: '', title: 'Actions', actions: true, template: this.more },
    ];
  }

  fetchTableData() {
    // this.accountId = "acct_20240430095123743787";
    this.fullfilmentApiService
      .getShowAcService(this.accountId)
      .subscribe((res) => {
        if (res?.list) {
          this.accessPlanData = res.list
            .filter((l: any) => l.serviceUses) // Filter out items without serviceUses
            .flatMap((l: any) => l.serviceUses) // Flatten and collect all serviceUses
            .map((user: any) => ({ ...user, show: false })); // Add the `show` property with a default value
        }
      });
  }

  fetchUsageTypeOptions() {
    this.fullfilmentApiService.getShowPlan().subscribe((res) => {
      if (res) {
        this.usageTypes = Object.entries(res).map(([key, value]) => ({
          value: key,
          title: value,
        }));
      }
    });
  }

  // fetchShowAllService() {
  //   this.fullfilmentApiService.getShowAllServcie().subscribe(res => {
  //     console.log("getShowAllServcie", res);
  //   });
  // }

  openAccessAddDialog(data?: AccessPlanServiceUse): void {
    this.isEditMode = false;
    if (!this.row && !this.fullfilmentApiService.fulfillmentRow) {
      this.toastr.warning(
        'Please go to Fulfillment Table to select a row again.',
      );
      return;
    }
    this.assessPlanGroup.reset();
    if (data) {
      this.isEditMode = true;
      if (data?.name) this.assessPlanGroup.get('name')?.setValue(data.name);
      if (this.row?.planType)
        this.assessPlanGroup.get('name')?.setValue(this.row.planType);
      if (data?.totalQuantity)
        this.assessPlanGroup.get('totalQuantity')?.setValue(data.totalQuantity);
    }
    const dialogRef = this.dialog.open(this.addAccessDialogTemplate, {
      panelClass: 'extend-services-dialog-container',
    });
    dialogRef.afterClosed().subscribe((result) => {
      console.log('The dialog was closed');
      // handle dialog close if necessary
    });
  }

  onDeletePlan(obj: any) {
    if (obj?.id && confirm('Are you sure?')) {
      this.fullfilmentApiService.deleteAccessplan(obj.id).subscribe((res) => {
        if (res) {
          this.toastr.success(
            'Your access plan has been deleted successfully.',
          );
          this.fetchTableData();
        }
      });
    }
  }

  save(): void {
    if (!this.assessPlanGroup.valid) {
      this.toastr.warning('Please fill all required fields.');
      return;
    }
    // assign row data
    const row = this.row || this.fullfilmentApiService.fulfillmentRow;
    let payload: AccessPlan = new AccessPlan(row);

    // Service
    let obj: AccessPlanServiceUse = new AccessPlanServiceUse();
    obj.name = this.assessPlanGroup.value.name;

    // Quantity
    obj.totalQuantity = this.assessPlanGroup.value.totalQuantity;

    payload.serviceUses = [obj];

    // Usage Type
    payload.planType = this.assessPlanGroup.value.planType;

    let obs!: Observable<any>;
    if (this.isEditMode)
      obs = this.fullfilmentApiService.updateAccessplan(payload);
    else obs = this.fullfilmentApiService.addAccessplan(payload);

    obs.subscribe({
      next: (res) => {
        this.toastr.success('Your access plan has been saved successfully.');
        this.closeDialog();
        this.fetchTableData(); // Reload the table data after saving
      },
      error: (err) => {
        console.log(err);
        let msg = 'Something went wrong';
        if (err?.error?.message) msg = err.error.message;
        this.toastr.error(msg);
        this.closeDialog();
      },
    });
  }

  closeDialog(): void {
    this.dialog.closeAll();
  }

  goBack() {
    this.router.navigateByUrl('/fulfillment-table');
  }
}
