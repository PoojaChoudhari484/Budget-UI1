import { Component } from '@angular/core';

@Component({
    selector: 'app-fulfillment-table',
    templateUrl: './fulfillment-table.component.html',
    styleUrls: ['./fulfillment-table.component.scss'],
    standalone: false
})
export class FulfillmentTableComponent {}
