import { NgModule } from '@angular/core';
import { CommonModule, DatePipe } from '@angular/common';
import { FulfillmentTableComponent } from './fulfillment-table.component';
import { FulfillmentTableRoutingModule } from './fulfillment-table-routing.module';
import { ReusableTableModule } from '../shared/table/table.module';
import { DrawerModule } from '../shared/drawer/drawer.module';
import { MatDialogModule } from '@angular/material/dialog';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { DatePicker } from 'primeng/datepicker';
import { AccessPlanTableComponent } from './pages/access-plan-table/access-plan-table.component';
import { FulfillmentTableContainerComponent } from './pages/fulfillment-table-container/fulfillment-table-container.component';
import { MatAngularModule } from '../mat-angular/mat-angular.module';
@NgModule({
  imports: [
    CommonModule,
    FulfillmentTableRoutingModule,
    ReusableTableModule,
    DrawerModule,
    MatDialogModule,
    ReactiveFormsModule,
    DatePicker,
    FormsModule,
    MatAngularModule,
  ],
  providers: [DatePipe],
  declarations: [
    FulfillmentTableComponent,
    AccessPlanTableComponent,
    FulfillmentTableContainerComponent,
  ],
})
export class FulfillmentTableModule {}
