import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { FulfillmentTableComponent } from './fulfillment-table.component';
import { AccessPlanTableComponent } from './pages/access-plan-table/access-plan-table.component';
import { FulfillmentTableContainerComponent } from './pages/fulfillment-table-container/fulfillment-table-container.component';

const routes: Routes = [
  { path: '', redirectTo: '/fulfillment-table', pathMatch: 'full' },
  {
    path: '',
    component: FulfillmentTableComponent,
    children: [
      { path: '', component: FulfillmentTableContainerComponent },
      { path: ':accountId/access-plans', component: AccessPlanTableComponent },
    ],
  },
  { path: '**', redirectTo: '/fulfillment-table', pathMatch: 'full' },
];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule],
})
export class FulfillmentTableRoutingModule {}
