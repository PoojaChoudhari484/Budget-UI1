export class AccessPlanResponse {
  ResponseCode: number;
  ResponseMessage: string;
  list: AccessPlan[] = [];
}

export class AccessPlan {
  id: number;
  accountId: string = '';
  customerId: string = '';
  expiryDate: string = '';
  fromDate: string = '';
  moduleName: string = '';
  serviceCode: string = '';
  serviceName: string = '';
  status: string = '';
  usesThreshold: string = '';
  serviceUses: AccessPlanServiceUse[] = [];
  email: string = '';
  planType?: string;

  constructor(data?: AccessPlan) {
    if (data) {
      Object.assign(this, data); // Automatically assigns matching properties
    }
  }
}

export class AccessPlanServiceUse {
  customerId: string = '';
  customer_srv_pk?: number;
  endDate: string = '';
  fromDate: string = '';
  id: number = 0;
  name: string = '';
  serviceCode: string = '';
  totalQuantity: number = 0;
  unq_id_with_qty: number = 0;
  usesCount: number = 0;
}
