import { Component, Inject } from '@angular/core';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { MAT_DIALOG_DATA, MatDialogRef } from '@angular/material/dialog';
import { ToastrService } from 'ngx-toastr';
import { FulfillmentV2Service } from 'src/app/fulfillment-v2/services/fulfillment-v2.service';

@Component({
    selector: 'app-service-model',
    templateUrl: './service-model.component.html',
    styleUrls: ['./service-model.component.scss'],
    standalone: false
})
export class ServiceModelComponent {
  serviceForm!: FormGroup;
  qualityTypeList = [
    { value: 'Unique Quality', label: 'Unique Quality' },
    { value: 'Quality', label: 'Quality' },
    { value: 'Duration', label: 'Duration' },
  ];
  constructor(
    private fb: FormBuilder,
    public dialogRef: MatDialogRef<ServiceModelComponent>,
    @Inject(MAT_DIALOG_DATA) public data: any,
    private fulfillmentService: FulfillmentV2Service,
    private toastr: ToastrService,
  ) {}

  ngOnInit(): void {
    console.log('this.data', this.data);
    this.serviceForm = this.fb.group({
      name: [this.data?.name || '', Validators.required],
      usageQuality: [this.data?.usageQuality || '', Validators.required],
      validity: [
        this.data?.validForDay || '',
        [Validators.required, Validators.min(1)],
      ],
    });
  }

  // SAVE PRODUCT -----------------------

  saveProduct() {
    if (this.serviceForm.valid) {
      const formData = this.serviceForm.value;
      console.log('formData', formData);
      const payload: any = {
        serviceCode: 'srv0018',
        name: formData.name,
        subscription: formData.usageQuality,
        validForDay: formData.validity,
      };

      if (this.data) {
        payload.Id = this.data.Id;

        this.fulfillmentService.updateService(payload).subscribe((res: any) => {
          let msg = 'Product Updated Successfully';

          if (res?.ResponseCode >= 0) {
            this.toastr.success(msg, 'Success');
            this.dialogRef.close(res);
          } else {
            this.toastr.error('Error while saving Product', 'Error');
          }
        });
      } else {
        this.fulfillmentService.createService(payload).subscribe((res: any) => {
          if (res?.ResponseCode >= 0) {
            this.toastr.success('New Product Added Successfully', 'Success');
            this.dialogRef.close(res);
          } else {
            this.toastr.error('Error while saving Product', 'Error');
          }
        });
      }
    } else {
      this.serviceForm.markAllAsTouched();
    }
  }

  closeProductModel() {
    this.dialogRef.close();
  }
}
