import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';

const routes: Routes = [
  //   {
  //   path: 'tools',
  //   loadChildren: () => import('./tools/tools.module').then(m => m.ToolsModule),
  // },
  {
    path: 'auth/sign-in',
    loadChildren: () =>
      import('./authentication/authentication.module').then(
        (m) => m.AuthenticationModule,
      ),
  },
  {
    path: '',
    loadChildren: () =>
      import('./layout/layout.module').then((m) => m.LayoutModule),
  },
  {
    path: '',
    loadChildren: () =>
      import('./budget-allocation/budget-automation.module').then(
        (m) => m.BudgetAllocationModule,
      ),
  },
  {
    path: 'design-automation',
    loadChildren: () =>
      import('./design-automation/design-automation.module').then(
        (m) => m.DesignAutomationModule,
      ),
  },
  // { path: '**', redirectTo: 'auth/sign-in' }
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule],
})
export class AppRoutingModule {}
