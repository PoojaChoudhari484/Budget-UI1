import {Component, EventEmitter, OnInit, Output} from '@angular/core';
import {ActivatedRoute} from "@angular/router";
import { SummaryCalculationFfComponent } from './tabs/summary-calculation-ff/summary-calculation-ff.component';


@Component({
    selector: 'app-ff-summary',
    templateUrl: './ff-summary.component.html',
    styleUrls: ['./ff-summary.component.scss'],
    standalone: false
})
export class FFSummaryComponent implements OnInit {

  @Output() moveToTab = new EventEmitter<string>();
  projectName: string = '';
  projectType: string = '';
  documentVersion: string = '';
  date: string = '';
  public types: string[] = [];
  public activeTab: string = 'summary-calculation-ff';

  constructor(private activatedRoute: ActivatedRoute) {
  }

  ngOnInit(): void {
    this.activatedRoute.queryParams.subscribe((params) => {
      this.projectName = params['projectName'];
      this.projectType = params['projectType'];
      this.documentVersion = params['documentVersion'];
      this.date = params['date'];
    });
  }

  setActiveTab(tab: string): void {
    this.activeTab = tab;
  }

}
