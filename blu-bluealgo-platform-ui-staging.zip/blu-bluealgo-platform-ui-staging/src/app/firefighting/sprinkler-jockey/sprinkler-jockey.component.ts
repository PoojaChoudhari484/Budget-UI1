import { Component, EventEmitter, OnInit, Output } from '@angular/core';
import { LocalApiService } from '../../core/services/local-api.service';
import { CalculusCommonService } from '../../core/services/calculus-common.service';
import { Summary } from '../../core/models/Summary.model';
import { HttpClient } from '@angular/common/http';

@Component({
    selector: 'app-sprinkler-jockey',
    templateUrl: './sprinkler-jockey.component.html',
    styleUrls: ['./sprinkler-jockey.component.scss'],
    standalone: false
})
export class SprinklerJockeyComponent implements OnInit {

  @Output() moveToTab = new EventEmitter<string>();
  inputSummaries: any[] = [
    {
      id: 1,
      name: 'Horizontal',
      value: '',
      icon: 'assets/images/icons/enterprise.svg',
    },
    {
      id: 2,
      name: 'Vertical',
      value: '',
      icon: 'assets/images/icons/enterprise.svg',
    },
  ];
  inputBSummaries = [
    {
      id: 1,
      name: 'Horizontal',
      value: 'Horizontal',
      icon: 'assets/images/icons/swimming_pool.svg',
    },
    // {
    //   id: 2,
    //   name: 'Vertical',
    //   value: 'Vertical',
    //   icon: 'assets/images/icons/landscape.svg',
    // }
  ];
  formData = {
    apartmentName: '',
    location: 'Horizontal',
    // pipeSection: '1',
    waterFlowRate: 0,
    waterFlowUnit: 'lps', // Default unit
    internalPipeDiameter: 0,
    internalPipeUnit: 'mm', // Default unit
    length: 0,
    lengthUnit: 'm', // Default unit
    pressureDrop: 40,
    totalPressureDrop: 60,
    valveType: '',
    quantity: 0,
    residual_pressure_head: 0,
    efficiency: 0,
    lengthOfPipe: 0,
    subType: 'x',
  };
  valveTypeTypes: string[] = [
    //'Actual Inside Diameter',
    'Gate Valve',
    'Standard 90 Elbow',
    'Standard Tee Thru Flow',
    'Standard Tee Branch Flow',
    'Close Return Bend',
    'NRV',
    'Angle Valve Full Open',
    'Globe Valve',
    'Butterfly Valve',
    '90 Welding Elbow rd1',
    '90 Welding Elbow rd2',
    'Miter Bend 45',
    'Miter Bend 90',
    'Misc',
  ];


  transformValveLabel(valve: string): string {
    if (valve === '90 Welding Elbow rd1') {
      return '90 Welding Elbow r/d=1';
    }
    if (valve === '90 Welding Elbow rd2') {
      return '90 Welding Elbow r/d=2';
    }
    return valve;
  }

  showInput = false;
  residentialRefuge: number = 0;
  inputResponse: any = {};
  donutChartLabels = ['Organic Waste', 'Inorganic Waste'];
  inputDropdownArrowSrc = 'assets/images/icons/down_arrow.svg';
  summaryText = 'Summary - A';
  summaryType = 'A';
  showInputA = false;
  showInputB = false;
  units: number = 0;
  area: number = 0;
  pools: number;
  results: any = [];
  selectedInputASummary: any | null = null;
  selectedInputBSummary: any | null = null;
  mainResponse: any = {};
  globalVar: any = {};
  inputAResponse: any = {};
  inputBResponse: any = {};
  supportStaffs: number[] = [0, 10, 15, 20];
  showInputASummary = true;
  showInputBSummary = false;
  activeButtonId: string | null = 'tab-input-a';
  unitTypes: string[] = ['LPD', 'KLD'];
  selectedUnit: string = 'LPD';
  flushingWaterRequired = 6;
  spinner: boolean = false;
  diameterValues: number[] = [
    15, 20, 25, 32, 40, 50, 65, 80, 100, 150, 200, 250, 300,
  ];
  serialNo: number;
waterCurtainLength: any;
discharge: any;
totalDischarge: any;
  constructor(
    private apiService: LocalApiService,
    private calculusCommonService: CalculusCommonService,
  ) { }

  ngOnInit(): void {
    const tabs = document.querySelectorAll<HTMLElement>('[data-tabs-target]');
    const tabContents =
      document.querySelectorAll<HTMLElement>("[role='tabpanel']");
    this.setScreen('straight');
    tabs.forEach((tab) => {
      tab.addEventListener('click', () => {
        // Remove active states from all tabs and hide all content
        tabs.forEach((t) =>
          t.classList.remove(
            'border-blue-500',
            'text-blue-600',
            'dark:text-blue-500',
            'border-[#1D40AB]',
            'text-[#1D40AB]',
          ),
        );
        tabContents.forEach((content) => content.classList.add('hidden'));

        // Add active state to the clicked tab and show corresponding content
        tab.classList.add(
          'border-blue-500',
          'text-blue-600',
          'dark:text-blue-500',
          'border-b-2',
        );
        const targetSelector = tab.getAttribute('data-tabs-target');

        // Check if targetSelector is non-null before using it
        if (targetSelector) {
          const target = document.querySelector<HTMLElement>(targetSelector);
          if (target) {
            target.classList.remove('hidden');
          }
        }
      });
    });
    this.processPressureData(this.formData);
  }
getDischarge()
{
  this.apiService.post('discharge_sprinkler_jockey', {'water_curtain_len': this.waterCurtainLength}).subscribe({
      next: (response: any) => {
        this.discharge = response.discharge_LPM_m;
        this.totalDischarge = response.total_discharge_lpm
        this.spinner = false;
      },
      error: (error) => {
        this.spinner = false;
      },
    });
}

  processPressureData(formData: any) {
    let payload: any = formData;
    let fittingValve: any = { type: '', quantity: 0 };
    if (this.formData.valveType && this.formData.quantity) {
      fittingValve.type = this.formData.valveType;
      fittingValve.quantity = this.formData.quantity;
    }

    this.apiService.post('get_pressure_sprinkler_jockey', payload).subscribe({
      next: (response: any) => {
        this.inputResponse = response;
        this.results = [];
        if (response?.results?.length > 0) {
          this.resultsOrder(response.results);
        }
        this.globalVar = response['global variables'];
        this.formData.efficiency = this.globalVar?.["Effeciency %"] ?? 0;
        this.initialInputSummaryLoad(response);

        this.spinner = false;
      },
      error: (error) => {
        this.spinner = false;
      },
    });
  }

  resultsOrder(results: any) {
    let horizontals = results
      .filter((f: any) => f.input.subType === 'horizontal')
      .sort((a: any, b: any) => a.input.sl - b.input.sl);

    let others = results
      .filter((f: any) => f.input.subType !== 'horizontal')
      .sort((a: any, b: any) => a.input.sl - b.input.sl);

    this.results = [...horizontals, ...others];
  }

  addItem(e: Event, id: number, name: string, targetArray: any): void {

  e.stopPropagation();



  // ✅ Find the first tab of the same type (Horizontal or Vertical)

  const firstSameTypeIndex = targetArray.findIndex(

    (item: any) => item.name === name

  );



  if (firstSameTypeIndex !== -1) {

    const newItem = { ...targetArray[firstSameTypeIndex] }; // clone from first of same type



    newItem.name = name;

    newItem.id = targetArray.length + 1;

    newItem.isSaved = false;

    newItem.location = '';



   if (name === 'Horizontal') {

  // Add after last horizontal tab

  const lastHorizontalIndex = targetArray.reduce((lastIndex: number, item: any, i: number) => {

    return item.name.toLowerCase().includes('horizontal') ? i : lastIndex;

  }, -1);



  if (lastHorizontalIndex !== -1) {

    targetArray.splice(lastHorizontalIndex + 1, 0, newItem);

  } else {

    targetArray.push(newItem);



  }

} else {

  // Add after last vertical tab

  const lastVerticalIndex = targetArray.reduce((lastIndex: number, item: any, i: number) => {

    return item.name.toLowerCase().includes('vertical') ? i : lastIndex;

  }, -1);



  if (lastVerticalIndex !== -1) {

    targetArray.splice(lastVerticalIndex + 1, 0, newItem);

  } else {

    targetArray.push(newItem);

  }

}



    this.updateIds(targetArray);

    console.log(targetArray);

  }

}


  removeItem(event: MouseEvent, id: number, targetArray: any): void {
    let find = targetArray.find((f: any) => f.id === id);
    let count = targetArray.filter((f: any) => f.name === find.name).length;
    if (count === 1) {
      this.removeRow(id);
    } else {
      event.stopPropagation(); // Prevents the parent click handler from firing
      const index = targetArray.findIndex((item: any) => item['id'] === id);
      if (index !== -1) {
        targetArray.splice(index, 1);
        // this.updateIds(targetArray);
        this.removeRow(id);
      }
    }
  }

  private updateIds(targetArray: any): void {
    targetArray.forEach((item: any, idx: any) => {
      // item['id'] = idx + 1;
      let summary = this.updateApartmentSummaries(item.id, [item], targetArray);
      targetArray[idx] = summary[0];
    });
  }

  onSave() {
    this.spinner = true;
    let payload: any = [];
    let fittingValve: any = { type: '', quantity: 0 };
    if (this.formData.valveType || this.formData.quantity) {
      fittingValve.type = this.formData.valveType;
      fittingValve.quantity =
        this.formData.lengthUnit === 'ft'
          ? this.formData.quantity * 304.8
          : this.formData.quantity ?? 0;
    }

    let data = {
      sl: this.serialNo,
      type:
        this.getScreen() === 'valve'
          ? 'Hydrant(Low zone)'
          : 'Hydrant(High zone)',
      location: this.formData.location,
      // pipe_section: this.showInputASummary ? this.formData.pipeSection : this.formData.valveType,
      residual_pressure_head: this.formData.residual_pressure_head,
      subType:
        this.formData.subType === 'Horizontal' ? 'horizontal' : 'vertical',

      parameters: {
        water_flow_rate:
          this.formData.waterFlowUnit === 'gpm'
            ? this.formData?.waterFlowRate * 3.78541 // gpm ➝ lpm
            : this.formData.waterFlowUnit === 'lps'
              ? this.formData?.waterFlowRate * 60     // lps ➝ lpm
              : this.formData?.waterFlowRate,
        internal_pipe_diameter:
          this.formData.internalPipeUnit === 'in'
            ? this.formData?.internalPipeDiameter * 25.4
            : this.formData?.internalPipeDiameter,
        length:
          this.formData.lengthUnit === 'ft'
            ? this.formData?.length * 3.28084
            : this.formData?.length,
        fitting_valve: this.getScreen() === 'valve' ? fittingValve : {},
      },
    };
    if (this.formData.valveType === 'Misc') {
      data.parameters = {
        ...data.parameters,
        Equivalent_length_of_Pipe_for_each_fitting: this.formData.lengthOfPipe ?? 0
      } as any;
    }
    payload[0] = data;
    this.apiService.post('get_pressure_sprinkler_jockey', payload).subscribe({
      next: (response: any) => {
        this.inputResponse = response;

        this.results = [];
        if (response?.results?.length > 0) {
          this.resultsOrder(response.results);
        }
        this.globalVar = response['global variables'];
        this.formData.efficiency = this.globalVar?.["Effeciency %"] ?? 0;
        this.initialInputSummaryLoad(response);
        this.spinner = false;
      },
      error: (error) => {
        this.spinner = false;
        console.error('API Error:', error);
      },
    });
  }

  updateApartmentSummaries(id: number, summaryToUpdate: any , targetArray?: any[]) {
    this.formData.residual_pressure_head =
      this.globalVar?.['Residual pressure head'];

    const keyMap: { [key: string]: string } = {
      Horizontal: 'Horizontal',
      Vertical: 'Vertical',
    };
    return summaryToUpdate?.map((item: { name: string | number }) => {
      const key = keyMap[item.name];
      if (id) {
         let details: any = this.inputResponse?.results?.find((f: any) => f.input.sl === id);

        if (!details) {

          details = {};

          let find = targetArray?.find((f: any) => f?.id === id);

          if (find) {

            const input: any = {parameters: {}};

            input.location = this.showInputBSummary ? '' : find?.location;

            input.parameters.water_flow_rate_lps = find?.parameters?.water_flow_rate_lps;

            input.parameters.internal_pipe_diameter = find?.parameters?.internal_pipe_diameter;

            input.parameters.length = find?.parameters?.length;

            input.parameters.fitting_valve = find?.parameters?.fitting_valve;

            details.input = {...input};

          }

        }


        return {
          ...item,
          value: key,
          location: details?.input?.['location'] || '',
          type: details?.input?.['type'],
          pipe_section: details?.input?.['pipe_section'] || '',
          residual_pressure_head:
            details?.input?.['residual_pressure_head'] || '',
          parameters: {
             water_flow_rate_lps: details?.input?.parameters?.['water_flow_rate_lps'] || 0,
            internal_pipe_diameter:

              details?.input?.parameters?.['internal_pipe_diameter'] || 0,

            length: details?.input?.parameters?.['length'] || 0,

            fitting_valve: details?.input?.parameters?.fitting_valve,
          },
          pressureDrop: details?.pressure?.['Pressure Drop'],
          totalPD: details?.pressure?.['Total P.D in pipes'],
          equivalentLength:
            details?.pressure?.['Equivalent length of Pipe for each fitting'],
          valveFittingPD: details?.pressure?.['Valve & Fitting PD'],
        };
      }
      return {
        ...item,
        value: '0',
        'Inorganic Waste': 0,
        'Organic Waste': 0,
        'Total Population': 0,
        Totals: 0,
        no_of_units: 0,
        residentialRefuge: 0,
      };
    });
  }

  toggleInputA(summary: any) {
    this.serialNo = summary?.id;
    this.showInputA = !this.showInputA;
    this.selectedInputASummary = this.showInputA ? summary : null;

    this.formData.location = summary?.location;
    // this.formData.pipeSection = summary?.pipe_section;
    this.formData.waterFlowRate = summary?.parameters?.water_flow_rate_lps;
    // changes
    this.formData.waterFlowUnit = 'lps';
    this.previousWaterFlowUnit = 'lps'

    this.formData.internalPipeDiameter =
      summary?.parameters?.internal_pipe_diameter;
    this.formData.length = summary?.parameters?.length;
    this.formData.subType = summary?.name;

    if (this.showInputA) {
      this.inputDropdownArrowSrc = 'assets/images/icons/up_arrow.svg';
      this.summaryText = 'Apartment Size';
      // this.onInputAChange();
    } else {
      this.inputDropdownArrowSrc = 'assets/images/icons/down_arrow.svg';
      this.summaryText = 'Summary - A';
    }
  }

  toggleInputB(summary: any) {
    this.serialNo = summary?.id;
    this.showInputB = !this.showInputB;
    this.selectedInputBSummary = this.showInputB ? summary : null;

    this.formData.quantity = summary?.parameters?.fitting_valve?.quantity;
    this.formData.valveType = summary?.parameters?.fitting_valve?.type ?? '';
    this.formData.location = summary?.location;
    // this.formData.pipeSection = summary?.pipe_section;
    this.formData.waterFlowRate = summary?.parameters?.water_flow_rate_lps;
    // changes
    this.formData.waterFlowUnit = 'lps';
    this.previousWaterFlowUnit = 'lps'
    
    this.formData.internalPipeDiameter =
      summary?.parameters?.internal_pipe_diameter;
    this.formData.length = summary?.parameters?.length;
    this.formData.subType = summary?.name;

    if (this.showInputB) {
      this.inputDropdownArrowSrc = 'assets/images/icons/up_arrow.svg';
      this.summaryText = '';
      // this.onInputBChange();
    } else {
      this.inputDropdownArrowSrc = 'assets/images/icons/down_arrow.svg';
      this.summaryText = 'Summary - B';
    }
  }

  private getScreen(): string {
    const screen = sessionStorage.getItem('screen');
    return screen ? screen : 'straight';
  }

  private setScreen(screen: string): void {
    sessionStorage.setItem('screen', screen);
  }

  toggleInputsSummary(id: string) {
    this.activeButtonId = this.activeButtonId === id ? null : id;
    if (this.activeButtonId?.includes('-a')) {
      this.processPressureData({});
      this.setScreen('straight');
      this.showInputASummary = true;
      this.showInputBSummary = false;
      this.summaryText = 'Summary - A';
      this.summaryType = 'A';
    } else if (this.activeButtonId?.includes('-b')) {
      this.processPressureData({ screen: 'valve' });
      this.setScreen('valve');
      this.showInputBSummary = true;
      this.showInputASummary = false;
      this.summaryText = 'Summary - B';
      this.summaryType = 'B';
    } else {
      return;
    }
  }

  getButtonClasses(id: string) {
    if (this.activeButtonId === id) {
      return {
        'bg-white': true,
        'py-[7px]': true,
        'text-[#1D40AB]': true,
        'text-[#000000]': false,
      };
    } else {
      return {
        'bg-white': false,
        'py-[7px]': false,
        'text-[#1D40AB]': false,
        'text-[#7F7E7E]': true,
      };
    }
  }

  validateResidentialRefuge(residentialRefuge: number) {
    if (residentialRefuge < 0.3) {
      this.residentialRefuge = 0.3;
      return 0.3;
    } else if (residentialRefuge > 0.6) {
      this.residentialRefuge = 0.6;
      return 0.6;
    }
    return residentialRefuge;
  }

  submit() {
    const projectDetailsString = sessionStorage.getItem('PROJECTDETAILS');

    let projectName = '';
    let projectType = '';
    let documentVersion = '';
    let date = '';

    if (projectDetailsString) {
      const projectDetails = JSON.parse(projectDetailsString);
      projectName = projectDetails.queryParams.projectName;
      projectType = projectDetails.queryParams.projectType;

      documentVersion = projectDetails.queryParams.documentVersion;
      date = projectDetails.queryParams.date;
    }

    const payload = {
      project_name: projectName,
      project_type: projectType,
      document_version: documentVersion,
      project_date: date,



      sub_module_name: 'sprinkler_jockey',
    };


    this.calculusCommonService.getReport(payload);
  }

  moveNext(): void {
    this.moveToTab.emit('sewage-sump-pump');
  }

  getInfo(buttonElement: HTMLElement) {
    this.calculusCommonService.openInfoPopUp(
      buttonElement,
      'pump_head_firefighting',
    );
  }

  reset() {
    let type = this.activeButtonId === 'tab-input-a' ? 'straight_sprinkler_jockey' : 'valve_sprinkler_jockey';
    this.spinner = true;
    this.apiService
      .post('reset_ff', { screen: type })
      .subscribe((response: any) => {
        this.inputResponse = response;
        this.results = [];
        if (response?.results?.length > 0) {
          this.resultsOrder(response.results);
        }
        this.globalVar = response?.['global variables'];
        this.formData.efficiency = this.globalVar?.["Effeciency %"] ?? 0;
        this.initialInputSummaryLoad(response);

        this.spinner = false;
      });
  }

  initialInputSummaryLoad(response: any) {
    let horizontalFound: boolean = false;
    let verticalFound: boolean = false;
    if (this.activeButtonId === 'tab-input-a') {
      let summaries: any = [];
      response?.results?.forEach((result: any) => {
        if (result?.input?.subType === 'horizontal') {
          horizontalFound = true;
          let summary = {
            ...this.inputSummaries.find((f) => f.name === 'Horizontal'),
          };
          summary.id = result?.input?.sl ?? summaries?.length + 1;
          summaries.push(summary);
        } else {
          verticalFound = true;
          let summary = {
            ...this.inputSummaries.find((f) => f.name === 'Vertical'),
          };
          summary.id = result?.input?.sl ?? summaries?.length + 1;
          summaries.push(summary);
        }
      });
      if (!horizontalFound) {
        let s = this.inputSummaries.find((f) => f.name === 'Horizontal');
        s.id = 1;
        summaries.push(s);
      }
      if (!verticalFound) {
        let s = this.inputSummaries.find((f) => f.name === 'Vertical');
        if (!s) {
          s = {
            id: null,
            name: 'Vertical',
            value: '',
            icon: 'assets/images/icons/enterprise.svg',
          };
        }
        s.id = 2;
        summaries.push(s);
      }

      let horizontals = summaries
        ?.filter((f: any) => f?.name === 'Horizontal')
        ?.sort((a: any, b: any) => a?.id - b?.id);
      summaries = summaries
        ?.filter((f: any) => f?.name !== 'Horizontal')
        ?.sort((a: any, b: any) => a?.id - b?.id);
      summaries = [...horizontals, ...summaries];
      this.inputSummaries = summaries;

      summaries = [];
      this.inputSummaries.forEach((sum) => {
        let summary = this.updateApartmentSummaries(sum.id, [sum]);
        summaries.push(summary?.[0]);
      });
      this.inputSummaries = summaries;
    }

    // valve start
    else {
      let summaries: any = [];
      response?.results?.forEach((result: any) => {
        if (result?.input?.subType === 'horizontal') {
          horizontalFound = true;
          let summary = { ...this.inputBSummaries[0] };
          summary.id = result?.input.sl ?? summaries?.length + 1;
          summaries.push(summary);
        } else {
          // verticalFound = true;
          let summary = { ...this.inputBSummaries[1] };
          summary.id = result?.input?.sl ?? summaries?.length + 1;
          summaries.push(summary);
        }
      });

      if (!horizontalFound) {
        let s: any = this.inputBSummaries.find((f) => f.name === 'Horizontal');
        s.id = 1;
        summaries.push(s);
      }
      // if (!verticalFound) {
      //   let s = this.inputSummaries[1];
      //   s.id = this.inputSummaries.length + 1;
      //   summaries.push(s);
      // }

      let horizontals = summaries
        ?.filter((f: any) => f?.name === 'Horizontal')
        ?.sort((a: any, b: any) => a?.id - b?.id);
      summaries = summaries
        ?.filter((f: any) => f?.name !== 'Horizontal')
        ?.sort((a: any, b: any) => a?.id - b?.id);
      summaries = [...horizontals, ...summaries];
      this.inputBSummaries = summaries;

      summaries = [];
      this.inputBSummaries?.forEach((sum) => {
        let summary = this.updateApartmentSummaries(sum.id, [sum]);
        summaries.push(summary?.[0]);
      });
      this.inputBSummaries = summaries;
    }
    this.selectedInputSummaryUpdate();
  }

  selectedInputSummaryUpdate() {
    if (this.selectedInputASummary) {
      let findA = this.inputSummaries?.find(
        (f: any) => f?.id === this.selectedInputASummary?.id,
      );
      this.selectedInputASummary.pressureDrop = findA?.pressureDrop;
      this.selectedInputASummary.totalPD = findA?.totalPD;
    }

    if (this.selectedInputBSummary) {
      let findB: any = this.inputBSummaries?.find(
        (f: any) => f?.id === this.selectedInputBSummary?.id,
      );
      this.selectedInputBSummary.pressureDrop = findB?.pressureDrop;
      this.selectedInputBSummary.equivalentLength = findB?.equivalentLength;
      this.selectedInputBSummary.valveFittingPD = findB?.valveFittingPD;
    }
  }

  previousWaterFlowUnit: string = 'lps'; // default unit

   waterFlowUnitConversion(newUnit: string) {
    if (!this.formData?.waterFlowRate || !this.previousWaterFlowUnit) {
      this.previousWaterFlowUnit = newUnit;
      return;
    }

    const rate = this.formData.waterFlowRate;

    // Step 1: Convert from previous unit to base unit (liters per second)
    let valueInLps: number;
    switch (this.previousWaterFlowUnit) {
      case 'gpm':
        valueInLps = rate * 3.78541 / 60;
        break;
      case 'lpm':
        valueInLps = rate / 60;
        break;
      case 'lps':
      default:
        valueInLps = rate;
        break;
    }

    // Step 2: Convert from LPS to the new unit
    let convertedValue: number;
    switch (newUnit) {
      case 'gpm':
        convertedValue = valueInLps * 60 / 3.78541;
        break;
      case 'lpm':
        convertedValue = valueInLps * 60;
        break;
      case 'lps':
      default:
        convertedValue = valueInLps;
        break;
    }

    this.formData.waterFlowRate = +convertedValue.toFixed(4); // limit to 4 decimals
    this.previousWaterFlowUnit = newUnit;
  }

  diameterUnitConversion(unit: string) {
    if (unit === 'in') {
      this.diameterValues = [
        0.5905511811023623, 0.7874015748031497, 0.984251968503937,
        1.2598425196850394, 1.5748031496062993, 1.968503937007874,
        2.5590551181102366, 3.1496062992125986, 3.937007874015748,
        5.905511811023622, 7.874015748031496, 9.84251968503937,
        11.811023622047244,
      ];
      let inchValue = this.formData?.internalPipeDiameter / 25.4;
      this.formData.internalPipeDiameter = inchValue;
    } else if (unit === 'mm') {
      this.diameterValues = [
        15, 20, 25, 32, 40, 50, 65, 80, 100, 150, 200, 250, 300,
      ];
      let mmValue = this.formData?.internalPipeDiameter * 25.4;
      this.formData.internalPipeDiameter = mmValue;
    }
  }

  lengthUnitConversion(unit: string) {
    if (unit === 'ft') {
      let ftValue = this.formData?.length / 3.28084;
      this.formData.length = ftValue;
    } else if (unit === 'm') {
      let mValue = this.formData?.length * 3.28084;
      this.formData.length = mValue;
    }
  }

  fittingUnitConversion(unit: string) {
    if (unit === 'ft') {
      let ftValue = this.formData?.quantity / 304.8;
      this.formData.quantity = ftValue;
    } else if (unit === 'mm') {
      let mmValue = this.formData?.quantity * 304.8;
      this.formData.quantity = mmValue;
    }
  }

  onResidualInputChange() {
    let type = this.activeButtonId === 'tab-input-a' ? 'straight' : 'valve';
    this.apiService
      .post('get_pressure_sprinkler_jockey', {
        residual_head: this.formData?.residual_pressure_head ?? 0,
        efficiency: this.formData?.efficiency ?? 0,



        type: type,
      })
      .subscribe((response: any) => {
        // this.globalVar['Residual pressure head'] = res.residual_head ?? 0;
        this.inputResponse = response;
        this.results = [];
        if (response?.results?.length > 0) {
          this.resultsOrder(response.results);
        }
        this.globalVar = response?.['global variables'];
        this.formData.efficiency = this.globalVar?.["Effeciency %"] ?? 0;
        this.initialInputSummaryLoad(response);
      });
  }

  removeRow(sl: number) {
    this.spinner = true;
    let type = this.activeButtonId === 'tab-input-a' ? 'straight' : 'valve';
    this.apiService
      .post('delete_firefighter_sprinkler_jockey', { sl: sl, type: type })
      .subscribe(
        (response: any) => {
          this.inputResponse = response;
          this.results = [];
          if (response?.results?.length > 0) {
            this.resultsOrder(response.results);
          }
          this.globalVar = response?.['global variables'];
          this.formData.efficiency = this.globalVar?.["Effeciency %"] ?? 0;
          this.initialInputSummaryLoad(response);

          this.spinner = false;
        },
        (error) => (this.spinner = false),
      );
  }
}
