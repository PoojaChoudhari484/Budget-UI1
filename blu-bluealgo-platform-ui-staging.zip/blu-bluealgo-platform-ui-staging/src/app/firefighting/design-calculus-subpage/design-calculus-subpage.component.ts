import { Location } from '@angular/common';
import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { ModuleService } from 'src/app/services/module.service';

@Component({
    selector: 'app-design-calculus-subpage',
    templateUrl: './design-calculus-subpage.component.html',
    styleUrls: ['./design-calculus-subpage.component.scss'],
    standalone: false
})
export class DesignCalculusSubpageComponent implements OnInit {
  modules: string[] = [
    'Hydrant',
    'Hydrant Jockey',
    'Sprinkler',
    'Drencher Pump',
    'Summary'
  ];

  constructor(
    private router: Router,
    private moduleService: ModuleService
  ) {}

  ngOnInit(): void {}

   goTo(module: string) {
   const moduleRouteMap: { [key: string]: string } = {
      "Hydrant": '/firefighting/hydrant-high-zone',
      "Sprinkler": '/firefighting/sprinkler-high-zone',
      "Hydrant Jockey":'/firefighting/hydrant-jockey',
      
      "Drencher Pump":'/firefighting/sprinkler-jockey',
      "Summary": '/firefighting/ff-summary',
    };

    this.moduleService.updateSelectedSubModule(module);
     this.router.navigate([moduleRouteMap[module]], 
  JSON.parse(sessionStorage.getItem('PROJECTDETAILS') || '{}'));
  }
}
