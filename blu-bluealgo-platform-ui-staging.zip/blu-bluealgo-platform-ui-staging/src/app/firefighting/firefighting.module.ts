import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FireFightingRoutingModule } from './firefighting-routing.module';
import { MatIconModule } from '@angular/material/icon';
import { MatButtonModule } from '@angular/material/button';
import { FormsModule } from '@angular/forms';
import { BrowserModule } from '@angular/platform-browser';
import { BrowserAnimationsModule } from '@angular/platform-browser/animations';
import { MatProgressBarModule } from '@angular/material/progress-bar';
import { ProjectDetailsComponent } from './project-details/project-details.component';  
import { MatAngularModule } from '../mat-angular/mat-angular.module';
import { SharedCCModule } from '../shared-cc/shared-cc.module';
import { SummaryCalculationFfComponent } from './ff-summary/tabs/summary-calculation-ff/summary-calculation-ff.component';

@NgModule({
  declarations: [
    ProjectDetailsComponent,
    SummaryCalculationFfComponent,
  ],
  imports: [
    CommonModule,
    SharedCCModule,
    FireFightingRoutingModule,
    BrowserModule,
    BrowserAnimationsModule,
    MatProgressBarModule,
    FormsModule,
    MatIconModule,
    MatButtonModule,
    MatAngularModule,
  ],
})
export class FireFightingModule {}
