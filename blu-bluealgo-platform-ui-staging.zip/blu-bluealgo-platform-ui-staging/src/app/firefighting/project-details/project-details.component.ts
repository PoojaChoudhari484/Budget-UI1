import { Component } from '@angular/core';
import { Router } from '@angular/router';
import { ActivatedRoute } from '@angular/router';
import { ModuleService } from 'src/app/services/module.service';
import { LocalApiService } from 'src/app/core/services/local-api.service';

@Component({
    selector: 'app-project-details',
    templateUrl: './project-details.component.html',
    styleUrls: ['./project-details.component.scss'],
    standalone: false
})
export class ProjectDetailsComponent {


  selectedModule: string = '';
  documentVersion: string = '';
  projectName: string = '';
  projectType: string = '';
   isNewProject: boolean = false;
  newProjectName: string = '';
   showProgress = false;
  progressValue = 0;
  onClickCloseOrNext = true;
  interval: any;
  loading: boolean;
  constructor(
    private apiService: LocalApiService,
    private router: Router,
    private moduleService: ModuleService,
    private activatedRoute: ActivatedRoute,
  ) {}

  ngOnInit(): void {
    this.apiService.post<any>('get_project_name', {}).subscribe(
      (response) => {
         this.projectName = response.project_name;
      },
      (error) => {
        console.error('API Error:', error);
      },
    );
    
    this.activatedRoute.queryParams.subscribe((params) => {
      const moduleFromQuery = params['module'];
      

      if (moduleFromQuery) {
        this.moduleService.updateSelectedModule(moduleFromQuery);
      }
    });

    this.moduleService.selectedSubModule$.subscribe((module) => {
      this.selectedModule = module;
      this.updateDocumentVersion(module, this.projectName, this.projectType);
    });

    this.projectName = this.projectName || '';
    this.projectType = this.projectType || '';
  }

  onInputChange() {
    this.updateDocumentVersion(
      this.selectedModule,
      this.projectName,
      this.projectType,
    );
  }

  updateDocumentVersion(
    module: string,
    projectName: string,
    projectType: string,
  ) {
    const moduleAbbreviations: { [key: string]: string } = {
      "Hydrant": 'HY',
      "Sprinkler": 'SP',
      "Hydrant Jockey":'HYJ',
      "Hydrant Sprinkler":"HYS",
      
      Reports: 'REP',
    };

    const projectNamePrefix = projectName ? projectName.slice(0, 4) : 'Cent';
    const projectTypePrefix = projectType ? projectType.slice(0, 4) : 'Resi';

    const abbreviation = moduleAbbreviations[module] || 'GEN';

    this.documentVersion = `LTR/HO-MEPF/Design/${abbreviation}/${projectTypePrefix}-${projectNamePrefix}-001`;
  }
  navigateToOwc() {
    const moduleRouteMap: { [key: string]: string } = {
      "Hydrant": '/firefighting/hydrant-high-zone',
      "Sprinkler": '/firefighting/sprinkler-high-zone',
      "Hydrant Jockey":'/firefighting/hydrant-jockey',
      
      "Sprinkler Jockey":'/firefighting/sprinkler-jockey',
      "Summary": '/firefighting/ff-summary',
      
      
    }

    this.showProgress = true;
  this.onClickCloseOrNext = false;
  this.progressValue = 0;


     const navigationExtras = {
        queryParams: {
          projectName: Array.isArray(this.projectName) ? this.newProjectName : this.newProjectName || this.projectName,
          projectType: this.projectType,
          documentVersion: this.documentVersion,
          date: new Date().toISOString().split('T')[0],
        },
      };
    sessionStorage.setItem('PROJECTDETAILS', JSON.stringify(navigationExtras),);
       this.loading = true; // start loading

this.apiService.post<any>('get_project_name', navigationExtras).subscribe(
  (response) => {
    console.log(response);
    this.loading = false; // stop loading
    this.router.navigate(['/firefighting/design-calculus-submodules/'], navigationExtras);
  },
  (error) => {
    console.error('API Error:', error);
    this.loading = false; // stop loading even on error
  }
);
 let totalDuration = 300; // 300 seconds = 5 minutes
    let intervalTime = 1000; // update every 1 second
    let step = 100 / totalDuration; // How many percent increase per second
    this.interval = setInterval(() => {
    this.progressValue += step;

    if (this.progressValue >= 100) {
      clearInterval(this.interval);
      this.showProgress = false;
      this.router.navigate(['/firefighting/design-calculus-submodules/'], navigationExtras);
      
    }
  }, intervalTime);

      
    
  }
  navigateToModules() {
    this.router.navigate(['/phe/design-calculus']);
  }
}
