import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { HydrantHighZoneComponent } from './hydrant-high-zone/hydrant-high-zone.component';
import { SprinklerHighZoneComponent } from './sprinkler-high-zone/sprinkler-high-zone.component';
import { SprinklerJockeyComponent } from './sprinkler-jockey/sprinkler-jockey.component';
import { HydrantJockeyComponent } from './hydrant-jockey/hydrant-jockey.component';
import {FFSummaryComponent} from "./ff-summary/ff-summary.component";
import { SummaryCalculationFfComponent } from './ff-summary/tabs/summary-calculation-ff/summary-calculation-ff.component'; 
import { ProjectDetailsComponent } from './project-details/project-details.component';
import { DesignCalculusSubpageComponent } from './design-calculus-subpage/design-calculus-subpage.component';

const routes: Routes = [
  {
    path: '',
    children: [
      { path: '', redirectTo: 'hydrant-high-zone', pathMatch: 'full' },
      { path: 'hydrant-high-zone', component: HydrantHighZoneComponent },
      { path: 'sprinkler-high-zone', component: SprinklerHighZoneComponent },
      { path: 'sprinkler-jockey', component: SprinklerJockeyComponent },
      { path: 'hydrant-jockey', component: HydrantJockeyComponent },
      { path: 'ff-summary', redirectTo: 'summary-calculation-ff',pathMatch: 'full'},
      {path: 'summary-calculation-ff',component: SummaryCalculationFfComponent},
      {path: 'design-calculus-submodules',component: DesignCalculusSubpageComponent},
      { path: 'project-details', component: ProjectDetailsComponent },
    ],
  },
];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule],
})
export class FireFightingRoutingModule {}
