import { ComponentFixture, TestBed } from '@angular/core/testing';

import { SprinklerHighZoneComponent } from './sprinkler-high-zone.component';

describe('SprinklerHighZoneComponent', () => {
  let component: SprinklerHighZoneComponent;
  let fixture: ComponentFixture<SprinklerHighZoneComponent>;

  beforeEach(() => {
    TestBed.configureTestingModule({
      declarations: [SprinklerHighZoneComponent],
    });
    fixture = TestBed.createComponent(SprinklerHighZoneComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
