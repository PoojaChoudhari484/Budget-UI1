import { Component } from '@angular/core';
import { ChartOptions, ChartData } from 'chart.js';

@Component({
    selector: 'app-invoice-dashboard',
    templateUrl: './invoice-dashboard.component.html',
    styleUrls: ['./invoice-dashboard.component.scss'],
    standalone: false
})
export class InvoiceDashboardComponent {
  isMonthlyDropdownOpen = false;
  showOptionsMenu = false;
  isFilterDropdownOpen = false;

  isOn: boolean = false;

  toggle() {
    this.isOn = !this.isOn;
  }

  toggleMonthlyDropdown() {
    this.isMonthlyDropdownOpen = !this.isMonthlyDropdownOpen;
  }


  togglleOptionsMenu() {
    this.showOptionsMenu = !this.showOptionsMenu;
  }

  onEditt() {
    this.showOptionsMenu = false;
  }

  onDeletee() {
    this.showOptionsMenu = false;
  }

  onSettingss() {
    this.showOptionsMenu = false;
  }
  


  toggleFilterDropdown() {
    this.isFilterDropdownOpen = !this.isFilterDropdownOpen;
  }



  public invoices = [
    {
      name: 'Arun Arora',
      number: 'Invc0001',
      invoiceDate: '21-04-2025',
      dueDate: '25-04-2025',
      terms: 'Net30',
      location: 'Location 1',
      item: 1,
      total: 200,
      status: 'Pending'
    },
    {
      name: 'Bryan Biz',
      number: 'Invc0002',
      invoiceDate: '21-04-2025',
      dueDate: '25-04-2025',
      terms: 'Net30',
      location: 'Location 1',
      item: 1,
      total: 400,
      status: 'Paid'
    },
    {
      name: 'Arun Arora',
      number: 'Invc0003',
      invoiceDate: '21-04-2025',
      dueDate: '25-04-2025',
      terms: 'Net30',
      location: 'Location 1',
      item: 1,
      total: 200,
      status: 'Pending'
    },
  ];


  public openMenuIndex: number | null = null;

toggleOptionsMenu(index: number) {
  if (this.openMenuIndex === index) {
    this.openMenuIndex = null; // close if same row clicked
  } else {
    this.openMenuIndex = index;
  }
}

onEdit() {
  this.openMenuIndex = null;
}

onDelete() {
  this.openMenuIndex = null;
}

onSettings() {
  this.openMenuIndex = null;
}

public barChartType: 'bar' = 'bar';

public paymentTrendsStackedChartData: ChartData<'bar'> = {
  labels: [
    'Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun',
    'Jul', 'Aug', 'Sep', 'Oct', 'Nov', 'Dec'
  ],
  datasets: [
    {
      label: 'Collected',
      data: [40000, 50000, 35000, 32000, 30000, 31000, 35000, 25000, 30000, 34000, 32000, 40000],
      backgroundColor: ['#CCCCCC','#CCCCCC','#CCCCCC','#CCCCCC','#CCCCCC','#CCCCCC','#CCCCCC','#CCCCCC','#4C89FF','#3AC43D', '#FF7F50','#CCCCCC' 
      ],
      borderRadius: 20,
      barPercentage: 0.4,
      categoryPercentage: 0.4,
    },
  ]
};

public paymentTrendsStackedChartOptions: ChartOptions<'bar'> = {
  responsive: true,
  maintainAspectRatio: false,
  plugins: {
    legend: {
      display: false
    },
    tooltip: {
      enabled: true
    }
  },
  scales: {
    x: {
      grid: { display: false },
      ticks: { font: { size: 14 } }
    },
    y: {
      min: 0,
      max: 55000,
      grid: { display: false },
      ticks: { stepSize: 10000, font: { size: 14 } }
    }
  }
};


public paymentTrendsStackedChartOptionsColors: string[] = ['#3f83f8', '#22c55e', '#fb923c'];

  activeTab: string = 'actively';

  tabs = [
    { key: 'actively', label: 'Actively' },
    { key: 'log', label: 'Log a call' },
    { key: 'event', label: 'New event' }
  ];

  tasks = [
    { name: 'TASK' }
  ];

  createTask() {
    alert('Create a task clicked!');
  }

  activeTab2: string = 'aianalysis';

  tabs2 = [
    { key: 'aianalysis', label: 'AI Analysis' },
    { key: 'a/raging', label: 'A/R Aging' },
    { key: 'planvsactuals', label: 'Plan vs Actuals' }
  ];

  maintabs = [
    'Overview',
    'Details',
    'Invoices',
    'Reminders & Actions',
    'Notes & Files',
    'Disputes'
  ];

  mainactiveTab = 'Overview';

  selectTab(tab: string) {
    this.activeTab = tab;
  }
}
