import { Component } from '@angular/core';

@Component({
    selector: 'app-track-payment',
    templateUrl: './track-payment.component.html',
    styleUrls: ['./track-payment.component.scss'],
    standalone: false
})
export class TrackPaymentComponent {
  showOptionsMenu = false;
  isFilterDropdownOpen = false;
  issortDropdownOpen = false;

  togglleOptionsMenu() {
    this.showOptionsMenu = !this.showOptionsMenu;
  }

  onEditt() {
    this.showOptionsMenu = false;
  }

  onDeletee() {
    this.showOptionsMenu = false;
  }

  onSettingss() {
    this.showOptionsMenu = false;
  }

  toggleFilterDropdown() {
    this.isFilterDropdownOpen = !this.isFilterDropdownOpen;
  }

  togglesortDropdown() {
    this.issortDropdownOpen = !this.issortDropdownOpen;
  }


  public invoices = [
    {
      avatar: 'assets/images/Avatar.png',
      name: 'Arun Arora',
      receivable: '32.75',
      received: '500',
      outstanding: '0.00',
      bank: 'ICIC',
      inv_no: 'INV0001',
      date: '25-04-2025',
      currency: 'USD',
      proof_of_payment: 'assets/images/plan-view.png',
      verified_icon: 'assets/images/head.png'
    },
    {
      avatar: 'assets/images/Avatar.png',
      name: 'Bryan Brown',
      receivable: '44',
      received: '44',
      outstanding: '-44',
      bank: 'Bank of America',
      inv_no: 'INV0002',
      date: '25-04-2025',
      currency: 'INR',
      proof_of_payment: 'assets/images/plan-view.png',
    },
    {
      avatar: 'assets/images/Avatar.png',
      name: 'Arun Arora',
      receivable: '44',
      received: '44',
      outstanding: '0',
      bank: 'Bank of America',
      inv_no: 'INV0003',
      date: '25-04-2025',
      currency: 'INR',
      proof_of_payment: 'assets/images/plan-view.png',
      verified_icon: 'assets/images/head.png'
    }
  ];

  
  public openMenuIndex: number | null = null;

  toggleOptionsMenu(index: number) {
    this.openMenuIndex = this.openMenuIndex === index ? null : index;
  }

onEdit() {
  this.openMenuIndex = null;
}

onDelete() {
  this.openMenuIndex = null;
}

onSettings() {
  this.openMenuIndex = null;
}


statistics = [
  {
    title: 'DSO',
    value: 0,
    growth: '10% from this last week',
    icon: 'assets/images/down_growth.png',
  },
  {
    title: 'CEI',
    value: 0,
    growth: '10% from this last week',
    icon: 'assets/images/down_growth.png',
  },
  {
    title: 'Avg. days delinquent',
    value: 0,
    growth: '10% from this last week',
    icon: 'assets/images/down_growth.png',
  },
  {
    title: 'High risk account',
    value: 0,
    growth: '10% from this last week',
    icon: 'assets/images/down_growth.png',
  },
  {
    title: 'ART',
    value: 0,
    growth: '10% from this last week',
    icon: 'assets/images/down_growth.png',
  },
];


summaryCards = [
  {
    title: 'Total',
    value: '$120.75',
    icon: 'total',
  },
  {
    title: 'Overdue',
    value: '$44',
    icon: 'overdue',
  },
  {
    title: 'Received',
    value: '$588',
    icon: 'received',
  },
  {
    title: 'Open invoice',
    value: '1',
    icon: 'open_invoice',
  },
  {
    title: 'Severely delayed',
    value: '0',
    icon: 'severely_delayed',
  },
];
}
