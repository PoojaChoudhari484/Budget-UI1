import { Component } from '@angular/core';
import { ChartOptions, ChartData } from 'chart.js';

@Component({
    selector: 'app-customer-dashboard',
    templateUrl: './customer-dashboard.component.html',
    styleUrls: ['./customer-dashboard.component.scss'],
    standalone: false
})


export class CustomerDashboardComponent {
  isOn: boolean = false;

  toggle() {
    this.isOn = !this.isOn;
  }

  public barChartType: 'bar' = 'bar';


  public paymentTrendsStackedChartData: ChartData<'bar'> = {
    labels: [
      'Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun',
      'Jul', 'Aug', 'Sep', 'Oct', 'Nov', 'Dec'
    ],
    datasets: [
      {
        label: 'Collected',
        data: [40000, 50000, 35000, 32000, 30000, 31000, 35000, 25000, 30000, 34000, 32000, 40000],
        backgroundColor: ['#CCCCCC','#CCCCCC','#CCCCCC','#CCCCCC','#CCCCCC','#CCCCCC','#CCCCCC','#CCCCCC','#4C89FF','#3AC43D', '#FF7F50','#CCCCCC' 
        ],
        borderRadius: 20,
        barPercentage: 0.4,
        categoryPercentage: 0.4,
      },
    ]
  };

  public paymentTrendsStackedChartOptions: ChartOptions<'bar'> = {
    responsive: true,
    maintainAspectRatio: false,
    plugins: {
      legend: {
        display: false
      },
      tooltip: {
        enabled: true
      }
    },
    scales: {
      x: {
        grid: { display: false },
        ticks: { font: { size: 14 } }
      },
      y: {
        min: 0,
        max: 55000,
        grid: { display: false },
        ticks: { stepSize: 10000, font: { size: 14 } }
      }
    }
  };

  public paymentTrendsStackedChartOptionsColors: string[] = ['#3f83f8', '#22c55e', '#fb923c'];

  activeTab: string = 'actively';

  tabs = [
    { key: 'actively', label: 'Actively' },
    { key: 'log', label: 'Log a call' },
    { key: 'event', label: 'New event' }
  ];

  tasks = [
    { name: 'TASK' }
  ];

  createTask() {
    alert('Create a task clicked!');
  }

  activeTab2: string = 'aianalysis';

  tabs2 = [
    { key: 'aianalysis', label: 'AI Analysis' },
    { key: 'a/raging', label: 'A/R Aging' },
    { key: 'planvsactuals', label: 'Plan vs Actuals' }
  ];

  maintabs = [
    'Overview',
    'Details',
    'Invoices',
    'Reminders & Actions',
    'Notes & Files',
    'Disputes'
  ];

  mainactiveTab = 'Overview';

  selectTab(tab: string) {
    this.activeTab = tab;
  }


  public profile_invoice = [
    {
      invoice_id: '1001',
      date: '21-04-2025',
      invoicedamount: '50000',
      paidamount: '2500',
      dueamount: '30000',
      overdueamount: '15000',
      status: 'green'
    },
    {
      invoice_id: '1002',
      date: '21-04-2025',
      invoicedamount: '50000',
      paidamount: '2500',
      dueamount: '30000',
      overdueamount: '15000',
      status: 'red'
    },
    {
      invoice_id: '1003',
      date: '21-04-2025',
      invoicedamount: '50000',
      paidamount: '2500',
      dueamount: '30000',
      overdueamount: '15000',
      status: 'gray'
    },
    {
      invoice_id: '1004',
      date: '21-04-2025',
      invoicedamount: '50000',
      paidamount: '2500',
      dueamount: '30000',
      overdueamount: '15000',
      status: 'orange'
    },
  ];
}
