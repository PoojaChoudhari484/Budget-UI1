import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { DashboardComponent } from './dashboard.component';
import { CustomerDashboardComponent } from './customer-dashboard/customer-dashboard.component';
import { InvoiceDashboardComponent } from './invoice-dashboard/invoice-dashboard.component';
import { TrackPaymentComponent } from './track-payment/track-payment.component';

const routes: Routes = [
  {
    path: '',
    component: DashboardComponent,
  },
  {
    path: 'customer-dashboard',
    component: CustomerDashboardComponent,
  },
  {
    path: 'invoice-dashboard',
    component: InvoiceDashboardComponent,
  },
  {
    path: 'track-payment',
    component: TrackPaymentComponent,
  },
];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule],
})
export class DashboardRoutingModule {}
