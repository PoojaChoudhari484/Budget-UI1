import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { DashboardComponent } from './dashboard.component';
import { DashboardRoutingModule } from './dashboard-routing.module';
import { CustomerDashboardComponent } from './customer-dashboard/customer-dashboard.component';
import { NgChartsModule } from 'ng2-charts';
import { InvoiceDashboardComponent } from './invoice-dashboard/invoice-dashboard.component';
import { TrackPaymentComponent } from './track-payment/track-payment.component';

@NgModule({
  imports: [CommonModule, DashboardRoutingModule,NgChartsModule,CommonModule],
  declarations: [DashboardComponent, CustomerDashboardComponent, InvoiceDashboardComponent, TrackPaymentComponent,],
})
export class DashboardModule {}
