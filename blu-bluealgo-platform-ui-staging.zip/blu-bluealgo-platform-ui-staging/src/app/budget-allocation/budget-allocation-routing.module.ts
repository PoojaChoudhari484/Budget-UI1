import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { AuthGuard } from '../core/guard/auth.guard';
import { BudgetAllocationComponent } from './budget-allocation.component';
import { BudgetReportsComponent } from './budget-reports/budget-reports.component';
import { AdminDashboardComponent } from './admin-dashboard/admin-dashboard.component';
import { DesignDepartmentComponent } from './design-department/design-department.component';
import { MoreDepartmentComponent } from './more-department/more-department.component';
import { InputCComponent } from './input-c/input-c.component';

const routes: Routes = [
  {
    path: '',
    component: BudgetAllocationComponent,
    canActivate: [AuthGuard],
    children: [
      { path: '', redirectTo: 'department-dashboard', pathMatch: 'full' },
      {
        path: 'budget-report',
        canActivate: [AuthGuard],
        component: BudgetReportsComponent,
      },
      {
        path: 'admin-dashboard',
        canActivate: [AuthGuard],
        component: AdminDashboardComponent,
      },
      {
        path: 'department-dashboard',
        canActivate: [AuthGuard],
        component: DesignDepartmentComponent,
      },
      {
        path: 'more-department',
        canActivate: [AuthGuard],
        component: MoreDepartmentComponent,
      },
      {
        path: 'input-c',
        canActivate: [AuthGuard],
        component: InputCComponent,
      },
    ],
  },
];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule],
})
export class BudgetAllocationRoutingModule {}
