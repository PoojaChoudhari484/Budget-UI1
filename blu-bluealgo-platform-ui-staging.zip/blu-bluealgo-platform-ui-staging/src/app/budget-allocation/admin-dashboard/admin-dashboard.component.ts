import { Component, ViewChild } from '@angular/core';
import {
  ApexChart,
  ApexDataLabels,
  ApexLegend,
  ApexNonAxisChartSeries,
  ApexPlotOptions,
  ApexResponsive,
  ApexTooltip,
  ChartComponent,
} from 'ng-apexcharts';

export type ChartOptions = {
  series: ApexNonAxisChartSeries;
  chart: ApexChart;
  responsive: ApexResponsive[];
  legend: ApexLegend;
  dataLabels: ApexDataLabels;
  tooltip: ApexTooltip;
  plotOptions: ApexPlotOptions;
};

@Component({
    selector: 'app-admin-dashboard',
    templateUrl: './admin-dashboard.component.html',
    styleUrls: ['./admin-dashboard.component.scss'],
    standalone: false
})
export class AdminDashboardComponent {
  @ViewChild('chart') chart!: ChartComponent;
  public chartOptions: ChartOptions;

  ellipseImages: string[] = [
    './assets/images/icon-images/Template_white.svg',
    './assets/images/icon-images/Teams.svg',
    './assets/images/icon-images/Projects.svg',
    './assets/images/icon-images/Calendar.svg',
    './assets/images/icon-images/Document.svg',
    './assets/images/icon-images/Report.svg',
  ];

  segment1Value: number = 20;
  segment2Value: number = 40;
  segment3Value: number = 10;
  Object = Object;

  menuList: string[] = [
    'Dashboard',
    'Teams',
    'Projects',
    'Calendar',
    'Document',
    'Report',
  ];
  selectedMenuIndex: number = 0;

  constructor() {
    this.chartOptions = this.initChart();
  }

  ngOnInit(): void {}

  initChart(): ChartOptions {
    return {
      series: [44, 55, 13, 43], // Dynamic series data
      chart: {
        type: 'donut',
        width: '140px',
        height: '140px',
      },
      plotOptions: {
        pie: {
          donut: {
            size: '65%',
          },
        },
      },
      legend: {
        show: false, // This will hide the legend and series labels
      },
      dataLabels: {
        enabled: false, // This hides the labels inside the chart
      },
      tooltip: {
        enabled: false, // This disables the tooltip
      },
      responsive: [
        {
          breakpoint: 480,
          options: {
            chart: {
              width: '100%',
            },
          },
        },
      ],
    };
  }

  getData(i: number) {
    this.selectedMenuIndex = i;
  }
}
