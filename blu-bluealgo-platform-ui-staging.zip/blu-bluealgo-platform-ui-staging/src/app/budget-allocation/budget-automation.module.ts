import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';

import { BudgetAllocationRoutingModule } from './budget-allocation-routing.module';
import { BudgetAllocationComponent } from './budget-allocation.component';
import { BudgetAutomationHeaderComponent } from './common/budget-allocation-header/budget-automation-header.component';
import { NgApexchartsModule } from 'ng-apexcharts';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { MatFormFieldModule } from '@angular/material/form-field';
import { MatIconModule } from '@angular/material/icon';
import { LogoutSectionComponent } from './common/logout-section/logout-section.component';
import { provideHttpClient, withInterceptorsFromDi } from '@angular/common/http';
import { MatButtonModule } from '@angular/material/button';
import { MatInputModule } from '@angular/material/input';
import { MatSnackBarModule } from '@angular/material/snack-bar';
import { BudgetReportsComponent } from './budget-reports/budget-reports.component';
import { DesignDepartmentComponent } from './design-department/design-department.component';
import { AdminDashboardComponent } from './admin-dashboard/admin-dashboard.component';
import { MatDialogModule } from '@angular/material/dialog';
import { MoreDepartmentComponent } from './more-department/more-department.component';
import { InputCComponent } from './input-c/input-c.component';
import { DepartmentSectionComponent } from './common/department-section/department-section.component';
import { MatTooltipModule } from '@angular/material/tooltip';
import { SpinnerComponent } from './common/spinner/spinner.component';
import { FloatingZoomDialogComponent } from './common/floating-zoom-dialog/floating-zoom-dialog.component';
import { ScrollingModule } from '@angular/cdk/scrolling';
import { BudgetInformationDialogComponent } from './common/budget-information-dialog/budget-information-dialog.component';

@NgModule({
  declarations: [
    BudgetAllocationComponent,
    BudgetAutomationHeaderComponent,
    LogoutSectionComponent,
    BudgetReportsComponent,
    DesignDepartmentComponent,
    AdminDashboardComponent,
    MoreDepartmentComponent,
    InputCComponent,
    DepartmentSectionComponent,
    SpinnerComponent,
    FloatingZoomDialogComponent,
    FloatingZoomDialogComponent,
    FloatingZoomDialogComponent,
    BudgetInformationDialogComponent,
  ],
  exports: [LogoutSectionComponent, SpinnerComponent],
  imports: [CommonModule,
    BudgetAllocationRoutingModule,
    FormsModule,
    MatFormFieldModule,
    MatIconModule,
    ReactiveFormsModule,
    MatButtonModule,
    MatInputModule,
    NgApexchartsModule,
    MatSnackBarModule,
    MatDialogModule,
    MatTooltipModule,
    ScrollingModule
  ],
  providers: [provideHttpClient(withInterceptorsFromDi())]
})
export class BudgetAllocationModule { }
