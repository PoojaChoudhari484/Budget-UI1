import { Injectable } from '@angular/core';
import { HttpClient, HttpParams, HttpResponse } from '@angular/common/http';
import { Observable } from 'rxjs';
import { BUDGET_BASE_URL } from './budget-base-url';

@Injectable({
  providedIn: 'root',
})
export class BudgetReportsService {
  private base_url = BUDGET_BASE_URL + 'outputs/';

  constructor(private http: HttpClient) {}

  getDataByDepartment(dept: string): Observable<any> {
    const params = new HttpParams().set('isWithoutBase', 'yes');
    return this.http.get<any>(this.base_url + dept, {
      params,
    });
  }

  update(model: any, dept: string): Observable<any> {
    const params = new HttpParams().set('isWithoutBase', 'yes');
    return this.http.post<any>(this.base_url + dept, model, {
      params,
    });
  }
}
