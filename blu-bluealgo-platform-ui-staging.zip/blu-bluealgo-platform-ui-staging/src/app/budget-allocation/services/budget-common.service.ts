import { Injectable } from '@angular/core';
import { HttpClient, HttpParams, HttpResponse } from '@angular/common/http';
import { BUDGET_BASE_URL } from './budget-base-url';
import { Observable } from 'rxjs';

@Injectable({
  providedIn: 'root',
})
export class BudgetCommonService {
  constructor(private http: HttpClient) {}

  getDepartmentList(model: any) {
    model.username = localStorage.getItem('username');
    model.customerId = localStorage.getItem('customerId');
    model.accessToken = localStorage.getItem('token');
    const params = new HttpParams().set('isWithoutBase', 'yes');
    return this.http.post<any>(BUDGET_BASE_URL + 'get_departments', model, {
      params,
    });
  }

  getInstructionByDepartment(model: any) {
    const params = new HttpParams().set('isWithoutBase', 'yes');
    return this.http.post<any>(BUDGET_BASE_URL + 'get_department_info', model, {
      params,
    });
  }

  getMasterData(): Observable<any> {
    const params = new HttpParams().set('isWithoutBase', 'yes');
    return this.http.get<any>(BUDGET_BASE_URL + 'fetch_master_file', {
      params,
    });
  }

  getDataByDepartment(dept: string): Observable<any> {
    const params = new HttpParams().set('isWithoutBase', 'yes');
    return this.http.get<any>(BUDGET_BASE_URL + 'fetch_master/' + dept, {
      params,
    });
  }

  update(model: any, dept: string) {
    const params = new HttpParams().set('isWithoutBase', 'yes');
    return this.http.post<any>(
      BUDGET_BASE_URL + 'update_master/' + dept,
      model,
      { params },
    );
  }

  uploadFile(formData: FormData): Observable<any> {
    const params = new HttpParams().set('isWithoutBase', 'yes');
    return this.http.post(BUDGET_BASE_URL + 'upload', formData, {
      params,
      responseType: 'text',
    });
  }

  downloadExcel(payload: any): Observable<HttpResponse<Blob>> {
    const params = new HttpParams().set('isWithoutBase', 'yes');
    return this.http.post(BUDGET_BASE_URL + 'download_table', payload, {
      params,
      responseType: 'blob',
      observe: 'response',
    });
  }

  getTowers(payload: any) {
    const params = new HttpParams().set('isWithoutBase', 'yes');
    return this.http.post<any>(BUDGET_BASE_URL + 'fetch_towers', payload, {
      params,
    });
  }

  getHighLightedTower() {
    const params = new HttpParams().set('isWithoutBase', 'yes');
    return this.http.get<any>(BUDGET_BASE_URL + 'tower_highlight', { params });
  }
}
