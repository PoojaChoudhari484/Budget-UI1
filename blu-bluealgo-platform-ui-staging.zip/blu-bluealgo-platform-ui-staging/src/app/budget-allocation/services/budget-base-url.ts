import { environment } from "src/environments/environment";


export const BUDGET_BASE_URL = environment.budget_base_url ;


