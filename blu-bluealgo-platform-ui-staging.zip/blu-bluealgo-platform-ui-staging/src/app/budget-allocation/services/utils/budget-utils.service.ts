import { Injectable } from '@angular/core';

@Injectable({
  providedIn: 'root',
})
export class BudgetUtilsService {
  constructor() {}

  // Updated navigateFieldsByArrow method
  // navigateFieldsByArrow(event: KeyboardEvent, currentField: HTMLInputElement, inputs: HTMLInputElement[]): void {
  //   const currentIndex = inputs.indexOf(currentField);
  //
  //   if (currentIndex === -1) return;
  //
  //   const totalColumns = this.getTotalColumns(inputs);
  //   let nextIndex: number | null = null;
  //
  //   switch (event.key) {
  //     case 'ArrowRight':
  //       nextIndex = currentIndex + 1;
  //       break;
  //     case 'ArrowLeft':
  //       nextIndex = currentIndex - 1;
  //       break;
  //     case 'ArrowDown':
  //       nextIndex = currentIndex + totalColumns;
  //       break;
  //     case 'ArrowUp':
  //       nextIndex = currentIndex - totalColumns;
  //       break;
  //   }
  //
  //   // Ensure the next index is valid and skip fields with pointer-events: none or readonly
  //   while (nextIndex !== null && inputs[nextIndex] && !this.isFieldFocusable(inputs[nextIndex])) {
  //     if (event.key === 'ArrowRight' || event.key === 'ArrowDown') {
  //       nextIndex++;
  //     } else if (event.key === 'ArrowLeft' || event.key === 'ArrowUp') {
  //       nextIndex--;
  //     } else {
  //       break;
  //     }
  //
  //     if (nextIndex < 0 || nextIndex >= inputs.length) {
  //       nextIndex = null; // Break if no valid focusable field is found
  //     }
  //   }
  //
  //   // Prevent default and focus the next field if it's valid
  //   if (nextIndex !== null && inputs[nextIndex]) {
  //     event.preventDefault();
  //     inputs[nextIndex].focus();
  //   }
  // }
  //
  // // Helper method to check if a field is focusable
  // private isFieldFocusable(input: HTMLInputElement): boolean {
  //   const computedStyle = window.getComputedStyle(input);
  //   return (
  //     input.offsetParent !== null && // Ensure the element is visible
  //     !input.hasAttribute('readonly') && // Skip readonly fields
  //     computedStyle.pointerEvents !== 'none' // Skip fields with pointer-events: none
  //   );
  // }
  //
  // // Calculate total columns
  // private getTotalColumns(inputs: HTMLInputElement[]): number {
  //   const rows = inputs.map(input => input.closest('tr'));
  //   const uniqueRows = Array.from(new Set(rows));
  //   return uniqueRows.length ? inputs.length / uniqueRows.length : 0;
  // }

  // Skip disable row.
  navigateFieldsByArrow(
    event: KeyboardEvent,
    currentField: HTMLInputElement,
    inputs: HTMLInputElement[],
  ): void {
    const currentIndex = inputs.indexOf(currentField);

    if (currentIndex === -1) return;

    const totalColumns = this.getTotalColumns(inputs);
    const currentRow = Math.floor(currentIndex / totalColumns);
    const currentCol = currentIndex % totalColumns;
    let nextRow = currentRow;
    let nextCol = currentCol;

    // Prevent default behavior immediately to stop value change
    if (
      ['ArrowRight', 'ArrowLeft', 'ArrowDown', 'ArrowUp'].includes(event.key)
    ) {
      event.preventDefault();
    }

    switch (event.key) {
      case 'ArrowRight':
        nextCol++;
        break;
      case 'ArrowLeft':
        nextCol--;
        break;
      case 'ArrowDown':
        nextRow++;
        break;
      case 'ArrowUp':
        nextRow--;
        break;
      default:
        return; // Exit if not an Arrow key
    }

    // Validate the calculated row and column
    let nextIndex = this.getIndexByRowCol(
      nextRow,
      nextCol,
      totalColumns,
      inputs,
    );

    // Find the next valid focusable field, skipping disabled rows or fields
    while (
      nextIndex !== null &&
      (!inputs[nextIndex] || !this.isFieldFocusable(inputs[nextIndex]))
    ) {
      if (event.key === 'ArrowRight') {
        nextCol++;
      } else if (event.key === 'ArrowLeft') {
        nextCol--;
      } else if (event.key === 'ArrowDown') {
        nextRow++;
      } else if (event.key === 'ArrowUp') {
        nextRow--;
      }

      // Recalculate the index
      nextIndex = this.getIndexByRowCol(nextRow, nextCol, totalColumns, inputs);

      // Stop if out of bounds
      if (
        nextCol < 0 ||
        nextCol >= totalColumns ||
        nextRow < 0 ||
        nextRow >= Math.ceil(inputs.length / totalColumns)
      ) {
        nextIndex = null;
      }
    }

    // Focus the next valid field
    if (nextIndex !== null && inputs[nextIndex]) {
      inputs[nextIndex].focus();
    }
  }

  // Helper method to check if a field is focusable
  private isFieldFocusable(input: HTMLInputElement): boolean {
    const computedStyle = window.getComputedStyle(input);
    return (
      input.offsetParent !== null && // Ensure the element is visible
      !input.hasAttribute('readonly') && // Skip readonly fields
      computedStyle.pointerEvents !== 'none' // Skip fields with pointer-events: none
    );
  }

  // Helper method to calculate the index based on row and column
  private getIndexByRowCol(
    row: number,
    col: number,
    totalColumns: number,
    inputs: HTMLInputElement[],
  ): number | null {
    const index = row * totalColumns + col;
    return index >= 0 && index < inputs.length ? index : null;
  }

  // Calculate total columns
  private getTotalColumns(inputs: HTMLInputElement[]): number {
    const rows = inputs.map((input) => input.closest('tr'));
    const uniqueRows = Array.from(new Set(rows));
    return uniqueRows.length ? inputs.length / uniqueRows.length : 0;
  }
}
