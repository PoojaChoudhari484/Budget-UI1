import {
  Component,
  ElementRef,
  OnInit,
  QueryList,
  ViewChild,
  ViewChildren,
} from '@angular/core';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import {
  ApexChart,
  ApexDataLabels,
  ApexLegend,
  ApexNonAxisChartSeries,
  ApexPlotOptions,
  ApexResponsive,
  ApexTooltip,
  ChartComponent,
} from 'ng-apexcharts';
import { ToastrService } from 'ngx-toastr';
import { HttpResponse } from '@angular/common/http';
import { MatDialog } from '@angular/material/dialog';
import { Router } from '@angular/router';
import { BudgetUtilsService } from '../services/utils/budget-utils.service';
import { BudgetCommonService } from '../services/budget-common.service';
import { BudgetInformationDialogComponent } from '../common/budget-information-dialog/budget-information-dialog.component';

export type ChartOptions = {
  series: ApexNonAxisChartSeries;
  chart: ApexChart;
  responsive: ApexResponsive[];
  legend: ApexLegend;
  dataLabels: ApexDataLabels;
  tooltip: ApexTooltip;
  plotOptions: ApexPlotOptions;
};

@Component({
    selector: 'app-design-department',
    templateUrl: './design-department.component.html',
    styleUrls: ['./design-department.component.scss'],
    standalone: false
})
export class DesignDepartmentComponent implements OnInit {
  @ViewChild('chart') chart!: ChartComponent;
  public chartOptions: ChartOptions;
  @ViewChild('fileInput') fileInput: ElementRef<HTMLInputElement> | undefined;
  @ViewChildren('numberInputField') numberInputFields!: QueryList<
    ElementRef<HTMLInputElement>
  >;

  inputADepartmentKeyOrder = [
    'Company',
    'Project Name',
    'Project',
    'Tower',
    'Tower Option',
    'Nature',
    'UoM',
    'Type',
    'Percent',
    'Configuration',
    'Total Potential (Units)',
    'Total Launched (Units)',
    'Total Launched (Area)',
    'Total Launched (Value)',
    'Area per unit',
    "PTD Sold till Dec'24 (Units)",
    "PTD Sold till Dec'24 (Area)",
    'Avg rate (PTD Dec 24) for existing project/ Rate for New Project',
    "YTD Dec'24 Act (Units)",
    "YTD Dec'24 Act (Area)",
    'YTD Dec 24 @ CSV Sales',
    'YTD Dec Spends including GST',
    'YTD Dec Spend % (including GST)',
    'FY-25 Sales @ CSV (Est)',
    'Spend % (Incl. GST)1',
    'FY25 Est Spends with GST & W/o SOSF',
    'SOSF1',
    'Total1',
    'FY-26 Sales @ CSV (Bud)',
    'Spend % (Incl. GST)2',
    'Bud Marketing Spend Excluding SOSF & including GST',
    'SOSF2',
    'Total2',
    'Total Potential',
    'Total Potential (Units)',
    'Total Launched',
    'Total Launched (Area)',
    'Area per unit',
    "PTD Sold till Dec'24",
    "Resi Revenue till Dec'24",
    "PTD Sold till Dec'24 Area",
    'Avg rate (PTD Dec 24) for existing project/ Rate for New Project',
    "YTD Dec'24 Act",
    "YTD Dec'24 Act Area",
    'Sold in Q4 FY25',
    "Sold till Mar'25",
    'Sold in FY26',
    "Sold till Mar'26",
    'Category',
    'Expected Date to receive OC',
    'No. of unit for which OC expected to be received',
    'Total Development Size Lakh Sq ft',
    'YTD Dec-24',
    'Actual Apr-Dec 24',
    'Amount',
    "Balance Leasable Inventory as on Dec'24 end",
    'Expense',
    'Area (BUA) (Mn sq ft)',
    'Nature of Expenses',
    'Total Approved Amount',
    'Fees paid till Dec-24',
    'Approved Budget',
    'Actual Spent till Mar-24',
    'Spent till Mar 24',
    'Spent from Apr 24 to Dec 24',
    'PTD Spent as on Dec 24',
    'Balance cost to go as on Dec 24',
    'Area',
    'Avg rate (PTD Dec 24) for existing project/ Rate for New Project',
    'Area (per Unit)',
    'Total Potential Units',
    'Total Launched units',
    'Total Area (Launched units)',
    "PTD Sold till Dec'24",
    "Invt as on Dec'24",
    "YTD Dec'24",
    "YTD Dec'24 Act",
    'Expense',
    'Total AV (of launched Units)',
    'Apr-24',
    'May-24',
    'Jun-24',
    'Jul-24',
    'Aug-24',
    'Sep-24',
    'Oct-24',
    'Nov-24',
    'Dec-24',
    '9M FY 25',
    'Jan-25',
    'Feb-25',
    'Mar-25',
    "Till Mar'25",
    'Q4 FY 2025',
    'Sold yet to be recognized',
    'OC Received Status',
    'Q4 FY25',
    'Apr-25',
    'YTD Mar-25',
    'May-25',
    'Jun-25',
    'Jul-25',
    'July-25',
    'Aug-25',
    'Sep-25',
    'Sept-25',
    'Oct-25',
    'Nov-25',
    'Dec-25',
    'Jan-26',
    'Feb-26',
    'Mar-26',
    'FY 25',
    'FY 26',
    'FY 2026',
    'Cumm Mar-26',
    'FY 27 (Projected)',
    'FY-27',
    'FY 27',
    'Yet to be sold as on Dec 24',
    'OI Check1',
    'Yet to be sold as on Mar 25',
    'OI Check2',
    'Yet to be handedover as on Dec 24',
    'Rev Check1',
    'Yet to be handedover as on Mar 25',
    'Rev Check2',
    'Remarks (Optional)',
    'Entity Name',
  ];
  editableTextFields: string[] = ['Tower', 'Remarks', 'Schedule Date'];
  versions = ['Version 1.0', 'Version 1.1', 'Version 1.2', 'Version 2.0'];
  ineligibleTotalRowDepartments: string[] = ['Rent'];
  columnWiseCssClasses: Record<string, string[]> = {
    'bg-inherit': ['Project Name'],
    'bg-[#d6e5f0]': ['Jan-25', 'Feb-25', 'Mar-25'],
    'bg-[#f8e0d5]': [
      'Apr-25',
      'May-25',
      'Jun-25',
      'Jul-25',
      'July-25',
      'Aug-25',
      'Sep-25',
      'Sept-25',
      'Oct-25',
      'Nov-25',
      'Dec-25',
      'Jan-26',
      'Feb-26',
      'Mar-26',
      'FY 25',
    ],
    'bg-[#2E2E2E] text-[#FFD700] opacity-90': [
      'Q4 FY25',
      'Q4 FY 2025',
      'FY 26',
      'FY 2026',
      'Total Potential (Units)',
      'Total Launched (Units)',
      'Area per unit',
      "PTD Sold till Dec'24",
      "Invt as on Dec'24",
      "YTD Dec'24",
      "Invt as on Apr'26",
      'Total Area (Launched units)',
      'Avg rate (PTD Dec 24) for existing project/ Rate for New Project',
      'Total AV (of launched Units)',
      'Schedule Date',
      'PTD Spent as on Dec 24',
      'Balance cost to go as on Dec 24',
      'YTD Dec Spend % (including GST) YTD Dec 24 @ CSV Sales',
      'FY25 Est Spends with GST & W/o SOSF',
      'FY-25 Sales @ CSV (Est)',
      'Total1',
      'FY-26 Sales @ CSV (Bud)',
      'Bud Marketing Spend Excluding SOSF & including GS',
      'Total2',
      'Sold in Q4 FY25',
      "Sold till Mar'25",
      'Sold in FY26',
      "Sold till Mar'26",
      "Till Mar'25",
      'Sold yet to be recognized',
      'Yet to be sold as on Dec 24',
      'OI Check1',
      'Yet to be sold as on Mar 25',
      'OI Check2',
      'Yet to be handedover as on Dec 24',
      'Rev Check1',
      'Yet to be handedover as on Mar 25',
      'Rev Check2',
      'OC received status',
      'Inventory',
      'Totals',
      'Write off',
      'Bal1',
      'Bal2',
      'Bal3',
    ],
  };
  staticHeaderGroup: Record<string, string[]> = {
    Est: ['Jan-25', 'Feb-25', 'Mar-25'],
    TOTALS: ['Q4 FY25', 'Q4 FY 2025', 'FY 26', 'FY 2026'],
    Budget: [
      'Apr-25',
      'May-25',
      'Jun-25',
      'Jul-25',
      'July-25',
      'Aug-25',
      'Sep-25',
      'Sept-25',
      'Oct-25',
      'Nov-25',
      'Dec-25',
      'Jan-26',
      'Feb-26',
      'Mar-26',
      'FY 25',
    ],
    Projected: ['FY 27 (Projected)', 'FY-27', 'FY 27'],
  };

  initApplyFilterDepartments: string[] = [
    'Sales',
    'Sales Extended Units',
    'Sales Extended Area',
    'Sales Extended Rate',
    'Sales Extended AV',
    'Phy Milestone',
    'Construction',
    'Collection',
    'Revenue',
  ];
  loading: boolean = false;
  currentCompanyIndex = 0;
  selectedCompanyName: string | null = null;
  spinner: boolean = false;
  year2024Value: number = 50;
  year2025Value: number = 75;
  segment1Value: number = 50;
  segment2Value: number = 40;
  segment3Value: number = 30;
  deptSelectedIndex: number = 0;
  departmentName: string = '';
  departmentList: string[] = [];
  frmGroup: FormGroup;
  masterData: any = {};
  companyList: string[] = [];
  searchCompanyList: string[] = [];
  projectMap: { [key: string]: string[] } = {};
  typeMap: { [key: string]: string } = {};
  file: any;
  tableData: any[] = [];
  Object = Object;
  isEditEnable: boolean = false;
  isFullScreen: boolean = false;
  tableHeaders: string[] = [];
  filterProjectMapWithCompany: {
    [key: string]: {
      project: string;
      isProjectChecked: boolean;
      type: string;
      isTypeChecked: boolean;
    }[];
  } = {};
  filterCompanyList: string[] = [];
  typeList: string[] = [];
  filterTypeList: string[] = [];
  selectAllProject: boolean = false;
  selectAllType: boolean = false;
  isPreview: boolean = false;
  zoomLevel: number;
  currencyFormat: string = 'absolute';
  previousCurrencyFormat: string = 'absolute';
  isQuarterView: boolean = false;
  highlightObj: any;
  groupedData: Record<string, any[]> = {};
  deptInstruction: any = {};
  collectedTypes: string[] = [];
  frozenColumns = new Set<string>();

  constructor(
    private toastr: ToastrService,
    private formBuilder: FormBuilder,
    // private designDepartmentService: DesignDepartmentService,
    private dialog: MatDialog,
    private router: Router,
    private budgetUtilsService: BudgetUtilsService,
    private budgetCommonService: BudgetCommonService,
  ) {
    this.chartOptions = this.initChart();
  }

  ngOnInit(): void {
    this.initForm();
    this.getMasterData();
  }

  initForm() {
    this.frmGroup = this.formBuilder.group({
      company: ['', Validators.required],
      project: ['', Validators.required],
    });
  }

  initChart(): ChartOptions {
    return {
      series: [44, 55, 13, 43], // Dynamic series data
      chart: {
        type: 'donut',
        width: '100px',
        height: '100px',
      },
      legend: {
        show: false, // This will hide the legend and series labels
      },
      plotOptions: {
        pie: {
          donut: {
            size: '65%',
          },
        },
      },
      dataLabels: {
        enabled: false, // This hides the labels inside the chart
      },
      tooltip: {
        enabled: true, // This disables the tooltip
      },
      responsive: [
        {
          breakpoint: 480,
          options: {
            chart: {
              width: '100%',
            },
          },
        },
      ],
    };
  }

  /* =========================== Edit Table ================================ */

  editTable(){

    this.isEditEnable = !this.isEditEnable

  }

  /* ======================================================================= */

  getMasterData() {
    this.budgetCommonService.getMasterData().subscribe((res) => {
      this.masterData = res;
      this.extractCompaniesAndProjects();
    });
  }

  getDepartmentList(res: any) {
    this.departmentList = res;
  }

  extractCompaniesAndProjects() {
    this.companyList = [];
    this.projectMap = {};
    this.typeMap = {};
    this.searchCompanyList = [];


    Object.keys(this.masterData)?.forEach((companyName: string) => {

      this.companyList.push(companyName);
      this.searchCompanyList.push(companyName);
      this.projectMap[companyName] = [];
      (this.masterData[companyName] as any[])?.forEach((project: any) => {
        Object.keys(project).forEach((projectName: string) => {
          this.projectMap[companyName].push(projectName);
          this.typeMap[projectName] = project[projectName].type;
          if (!this.typeList.includes(project[projectName].type))
            this.typeList.push(project[projectName].type);
        });
      });
    });
  }

  getInstructionByDept() {
    this.budgetCommonService
      .getInstructionByDepartment({ department: this.departmentName })
      .subscribe((res) => {
        this.deptInstruction = res;
      });
  }

  onChangeDepartment(i: number) {
    this.currencyFormat = 'absolute';
    this.previousCurrencyFormat = 'absolute';
    this.isQuarterView = false;
    this.deptSelectedIndex = i;
    this.departmentName = this.departmentList[this.deptSelectedIndex];
    this.getInstructionByDept();
    this.getTableData();

    if (this.departmentName === 'Construction') {
      this.budgetCommonService.getHighLightedTower().subscribe((res) => {
        this.highlightObj = res;
      });
    }
  }



  getTableData() {
    this.loading = true; // Loader start
    this.budgetCommonService
      .getDataByDepartment(this.departmentName)
      .subscribe({
        next: (res) => {
          res?.forEach((row: any, index: number) => {
            row['uniqueTempId'] = 'key-$' + index;
          });

          this.tableData = res;

          if (this.initApplyFilterDepartments.includes(this.departmentName)) {
            const defaultCompanies = this.companyList?.slice(0, 4);
            defaultCompanies.forEach((company, index) => {
              this.updateFilterCompanies({ target: { checked: true } }, company, index === 0);
            });
            if (defaultCompanies.length > 0) {
              this.filterCompanyList = [...defaultCompanies];
              defaultCompanies.forEach(company => {
                this.updateFilterCompanies({ target: { checked: true } }, company);
              });
            }
            this.showResults();
          } else {
            const defaultCompanies = this.companyList?.slice(0, 4);
            this.filterCompanyList = [...defaultCompanies];
            const filteredData = res.filter((d: { [x: string]: string; }) => defaultCompanies.includes(d['Company']));
            this.extractAndSortData(filteredData);
          }
          this.loading = false; // Loader stop
        },
        error: () => {
          this.loading = false; // Error case me bhi loader hata dena
        }
      });
  }



  showMoreCompanies() {
    let companiesAdded = 0;

    while (companiesAdded < 4 && this.currentCompanyIndex + 1 < this.companyList.length) {
      this.currentCompanyIndex++;
      const nextCompany = this.companyList[this.currentCompanyIndex];
      this.filterCompanyList.push(nextCompany);
      this.updateFilterCompanies({ target: { checked: true } }, nextCompany);
      companiesAdded++;
    }

    if (companiesAdded > 0) {
      this.showResults();
    } else {
      console.log('No more companies to show');
    }
  }

  showAllCompanies() {
    this.filterCompanyList = [...this.companyList];
    this.companyList.forEach((company) => {
      this.updateFilterCompanies({ target: { checked: true } }, company);
    });
    this.showResults();
  }
  showLessCompanies() {
    let companiesRemoved = 0;

    while (companiesRemoved < 4 && this.currentCompanyIndex >= 0) {
      const companyToRemove = this.companyList[this.currentCompanyIndex];
      const index = this.filterCompanyList.indexOf(companyToRemove);

      if (index > -1) {
        this.filterCompanyList.splice(index, 1);
      }

      this.updateFilterCompanies({ target: { checked: false } }, companyToRemove);
      this.currentCompanyIndex--;
      companiesRemoved++;
    }

    if (companiesRemoved > 0) {
      this.showResults();
    } else {
      console.log('No more companies to remove');
    }
  }



  extractAndSortData(data: any) {
    this.tableHeaders = [];
    let tempDataSource: any[] = [];

    data?.forEach((row: any) => {
      const processedRow: any = {};

      this.inputADepartmentKeyOrder.forEach((orderKey) => {
        if (row.hasOwnProperty(orderKey)) {
          if (!this.tableHeaders.includes(orderKey)) {
            this.tableHeaders.push(orderKey);
          }
          processedRow[orderKey] = row[orderKey];
        }
      });
      Object.keys(row).forEach((key) => {
        if (!this.inputADepartmentKeyOrder.includes(key)) {
          if (!this.tableHeaders.includes(key)) {
            this.tableHeaders.push(key);
          }
          processedRow[key] = row[key];
        }
      });
      tempDataSource.push(processedRow);
    });


    // Extra column header push for radio button.
    if (this.tableHeaders.includes('Company')) {
      let companyIndex = this.tableHeaders?.indexOf('Company');
      this.tableHeaders.splice(companyIndex + 1, 0, '');
    } else this.tableHeaders.splice(0, 0, '');

    if (this.currencyFormat !== 'absolute') this.onChangeCurrencyFormat();

    this.initCalculation(tempDataSource);
    this.groupByCompany(tempDataSource);
  }

  initCalculation(dataList: any) {
    const periods: Record<string, string[]> = {
      'Q4 FY25': ['Jan-25', 'Feb-25', 'Mar-25'],
      'FY 26': [
        'Apr-25',
        'May-25',
        'Jun-25',
        'Jul-25',
        'Aug-25',
        'Sep-25',
        'Oct-25',
        'Nov-25',
        'Dec-25',
        'Jan-26',
        'Feb-26',
        'Mar-26',
      ],
    };

    dataList?.forEach((row: any) => {
      Object.keys(row)?.forEach((period: string) => {
        if (period in periods) {
          const months = periods[period];
          row[period] = months.reduce(
            (sum, month) => sum + (Number(row[month]) || 0),
            0,
          );
        }
      });
    });
  }

  groupByCompany(dataList: any) {
    this.groupedData = {};
    for (const item of dataList) {
      const company = item['Company'];
      this.groupedData[company] = this.groupedData[company] || [];
      this.groupedData[company] = [...this.groupedData[company], item];
    }
  }

  selectFile() {
    if (this.fileInput) {
      this.fileInput.nativeElement.click();
    } else {
      console.error('File input not found');
    }
  }

  onFileSelected(event: any): void {
    this.file = event.target.files[0];
    if (this.file) {
      const formData = new FormData();
      formData.append('file', this.file);
      formData.append('department', this.departmentName);

      this.budgetCommonService.uploadFile(formData).subscribe(
        (res) => {
          this.toastr.success(res);
          this.resetFileInput();
          this.getTableData();
        },
        (error) => {
          this.toastr.error(error);
          this.resetFileInput();
        },
      );
    }
  }

  resetFileInput() {
    if (this.fileInput) {
      this.fileInput.nativeElement.value = '';
    }
  }

  downloadExcel(): void {
    const payload: any = {
      department: this.departmentName,
    };

    this.budgetCommonService
      .downloadExcel(payload)
      .subscribe((response: HttpResponse<Blob>) => {
        const contentDisposition = response.headers.get('Content-Disposition');

        let fileName = this.departmentName?.toLowerCase() + '_department_data';

        if (contentDisposition) {
          const match = contentDisposition.match(/filename="([^"]+)"/);
          if (match && match[1]) {
            fileName = match[1];
          }
        }

        const fileBlob = new Blob([response.body!], {
          type: response.body?.type || 'application/octet-stream',
        });

        const url = window.URL.createObjectURL(fileBlob);
        const anchor = document.createElement('a');
        anchor.href = url;
        anchor.download = fileName;
        anchor.click();
        window.URL.revokeObjectURL(url);
      });
  }

  async updateTable() {
    let res: boolean = await this.removeTempKeyAndRevertToAbsoluteValue();
    if (res) {
      this.budgetCommonService
        .update(this.tableData, this.departmentName)
        .subscribe((res) => {
          this.toastr.success(res.message, 'OK');
          this.previousCurrencyFormat = 'absolute';
          this.getTableData();
        });
    }
  }

  removeTempKeyAndRevertToAbsoluteValue(): Promise<boolean> {
    return new Promise((resolve) => {
      // check currency format and set revert number.
      const currencyRevertNumber =
        this.currencyFormat === 'lacks'
          ? 100000
          : this.currencyFormat === 'crores'
            ? 10000000
            : 1;

      // After group view by company.
      Object.entries(this.groupedData)?.forEach(([company, values]) => {
        values.forEach((row) => {
          // Revert currency format to absolute value
          if (currencyRevertNumber !== 1) {
            Object.entries(row)?.forEach(([key, value]: [string, any]) => {
              let numericValue = Number(value);
              if (!isNaN(numericValue)) {
                row[key] = value * currencyRevertNumber;
              }
            });
          }
          // Temp key delete action.
          if (row.hasOwnProperty('isSelected')) {
            delete row['isSelected'];
          }
          // Replace row in original json.
          let findIndex: number = this.tableData?.findIndex(
            (t) => t['uniqueTempId'] === row['uniqueTempId'],
          );
          if (row.hasOwnProperty('uniqueTempId')) {
            delete row['uniqueTempId'];
          }
          if (findIndex !== -1) {
            this.tableData[findIndex] = row;
          }
        });
      });

      resolve(true);
    });
  }

  toggleFullScreen() {
    this.isFullScreen = !this.isFullScreen;
  }

  toggleMoreDepartment() {
    this.router.navigateByUrl('/more-department');
  }

  openFilter(templateRef: any) {
    this.dialog.open(templateRef, {
      minWidth: '400px',
      height: 'auto',
      disableClose: false,
    });
  }

  updateFilterCompanies(event: any, company: string, replace: boolean = false): void {
    this.filterTypeList = [];
    this.selectAllProject = false;

    if (replace) {
      this.filterCompanyList = [];
    }

    const isChecked = event.target.checked;
    if (isChecked) {
      if (!this.filterCompanyList.includes(company)) {
        this.filterCompanyList.push(company);
      }
    } else {
      const index: number = this.filterCompanyList.indexOf(company);
      if (index > -1) {
        this.filterCompanyList.splice(index, 1);
      }
    }

    this.filterProjectMapWithCompany = {};
    this.filterCompanyList.forEach((company) => {
      if (this.projectMap[company]) {
        let projects: any[] = [];
        this.projectMap[company]?.forEach((project) => {
          let row: any = {};
          row.project = project;
          row.isProjectChecked = false;
          row.type = this.typeMap[project];
          row.isTypeChecked = false;
          projects.push(row);
        });

        this.filterProjectMapWithCompany[company] = projects;
      }
    });
  }


  setUniqueType(row: any, project: string, projects: any) {
    console.log(this.filterProjectMapWithCompany);

    let type = this.typeMap[project];
    // let companyElement = this.filterProjectMapWithCompany[company];
    if (projects.length > 0) {
      const isTypePresent = projects.some(
        (element: any) => element.type === type,
      );
      if (!isTypePresent) {
        row.type = type;
        row.isTypeChecked = false;
      }
    } else {
      row.type = this.typeMap[project];
      row.isTypeChecked = false;
    }

    console.log(row);
  }

  showResults() {
    if (this.filterCompanyList.length > 0) {
      let filterDataList: any[] = [];

      Object.entries(this.filterProjectMapWithCompany)?.forEach(([company, values]) => {
        let isCheckedAny: boolean = values.some(
          (s) => s.isProjectChecked || s.isTypeChecked,
        );

        if (values.length > 0 && isCheckedAny) {
          values?.forEach((value) => {
            let findList: any[] = [];
            if (value.isProjectChecked) {
              findList = this.tableData?.filter(
                (data) =>
                  data['Company'] === company &&
                  data['Project Name'] === value.project,
              );
            } else if (value.isTypeChecked) {
              findList = this.tableData?.filter(
                (data) =>
                  data['Company'] === company && data['Type'] === value.type,
              );
            }
            if (findList?.length > 0) filterDataList.push(...findList);
          });
        } else {
          // Agar project/type check nahi hai to poori company ka data le lo
          let findList = this.tableData?.filter(
            (data) => data['Company'] === company,
          );
          if (findList.length > 0) filterDataList.push(...findList);
        }
      });

      const uniqueDataList = Array.from(
        new Set(filterDataList.map((item) => JSON.stringify(item))),
      ).map((item) => JSON.parse(item));

      this.extractAndSortData(uniqueDataList);

    } else if (this.filterTypeList.length > 0) {
      let filterDataList: any[] = [];
      this.filterTypeList?.forEach((type) => {
        let findList = this.tableData?.filter((data) => data['Type'] === type);
        if (findList?.length > 0) filterDataList.push(...findList);
      });
      this.extractAndSortData(filterDataList);
    } else {
      let defaultCompanies = this.filterCompanyList.length > 0
        ? this.filterCompanyList
        : this.companyList.slice(0, 4);

      let findList = this.tableData.filter(d => defaultCompanies.includes(d['Company']));
      this.extractAndSortData(findList);
    }

  }


  resetFilters() {
    this.filterProjectMapWithCompany = {};
    this.filterCompanyList = [];
    this.filterTypeList = [];

    this.extractAndSortData(this.tableData);
  }

  toggleSelectAllProject(event: any) {
    const isChecked = event.target.checked;
    if (isChecked) this.selectAllType = false;
    Object.entries(this.filterProjectMapWithCompany)?.forEach(
      ([company, values]) => {
        values?.forEach((row) => {
          row.isProjectChecked = event.target.checked;
          row.isTypeChecked = false;
        });
      },
    );
  }

  getTotalByKey(key: string): any {
    let total = 0;
    Object.entries(this.groupedData)?.forEach(([company, values]) => {
      values.forEach((row) => {
        if (row[key] !== undefined && !isNaN(row[key])) {
          total += Number(row[key]);
        }
      });
    });
    return total > 0 ? total : '';
  }

  sumInputA(row: any, key: string) {
    const periods = {
      'Q4 FY25': ['Jan-25', 'Feb-25', 'Mar-25'],
      'FY 26': [
        'Apr-25',
        'May-25',
        'Jun-25',
        'Jul-25',
        'Aug-25',
        'Sep-25',
        'Oct-25',
        'Nov-25',
        'Dec-25',
        'Jan-26',
        'Feb-26',
        'Mar-26',
      ],
    };

    for (const [period, months] of Object.entries(periods)) {
      if (months.includes(key)) {
        row[period] = months.reduce(
          (sum, month) => sum + (Number(row[month]) || 0),
          0,
        );
      }
    }
  }

  refreshRow(row: any) {
    // this.dataSource?.splice(rowIndex, 1);
    Object.entries(row)?.forEach(([key, value]: [string, any]) => {
      let numericValue = Number(value);
      if (!isNaN(numericValue)) {
        row[key] = '';
      }
    });
  }

  resetTable() {

    this.currencyFormat = 'absolute';
    this.previousCurrencyFormat = 'absolute';
    this.isQuarterView = false;

    // Clear numeric values from tableData

    {
      this.tableData = this.tableData.map(row => {
        const newRow = { ...row };
        Object.keys(newRow).forEach(key => {
          if (!isNaN(Number(newRow[key]))) {
            newRow[key] = '';
          }
        });
        return newRow;
      });
    }
    this.extractAndSortData(this.tableData);
  }
  onChangeCurrencyFormat() {
    // Step 1: Revert the values based on the previous currency format
    Object.entries(this.groupedData)?.forEach(([company, values]) => {
      values?.forEach((row) => {
        Object.entries(row)?.forEach(([key, value]: [string, any]) => {
          let numericValue = Number(value);
          if (!isNaN(numericValue)) {
            switch (this.previousCurrencyFormat) {
              case 'lacks': {
                row[key] = numericValue * 100000;
                break;
              }
              case 'crores': {
                row[key] = numericValue * 10000000;
                break;
              }
              case 'absolute': {
                break;
              }
            }
          }
        });
      });
    });

    // Step 2: Apply the new format (currencyFormat or selected format)
    Object.entries(this.groupedData)?.forEach(([company, values]) => {
      values?.forEach((row) => {
        Object.entries(row)?.forEach(([key, value]: [string, any]) => {
          let numericValue = Number(value);
          if (!isNaN(numericValue)) {
            switch (this.currencyFormat) {
              case 'absolute': {
                row[key] = Number(numericValue.toFixed(0));
                break;
              }
              case 'lacks': {
                row[key] = numericValue / 100000;
                break;
              }
              case 'crores': {
                row[key] = numericValue / 10000000;
                break;
              }
            }
          }
        });
      });
    });

    // Step 3: Update the previous currency format to the current one
    this.previousCurrencyFormat = this.currencyFormat;
  }

  getFieldType(value: any, key: string): string {
    if (isNaN(value) || this.editableTextFields.includes(key)) {
      return 'text';
    } else {
      return 'number';
    }
  }

    allowOnlyNumbers(event: KeyboardEvent) {
    const charCode = event.which ? event.which : event.keyCode;

    // allow: backspace (8), tab (9), enter (13), delete (46), arrow keys
    if (
      charCode > 31 &&
      (charCode < 48 || charCode > 57)
    ) {
      event.preventDefault(); // stop input
      this.toastr.error('Only numbers allowed', 'Invalid Input');
    }
  }

  getDynamicWidth(text: string): string {
    const baseWidth = text?.length * 8;
    const minWidth = 50;
    const maxWidth = 500;

    const finalWidth = Math.max(minWidth, Math.min(baseWidth, maxWidth));
    return `${finalWidth + 20}px`;
  }

  toggleQuarter() {
    this.spinner = true;
    this.isQuarterView = !this.isQuarterView;

    if (this.isQuarterView) {
      // Hard reference breaking.
      let tempString = JSON.stringify(this.tableData);
      let tempData = JSON.parse(tempString);

      let quarterMap = {
        'Q4 FY25': ['Jan-25', 'Feb-25', 'Mar-25'],
        'Q1 FY25': ['Apr-25', 'May-25', 'Jun-25'],
        'Q2 FY25': ['Jul-25', 'Aug-25', 'Sep-25'],
        'Q3 FY25': ['Oct-25', 'Nov-25', 'Dec-25'],
        'Q4 FY26': ['Jan-26', 'Feb-26', 'Mar-26'],
      };

      tempData?.forEach((row: any) => {
        for (const [quarterKey, months] of Object.entries(quarterMap)) {
          let sum = 0;
          months.forEach((month) => {
            if (row.hasOwnProperty(month)) {
              let value = Number(row[month]);
              sum += value;
              delete row[month];
            }
          });
          row[quarterKey] = sum;
        }
      });

      this.extractAndSortData(tempData);
    } else {
      this.resetTable();
    }

    setTimeout(() => {
      this.spinner = false;
    }, 2000);
  }

  getColumnCss(project: string, tower: string, column: string): string {
    let cssClass = 'bg-transparent';

    /**
     * Check for group columns first
     * Column wise css generate
     */
    for (const [bgColor, months] of Object.entries(this.columnWiseCssClasses)) {
      if (months.includes(column)) {
        cssClass = bgColor;
        break;
      }
    }

    // Row wise css generate.
    // Now, check for specific department conditions (if Construction department)
    if (this.departmentName === 'Construction' && this.highlightObj) {
      if (project && tower && column) {
        let findProject = this.highlightObj[project];
        let findTower = findProject?.hasOwnProperty(tower);

        if (findTower) {
          let months = findProject[tower];
          if (months?.includes(column)) {
            cssClass = 'bg-lime-200';
          }
        }
      }
    }

    return cssClass;
  }

  navigateFieldsByKeyboardArrow(
    event: KeyboardEvent,
    currentField: HTMLInputElement,
  ): void {
    const inputs = this.numberInputFields
      .toArray()
      .map((input) => input.nativeElement);
    this.budgetUtilsService.navigateFieldsByArrow(event, currentField, inputs);
  }

  getHeader(column: string): string {
    let header: string = '';

    for (const [key, months] of Object.entries(this.staticHeaderGroup)) {
      if (months.includes(column)) {
        header = key;
      }
    }
    return header;
  }

  openInstructionPopUp(buttonElement: HTMLElement) {
    const rect = buttonElement.getBoundingClientRect();
    this.dialog.open(BudgetInformationDialogComponent, {
      data: this.deptInstruction,
      position: {
        top: `${rect.top}px`,
        left: `${rect.left + 50}px`,
      },
      width: '500px',
    });
  }

  isFilterIcon(column: string): boolean {
    let result = false;
    if (column === 'Company') {
      if (this.filterCompanyList?.length > 0) {
        result = true;
      }
    } else if (column === 'Project Name') {
      for (const [company, projectArray] of Object.entries(
        this.filterProjectMapWithCompany,
      )) {
        if (projectArray.some((project) => project.isProjectChecked)) {
          result = true;
          break;
        }
      }
    } else if (column === 'Type') {
      if (this.filterTypeList.length > 0) {
        result = true;
      } else {
        for (const [company, projectArray] of Object.entries(
          this.filterProjectMapWithCompany,
        )) {
          if (projectArray.some((project) => project.isTypeChecked)) {
            result = true;
            break;
          }
        }
      }
    }
    return result;
  }

  updateFilterTypes(event: any, type: string) {
    const isChecked = event.target.checked;
    if (isChecked) {
      if (!this.filterTypeList.includes(type)) this.filterTypeList.push(type);
    } else {
      const index: number = this.filterTypeList.indexOf(type);
      if (index !== -1) {
        this.filterTypeList.splice(index, 1);
      }
    }
  }

  getUniqueType(type: string) {
    if (this.collectedTypes.includes(type)) {
      return false;
    } else {
      this.collectedTypes.push(type);
      return true;
    }
  }

  updateTypeChecked(event: any, type: string, company: string) {
    if (event.target.checked == true) this.selectAllProject = false;
    this.filterProjectMapWithCompany[company]?.forEach((row) => {
      row.isProjectChecked = false;
      if (row.type === type) {
        row.isTypeChecked = event.target.checked;
      }
    });
  }

  resetCollectedTypes(): any {
    this.collectedTypes = [];
    return;
  }

  updateCompanyChecked(event: any, company: string) {
    if (event.target.checked) {
      this.selectAllType = false;
      this.filterProjectMapWithCompany[company]?.forEach((row) => {
        row.isTypeChecked = false;
      });
    }
  }

  toggleSelectAllType(event: any) {
    let isChecked = event.target.checked;
    if (isChecked) this.selectAllProject = false;
    for (const [company, values] of Object.entries(
      this.filterProjectMapWithCompany,
    )) {
      values?.forEach((row) => {
        row.isTypeChecked = isChecked;
        row.isProjectChecked = false;
      });
    }
  }

  toggleFreeze(event: Event, column: string) {
    const isChecked = (event.target as HTMLInputElement).checked;
    if (isChecked) {
      this.frozenColumns.add(column);
    } else {
      this.frozenColumns.delete(column);
    }
  }

  SearchCompanyByName($event: Event) {
    const input = $event.target as HTMLInputElement;
    const searchText = input.value.toLowerCase();

    // Company list ko filter karo
    this.searchCompanyList = this.companyList.filter((company: string) => {
      return company.toLowerCase().includes(searchText);
    });

    // Sirf search result wali companies ka data table me dikhane ke liye
    const filteredData = this.tableData.filter((row: any) =>
      this.searchCompanyList.includes(row['Company'])
    );

    this.extractAndSortData(filteredData);
  }


  getBodyFrozenCss() {
    return 'sticky left-0 bg-inherit z-10'
  }

  getFooterFrozenCss() {
    return 'sticky left-0'
  }

  // In your component, after view initialized or on demand
  getTdLeftOffset(colIndex: number): number {
    const el = document?.getElementById('col' + colIndex);
    if (!el || colIndex == 0) return 0;

    // Get bounding rect relative to viewport
    const rect = el?.getBoundingClientRect();

    // Option B: relative to table's left edge (recommended)
    const tableEl = document?.querySelector('.data-table') as HTMLElement;
    if (!tableEl) return rect?.left;

    const tableRect = tableEl?.getBoundingClientRect();

    let res = (rect?.left ?? 0) - (tableRect.left ?? 0);
    return res;
  }

}
