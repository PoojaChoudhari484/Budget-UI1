import {
  Component,
  ElementRef,
  OnInit,
  QueryList,
  ViewChild,
  ViewChildren,
} from '@angular/core';
import { ChartComponent } from 'ng-apexcharts';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { ToastrService } from 'ngx-toastr';
import { DesignDepartmentService } from '../services/design-department.service';
import { MatDialog } from '@angular/material/dialog';
import { HttpResponse } from '@angular/common/http';
import { ChartOptions } from '../design-department/design-department.component';
import { debounceTime, Subject } from 'rxjs';
import { BudgetUtilsService } from '../services/utils/budget-utils.service';

@Component({
    selector: 'app-input-c',
    templateUrl: './input-c.component.html',
    styleUrls: ['./input-c.component.scss'],
    standalone: false
})
export class InputCComponent implements OnInit {
  @ViewChild('chart') chart!: ChartComponent;
  public chartOptions: ChartOptions;
  @ViewChild('fileInput') fileInput: ElementRef<HTMLInputElement> | undefined;
  @ViewChildren('numberInputField') numberInputFields!: QueryList<
    ElementRef<HTMLInputElement>
  >;

  updateSubject = new Subject<void>();
  isNaN = isNaN;
  dropdownIcon: any = './assets/images/icon-images/dropdown_arrow.svg';
  ellipseImages: string[] = [
    './assets/images/icon-images/Ellipse_green.svg',
    './assets/images/icon-images/Ellipse_red.svg',
    './assets/images/icon-images/Ellipse_yellow.svg',
  ];

  inputADepartmentKeyOrder = [
    'Company',
    'Project Name',
    'Project',
    'Tower',
    'Tower Option',
    'Nature',
    'UoM',
    'Type',
    'Configuration',
    'Total Potential',
    'Total Launched',
    'Total Launched Area',
    'Area per unit',
    "PTD Sold till Dec'24",
    "PTD Sold till Dec'24 Area",
    'Avg rate (PTD Dec 24) for existing project/ Rate for New Project',
    "YTD Dec'24 Act",
    "YTD Dec'24 Act Area",
    'Category',
    'Expected Date to receive OC',
    'No. of unit for which OC expected to be received',
    'Total Development Size Lakh Sq ft',
    'YTD Dec-24',
    'Actual Apr-Dec 24',
    'Amount',
    "Balance Leasable Inventory as on Dec'24 end",
    'Expense',
    'Fees paid till Dec-24',
    'Nature of Expenses',
    'Total Approved Amount',
    'Jan-25',
    'Feb-25',
    'Mar-25',
    'Q4 FY 2025',
    'Q4 FY25',
    'Apr-25',
    'YTD Mar-25',
    'May-25',
    'Jun-25',
    'Jul-25',
    'July-25',
    'Aug-25',
    'Sep-25',
    'Sept-25',
    'Oct-25',
    'Nov-25',
    'Dec-25',
    'Jan-26',
    'Feb-26',
    'Mar-26',
    'FY 25',
    'FY 26',
    'FY 2026',
    'Cumm Mar-26',
    'FY 27 (Projected)',
    'Remarks (Optional)',
    'FY-27',
  ];
  versions: string[] = [
    'Version 1.0',
    'Version 1.2',
    'Version 1.3',
    'Version 2.0',
  ];
  spinner: boolean = false;
  year2024Value: number = 50;
  year2025Value: number = 75;
  segment1Value: number = 50;
  segment2Value: number = 40;
  segment3Value: number = 30;
  deptSelectedIndex: number = 0;
  departmentList: string[] = [];
  frmGroup: FormGroup;
  masterData: any = {};
  companyList: string[] = [];
  projectMap: { [key: string]: string[] } = {};
  typeMap: { [key: string]: string } = {};
  projectList: any[] = [];
  file: any;
  dataSource: any[] = [];
  tableData: any[] = [];
  Object = Object;
  isEdit: boolean = true;
  isFullScreen: boolean = false;
  tableHeaders: string[] = [];
  filterProjectMapWithCompany: {
    [key: string]: { name: string; isChecked: boolean }[];
  } = {};
  filterCompanyList: string[] = [];
  selectAll: boolean = false;
  isPreview: boolean = false;
  zoomLevel: number;
  isDebounceInitialized: boolean = false;
  currencyFormat: string = 'absolute';
  previousCurrencyFormat: string = 'absolute';

  constructor(
    private toastr: ToastrService,
    private formBuilder: FormBuilder,
    private designDepartmentService: DesignDepartmentService,
    private dialog: MatDialog,
    private budgetUtilsService: BudgetUtilsService,
  ) {
    this.chartOptions = this.initChart();
  }

  ngOnInit(): void {
    this.initForm();
    this.getMasterData();
  }

  callUpdate() {
    if (!this.isDebounceInitialized) {
      this.initializeDebounce();
      this.isDebounceInitialized = true;
    }
    this.updateSubject.next();
  }

  initializeDebounce(): void {
    this.updateSubject.pipe(debounceTime(1500)).subscribe(() => {
      this.updateTable();
    });
  }

  initForm() {
    this.frmGroup = this.formBuilder.group({
      company: ['', Validators.required],
      project: ['', Validators.required],
    });
  }

  initChart(): ChartOptions {
    return {
      series: [44, 55, 13, 43], // Dynamic series data
      chart: {
        type: 'donut',
        width: '100px',
        height: '100px',
      },
      legend: {
        show: false, // This will hide the legend and series labels
      },
      plotOptions: {
        pie: {
          donut: {
            size: '65%',
          },
        },
      },
      dataLabels: {
        enabled: false, // This hides the labels inside the chart
      },
      tooltip: {
        enabled: true, // This disables the tooltip
      },
      responsive: [
        {
          breakpoint: 480,
          options: {
            chart: {
              width: '100%',
            },
          },
        },
      ],
    };
  }

  getMasterData() {
    this.designDepartmentService.getMasterData().subscribe((res) => {
      this.masterData = res;
      this.extractCompaniesAndProjects();
    });
  }

  getDepartmentList(res: any[]) {
    this.departmentList = res;
  }

  extractCompaniesAndProjects() {
    this.companyList = [];
    this.projectMap = {};
    this.typeMap = {};

    Object.keys(this.masterData).forEach((companyName: string) => {
      this.companyList.push(companyName);
      this.projectMap[companyName] = [];
      (this.masterData[companyName] as any[]).forEach((project: any) => {
        Object.keys(project).forEach((projectName: string) => {
          this.projectMap[companyName].push(projectName);
          this.typeMap[projectName] = project[projectName].type;
        });
      });
    });
  }

  getProjectListByCompany(event: any) {
    this.projectList = [];
    const selectedCompany = event.target.value;
    this.projectList = this.projectMap[selectedCompany];
  }

  onChangeDepartment(i: number) {
    this.currencyFormat = 'absolute';
    this.previousCurrencyFormat = 'absolute';
    this.deptSelectedIndex = i;
    this.getTableData();
  }

  getTableData() {
    let department = this.departmentList[this.deptSelectedIndex];
    this.designDepartmentService
      .getDataByDepartment(department)
      .subscribe((res) => {
        this.tableData = res;
        this.extractAndSortData(res);
      });
  }

  setTowerOption(res: any) {
    res?.forEach((row: any) => {
      if (row['Tower']) {
        row['Tower Option'] = [row['Tower']];
      } else row['Tower Option'] = [];
    });
    console.log(res);
    this.tableData = res;
    this.extractAndSortData(res);
  }

  extractAndSortData(data: any) {
    this.dataSource = [];
    this.tableHeaders = [];

    data?.forEach((row: any) => {
      const processedRow: any = {};

      this.inputADepartmentKeyOrder.forEach((orderKey) => {
        if (row.hasOwnProperty(orderKey)) {
          if (!this.tableHeaders.includes(orderKey)) {
            this.tableHeaders.push(orderKey);
          }
          processedRow[orderKey] = row[orderKey];
        }
      });
      Object.keys(row).forEach((key) => {
        if (!this.inputADepartmentKeyOrder.includes(key)) {
          if (!this.tableHeaders.includes(key)) {
            this.tableHeaders.push(key);
          }
          processedRow[key] = row[key];
        }
      });
      this.dataSource.push(processedRow);
    });

    if (this.currencyFormat !== 'absolute') this.onChangeCurrencyFormat();
  }

  selectFile() {
    if (this.fileInput) {
      this.fileInput.nativeElement.click();
    } else {
      console.error('File input not found');
    }
  }

  onFileSelected(event: any): void {
    this.file = event.target.files[0];
    if (this.file) {
      const formData = new FormData();
      formData.append('file', this.file);
      formData.append(
        'department',
        this.departmentList[this.deptSelectedIndex],
      );

      this.designDepartmentService.uploadFile(formData).subscribe(
        (res) => {
          this.toastr.success(res);
          this.resetFileInput();
          this.getTableData();
        },
        (error) => {
          this.toastr.error(error);
          this.resetFileInput();
        },
      );
    }
  }

  resetFileInput() {
    if (this.fileInput) {
      this.fileInput.nativeElement.value = '';
    }
  }

  addRow() {
    let frmValue = this.frmGroup.value;

    const newRow: Record<string, any> = {};
    Object.keys(this.dataSource[0]).forEach((key) => {
      if (key === 'Company') {
        newRow[key] = frmValue.company;
      } else if (key === 'Project Name') {
        newRow[key] = frmValue.project;
      } else if (key === 'Type') {
        newRow[key] = this.getTypeByCompany();
      } else {
        newRow[key] = null;
      }
    });
    this.dataSource.push(newRow);
  }

  getTowerOptions(row: any) {
    if (row['Tower Option']?.length < 1 || !row['Tower Option']) {
      if (row['Company'] && row['Project Name']) {
        let payload = { company: row['Company'], project: row['Project Name'] };
        this.designDepartmentService.getTowers(payload).subscribe((res) => {
          row['Tower Option'] = [...res['towers']];
        });
      }
    }
  }

  getTypeByCompany() {
    const selectedProject = this.frmGroup.value.project;
    return this.typeMap[selectedProject];
  }

  downloadExcel(): void {
    const payload: any = {
      department: this.departmentList[this.deptSelectedIndex],
    };

    this.designDepartmentService
      .downloadExcel(payload)
      .subscribe((response: HttpResponse<Blob>) => {
        const contentDisposition = response.headers.get('Content-Disposition');

        let fileName =
          this.departmentList[this.deptSelectedIndex]?.toLowerCase() +
          '_department_data';

        if (contentDisposition) {
          const match = contentDisposition.match(/filename="([^"]+)"/);
          if (match && match[1]) {
            fileName = match[1];
          }
        }

        const fileBlob = new Blob([response.body!], {
          type: response.body?.type || 'application/octet-stream',
        });

        const url = window.URL.createObjectURL(fileBlob);
        const anchor = document.createElement('a');
        anchor.href = url;
        anchor.download = fileName;
        anchor.click();
        window.URL.revokeObjectURL(url);
      });
  }

  async updateTable() {
    let res: boolean = await this.revertCurrencyFormatToAbsolute();
    if (res) {
      this.previousCurrencyFormat = 'absolute'; // initial json will come always absolute value.
      let dept = this.departmentList[this.deptSelectedIndex]?.toLowerCase();
      this.designDepartmentService.update(this.dataSource, dept).subscribe(
        (res) => {
          this.getTableData();
          this.toastr.success(res.message, 'OK');
        },
        (error) => {
          this.toastr.success(error, 'OK');
          this.getTableData();
        },
      );
    }
  }

  revertCurrencyFormatToAbsolute(): Promise<boolean> {
    return new Promise((resolve) => {
      // check currency format and set revert number.
      const currencyRevertNumber =
        this.currencyFormat === 'lacks'
          ? 100000
          : this.currencyFormat === 'crores'
            ? 10000000
            : 1;

      if (currencyRevertNumber !== 1) {
        this.dataSource?.forEach((row) => {
          Object.entries(row)?.forEach(([key, value]: [string, any]) => {
            let numericValue = Number(value);
            if (!isNaN(numericValue)) {
              row[key] = value * currencyRevertNumber;
            }
          });
        });
      }
      resolve(true);
    });
  }

  toggleFullScreen() {
    this.isFullScreen = !this.isFullScreen;
  }

  openFilter(templateRef: any) {
    this.dialog.open(templateRef, {
      width: '600px',
      height: 'auto',
    });
  }

  updateFilterCompanies(event: any, company: string): void {
    this.selectAll = false;
    const isChecked = event.target.checked;
    if (isChecked) {
      if (!this.filterCompanyList.includes(company)) {
        this.filterCompanyList.push(company);
      }
    } else {
      const index: number = this.filterCompanyList.indexOf(company);
      if (index > -1) {
        this.filterCompanyList.splice(index, 1);
      }
    }

    this.filterProjectMapWithCompany = {};
    this.filterCompanyList.forEach((company) => {
      if (this.projectMap[company]) {
        let projects: any[] = [];
        this.projectMap[company]?.forEach((project) => {
          let row: any = {};
          row.name = project;
          row.isChecked = false;
          projects.push(row);
        });
        console.log(projects);

        this.filterProjectMapWithCompany[company] = projects;
        console.log(this.filterProjectMapWithCompany);
      }
    });
  }

  showResults() {
    if (this.filterCompanyList.length > 0) {
      let filterDataList: any[] = [];

      Object.entries(this.filterProjectMapWithCompany)?.forEach(
        ([company, projects]) => {
          console.log(company);
          let isCheckedAny: boolean = projects.some((s) => s.isChecked);
          if (projects.length > 0 && isCheckedAny) {
            projects?.forEach((project) => {
              if (project.isChecked) {
                let findList = this.tableData?.filter(
                  (data) =>
                    data['Company'] === company &&
                    data['Project Name'] === project.name,
                );
                if (findList?.length > 0) filterDataList.push(...findList);
              }
            });
          } else {
            let findList = this.tableData?.filter(
              (data) => data['Company'] === company,
            );
            if (findList.length > 0)
              filterDataList = [...filterDataList, ...findList];
          }
        },
      );
      this.extractAndSortData(filterDataList);
    } else this.extractAndSortData(this.tableData);
  }

  resetFilters() {
    this.filterProjectMapWithCompany = {};
    this.filterCompanyList = [];
    this.extractAndSortData(this.tableData);
  }

  toggleSelectAllProject(event: any) {
    const isChecked = event.target.checked;
    Object.entries(this.filterProjectMapWithCompany)?.forEach(
      ([company, projects]) => {
        projects?.forEach((project) => {
          project.isChecked = isChecked;
        });
      },
    );
  }

  deleteTowerOption(row: any) {
    delete row['Tower Option'];
  }

  getTotalByKey(key: string): any {
    let total = 0;
    this.dataSource?.forEach((row) => {
      if (row[key] !== undefined && !isNaN(row[key])) {
        total += Number(row[key]);
      }
    });
    return total > 0 ? total : '';
  }

  sumInputA(row: any, key: string) {
    const periods = {
      'Q4 FY25': ['Jan-25', 'Feb-25', 'Mar-25'],
      'FY 26': [
        'Apr-25',
        'May-25',
        'Jun-25',
        'Jul-25',
        'Aug-25',
        'Sep-25',
        'Oct-25',
        'Nov-25',
        'Dec-25',
        'Jan-26',
        'Feb-26',
        'Mar-26',
      ],
    };

    for (const [period, months] of Object.entries(periods)) {
      if (months.includes(key)) {
        row[period] = months.reduce(
          (sum, month) => sum + (Number(row[month]) || 0),
          0,
        );
      }
    }

    // call update table.
    this.updateSubject.next();
  }

  zoomIn(): void {
    this.zoomLevel = Math.min(this.zoomLevel + 0.1, 2);
  }

  zoomOut(): void {
    this.zoomLevel = Math.max(this.zoomLevel - 0.1, 0.3);
  }

  resetTable() {
    this.extractAndSortData(this.tableData);
  }

  onChangeCurrencyFormat() {
    // Step 1: Revert the values based on the previous currency format
    this.dataSource?.forEach((row: any) => {
      Object.entries(row)?.forEach(([key, value]: [string, any]) => {
        let numericValue: number = Number(value);
        if (!isNaN(numericValue)) {
          switch (this.previousCurrencyFormat) {
            case 'lacks': {
              row[key] = numericValue * 100000;
              break;
            }
            case 'crores': {
              row[key] = numericValue * 10000000;
              break;
            }
            case 'absolute': {
              break;
            }
          }
        }
      });
    });

    // Step 2: Apply the new format (currencyFormat or selected format)

    this.dataSource?.forEach((row: any) => {
      Object.entries(row)?.forEach(([key, value]: [string, any]) => {
        let numericValue: number = Number(value);
        if (!isNaN(numericValue)) {
          switch (this.currencyFormat) {
            case 'absolute': {
              row[key] = Number(numericValue.toFixed(0));
              break;
            }
            case 'lacks': {
              row[key] = numericValue / 100000;
              break;
            }
            case 'crores': {
              row[key] = numericValue / 10000000;
              break;
            }
          }
        }
      });
    });

    this.previousCurrencyFormat = this.currencyFormat;
  }

  navigateFieldsByKeyboardArrow(
    event: KeyboardEvent,
    currentField: HTMLInputElement,
  ): void {
    const inputs = this.numberInputFields
      .toArray()
      .map((input) => input.nativeElement);
    this.budgetUtilsService.navigateFieldsByArrow(event, currentField, inputs);
  }
}
