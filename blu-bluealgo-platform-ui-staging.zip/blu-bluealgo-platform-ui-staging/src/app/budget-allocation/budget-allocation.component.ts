import { Component } from '@angular/core';

@Component({
    selector: 'app-budget-allocation',
    templateUrl: './budget-allocation.component.html',
    styleUrls: ['./budget-allocation.component.scss'],
    standalone: false
})
export class BudgetAllocationComponent {}
