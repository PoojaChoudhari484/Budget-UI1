import { Component, EventEmitter, Input, OnInit, Output } from '@angular/core';
import { BudgetCommonService } from '../../services/budget-common.service';

@Component({
    selector: 'app-department-section',
    templateUrl: './department-section.component.html',
    styleUrls: ['./department-section.component.scss'],
    standalone: false
})
export class DepartmentSectionComponent implements OnInit {
  ellipseImages: string[] = [
    './assets/images/icon-images/Ellipse_green.svg',
    './assets/images/icon-images/Ellipse_red.svg',
    './assets/images/icon-images/Ellipse_yellow.svg',
  ];

  @Input() screenName: string;
  @Output() onChangeDepartment = new EventEmitter<any>();
  @Output() departmentResponse = new EventEmitter<any>();
  departmentList: string[] = [];
  deptSelectedIndex: number = 0;

  constructor(private budgetCommonService: BudgetCommonService) {}

  ngOnInit() {
    this.getDepartmentList();
  }

  getDepartmentList() {
    let payload: any = { screen: this.screenName };
    this.budgetCommonService.getDepartmentList(payload).subscribe((res) => {
      this.departmentList = [...res.departments];
      if (this.departmentList.length > 0) {
        this.departmentResponse.emit(this.departmentList);
        this.onChangeDepartment.emit(0);
      }
      // this.getTableData();
    });
  }

  selectChange(index: number): void {
    this.deptSelectedIndex = index;
    this.onChangeDepartment.emit(index);
  }
}
