import { Component, OnInit } from '@angular/core';
import { BudgetCommonService } from '../../services/budget-common.service';
import { BUDGET_BASE_URL } from '../../services/budget-base-url';

@Component({
  selector: 'app-budget-allocation-header',
  templateUrl: './budget-automation-header.component.html',
  styleUrls: ['./budget-automation-header.component.scss'],
  standalone: false,
})
export class BudgetAutomationHeaderComponent implements OnInit {
  userInfo: any = {};

  constructor(private budgetCommonService: BudgetCommonService) {}

  ngOnInit() {
    this.getDepartmentList();
  }

  getDepartmentList() {
    let payload: any = { screen: 'InputA' };
    this.budgetCommonService.getDepartmentList(payload).subscribe((res) => {
      this.userInfo = res;
    });
  }
  goToMasterUrl()
  {
   window.location.href = BUDGET_BASE_URL+'admin_dashboard';

  }
}
