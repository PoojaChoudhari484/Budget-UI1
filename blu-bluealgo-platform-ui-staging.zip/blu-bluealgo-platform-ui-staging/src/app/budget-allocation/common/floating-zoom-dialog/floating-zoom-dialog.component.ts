import { Component, EventEmitter, OnInit, Output } from '@angular/core';

@Component({
    selector: 'app-floating-zoom-dialog',
    templateUrl: './floating-zoom-dialog.component.html',
    styleUrls: ['./floating-zoom-dialog.component.scss'],
    standalone: false
})
export class FloatingZoomDialogComponent implements OnInit {
  @Output() zoomLevelChange = new EventEmitter<any>();
  @Output() zoomLevelReset = new EventEmitter<any>();
  @Output() initZoomLevel = new EventEmitter<any>();
  zoomLevel: number = 0.8;

  constructor() {}

  ngOnInit() {
    this.initZoomLevel.emit(this.zoomLevel);
  }

  zoomIn(): void {
    this.zoomLevel = Math.min(this.zoomLevel + 0.1, 2);
    this.zoomLevelChange.emit(this.zoomLevel);
  }

  zoomOut(): void {
    this.zoomLevel = Math.max(this.zoomLevel - 0.1, 0.3);
    this.zoomLevelChange.emit(this.zoomLevel);
  }

  zoomReset() {
    this.zoomLevelReset.emit((this.zoomLevel = 0.8));
  }
}
