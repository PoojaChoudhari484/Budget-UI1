import { Component } from '@angular/core';
import { Router } from '@angular/router';

@Component({
    selector: 'app-logout-section',
    templateUrl: './logout-section.component.html',
    styleUrls: ['./logout-section.component.scss'],
    standalone: false
})
export class LogoutSectionComponent {
  constructor(private router: Router) {}

  logOut() {
    localStorage.clear();
    this.router.navigate(['/auth/sign-in']);
  }
}
