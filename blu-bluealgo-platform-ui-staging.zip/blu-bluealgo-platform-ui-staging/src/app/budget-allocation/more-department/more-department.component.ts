import {
  ChangeDetectorRef,
  Component,
  ElementRef,
  OnInit,
  QueryList,
  ViewChild,
  ViewChildren,
} from '@angular/core';
import { ChartComponent } from 'ng-apexcharts';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { ToastrService } from 'ngx-toastr';
import { MatDialog } from '@angular/material/dialog';
import { HttpResponse } from '@angular/common/http';
import { ChartOptions } from '../design-department/design-department.component';
import { BudgetUtilsService } from '../services/utils/budget-utils.service';
import { BudgetInformationDialogComponent } from '../common/budget-information-dialog/budget-information-dialog.component';
import { BudgetCommonService } from '../services/budget-common.service';

@Component({
    selector: 'app-more-department',
    templateUrl: './more-department.component.html',
    styleUrls: ['./more-department.component.scss'],
    standalone: false
})
export class MoreDepartmentComponent implements OnInit {
  @ViewChild('chart') chart!: ChartComponent;
  public chartOptions: ChartOptions;
  @ViewChild('fileInput') fileInput: ElementRef<HTMLInputElement> | undefined;
  @ViewChildren('numberInputField') numberInputFields!: QueryList<
    ElementRef<HTMLInputElement>
  >;

  dropdownIcon: any = './assets/images/icon-images/dropdown_arrow.svg';
  ellipseImages: string[] = [
    './assets/images/icon-images/Ellipse_green.svg',
    './assets/images/icon-images/Ellipse_red.svg',
    './assets/images/icon-images/Ellipse_yellow.svg',
  ];
  inputBDepartmentKeyOrder = [
    'Company',
    'Project',
    'Nature',
    'UoM',
    'Category',
    'Write Off',
    'Inventory',
    'Total',
    'New/Existing Lease',
    'Monthly Rent PSF',
    'Type',
    'Expected Date to receive OC',
    'No. of unit for which OC expected to be received',
    'Project Name',
    'Total Development Size Lakh Sq ft',
    'Approved Budget',
    'Spent till Mar 24',
    'YTD Dec-24',
    'Actual Apr-Dec 24',
    'Amount',
    "Balance Leasable Inventory as on Dec'24 end",
    'Expense',
    'Fees paid till Dec-24',
    'Nature of Expenses',
    'Total Approved Amount',
    'Total Area',
    "PTD Sold till Dec'24",
    "Leased as on Dec'24",
    'Bal1',
    'PTD Sold till Mar 25',
    'Leased as on Mar 25',
    'Bal2',
    'PTD Sold till Mar 26',
    'Leased as on Mar 26',
    'Bal3',
    'Area',
    'Rate',
    'Rent Free Period',
    'Total Lease Period',
    'Assumption',
    'Effective Monthly Rent PSF',
    'Jan-25',
    'Feb-25',
    'Mar-25',
    'Q4 FY 2025',
    'Q4 FY25',
    'YTD Mar-25',
    'Apr-25',
    'May-25',
    'Jun-25',
    'Jul-25',
    'Aug-25',
    'Sep-25',
    'Oct-25',
    'Nov-25',
    'Dec-25',
    'Jan-26',
    'Feb-26',
    'Mar-26',
    'FY 26',
    'FY 2026',
    'Cumm Mar-26',
    'FY 27 (Projected)',
    'Remarks (Optional)',
    'FY-27',
  ];
  stringInputColumns: string[] = ['Category'];
  readonlyRow: string[] = [
    'Revenue',
    'Expenses Detail',
    'Lease Rental : Cashflow',
    'Lease Rental : Revenue',
    'CAM Income',
    'CAM Expense',
    'Security Deposit',
    'Sub total (Revenue)',
    'Sub total (Expenses)',
    'SALE',
    'Total',
    'Repairs & Maintenance',
    'Food & Hotels',
    'Utility',
    'Communication & Courier',
    'Printing & Stationery LTR, SOSF & Project Office',
    'Staff Welfare',
    'Security (MSSC & Traffic Warden)',
  ];
  editableTextFields: string[] = ['Remarks'];
  dropdownColumns: string[] = ['New/Existing Lease'];
  versions: string[] = [
    'Version 1.0',
    'Version 1.1',
    'Version 1.2',
    'Version 2.0',
  ];
  columnWiseCssClasses: Record<string, string[]> = {
    'bg-[#d6e5f0]': ['Jan-25', 'Feb-25', 'Mar-25'],
    'bg-[#f8e0d5]': [
      'Apr-25',
      'May-25',
      'Jun-25',
      'Jul-25',
      'July-25',
      'Aug-25',
      'Sep-25',
      'Sept-25',
      'Oct-25',
      'Nov-25',
      'Dec-25',
      'Jan-26',
      'Feb-26',
      'Mar-26',
      'FY 25',
    ],
    'bg-[#2E2E2E] text-[#FFD700] opacity-90': [
      'Q4 FY25',
      'Q4 FY 2025',
      'FY 26',
      'FY 2026',
      'Total Potential (Units)',
      'Total Launched (Units)',
      'Area per unit',
      "PTD Sold till Dec'24",
      "Invt as on Dec'24",
      "YTD Dec'24",
      "Invt as on Apr'26",
      'Total Area (Launched units)',
      'Avg rate (PTD Dec 24) for existing project/ Rate for New Project',
      'Total AV (of launched Units)',
      'Schedule Date',
      'PTD Spent as on Dec 24',
      'Balance cost to go as on Dec 24',
      'YTD Dec Spend % (including GST) YTD Dec 24 @ CSV Sales',
      'FY25 Est Spends with GST & W/o SOSF',
      'FY-25 Sales @ CSV (Est)',
      'Total1',
      'FY-26 Sales @ CSV (Bud)',
      'Bud Marketing Spend Excluding SOSF & including GS',
      'Total2',
      'Sold in Q4 FY25',
      "Sold till Mar'25",
      'Sold in FY26',
      "Sold till Mar'26",
      "Till Mar'25",
      'Sold yet to be recognized',
      'Yet to be sold as on Dec 24',
      'OI Check1',
      'Yet to be sold as on Mar 25',
      'OI Check2',
      'Yet to be handedover as on Dec 24',
      'Rev Check1',
      'Yet to be handedover as on Mar 25',
      'Rev Check2',
      'OC received status',
      'Inventory',
      'Totals',
      'Write off',
      'Bal1',
      'Bal2',
      'Bal3',
    ],
  };
  spinner: boolean = false;
  year2024Value: number = 50;
  year2025Value: number = 75;
  segment1Value: number = 50;
  segment2Value: number = 40;
  segment3Value: number = 30;
  deptSelectedIndex: number = 0;
  departmentList: any[] = [];
  frmGroup: FormGroup;
  loading: boolean = false;
  masterData: any = {};
  companyList: string[] = [];
  projectMap: { [key: string]: string[] } = {};
  typeMap: { [key: string]: string } = {};
  projectList: string[] = [];
  file: any;
  dataSource: any[] = [];
  tableData: any[] = [];
  Object = Object;
  isEditEnable: boolean = false;
  isFullScreen: boolean = false;
  tableHeaders: string[] = [];
  filterProjectMapWithCompany: {
    [key: string]: { name: string; isChecked: boolean }[];
  } = {};
  filterCompanyList: string[] = [];
  selectAll: boolean = false;
  isPreview: boolean = false;
  zoomLevel: number;
  isTotalRow: boolean = false;
  currencyFormat: string = 'absolute';
  previousCurrencyFormat: string = 'absolute';
  isQuarterView: boolean = false;
  departmentName: string = '';
  deptInstruction: any = {};

  constructor(
    private toastr: ToastrService,
    private formBuilder: FormBuilder,
    private dialog: MatDialog,
    private cd: ChangeDetectorRef,
    private budgetUtilsService: BudgetUtilsService,
    private budgetCommonService: BudgetCommonService,
  ) {
    this.chartOptions = this.initChart();
  }

  ngOnInit(): void {
    this.initForm();
    this.getMasterData();
  }

  initForm() {
    this.frmGroup = this.formBuilder.group({
      company: ['', Validators.required],
      project: ['', Validators.required],
    });
  }

  initChart(): ChartOptions {
    return {
      series: [44, 55, 13, 43], // Dynamic series data
      chart: {
        type: 'donut',
        width: '100px',
        height: '100px',
      },
      legend: {
        show: false, // This will hide the legend and series labels
      },
      plotOptions: {
        pie: {
          donut: {
            size: '65%',
          },
        },
      },
      dataLabels: {
        enabled: false, // This hides the labels inside the chart
      },
      tooltip: {
        enabled: true, // This disables the tooltip
      },
      responsive: [
        {
          breakpoint: 480,
          options: {
            chart: {
              width: '100%',
            },
          },
        },
      ],
    };
  }

  getDepartmentList(res: any) {
    // let payload: any = { screen: 'InputB' };
    // this.budgetBaseService.getDepartmentList(payload).subscribe((res) => {
    //   this.departmentList = [...res.departments];
    //   this.getTableData();
    // });

    this.departmentList = res;
  }

  getInstructionByDept() {
    this.budgetCommonService
      .getInstructionByDepartment({ department: this.departmentName })
      .subscribe((res) => {
        this.deptInstruction = res;
      });
  }

  getMasterData() {
    this.budgetCommonService.getMasterData().subscribe((res) => {
      this.masterData = res;
      this.extractCompaniesAndProjects();
    });
  }

  extractCompaniesAndProjects() {
    this.companyList = [];
    this.projectMap = {};
    this.typeMap = {};

    Object.keys(this.masterData).forEach((companyName: string) => {
      this.companyList.push(companyName);
      this.projectMap[companyName] = [];
      (this.masterData[companyName] as any[]).forEach((project: any) => {
        Object.keys(project).forEach((projectName: string) => {
          this.projectMap[companyName].push(projectName);
          this.typeMap[projectName] = project[projectName].type;
        });
      });
    });
  }

  getProjectListByCompany(event: any) {
    this.projectList = [];
    this.dataSource = [];
    const selectedCompany = event.target.value;
    this.projectList = this.projectMap[selectedCompany];
    this.frmGroup.patchValue({ project: '' });
  }

  onChangeDepartment(i: number) {
    this.isQuarterView = false;
    this.deptSelectedIndex = i;
    this.departmentName = this.departmentList[this.deptSelectedIndex];
    this.initForm();
    this.getInstructionByDept();
    this.getTableData();
  }

  onChangeProject() {
    this.previousCurrencyFormat = 'absolute';
    this.isQuarterView = false;

    this.isTotalRow = false;
    this.dataSource = [];
    let frmValue = this.frmGroup.value;
    if (frmValue.company && frmValue.project) {
      let filteredData: any;
      filteredData = this.tableData.find(
        (item) =>
          item.Company === frmValue?.company &&
          item.Project === frmValue?.project,
      );
      if (!filteredData) {
        filteredData = this.tableData.find(
          (item) => item.Company === '' && item.Project === '',
        );
      }
      this.extractAndSortData(filteredData);
    }
  }

  getTableData() {
    this.loading = true; // Loader start
    this.currencyFormat = 'absolute';
    this.previousCurrencyFormat = 'absolute';
    this.dataSource = [];

    this.budgetCommonService
      .getDataByDepartment(this.departmentName)
      .subscribe((res) => {
        this.tableData = res;
        this.onChangeProject();
        this.loading = false;
      });
  }

  // setTowerOption(res: any) {
  //   res?.forEach((row: any) => {
  //     if (row['Tower']) {
  //       row['Tower Option'] = [row['Tower']];
  //     } else row['Tower Option'] = [];
  //   });
  //   console.log(res);
  //   this.tableData = res;
  //   this.extractAndSortData(res);
  // }

  extractAndSortData(data: any) {
    this.dataSource = [];
    this.tableHeaders = [];

    this.inputBDepartmentKeyOrder?.forEach((orderKey) => {
      // let key = data[orderKey];
      let key = data?.hasOwnProperty(orderKey);
      if (key && orderKey !== 'Project' && orderKey !== 'Company') {
        this.tableHeaders.push(orderKey);
      }
    });

    data['Category']?.forEach((category: string, index: number) => {
      const row: any = {};
      this.tableHeaders?.forEach((header) => {
        row[header] = data[header][index];
        // if (
        //   header !== 'Category' &&
        //   header !== 'Project' &&
        //   header !== 'Company'
        // ) {
        //   row[header] = data[header][index];
        // }
      });
      this.dataSource.push(row);

      if (category === 'Total') {
        this.isTotalRow = true;
      }
    });

    this.initCalculation(this.dataSource);
    if (this.currencyFormat !== 'absolute') this.onChangeCurrencyFormat();
  }


  initCalculation(dataList: any) {
    const periods: Record<string, string[]> = {
      'Q4 FY 2025': ['Jan-25', 'Feb-25', 'Mar-25'],
      'YTD Mar-25': ['YTD Dec-24', 'Jan-25', 'Feb-25', 'Mar-25'],
      'FY 26': [
        'Apr-25',
        'May-25',
        'Jun-25',
        'Jul-25',
        'Aug-25',
        'Sep-25',
        'Oct-25',
        'Nov-25',
        'Dec-25',
        'Jan-26',
        'Feb-26',
        'Mar-26',
      ],
    };

    dataList?.forEach((row: any) => {
      Object.keys((period: string) => {
        if (period in periods) {
          const months = periods[period];
          row[period] = months.reduce(
            (sum, month) => sum + (Number(row[month]) || 0),
            0,
          );
        }
      });
      row['Cumm Mar-26'] =
        (Number(row['Q4 FY 2025']) || 0) + (Number(row['FY 26']) || 0);
    });

    if (this.departmentName === 'Commercial PMC') {
      this.subTotalAndTotalCalculation();
    }
  }

  subTotalAndTotalCalculation() {
    let subTotalRows: any[] = [];
    let subTotalObj: any = {};

    // Subtotal calculation here.
    this.dataSource?.forEach((row, index) => {
      if (row['Category'].includes('Sub total')) {
        subTotalObj['Category'] = row['Category'];
        this.dataSource[index] = { ...subTotalObj };
        subTotalRows.push(subTotalObj);
        subTotalObj = {};
        return;
      }

      Object.entries(row)?.forEach(([key, value]: [string, any]) => {
        let numericValue = Number(value);
        if (!isNaN(numericValue)) {
          subTotalObj[key] = Number(subTotalObj[key] || 0) + numericValue;
        } else subTotalObj[key] = value;
      });
    });

    // Total Row calculation.
    // let totalRowObj: any = {};
    // subTotalRows?.forEach(row => {
    //   for (const [key, value] of Object.entries(row)) {
    //     let numericValue = Number(value);
    //     if (!isNaN(numericValue)) {
    //       totalRowObj[key] = Number(totalRowObj[key] || 0) + numericValue;
    //     } else totalRowObj[key] = value;
    //   }
    // })

    // pbt calculation here.
    let pbtRowObj: any = {};
    if (subTotalRows.length > 1) {
      const subTotalOne: any = subTotalRows[0];
      const subTotalTwo: any = subTotalRows[1];
      for (const [key, value] of Object.entries(subTotalRows[0])) {
        let numericValueSubOne = Number(subTotalOne[key]);
        let numericValueSubTwo = Number(subTotalTwo[key]);
        if (!isNaN(numericValueSubOne) && !isNaN(numericValueSubTwo)) {
          pbtRowObj[key] = numericValueSubOne - numericValueSubTwo;
        } else pbtRowObj[key] = value;
      }
    }

    // Find total row and pbt row to replace.
    let totalRowIndex: number = -1;
    let pbtRowIndex: number = -1;
    this.dataSource?.forEach((data, index) => {
      if (data['Category'] === 'Total') {
        totalRowIndex = index;
      } else if (data['Category'] === 'PBT') {
        pbtRowIndex = index;
      }
    });

    // replace here total.
    // if (totalRowIndex) {
    //   for (const [key, value] of Object.entries(this.dataSource[totalRowIndex])) {
    //     let numericValue = this.dataSource[totalRowIndex][key];
    //     if (!isNaN(numericValue)) {
    //       this.dataSource[totalRowIndex][key] = totalRowObj[key];
    //     }
    //   }
    // }

    // replace here pbt.
    if (pbtRowIndex) {
      for (const [key, value] of Object.entries(this.dataSource[pbtRowIndex])) {
        let numericValue = pbtRowObj[key];
        if (!isNaN(numericValue)) {
          this.dataSource[pbtRowIndex][key] = pbtRowObj[key];
        }
      }
    }
  }

  selectFile() {
    if (this.fileInput) {
      this.fileInput.nativeElement.click();
    } else {
      console.error('File input not found');
    }
  }

  onFileSelected(event: any): void {
    this.file = event.target.files[0];
    if (this.file) {
      const formData = new FormData();
      formData.append('file', this.file);
      formData.append('department', this.departmentName);

      this.budgetCommonService.uploadFile(formData).subscribe(
        (res) => {
          this.toastr.success(res);
          this.resetFileInput();
          this.getTableData();
        },
        (error) => {
          this.toastr.error(error);
          this.resetFileInput();
        },
      );
    }
  }

  resetFileInput() {
    if (this.fileInput) {
      this.fileInput.nativeElement.value = '';
    }
  }

  addRow() {
    let frmValue = this.frmGroup.value;

    const newRow: Record<string, any> = {};
    Object.keys(this.dataSource[0]).forEach((key) => {
      if (key === 'Company') {
        newRow[key] = frmValue.company;
      } else if (key === 'Project Name') {
        newRow[key] = frmValue.project;
      } else if (key === 'Type') {
        newRow[key] = this.getTypeByCompany();
      } else {
        newRow[key] = null;
      }
    });
    this.dataSource.push(newRow);
  }

  getTowerOptions(row: any) {
    if (row['Tower Option']?.length < 1 || !row['Tower Option']) {
      if (row['Company'] && row['Project Name']) {
        let payload = { company: row['Company'], project: row['Project Name'] };
        this.budgetCommonService.getTowers(payload).subscribe((res) => {
          row['Tower Option'] = [...res['towers']];
        });
      }
    }
  }

  getTypeByCompany() {
    const selectedProject = this.frmGroup.value.project;
    return this.typeMap[selectedProject];
  }

  downloadExcel(): void {
    const payload: any = {
      department: this.departmentName,
    };

    this.budgetCommonService
      .downloadExcel(payload)
      .subscribe((response: HttpResponse<Blob>) => {
        const contentDisposition = response.headers.get('Content-Disposition');

        let fileName = this.departmentName?.toLowerCase() + '_department_data';

        if (contentDisposition) {
          const match = contentDisposition.match(/filename="([^"]+)"/);
          if (match && match[1]) {
            fileName = match[1];
          }
        }

        const fileBlob = new Blob([response.body!], {
          type: response.body?.type || 'application/octet-stream',
        });

        const url = window.URL.createObjectURL(fileBlob);
        const anchor = document.createElement('a');
        anchor.href = url;
        anchor.download = fileName;
        anchor.click();
        window.URL.revokeObjectURL(url);
      });
  }

  async updateTable() {
    const data: any = await this.generateModelForUpdateData();

    if (data) {
      const updateResponse = await this.budgetCommonService
        .update(data, this.departmentName)
        .toPromise();
      this.toastr.success(updateResponse.message, 'OK');

      const fetchResponse = await this.budgetCommonService
        .getDataByDepartment(this.departmentName)
        .toPromise();
      if (fetchResponse) {
        this.tableData = fetchResponse;
        this.onChangeProject();
      }
    }
  }

  generateModelForUpdateData(): Promise<any> {
    return new Promise((resolve) => {
      let jsonFormatObj: any = {};

      // check currency format and set revert number.
      const currencyRevertNumber =
        this.currencyFormat === 'lacks'
          ? 100000
          : this.currencyFormat === 'crores'
            ? 10000000
            : 1;

      this.tableHeaders
        // .filter((header) => header !== 'Category')
        .forEach((header: string) => {
          jsonFormatObj[header] = [];
        });

      this.dataSource.forEach((row: any) => {
        // Temp key delete action.
        if (row.hasOwnProperty('isNewRow')) {
          delete row['isNewRow'];
        }

        // Revert currency format to absolute value
        if (currencyRevertNumber !== 1) {
          Object.entries(row)?.forEach(([key, value]: [string, any]) => {
            let numericValue = Number(value);
            if (!isNaN(numericValue)) {
              row[key] = value * currencyRevertNumber;
            }
          });
        }

        // Format json like initial json.
        this.tableHeaders
          // .filter((header) => header !== 'Category')
          .forEach((header: string, index: number) => {
            jsonFormatObj[header].push(row[header]);
          });
      });

      let frmValue = this.frmGroup.value;
      // jsonFormatObj['Category'] = this.dataSource.map((row: any) => row.Category);
      jsonFormatObj['Company'] = frmValue.company;
      jsonFormatObj['Project'] = frmValue.project;

      resolve(jsonFormatObj);

      // const existingRowIndex = this.tableData.findIndex(
      //   (item) =>
      //     item.Company === frmValue?.company &&
      //     item.Project === frmValue?.project,
      // );
      //
      // if (existingRowIndex !== -1) {
      //   this.tableData[existingRowIndex] = jsonFormatObj;
      // } else {
      //   this.tableData.push(jsonFormatObj);
      // }
      //
      // // let finds data to update by company and return.
      // let dataList = this.tableData?.filter(
      //   (f) => f.Company === frmValue.company,
      // );
      // resolve(dataList);
    });
  }

  toggleFullScreen() {
    this.isFullScreen = !this.isFullScreen;
  }

  openFilter(templateRef: any) {
    this.dialog.open(templateRef, {
      width: '600px',
      height: 'auto',
    });
  }

  updateFilterCompanies(event: any, company: string): void {
    this.selectAll = false;
    const isChecked = event.target.checked;
    if (isChecked) {
      if (!this.filterCompanyList.includes(company)) {
        this.filterCompanyList.push(company);
      }
    } else {
      const index: number = this.filterCompanyList.indexOf(company);
      if (index > -1) {
        this.filterCompanyList.splice(index, 1);
      }
    }

    this.filterProjectMapWithCompany = {};
    this.filterCompanyList.forEach((company) => {
      if (this.projectMap[company]) {
        let projects: any[] = [];
        this.projectMap[company]?.forEach((project) => {
          let row: any = {};
          row.name = project;
          row.isChecked = false;
          projects.push(row);
        });
        console.log(projects);

        this.filterProjectMapWithCompany[company] = projects;
        console.log(this.filterProjectMapWithCompany);
      }
    });
  }

  showResults() {
    if (this.filterCompanyList.length > 0) {
      let filterDataList: any[] = [];

      Object.entries(this.filterProjectMapWithCompany)?.forEach(
        ([company, projects]) => {
          console.log(company);
          let isCheckedAny: boolean = projects.some((s) => s.isChecked);
          if (projects.length > 0 && isCheckedAny) {
            projects?.forEach((project) => {
              if (project.isChecked) {
                let find = this.tableData.find(
                  (data) =>
                    data['Company'] === company &&
                    data['Project Name'] === project.name,
                );
                if (find) filterDataList.push(find);
              }
            });
          } else {
            let findList = this.tableData.filter(
              (data) => data['Company'] === company,
            );
            if (findList.length > 0)
              filterDataList = [...filterDataList, ...findList];
          }
        },
      );
      this.extractAndSortData(filterDataList);
    } else this.extractAndSortData(this.tableData);
  }

  resetFilters() {
    this.filterProjectMapWithCompany = {};
    this.filterCompanyList = [];
  }

  toggleSelectAllProject(event: any) {
    const isChecked = event.target.checked;
    Object.entries(this.filterProjectMapWithCompany)?.forEach(
      ([company, projects]) => {
        projects?.forEach((project) => {
          project.isChecked = isChecked;
        });
      },
    );
  }

  deleteTowerOption(row: any) {
    delete row['Tower Option'];
  }

  getTotalByKey(key: string): any {
    let total = 0;
    this.dataSource?.forEach((row) => {
      if (row[key] !== undefined && !isNaN(row[key])) {
        total += Number(row[key]);
      }
    });
    return total > 0 ? total : '';
  }

  sumInputB(row: any, key: string) {
    const periods = {
      'Q4 FY 2025': ['Jan-25', 'Feb-25', 'Mar-25'],
      'YTD Mar-25': ['YTD Dec-24', 'Jan-25', 'Feb-25', 'Mar-25'],
      'FY 26': [
        'Apr-25',
        'May-25',
        'Jun-25',
        'Jul-25',
        'Aug-25',
        'Sep-25',
        'Oct-25',
        'Nov-25',
        'Dec-25',
        'Jan-26',
        'Feb-26',
        'Mar-26',
      ],
    };

    for (const [period, months] of Object.entries(periods)) {
      if (months.includes(key)) {
        row[period] = months.reduce(
          (sum, month) => sum + (Number(row[month]) || 0),
          0,
        );
      }
    }
    row['Cumm Mar-26'] =
      (Number(row['YTD Mar-25']) || 0) + (Number(row['FY 26']) || 0);

    // Subtotal and total calculation.
    if (this.departmentName === 'Commercial PMC') {
      this.subTotalAndTotalCalculation();
      // let rowIndex = this.dataSource.indexOf(row);
      // // find subtotal row index.
      // let subTotalRowIndex: number = 0;
      // for (let i = rowIndex + 1; i < this.dataSource.length; i++) {
      //   let data = this.dataSource[i];
      //   if (data['Category'].includes('Sub total')) {
      //     subTotalRowIndex = i;
      //     break;
      //   }
      // }
      // let subTotal = 0;
      // for (let i = subTotalRowIndex - 1; i >= 0; i--) {
      //   let data = this.dataSource[i];
      //   if (data['Category'].includes('Sub total')) {
      //     break;
      //   }
      //   subTotal += Number(data[key]);
      // }
      // this.dataSource[subTotalRowIndex][key] = subTotal;
      //
      // // Filter rows with 'Sub Total' in the 'Category' field
      // const subTotalRows = this.dataSource?.filter((row) =>
      //   row['Category'].includes('Sub total'),
      // );
      //
      // const totalOfSubTotal = subTotalRows
      //   ?.map((m) => Number(m[key]))?.reduce((sum, current) => sum + current, 0);
      //
      // // Assign the calculated total to the totalRow object
      // let totalRow: any;
      // let pbtRow: any;
      // this.dataSource?.forEach((data) => {
      //   if (data['Category'] === 'Total') {
      //     totalRow = data;
      //   } else if (data['Category'] === 'PBT') {
      //     pbtRow = data;
      //   }
      // });
      // totalRow[key] = totalOfSubTotal;
      //
      // // set PBT value subtotal one - subtotal 2.
      // let subTotalOne = subTotalRows[0];
      // let subTotalTwo = subTotalRows[1];
      // pbtRow[key] = subTotalOne[key] - subTotalTwo[key];
    }
  }

  getDepartmentType(): string {
    // const department = this.departmentList[this.deptSelectedIndex];
    if (this.departmentName === 'Commercial Sales and Lease') {
      return 'Commercial_Sales_and_Lease';
    } else if (this.departmentName === 'Commercial PMC') {
      return 'Commercial PMC';
    }
    return 'default';
  }

  getTotalOfColumn(header: string): number {
    let sum = 0;
    this.dataSource?.forEach((row) => {
      sum += Number(row[header]);
    });
    return sum;
  }

  getCssClass(category: string, column: string): string {
    let cssClass = 'bg-transparent';

    /**
     * Check for group columns first
     * Column wise css generate
     */
    for (const [bgColor, months] of Object.entries(this.columnWiseCssClasses)) {
      if (months.includes(column)) {
        cssClass = bgColor;
        break;
      }
    }

    // Row wise css generate.
    if (this.readonlyRow.includes(category)) {
      const baseClass = 'font-semibold pointer-events-none';
      if (category === 'Total' || category.includes('Sub total')) {
        cssClass = baseClass + ' bg-blue-200';
      } else {
        cssClass = baseClass + ' bg-yellow-200';
      }
    }
    return cssClass;
  }

  resetTable() {
    this.isQuarterView = false;
    this.currencyFormat = 'absolute';
    this.previousCurrencyFormat = 'absolute';
    this.dataSource = [];
    this.tableHeaders = [];

    // Clear numeric values from tableData
    this.tableData = this.tableData.map(row => {
      const newRow = {...row};
      Object.keys(newRow).forEach(key => {
        if (key !== 'Company' && key !== 'Project' && key !== 'Category') {
          if (Array.isArray(newRow[key])) {
            newRow[key] = newRow[key].map(() => '');
          } else {
            newRow[key] = '';
          }
        }
      });
      return newRow;
    });

    this.onChangeProject();
}

  onChangeCurrencyFormat() {
    // Step 1: Revert the values based on the previous currency format
    this.dataSource?.forEach((row: any) => {
      Object.entries(row)?.forEach(([key, value]: [string, any]) => {
        let numericValue: number = Number(value);
        if (!isNaN(numericValue)) {
          switch (this.previousCurrencyFormat) {
            case 'lacks': {
              row[key] = numericValue * 100000;
              break;
            }
            case 'crores': {
              row[key] = numericValue * 10000000;
              break;
            }
            case 'absolute': {
              break;
            }
          }
        }
      });
    });

    // Step 2: Apply the new format (currencyFormat or selected format)
    this.dataSource?.forEach((row: any) => {
      Object.entries(row)?.forEach(([key, value]: [string, any]) => {
        let numericValue: number = Number(value);
        if (!isNaN(numericValue)) {
          switch (this.currencyFormat) {
            case 'absolute': {
              row[key] = Number(numericValue.toFixed(0));
              break;
            }
            case 'lacks': {
              row[key] = numericValue / 100000;
              break;
            }
            case 'crores': {
              row[key] = numericValue / 10000000;
              break;
            }
          }
        }
      });
    });
    this.previousCurrencyFormat = this.currencyFormat;
  }

  getColumnFieldType(header: string): string {
    if (this.stringInputColumns.includes(header)) {
      return 'text';
    } else if (this.dropdownColumns.includes(header)) {
      return 'dropdown';
    } else {
      return 'number';
    }
  }

  getDynamicWidth(text: string): string {
    const baseWidth = text?.length * 8;
    const minWidth = 50;
    const maxWidth = 500;

    const finalWidth = Math.max(minWidth, Math.min(baseWidth, maxWidth));
    return `${finalWidth + 20}px`;
  }

  getFieldType(row: any, value: any, header: string): string {
    // const dept = this.departmentList[this.deptSelectedIndex];
    if (
      isNaN(value) ||
      this.editableTextFields.includes(header) ||
      (header === 'Category' &&
        this.departmentName === 'Commercial Sales and Lease') ||
      (row?.isNewRow && header === 'Category') // for new row only category will be alphanumeric only.
    ) {
      return 'text';
    } else if (this.dropdownColumns.includes(header)) {
      return 'dropdown';
    }
    {
      return 'number';
    }
  }

  isReadOnly(row: any, header: string): boolean {
    // const dept = this.departmentList[this.deptSelectedIndex];
    if (this.isEditEnable) {
      if (
        header === 'Category' &&
        this.departmentName === 'Commercial Sales and Lease'
      ) {
        return false;
      }
      if (this.editableTextFields.includes(header)) {
        return false;
      }
      if (row?.isNewRow) {
        return false;
      }
    }
    return true;
  }

  toggleQuarter() {
    this.spinner = true;
    this.tableHeaders = [];
    this.isQuarterView = !this.isQuarterView;

    if (this.isQuarterView) {
      // Hard reference breaking.
      let tempString = JSON.stringify(this.dataSource);
      let tempData = JSON.parse(tempString);
      this.dataSource = [];
      this.cd.detectChanges();

      let quarterMap = {
        'Q4 FY 2025': ['Jan-25', 'Feb-25', 'Mar-25'],
        'Q1 FY 2025': ['Apr-25', 'May-25', 'Jun-25'],
        'Q2 FY 2025': ['Jul-25', 'Aug-25', 'Sep-25'],
        'Q3 FY 2025': ['Oct-25', 'Nov-25', 'Dec-25'],
        'Q4 FY 2026': ['Jan-26', 'Feb-26', 'Mar-26'],
      };

      tempData?.forEach((row: any) => {
        for (const [quarterKey, months] of Object.entries(quarterMap)) {
          let sum = 0;
          months.forEach((month) => {
            if (row.hasOwnProperty(month)) {
              let value = Number(row[month]);
              sum += value;
              delete row[month];
            }
          });
          row[quarterKey] = sum;
        }
      });

      this.tableHeaders.push(...Object.keys(tempData[0]));
      this.dataSource = [...tempData];
      this.cd.detectChanges();
    } else {
      this.resetTable();
    }

    setTimeout(() => {
      this.spinner = false;
    }, 2000);
  }

  addOtherRow() {
    let row: any = {};
    row.isNewRow = true;

    this.tableHeaders.forEach((header) => {
      if (header === 'Category') {
        row[header] = 'New Category';
      } else row[header] = '';
    });
    this.dataSource.push(row);
  }

  removeOtherRow(rowIndex: number) {
    if (rowIndex) {
      this.dataSource?.splice(rowIndex, 1);
    }
  }

  navigateFieldsByKeyboardArrow(
    event: KeyboardEvent,
    currentField: HTMLInputElement,
  ): void {
    const inputs = this.numberInputFields
      .toArray()
      .map((input) => input.nativeElement);
    this.budgetUtilsService.navigateFieldsByArrow(event, currentField, inputs);
  }

  openInstructionPopUp(buttonElement: HTMLElement) {
    const rect = buttonElement.getBoundingClientRect();
    this.dialog.open(BudgetInformationDialogComponent, {
      data: this.deptInstruction,
      position: {
        top: `${rect.top}px`,
        left: `${rect.left + 50}px`,
      },
      width: '500px',
    });
  }
}
