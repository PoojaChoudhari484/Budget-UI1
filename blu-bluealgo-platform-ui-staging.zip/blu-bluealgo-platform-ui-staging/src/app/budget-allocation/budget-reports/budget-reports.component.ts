import {
  ChangeDetectorRef,
  Component,
  ElementRef,
  OnInit,
  QueryList,
  ViewChild,
  ViewChildren,
} from '@angular/core';
import { ChartComponent } from 'ng-apexcharts';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { ToastrService } from 'ngx-toastr';
import { HttpResponse } from '@angular/common/http';
import { ChartOptions } from '../design-department/design-department.component';
import { BudgetReportsService } from '../services/budget-reports.service';
import { BudgetCommonService } from '../services/budget-common.service';
import { BudgetUtilsService } from '../services/utils/budget-utils.service';
import { BudgetInformationDialogComponent } from '../common/budget-information-dialog/budget-information-dialog.component';
import { MatDialog } from '@angular/material/dialog';

@Component({
    selector: 'app-budget-reports',
    templateUrl: './budget-reports.component.html',
    styleUrls: ['./budget-reports.component.scss'],
    standalone: false
})
export class BudgetReportsComponent implements OnInit {
  @ViewChild('chart') chart!: ChartComponent;
  public chartOptions: ChartOptions;
  @ViewChild('fileInput') fileInput: ElementRef<HTMLInputElement> | undefined;
  @ViewChildren('numberInputField') numberInputFields!: QueryList<
    ElementRef<HTMLInputElement>
  >;

  dropdownIcon: any = './assets/images/icon-images/dropdown_arrow.svg';
  ellipseImages: string[] = [
    './assets/images/icon-images/Ellipse_green.svg',
    './assets/images/icon-images/Ellipse_red.svg',
    './assets/images/icon-images/Ellipse_yellow.svg',
  ];

  keyOrder = [
    'Category',
    'Type',
    'Particulars',
    'Assets',
    'Dec-24 A',
    'Mar-25 A',
    'Mar-26 A',
    'Liabilities',
    'Dec-24 L',
    'Mar-25 L',
    'Mar-26 L',
    'Total Sanctioned Capex',
    'Expected Date to receive OC',
    'No. of unit for which OC expected to be received',
    'Project Name',
    'Total Development Size Lakh Sq ft',
    'YTD Dec-24',
    'Actual Apr-Dec 24',
    'Amount',
    "Balance Leasable Inventory as on Dec'24 end",
    'Expense',
    'Fees paid till Dec-24',
    'Nature of Expenses',
    'Total Approved Amount',
    'Jan-24',
    'Feb-24',
    'Mar-24',
    'Apr-24',
    'May-24',
    'Jun-24',
    'Jul-24',
    'Aug-24',
    'Sep-24',
    'Oct-24',
    'Nov-24',
    'Dec-24',
    'Jan-25',
    'Feb-25',
    'Mar-25',
    'Q4 FY 2025',
    'Q4 FY25',
    'Apr-25',
    'YTD Mar-25',
    'May-25',
    'Jun-25',
    'Jul-25',
    'Aug-25',
    'Sep-25',
    'Oct-25',
    'Nov-25',
    'Dec-25',
    'Jan-26',
    'Feb-26',
    'Mar-26',
    'FY 25',
    'FY 26',
    'FY 2026',
    'Cumm Mar-26',
    'FY 27 (Projected)',
    'Remarks (Optional)',
    'FY-27',
  ];
  readonlyRows: string[] = [
    'OrderInflow - Order inflow',
    'OrderBook - Order Book',
    'Sales - Gross Sales',
    'PerfomanceIndicators - Performance indicators',
    'PointResourceUtil - Point Resource Utlization',
    'AvgResourceUtil - Average Resource Utlization',
    'Debtors',
    'Vendor Credits',
    'Customer Advances',
    'Gross Investment property',
    'Capital Work In Progress',
    'Gross Fixed Assets',
    'Depreciations',
    'OCA',
  ];
  versions = ['Version 1.0', 'Version 1.1', 'Version 1.2', 'Version 2.0'];
  editableTextFields: string[] = ['Remarks'];
  columnWiseCssClasses: Record<string, string[]> = {
    'bg-[#d6e5f0]': ['Jan-25', 'Feb-25', 'Mar-25'],
    'bg-[#f8e0d5]': [
      'Apr-25',
      'May-25',
      'Jun-25',
      'Jul-25',
      'July-25',
      'Aug-25',
      'Sep-25',
      'Sept-25',
      'Oct-25',
      'Nov-25',
      'Dec-25',
      'Jan-26',
      'Feb-26',
      'Mar-26',
      'FY 25',
    ],
    'bg-indigo-200': ['Assets'],
    'bg-cyan-200': ['Liabilities'],
    'bg-[#2E2E2E] text-[#FFD700] opacity-90': [
      'Q4 FY25',
      'Q4 FY 2025',
      'FY 26',
      'FY 2026',
    ],
  };
  parentColumns: string[] = ['Assets'];
  spinner: boolean = false;
  loading: boolean = false;
  year2024Value: number = 50;
  year2025Value: number = 75;
  segment1Value: number = 50;
  segment2Value: number = 40;
  segment3Value: number = 30;
  deptSelectedIndex: number = 1;
  departmentList: any[] = [];
  frmGroup: FormGroup;
  masterData: any = {};
  companyList: any[] = [];
  projectMap: { [key: string]: string[] } = {};
  typeMap: { [key: string]: string } = {};
  projectList: any[] = [];
  file: any;
  dataSource: any[] = [];
  tableData: any[] = [];
  Object = Object;
  isEditEnable: boolean = false;
  isFullScreen: boolean = false;
  tableHeaders: string[] = [];
  isPreview: boolean = false;
  zoomLevel: number;
  currencyFormat: string = 'absolute';
  previousCurrencyFormat: string = 'absolute';
  isQuarterView: boolean = false;
  departmentName: string = '';
  deptInstruction: any = {};

  constructor(
    private toastr: ToastrService,
    private formBuilder: FormBuilder,
    private budgetReportsService: BudgetReportsService,
    private budgetCommonService: BudgetCommonService,
    private cd: ChangeDetectorRef,
    private budgetUtilsService: BudgetUtilsService,
    private dialog: MatDialog,
  ) {
    this.chartOptions = this.initChart();
  }

  ngOnInit(): void {
    this.initForm();
  }

  initForm() {
    this.frmGroup = this.formBuilder.group({
      company: ['', Validators.required],
      project: ['', Validators.required],
    });
  }

  initChart(): ChartOptions {
    return {
      series: [44, 55, 13, 43], // Dynamic series data
      chart: {
        type: 'donut',
        width: '100px',
        height: '100px',
      },
      legend: {
        show: false, // This will hide the legend and series labels
      },
      plotOptions: {
        pie: {
          donut: {
            size: '65%',
          },
        },
      },
      dataLabels: {
        enabled: false, // This hides the labels inside the chart
      },
      tooltip: {
        enabled: true, // This disables the tooltip
      },
      responsive: [
        {
          breakpoint: 480,
          options: {
            chart: {
              width: '100%',
            },
          },
        },
      ],
    };
  }

  getDepartmentList(res: any) {
    this.departmentList = res;
    if (this.departmentList?.length > 0) this.onChangeDepartment(0);
  }

  getMasterData(deptResponse: any) {
    this.budgetCommonService.getMasterData().subscribe((res) => {
      this.masterData = res;
      this.extractCompaniesAndProjects((res: any) => {
        if (res) {
          this.getDepartmentList(deptResponse);
        }
      });
    });
  }

  getInstructionByDept() {
    this.budgetCommonService
      .getInstructionByDepartment({ department: this.departmentName })
      .subscribe((res) => {
        this.deptInstruction = res;
      });
  }

  extractCompaniesAndProjects(callBack: any): any {
    this.companyList = [];
    this.projectMap = {};
    this.typeMap = {};

    Object.keys(this.masterData).forEach((companyName: string) => {
      this.companyList.push(companyName);
      this.projectMap[companyName] = [];
      (this.masterData[companyName] as any[]).forEach((project: any) => {
        Object.keys(project).forEach((projectName: string) => {
          this.projectMap[companyName].push(projectName);
          this.typeMap[projectName] = project[projectName].type;
        });
      });
    });

    if (this.companyList?.length > 0) {
      this.frmGroup.patchValue({ company: this.companyList[0] });
      this.projectList = this.projectMap[this.frmGroup.value.company];
    }
    callBack(true);
  }

  onChangeCompany() {
    this.isQuarterView = false;
    this.projectList = [];
    let company = this.frmGroup.value.company;
    this.projectList = this.projectMap[company];

    this.getTableData();
  }

  onChangeDepartment(i: number) {
    this.isQuarterView = false;
    this.currencyFormat = 'absolute';
    this.previousCurrencyFormat = 'absolute';
    this.deptSelectedIndex = i;
    this.departmentName = this.departmentList[this.deptSelectedIndex];
    if (this.departmentName) {
      this.getInstructionByDept();
      this.getTableData();
    }
  }

  onChangeProject() {
    this.isQuarterView = false;
    this.getTableData();
  }

  getTableData(): any {
    this.loading = true;
    this.dataSource = [];
    let dept = this.departmentList[this.deptSelectedIndex];
    const selectedCompany = this.frmGroup.value?.company;
    let param = dept + '-' + selectedCompany;

    if (
      dept.toLowerCase() === 'project wise cost sheet' ||
      dept.toLowerCase() === 'working capital inventory'
    ) {
      if (!this.frmGroup.value.project) {
        this.frmGroup.patchValue({ project: 'All' });
      }
      let project = this.frmGroup.value.project;
      param = param + '-' + project;
    } else this.frmGroup.patchValue({ project: '' });

    this.budgetReportsService.getDataByDepartment(param).subscribe((res) => {
      this.tableData = res;
      this.extractAndSortData(res);
      this.loading = false;
    });
  }

  extractAndSortData(data: any): void {
    this.tableHeaders = [];
    this.keyOrder.forEach((orderKey) => {
      let key = data.hasOwnProperty(orderKey);
      if (key && orderKey !== 'Project' && orderKey !== 'Company') {
        this.tableHeaders.push(orderKey);
      }
    });

    let parentColumn = data.hasOwnProperty('Particulars')
      ? 'Particulars'
      : 'Assets';
    data[parentColumn]?.forEach((parentColumn: string, index: number) => {
      const row: any = {};
      this.tableHeaders?.forEach((header) => {
        row[header] = data[header][index];
      });
      this.dataSource.push(row);
    });
  }

  selectFile() {
    if (this.fileInput) {
      this.fileInput.nativeElement.click();
    } else {
      console.error('File input not found');
    }
  }

  getParentColumn(data: any): string {
    let parentColumn: string = '';
    for (const [column, value] of Object.entries(data)) {
      if (this.parentColumns.includes(column)) {
        parentColumn = column;
        break;
      }
    }
    return parentColumn;
  }

  onFileSelected(event: any): void {
    this.file = event.target.files[0];
    if (this.file) {
      const formData = new FormData();
      formData.append('file', this.file);
      formData.append(
        'department',
        this.departmentList[this.deptSelectedIndex],
      );

      this.budgetCommonService.uploadFile(formData).subscribe(
        (res) => {
          this.toastr.success(res);
          this.resetFileInput();
          this.getTableData();
        },
        (error) => {
          this.resetFileInput();
          this.toastr.error(error);
        },
      );
    }
  }

  resetFileInput() {
    if (this.fileInput) {
      this.fileInput.nativeElement.value = '';
    }
  }

  downloadExcel(): void {
    const payload: any = {
      department: this.departmentList[this.deptSelectedIndex],
    };

    this.budgetCommonService
      .downloadExcel(payload)
      .subscribe((response: HttpResponse<Blob>) => {
        const contentDisposition = response.headers.get('Content-Disposition');
        console.log('Content-Disposition Header:', contentDisposition);

        let fileName =
          this.departmentList[this.deptSelectedIndex]?.toLowerCase() +
          '_department_data';

        if (contentDisposition) {
          const match = contentDisposition.match(/filename="([^"]+)"/);
          if (match && match[1]) {
            fileName = match[1];
          }
        }

        const fileBlob = new Blob([response.body!], {
          type: response.body?.type || 'application/octet-stream',
        });

        const url = window.URL.createObjectURL(fileBlob);
        const anchor = document.createElement('a');
        anchor.href = url;
        anchor.download = fileName;
        anchor.click();
        window.URL.revokeObjectURL(url);
      });
  }

  updateTable() {
    let dept = this.departmentList[this.deptSelectedIndex];
    const selectedCompany = this.frmGroup.value?.company;
    // let param = dept + '-' + selectedCompany;

    let data = this.generateModel();
    console.log(data);

    this.budgetCommonService.update(data, dept).subscribe((res) => {
      this.toastr.success(res.message, 'OK');
    });
  }

  generateModel() {
    let jsonFormatList: any = {};

    this.tableHeaders.forEach((header: string) => {
      jsonFormatList[header] = [];
    });

    this.dataSource.forEach((row: any) => {
      this.tableHeaders.forEach((header: string, index: number) => {
        jsonFormatList[header].push(row[header]);
      });
    });

    jsonFormatList['Company'] = (this.tableData as any)['Company'];
    jsonFormatList['Project'] = (this.tableData as any)['Project'];

    return jsonFormatList;
  }

  toggleFullScreen() {
    this.isFullScreen = !this.isFullScreen;
  }

  sumInput(row: any, colIndex: number, rowIndex: number) {
    let dept = this.departmentList[this.deptSelectedIndex];
    if (dept === 'Working Capital') {
      if (row['Particulars'] === 'Closing') {
        for (let i = 2; i < this.tableHeaders.length; i++) {
          let head = this.tableHeaders[i];

          // Get the opening row index and the next opening row
          let openingRowIndex: number = rowIndex - 3;
          let nextOpeningRow = this.dataSource[openingRowIndex];

          // Update the opening row's head value to the previous column's value
          let previousColumnHead = this.tableHeaders[i - 1];
          nextOpeningRow[head] = row[previousColumnHead];

          // Calculate the sum for the column `head` from nextOpeningRow to nextClosingRow
          let nextClosingRow = this.dataSource[rowIndex];
          let sum = 0;

          for (let j = openingRowIndex; j < rowIndex; j++) {
            let currentRow = this.dataSource[j];
            sum += Number(currentRow[head]) || 0;
          }

          // Update the nextClosingRow's value for the column `head`
          nextClosingRow[head] = sum;
        }
      }
    } else if (dept === 'PMS') {
      if (
        row['Particulars'].includes('Intra Group') ||
        row['Particulars'].includes('Inter Group')
      ) {
        let head = this.tableHeaders[colIndex];

        let customerRow: any;
        let ifsRow: any;
        for (let i = rowIndex; i >= 0; i--) {
          let data = this.dataSource[i];
          if (data['Particulars'].includes('Customer')) {
            customerRow = data;
          } else if (data['Particulars'].includes('IFS')) {
            ifsRow = data;
          }
          if (customerRow && ifsRow) {
            break;
          }
        }
        let intraRow: any;
        let interRow: any;
        if (row['Particulars'].includes('Intra Group')) {
          intraRow = row;
          interRow = this.dataSource[rowIndex + 1];
        } else if (row['Particulars'].includes('Inter Group')) {
          interRow = row;
          intraRow = this.dataSource[rowIndex - 1];
        }

        let sum = Number(intraRow[head]) + Number(interRow[head]);
        customerRow[head] = Number(ifsRow[head]) - sum;
      }
    }
  }

  resetTable() {
    this.dataSource = [];
    this.isQuarterView = false;
    this.extractAndSortData(this.tableData);
  }

  onChangeCurrencyFormat() {
    // Step 1: Revert the values based on the previous currency format
    this.dataSource?.forEach((row) => {
      console.log(row);
      Object.entries(row)?.forEach(([key, value]: [string, any]) => {
        let numericValue: number = Number(value);
        if (!isNaN(numericValue)) {
          switch (this.previousCurrencyFormat) {
            case 'lacks': {
              row[key] = numericValue * 100000;
              break;
            }
            case 'crores': {
              row[key] = numericValue * 10000000;
              break;
            }
            case 'absolute': {
              break;
            }
          }
        }
      });
    });

    // Step 2: Apply the new format (currencyFormat or selected format)
    this.dataSource?.forEach((row: any) => {
      Object.entries(row)?.forEach(([key, value]: [string, any]) => {
        let numericValue: number = Number(value);
        if (!isNaN(numericValue)) {
          switch (this.currencyFormat) {
            case 'absolute': {
              row[key] = Number(numericValue.toFixed(0));
              break;
            }
            case 'lacks': {
              row[key] = numericValue / 100000;
              break;
            }
            case 'crores': {
              row[key] = numericValue / 10000000;
              break;
            }
          }
        }
      });
    });
    this.previousCurrencyFormat = this.currencyFormat;
  }

  getDynamicWidth(text: string): string {
    const baseWidth = text?.length * 8;
    const minWidth = 50;
    const maxWidth = 500;

    const finalWidth = Math.max(minWidth, Math.min(baseWidth, maxWidth));
    return `${finalWidth + 20}px`;
  }

  getCssClass(Particulars: string, column: string): string {
    let cssClass = 'bg-transparent';

    /**
     * Check for group columns first
     * Column wise css generate
     */
    for (const [bgColor, months] of Object.entries(this.columnWiseCssClasses)) {
      if (months.includes(column)) {
        cssClass = bgColor;
        break;
      }
    }

    // Row wise css generate.
    if (this.readonlyRows.includes(Particulars)) {
      cssClass = 'font-semibold pointer-events-none';
      if (Particulars === 'Total' || Particulars.includes('Sub total')) {
        cssClass += ' bg-blue-200';
      } else {
        cssClass += ' bg-yellow-200';
      }
    }
    return cssClass;
  }

  getFieldType(value: any, header: string): string {
    if (isNaN(value) || this.editableTextFields.includes(header)) {
      return 'text';
    } else {
      return 'number';
    }
  }

  toggleQuarter() {
    this.spinner = true;
    this.tableHeaders = [];
    this.isQuarterView = !this.isQuarterView;

    if (this.isQuarterView) {
      // Hard reference breaking.
      let tempString = JSON.stringify(this.dataSource);
      let tempData = JSON.parse(tempString);
      this.dataSource = [];
      this.cd.detectChanges();

      let quarterMap = {
        'Q4 FY 2025': ['Jan-25', 'Feb-25', 'Mar-25'],
        'Q1 FY 2025': ['Apr-25', 'May-25', 'Jun-25'],
        'Q2 FY 2025': ['Jul-25', 'Aug-25', 'Sep-25'],
        'Q3 FY 2025': ['Oct-25', 'Nov-25', 'Dec-25'],
        'Q4 FY 2026': ['Jan-26', 'Feb-26', 'Mar-26'],
      };

      tempData?.forEach((row: any) => {
        for (const [quarterKey, months] of Object.entries(quarterMap)) {
          let sum = 0;
          months.forEach((month) => {
            if (row.hasOwnProperty(month)) {
              let value = Number(row[month]);
              sum += value;
              delete row[month];
            }
          });
          row[quarterKey] = sum;
        }
      });

      this.tableHeaders.push(...Object.keys(tempData[0]));
      this.dataSource = [...tempData];
      this.cd.detectChanges();
    } else {
      this.resetTable();
    }

    setTimeout(() => {
      this.spinner = false;
    }, 2000);
  }

  navigateFieldsByKeyboardArrow(
    event: KeyboardEvent,
    currentField: HTMLInputElement,
  ): void {
    const inputs = this.numberInputFields
      .toArray()
      .map((input) => input.nativeElement);
    this.budgetUtilsService.navigateFieldsByArrow(event, currentField, inputs);
  }

  openInstructionPopUp(buttonElement: HTMLDivElement) {
    const rect = buttonElement.getBoundingClientRect();
    this.dialog.open(BudgetInformationDialogComponent, {
      data: this.deptInstruction,
      position: {
        top: `${rect.top}px`,
        left: `${rect.left + 50}px`,
      },
      width: '500px',
    });
  }
}
