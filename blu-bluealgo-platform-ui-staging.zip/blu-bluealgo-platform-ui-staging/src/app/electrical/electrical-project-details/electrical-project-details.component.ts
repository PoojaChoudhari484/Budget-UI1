import { Component } from '@angular/core';
import { Router } from '@angular/router';
import { ActivatedRoute } from '@angular/router';
import { ModuleService } from 'src/app/services/module.service';
import { LocalApiService } from 'src/app/core/services/local-api.service';

@Component({
    selector: 'app-electrical-project-details',
    templateUrl: './electrical-project-details.component.html',
    styleUrls: ['./electrical-project-details.component.scss'],
    standalone: false
})
export class ElectricalProjectDetailsComponent {
  moduleWiseSubModules = [
   
    {
      module: 'Electrical', submodule: [
        {name: 'Residential Load Sheets', route: '/electrical/load-sheets'},
        {name: 'Commercial Load Sheets', route: '/electrical/commercial-load-sheets'},
      ]
    }
  ]
  selectedModule: string = '';
  documentVersion: string = '';
  projectName: string = '';
  projectType: string = '';
  isNewProject: boolean = false;
  newProjectName: string = '';
  showProgress = false;
  progressValue = 0;
  onClickCloseOrNext = true;
  interval: any;
  loading: boolean;
  constructor(
    private apiService: LocalApiService,
    private router: Router,
    private moduleService: ModuleService,
    private activatedRoute: ActivatedRoute,
  ) {}

  ngOnInit(): void {
    this.apiService.post<any>('get_project_name', {}).subscribe(
      (response) => {
         this.projectName = response.project_name;
        console.log(response);
      },
      (error) => {
        console.error('API Error:', error);
      },
    );
    this.activatedRoute.queryParams.subscribe((params) => {
      
      const moduleFromQuery = params['module'];

      if (moduleFromQuery) {
        this.moduleService.updateSelectedModule(moduleFromQuery);
      }
    });

    this.moduleService.selectedSubModule$.subscribe((module) => {
      this.selectedModule = module;
      this.updateDocumentVersion(module, this.projectName, this.projectType);
    });

    this.projectName = this.projectName || '';
    this.projectType = this.projectType || '';
  }

  onInputChange() {
    this.updateDocumentVersion(
      this.selectedModule,
      this.projectName,
      this.projectType,
    );
  }

  updateDocumentVersion(
    module: string,
    projectName: string,
    projectType: string,
  ) {
    const moduleAbbreviations: { [key: string]: string } = {
      'Residential Load Sheets': 'RLS',
      'Commercial Load Sheets': 'CLS',
      Reports: 'REP',
    };

    const projectNamePrefix = projectName ? projectName.slice(0, 4) : 'Cent';
    const projectTypePrefix = projectType ? projectType.slice(0, 4) : 'Resi';

    const abbreviation = moduleAbbreviations[module] || 'GEN';

    this.documentVersion = `LTR/HO-MEPF/Design/${abbreviation}/${projectTypePrefix}-${projectNamePrefix}-001`;
  }
  navigateToOwc() {
  this.showProgress = true;
  this.onClickCloseOrNext = false;
  this.progressValue = 0;

      // API call + navigation
      const navigationExtras = {
        queryParams: {
          projectName: Array.isArray(this.projectName) ? this.newProjectName : this.newProjectName || this.projectName,
          projectType: this.projectType,
          documentVersion: this.documentVersion,
          date: new Date().toISOString().split('T')[0],
        },
      };

      this.apiService.post<any>('get_project_name', navigationExtras).subscribe(
        (response) => {
          console.log(response);
          this.router.navigate(['/electrical/design-calculus-submodules/'], navigationExtras);
        },
        (error) => {
          console.error('API Error:', error);
        }
      );

    let totalDuration = 300; // 300 seconds = 5 minutes
    let intervalTime = 1000; // update every 1 second
    let step = 100 / totalDuration; // How many percent increase per second
    this.interval = setInterval(() => {
    this.progressValue += step;

    if (this.progressValue >= 100) {
      clearInterval(this.interval);
      this.showProgress = false;
      this.router.navigate(['/electrical/design-calculus-submodules/'], navigationExtras);
      
    }
  }, intervalTime);
}
  navigateToModules() {
    this.router.navigate(['/phe/design-calculus']);
  }
}
