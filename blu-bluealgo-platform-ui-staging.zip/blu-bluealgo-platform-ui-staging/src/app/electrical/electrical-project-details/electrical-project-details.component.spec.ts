import { ComponentFixture, TestBed } from '@angular/core/testing';

import { ElectricalProjectDetailsComponent } from './electrical-project-details.component';

describe('ElectricalProjectDetailsComponent', () => {
  let component: ElectricalProjectDetailsComponent;
  let fixture: ComponentFixture<ElectricalProjectDetailsComponent>;

  beforeEach(() => {
    TestBed.configureTestingModule({
      declarations: [ElectricalProjectDetailsComponent]
    });
    fixture = TestBed.createComponent(ElectricalProjectDetailsComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
