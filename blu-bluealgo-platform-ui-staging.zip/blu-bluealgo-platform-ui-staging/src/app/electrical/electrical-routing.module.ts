import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { LoadSheetsComponent } from './load-sheets/load-sheets.component';
import {CommercialLoadSheetsComponent} from "./commercial-load-sheets/commercial-load-sheets.component";
import { ElectricalProjectDetailsComponent } from './electrical-project-details/electrical-project-details.component';
import { ElectricalSubPageComponent } from './electrical-sub-page/electrical-sub-page.component';
import { HsdComponent } from './hsd/hsd.component';
import { KvarComponent } from './kvar/kvar.component';
import { HtCablesComponent } from './ht-cables/ht-cables.component';
import { UpsComponent } from './ups/ups.component';
import { BusductComponent } from './busduct/busduct.component';
import { VdComponent } from './vd/vd.component';
const routes: Routes = [
  {
    path: '',
    children: [
      { path: '', redirectTo: 'load-sheets', pathMatch: 'full' },
      { path: 'load-sheets', component: LoadSheetsComponent },
      { path: 'commercial-load-sheets', component: CommercialLoadSheetsComponent },
      { path: 'project-details', component: ElectricalProjectDetailsComponent },
      {path: 'design-calculus-submodules',component: ElectricalSubPageComponent},
      {path: 'hsd',component: HsdComponent},
      {path: 'kvar', component: KvarComponent},
      {path: 'ht-cables', component: HtCablesComponent},
      {path: 'ups', component: UpsComponent},
      {path: 'busduct', component: BusductComponent},
      {path: 'vd', component:VdComponent},
    ],
  },
];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule],
})
export class ElectricalRoutingModule {}
