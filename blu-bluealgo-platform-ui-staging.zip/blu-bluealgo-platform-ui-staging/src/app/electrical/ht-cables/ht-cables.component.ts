import { Component, EventEmitter, Input, OnInit, Output } from '@angular/core';
import { Summary } from 'src/app/core/models/Summary.model';
import { LocalApiService } from 'src/app/core/services/local-api.service';
import * as Highcharts from 'highcharts';
import 'highcharts/highcharts-3d';
import { HttpClient } from '@angular/common/http';
import { CalculusCommonService } from '../../core/services/calculus-common.service';

@Component({
    selector: 'app-ht-cables',
    templateUrl: './ht-cables.component.html',
    styleUrls: ['./ht-cables.component.scss'],
    standalone: false
})
export class HtCablesComponent implements OnInit {
  @Input() public inputASummaries!: Summary[];
  @Input() public inputBSummaries!: Summary[];
  @Output() moveToTab = new EventEmitter<string>();

  public summaryText = 'Summary - A';
  public summaryType = 'A';
  public showInputA = false;
  public showInputB = false;
  public nominal_system_voltage = 0;
  public short_circuit_level = 0;
  public fault_withstand_time = 0;
  public xlpe_cable_conductor = 0;
  public nearest_selected_cable_size = 0;

  public selectedInputASummary: Summary | null = null;
  public selectedInputBSummary: Summary | null = null;
  public mainResponse: any = {};
  public inputAResponse: any = {};
  public inputBResponse: any = {};
  public supportStaffs: number[] = [0, 5, 10, 15, 20, 25, 30, 35, 40, 45, 50];

  public showInputASummary = true;
  public showInputBSummary = false;
  public showInput = false;
  public donutChartLabels = [
    'Domestic (Input A)',
    'Domestic (Input B)',
    'Flushing (Input A)',
    'Flushing (Input B)',
  ];
  public activeButtonId: string | null = 'tab-input-a';
  public inputDropdownArrowSrc = 'assets/images/icons/down_arrow.svg';
  public unitTypes: string[] = ['LPD', 'KLD'];
  public selectedUnit: string = 'LPD';
  public flushingWaterRequired = 6;
  highChartOptions: Highcharts.Options;
  Highcharts = Highcharts;
  barChartOptions: Highcharts.Options;

  public constructor(
    private apiService: LocalApiService,
    private http: HttpClient,
    private calculusCommonService: CalculusCommonService,
  ) {
    this.initializeHighChart();
    this.initializeBarChart();
  }
  ngOnInit(): void {
    const payload = {
      
    };

    this.apiService.post<any>('ht_cables', payload).subscribe(
      (response) => {
        this.inputAResponse = response;
        
        this.nominal_system_voltage = this.inputAResponse?.nominal_system_voltage ?? 0;
        this.short_circuit_level = this.inputAResponse?.short_circuit_level ?? 0;
        this.fault_withstand_time = this.inputAResponse?.fault_withstand_time ?? 0;
        this.xlpe_cable_conductor = this.inputAResponse?.xlpe_cable_conductor ?? 0;
        this.nearest_selected_cable_size = this.inputAResponse?.nearest_selected_cable_size ?? 0;      

        this.initializeHighChart();
        this.initializeBarChart();
      },
      (error) => {
        console.error('API Error:', error);
      },
    );
  }

  

  initializeHighChart(): void {
    let totalROWater = this.inputAResponse?.total_ro_water;
    
    let RORejectedWater = this.inputAResponse?.ro_reject_water;
   

    totalROWater = Number(totalROWater);
    RORejectedWater = Number(RORejectedWater);
    // flushingValueOfA = Number(flushingValueOfA);
    // flushingValueOfB = Number(flushingValueOfB);

    // console.log(domesticValueOfB);
    // console.log(flushingValueOfB);

    this.highChartOptions = {
      chart: {
        marginTop: 45,
        type: 'pie',
        backgroundColor: 'transparent',
        options3d: {
          enabled: true,
          alpha: 55,
          beta: 0,
        },
      },
      title: {
        text: '',
      },
      legend: {
        enabled: true,
        align: 'center',
        verticalAlign: 'top',
        y: 0,
        itemStyle: {
          color: '#333',
        },
      },
      plotOptions: {
        pie: {
          showInLegend: true,
          // colors: ['#19FB8B', '#FF645B'],
          innerSize: 90,
          depth: 40,
          dataLabels: {
            enabled: false,
            format: '{point.name}: {point.percentage:.1f}%',
            style: {
              color: 'white',
              fontWeight: 'bold',
            },
          },
        },
      },
      series: [
        {
          type: 'pie',
          // name: 'Waste',
          data: [
            { name: `Total RO Water [${this.selectedUnit}]`, y: totalROWater },
            {
              name: `RO Rejected Water [${this.selectedUnit}]`,
              y: RORejectedWater,
            },
            // { name: `Flushing [${this.selectedUnit}] A`, y: flushingValueOfA },
            // { name: `Flushing [${this.selectedUnit}] B`, y: flushingValueOfB },
          ],
          tooltip: {
            pointFormat: '{point.name}: {point.percentage:.1f}%',
          },
        },
      ],
      credits: {
        enabled: false,
      },
    };
  }

  initializeBarChart(): void {
    this.barChartOptions = {
      chart: {
        marginTop: 45,
        type: 'bar', // Changed from 'pie' to 'bar'
        backgroundColor: 'transparent',
        // Removed options3d as it's generally not used with bar charts by default.
      },
      title: {
        text: '',
      },
      legend: {
        enabled: true,
        align: 'center',
        verticalAlign: 'top',
        y: 0,
        itemStyle: {
          color: '#333',
        },
      },
      xAxis: {
        categories: [
          `Water Per person [LPCD]`,
          `Total RO Water [${this.selectedUnit}]`,
          `RO Rejected Water [${this.selectedUnit}]`,
          `RO Plant [LPH]`,
          `RO Plant Approx [LPH]`,
          `Storage Capacity [Ltrs]`,
        ],
        title: {
          text: null,
        },
      },
      yAxis: {
        min: 0,
        title: {
          text: 'Volume', // Adjust the title as needed
          align: 'middle',
          x: 0,
          y: 15,
        },
        labels: {
          overflow: 'justify',
        },
      },
      plotOptions: {
        series: {
          dataLabels: {
            enabled: true, // Enable data labels to show values on bars
            format: '{y}',
          },
        },
      },
      series: [
        {
          type: 'bar',
          name: 'Water', // Change or add a meaningful name
          data: [
            this.inputAResponse?.water_per_person,
            this.inputAResponse?.total_ro_water,
            this.inputAResponse?.ro_reject_water,
            this.inputAResponse?.ro_plant,
            this.inputAResponse?.ro_plant_approx,
            this.inputAResponse?.storage_capacity,
            // { y: this.inputAResponse?.ro_reject_water ?? 600, color: 'blue' }
          ],
          // Optionally, configure tooltip for individual bars
          tooltip: {
            pointFormat: '{point.category}: <b>{point.y}</b>',
          },
        },
      ],
      credits: {
        enabled: false,
      },
    };
  }

  toggleInputsSummary(id: string) {
    this.activeButtonId = this.activeButtonId === id ? null : id;
    if (this.activeButtonId?.includes('-a')) {
      this.showInputASummary = true;
      this.showInputBSummary = false;
      this.summaryText = 'Summary - A';
      this.summaryType = 'A';
    } else if (this.activeButtonId?.includes('-b')) {
      this.showInputBSummary = true;
      this.showInputASummary = false;
      this.summaryText = 'Summary - B';
      this.summaryType = 'B';
    } else {
      return;
    }
  }

  getButtonClasses(id: string) {
    if (this.activeButtonId === id) {
      return {
        'bg-white': true,
        'py-[7px]': true,
        'text-[#1D40AB]': true,
        'text-[#000000]': false,
      };
    } else {
      return {
        'bg-white': false,
        'py-[7px]': false,
        'text-[#1D40AB]': false,
        'text-[#7F7E7E]': true,
      };
    }
  }

  toggleInputA(summary: Summary) {
    this.showInputA = !this.showInputA;
    this.selectedInputASummary = this.showInputA ? summary : null;
    if (this.selectedInputASummary) {
      this.nominal_system_voltage =
        this.inputAResponse[this.selectedInputASummary!.value]?.[
          'nominal_system_voltage'
        ] ??
        this.mainResponse[this.selectedInputASummary!.value]?.['nominal_system_voltage'];
    }
    if (this.showInputA) {
      this.inputDropdownArrowSrc = 'assets/images/icons/up_arrow.svg';
      this.summaryText = 'Apartment Size';
      this.onInputAChange();
    } else {
      this.inputDropdownArrowSrc = 'assets/images/icons/down_arrow.svg';
      this.summaryText = 'Summary - A';
    }
    this.initializeHighChart();
  }

  onInputAChange() {
    const payload = {
       nominal_system_voltage : this.nominal_system_voltage,
   short_circuit_level : this.short_circuit_level,
   fault_withstand_time : this.fault_withstand_time,
   xlpe_cable_conductor : this.xlpe_cable_conductor,
   nearest_selected_cable_size : this.nearest_selected_cable_size,
    };

    this.apiService.post<any>('ht_cables', payload).subscribe(
      (response) => {
        this.inputAResponse = response;
        
        this.nominal_system_voltage = this.inputAResponse?.nominal_system_voltage ?? 0;
        this.short_circuit_level = this.inputAResponse?.short_circuit_level ?? 0;
        this.fault_withstand_time = this.inputAResponse?.fault_withstand_time ?? 0;
        this.xlpe_cable_conductor = this.inputAResponse?.xlpe_cable_conductor ?? 0;
        this.nearest_selected_cable_size = this.inputAResponse?.nearest_selected_cable_size ?? 0;      

        this.initializeHighChart();
        this.initializeBarChart();
      },
      (error) => {
        console.error('API Error:', error);
      },
    );

  }

  validateInputShouldNotBelessThanZero(data: number) {
    if (data < 0) {
      return 0;
    }
    return data;
  }

  toggleInputB(summary: Summary) {
    this.showInputB = !this.showInputB;
    this.selectedInputBSummary = this.showInputB ? summary : null;
    
    if (this.showInputB) {
      this.inputDropdownArrowSrc = 'assets/images/icons/up_arrow.svg';
      this.summaryText = '';
      
    } else {
      this.inputDropdownArrowSrc = 'assets/images/icons/down_arrow.svg';
      this.summaryText = 'Summary - B';
    }
    this.initializeHighChart();
  }

  
  
  
    





  submit() {
    const projectDetailsString = sessionStorage.getItem('PROJECTDETAILS');

    let projectName = '';
    let projectType = '';
    let documentVersion = '';
    let date = '';

    if (projectDetailsString) {
      const projectDetails = JSON.parse(projectDetailsString);
      projectName = projectDetails.queryParams.projectName;
      projectType = projectDetails.queryParams.projectType;
      documentVersion = projectDetails.queryParams.documentVersion;
      date = projectDetails.queryParams.date;
    }

    const payload = {
      project_name: projectName,
      project_type: projectType,
      document_version: documentVersion,
      project_date: date || '',

      project_id: documentVersion,
      sub_module_name: 'ht_cables',
    };
    // const url = `https://dev-designcalculus.bluealgo.com/reports_page`;
    // this.http.post(url, payload, {
    //   params: {isWithoutBase: 'yes'},
    //   responseType: 'text',
    // }).subscribe((response) => {
    //     window.location.href = url;
    //   }
    // );
    this.calculusCommonService.getReport(payload);
  }

  getInfo(buttonElement: HTMLElement) {
    this.calculusCommonService.openInfoPopUp(buttonElement, 'ht_cables');
  }
}
