import { Pipe, PipeTransform } from '@angular/core';

@Pipe({
    name: 'decimalFormat',
    standalone: false
})
export class DecimalFormatPipe implements PipeTransform {

  transform(value: any, digits: number = 2): string | any {
    const parsed = Number(value);

    // Check if value is a number or can be converted to number
    if (!isNaN(parsed)) {
      // If it's an integer (no decimal part), return as is
      if (Number.isInteger(parsed)) {
        return parsed.toString(); // keep as original integer
      }

      // If has decimal, format to fixed digits
      return parsed.toFixed(digits);
    }

    // If not a number, return original
    return value;
  }
}
