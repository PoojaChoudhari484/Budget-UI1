import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { ModuleService } from 'src/app/services/module.service';

@Component({
    selector: 'app-electrical-sub-page',
    templateUrl: './electrical-sub-page.component.html',
    styleUrls: ['./electrical-sub-page.component.scss'],
    standalone: false
})
export class ElectricalSubPageComponent {
  modules: string[] = [
    'Residential Load Sheets',
    'Commercial Load Sheets',
    'kVAR',
    'HT Cables',
    'HSD',
    'UPS',
    'Busduct',
    "VD and SC"
  ];

  constructor(
    private router: Router,
    private moduleService: ModuleService,
  ) {}

  ngOnInit(): void {
  }

  goTo(module: string) {
    this.moduleService.updateSelectedSubModule(module);
    const moduleRouteMap: { [key: string]: string } = {
      'Residential Load Sheets': '/electrical/load-sheets',
      'Commercial Load Sheets': '/electrical/commercial-load-sheets',
      'kVAR': '/electrical/kvar',
      'HT Cables': '/electrical/ht-cables',
      'HSD': '/electrical/hsd',
      'UPS': '/electrical/ups',
      'Busduct': '/electrical/busduct',
      "VD and SC":'/electrical/vd'
    };
     this.router.navigate([moduleRouteMap[module]], 
  JSON.parse(sessionStorage.getItem('PROJECTDETAILS') || '{}')
     );
  }
}
