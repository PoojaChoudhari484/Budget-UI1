import { ComponentFixture, TestBed } from '@angular/core/testing';

import { ElectricalSubPageComponent } from './electrical-sub-page.component';

describe('ElectricalSubPageComponent', () => {
  let component: ElectricalSubPageComponent;
  let fixture: ComponentFixture<ElectricalSubPageComponent>;

  beforeEach(() => {
    TestBed.configureTestingModule({
      declarations: [ElectricalSubPageComponent]
    });
    fixture = TestBed.createComponent(ElectricalSubPageComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
