import {Component, EventEmitter, OnInit, Output} from '@angular/core';
import {LocalApiService} from "../../core/services/local-api.service";
import {CalculusCommonService} from "../../core/services/calculus-common.service";
import {ActivatedRoute} from "@angular/router";

@Component({
    selector: 'app-ups',
    templateUrl: './ups.component.html',
    styleUrls: ['./ups.component.scss'],
    standalone: false
})
export class UpsComponent implements OnInit {

  @Output() moveToTab = new EventEmitter<string>();
  projectName: string = '';
  projectType: string = '';
  documentVersion: string = '';
  date: string = '';
  public types: string[] = [];
  public activeTab: string = 'emergency-lighting';

  constructor(private activatedRoute: ActivatedRoute) {}

  ngOnInit(): void {
    this.activatedRoute.queryParams.subscribe((params) => {
      this.projectName = params['projectName'];
      this.projectType = params['projectType'];
      this.documentVersion = params['documentVersion'];
      this.date = params['date'];
    });
  }

  setActiveTab(tab: string): void {
    this.activeTab = tab;
  }

}
