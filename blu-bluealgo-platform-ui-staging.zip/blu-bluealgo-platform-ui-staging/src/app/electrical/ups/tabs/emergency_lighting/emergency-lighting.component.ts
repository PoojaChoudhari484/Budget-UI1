import {Component, EventEmitter, OnInit, Output} from '@angular/core';
import { InputSummary } from 'src/app/shared/entities/input-summary';
import { LocalApiService } from 'src/app/core/services/local-api.service';
import { CalculusCommonService } from 'src/app/core/services/calculus-common.service';


export interface Payload {
  "description": string,
  "cl": number,
  "diversity": number,
  
    


  "isNew"?: boolean
}

@Component({
    selector: 'app-emergency-lighting',
    templateUrl: './emergency-lighting.component.html',
    styleUrls: ['./emergency-lighting.component.scss'],
    standalone: false
})
export class EmergencyLightingComponent implements OnInit {

  inputSummaries: InputSummary[] = [];
  selectedInputSummary: any | null = null;
  showInput = false;
  @Output() moveToTab = new EventEmitter<string>();
  inputDropdownArrowSrc = 'assets/images/icons/down_arrow.svg';
  summaryResponse: any = {};
  payload: Payload;
  description: string = '$new'

  constructor(
    private apiService: LocalApiService,
    private calculusCommonService: CalculusCommonService,
  ) {
  }

  ngOnInit(): void {
    this.getRetailResponse();
  }

  getRetailResponse() {
    this.apiService.post('ups_emergency_lighting', {}).subscribe(res => {
      console.log(res);
      this.summaryResponse = res;
      this.collectInputSummary();
    })
  }
deleteSummaryItem(item: any) {
    this.toggleInput(item);
    this.apiService.post('delete_ups_emergency_lighting', item).subscribe((res: any) => {
      this.summaryResponse = res;
      
      this.collectInputSummary();

    })
  }
  collectInputSummary() {
    this.inputSummaries = [];
    if (this.summaryResponse?.data?.length > 0) {
      this.summaryResponse?.data?.forEach((retail: any, i: number) => {
        let inputSummary: InputSummary = new InputSummary(retail.description, '',
          'assets/images/icons/enterprise.svg', true);
        this.inputSummaries.push(inputSummary);
      })
    }
  }

  toggleInput(summary: any) {
    this.showInput = !this.showInput;
    this.selectedInputSummary = this.showInput ? summary : null;
    if (this.showInput) {
      this.inputDropdownArrowSrc = 'assets/images/icons/up_arrow.svg';
    } else {
      this.summaryResponse.data = this.summaryResponse.data?.filter((s: any) => !s.isNew);
      this.inputDropdownArrowSrc = 'assets/images/icons/down_arrow.svg';
    }
    this.initInputObj();
  }

  initInputObj() {
    let findObj: any = this.summaryResponse?.data?.find((f: any) => f?.description === this.selectedInputSummary?.name);

    if (findObj) {
      if (findObj.description === this.description) findObj.description = '';
      this.payload = {
        description: findObj?.description ?? '',
        cl: findObj?.cl ?? 0,
        diversity: findObj?.diversity ?? 0,
        
      }
    }
  }

  addMore() {
    let newObj: Payload = {
      description: this.description,
      cl: 0,
      diversity: 0,
      isNew: true
    }
    this.summaryResponse.data.push(newObj);
    this.toggleInput({name: this.description})
  }

  onInputChange() {
    this.apiService.post('ups_emergency_lighting', this.payload).subscribe((res: any) => {
      this.summaryResponse = res;
      this.collectInputSummary();
    })
  }

  getInfo(buttonElement: HTMLElement) {
    this.calculusCommonService.openInfoPopUp(buttonElement, 'phe_summary');
  }

}
