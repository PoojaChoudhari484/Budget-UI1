import {Component, OnInit, ViewChild} from '@angular/core';
import {LocalApiService} from "../../core/services/local-api.service";
import {
  CommercialTypicalCorridorComponent
} from "./options/commercial-typical-corridor/commercial-typical-corridor.component";
import {CommercialFfComponent} from "./options/commercial-ff/commercial-ff.component";
import {CommercialStairComponent} from "./options/commercial-stair/commercial-stair.component";
import {RetailStairComponent} from "./options/retail-stair/retail-stair.component";
import { RetailLoadComponent } from './options/retail-load/retail-load.component';
import {NtaStairAndRampComponent} from "./options/nta-stair-and-ramp/nta-stair-and-ramp.component";
import {TaStairComponent} from "./options/ta-stair/ta-stair.component";
import {TaTypicalRefugeFloorComponent} from "./options/ta-typical-refuge-floor/ta-typical-refuge-floor.component";
import {TaGfAndPodiumComponent} from "./options/ta-gf-and-podium/ta-gf-and-podium.component";
import {NtaBasementGfAndPodiumComponent} from "./options/nta-basement-gf-and-podium/nta-basement-gf-and-podium.component";
import {
  CommercialAndRetailBasementsComponent
} from "./options/commercial-and-retail-basements/commercial-and-retail-basements.component";
import {TaTypicalFloorCorridorComponent} from "./options/ta-typical-floor-corridor/ta-typical-floor-corridor.component";
import {PheCommercialComponent} from "./options/phe-commercial/phe-commercial.component";
import {RetailPheComponent} from "./options/retail-phe/retail-phe.component";
import {PheResidentialComponent} from "./options/phe-residential/phe-residential.component";
import {ApartmentLoadDetailsComponent} from "./options/apartment-load-details/apartment-load-details.component";
import {ResidentialFfLoadComponent} from "./options/residential-ff-load/residential-ff-load.component";
import {T1SummaryComponent} from "./options/t1-summary/t1-summary.component";
import {FpElectricalLoadComponent} from "../commercial-load-sheets/options/fp-electrical-load/fp-electrical-load.component";
import {CoolingTowerComponent} from "../commercial-load-sheets/options/cooling-tower/cooling-tower.component";
import { ApartmentPointsComponent } from './options/apartment-points/apartment-points.component';
import { ElectricalPheSummaryComponent } from './options/electrical-phe-summary/electrical-phe-summary.component';
import { ElectricalFirefighterSummaryComponent } from './options/electrical-firefighter-summary/electrical-firefighter-summary.component';
import { ElectricalHvacSummaryComponent } from './options/electrical-hvac-summary/electrical-hvac-summary.component';
import { RetailSummaryComponent } from './options/retail-summary/retail-summary.component';
import { MainSummaryComponent} from './options/main-summary/main-summary.component';
import { ClubhouseComponent } from './options/clubhouse/clubhouse.component';
import { View } from '@ckeditor/ckeditor5-engine';
import { CalculusCommonService } from 'src/app/core/services/calculus-common.service';
@Component({
    selector: 'app-load-sheets',
    templateUrl: './load-sheets.component.html',
    styleUrls: ['./load-sheets.component.scss'],
    standalone: false
})
export class LoadSheetsComponent implements OnInit {

  @ViewChild(CommercialTypicalCorridorComponent) commercialTypicalCorridor: CommercialTypicalCorridorComponent;
  @ViewChild(CommercialFfComponent) commercialFF: CommercialFfComponent;
  @ViewChild(CommercialStairComponent) commercialStair: CommercialStairComponent;
  @ViewChild(RetailStairComponent) retailStair: RetailStairComponent;
  @ViewChild(RetailLoadComponent) retailLoad: RetailLoadComponent;
  @ViewChild(NtaStairAndRampComponent) ntaStairAndRamp: NtaStairAndRampComponent;
  @ViewChild(TaStairComponent) taStair: TaStairComponent;
  @ViewChild(TaTypicalRefugeFloorComponent) taTypicalRefugeFloor: TaTypicalRefugeFloorComponent;
  @ViewChild(TaGfAndPodiumComponent) taGfAndPodium: TaGfAndPodiumComponent;
  @ViewChild(NtaBasementGfAndPodiumComponent) NtaBasementGfAndPodium: NtaBasementGfAndPodiumComponent;
  @ViewChild(CommercialAndRetailBasementsComponent) commercialAndRetailBasements: CommercialAndRetailBasementsComponent;
  @ViewChild(TaTypicalFloorCorridorComponent) taTypicalFloorCorridor: TaTypicalFloorCorridorComponent;
  @ViewChild(PheCommercialComponent) pheCommercial: PheCommercialComponent;
  @ViewChild(RetailPheComponent) retailPhe: RetailPheComponent;
  @ViewChild(PheResidentialComponent) pheResidential: PheResidentialComponent;
  @ViewChild(ApartmentLoadDetailsComponent) apartmentLoadDetails: ApartmentLoadDetailsComponent;
  @ViewChild(ResidentialFfLoadComponent) residentialFfLoad: ResidentialFfLoadComponent;
  @ViewChild(T1SummaryComponent) t1Summary: T1SummaryComponent;
  @ViewChild(ApartmentPointsComponent) apartmentPoints: ApartmentPointsComponent;
  @ViewChild(ElectricalPheSummaryComponent) electricalPheSummary: ElectricalPheSummaryComponent;
  @ViewChild(ElectricalFirefighterSummaryComponent) electricalFirefighterSummary: ElectricalFirefighterSummaryComponent;
  @ViewChild(ElectricalHvacSummaryComponent) electricalHvacSummary: ElectricalHvacSummaryComponent;
  @ViewChild(RetailSummaryComponent) retailSummary: RetailSummaryComponent;
  @ViewChild(MainSummaryComponent) mainSummary: MainSummaryComponent;
  @ViewChild(ClubhouseComponent) clubhouse: ClubhouseComponent;

  activeOption: any = 'retail_stair';
  response: any = {};
tower: 'T1';


  constructor(
    private apiService: LocalApiService,
    private calculusCommonService: CalculusCommonService
  ) {
  }

  ngOnInit(): void {
    this.getResponse();
    
    
  }

  getResponse() {
    this.response = {};
    let payload= {tower:this.tower};
    if (this.activeOption === 'apartment_load_details') {
      payload = {tower:this.tower}
    }
    this.apiService.post<any>(this.activeOption, payload).subscribe(response => {
      this.response = response;
      this.tower = response.tower;
      
      console.log(response);
    })
  }

  generatePayload() {
    let firstKey: string = '';
    let secondKey: string = '';
    let componentResponse: any = {};

    if (this.activeOption === 'commercial_phe_load') {
      firstKey = 'plumbing_pumps';
      secondKey = 'equipments';
      componentResponse = this.pheCommercial?.response;
    } else if (this.activeOption === 'retail_phe_load') {
      firstKey = 'plumbing_pumps';
      secondKey = 'equipments';
      componentResponse = this.retailPhe?.response;
    } else if (this.activeOption === 'residential_phe_load') {
      firstKey = 'plumbing_pumps';
      secondKey = 'equipments';
      componentResponse = this.pheResidential?.response;
    } else if (this.activeOption === 'residential_ff_load') {
      firstKey = 'pumps_t1_to_t3';
      secondKey = 'pumps_t4_to_t6';
      componentResponse = this.residentialFfLoad?.response;
    }

    const transform = (arr: any[] = []) => arr.map((item: any) => ({
      type: item.type,
      location: item.location,
      quantity_working: item.quantity_working,
      quantity_standby: item.quantity_standby,
      discharge: item.discharge,
      head: item.head,
      kw_per_pump: item.kw_per_pump,
      hp_per_pump: item.hp_per_pump
    }));

    return {
      [firstKey]: transform(componentResponse?.[firstKey]),
      [secondKey]: transform(componentResponse?.[secondKey])
    };
  }

  submit() {
    let payload = {};
    if (this.activeOption === 'commercial_ff_load') payload = this.commercialFF.response;
    else if (this.activeOption === 'commercial_typical_corridor') payload = this.commercialTypicalCorridor.response;
    else if (this.activeOption === 'commercial_stair') payload = this.commercialStair.response;
    else if (this.activeOption === 'retail_stair') payload = this.retailStair.response;
     else if (this.activeOption === 'retail_load') payload = this.retailLoad.response;
    else if (this.activeOption === 'nta_stair_and_ramp') payload = this.ntaStairAndRamp.response;
    else if (this.activeOption === 'ta_stair') payload = this.taStair.response;
    else if (this.activeOption === 'ta_typical_refuge_floor') payload = this.taTypicalRefugeFloor.response;
    else if (this.activeOption === 'ta_gf_and_podium') payload = this.taGfAndPodium.response;
    else if (this.activeOption === 'nta_basement_gf_and_podium') payload = this.NtaBasementGfAndPodium.response;
    else if (this.activeOption === 'clubhouse') payload = this.clubhouse.response;
    else if (this.activeOption === 'commercial_and_retail_basements') payload = this.commercialAndRetailBasements.response;
    else if (this.activeOption === 'ta_typical_floor_corridor') payload = this.taTypicalFloorCorridor.response;
    else if (this.activeOption === 'commercial_phe_load') payload = this.generatePayload();
    else if (this.activeOption === 'retail_phe_load') payload = this.generatePayload();
    else if (this.activeOption === 'residential_phe_load') payload = this.generatePayload();
    else if (this.activeOption === 'apartment_load_details') payload = this.apartmentLoadDetails.response;
    else if (this.activeOption === 'residential_ff_load') payload = this.generatePayload();
    else if (this.activeOption === 't1_summary') payload = this.t1Summary.setPayload();
    else if (this.activeOption === 'retail_summary') payload = this.retailSummary.response;
    else if (this.activeOption === 'main_summary') payload = this.mainSummary.response;
    else if (this.activeOption === 'apartment_points') payload = this.apartmentPoints.response;
    else if (this.activeOption === 'electrical_phe_summary') payload = this.electricalPheSummary.response;
    else if (this.activeOption === 'electrical_firefighter_summary') payload = this.electricalFirefighterSummary.response;
    else if (this.activeOption === 'electrical_hvac_summary') payload = this.electricalHvacSummary.response;
    console.log(payload);
    payload = { ...payload, tower: this.tower };
       this.apiService.post<any>(this.activeOption, payload).subscribe(response => {
      this.response = response;
      console.log(response);
    })
  }
  get_summary() {
    const projectDetailsString = sessionStorage.getItem('PROJECTDETAILS');

    let projectName = '';
    let projectType = '';
    let documentVersion = '';
    let date = '';

    if (projectDetailsString) {
      const projectDetails = JSON.parse(projectDetailsString);
      projectName = projectDetails.queryParams.projectName;
      projectType = projectDetails.queryParams.projectType;
      documentVersion = projectDetails.queryParams.documentVersion;
      date = projectDetails.queryParams.date;
    }

    const payload = {
      project_name: projectName,
      project_type: projectType,
      document_version: documentVersion,
      
      sub_module_name: 'electrical_load_sheets',
    }

    this.calculusCommonService.getReport(payload);
  }

}
