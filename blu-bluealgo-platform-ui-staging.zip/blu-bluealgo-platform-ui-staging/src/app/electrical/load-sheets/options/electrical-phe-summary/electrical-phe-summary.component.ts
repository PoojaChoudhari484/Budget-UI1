import { Component, Input, Output, EventEmitter } from '@angular/core';

@Component({
    selector: 'app-electrical-phe-summary',
    templateUrl: './electrical-phe-summary.component.html',
    styleUrls: ['./electrical-phe-summary.component.scss'],
    standalone: false
})
export class ElectricalPheSummaryComponent {
  @Input() response: any = {};
  @Output() responseChange = new EventEmitter<any>();

 onUpdate() {
    
    
    return this.responseChange.emit(this.response);
  } 
}
