import { Component, Input } from '@angular/core';

@Component({
    selector: 'app-residential-ff-load',
    templateUrl: './residential-ff-load.component.html',
    styleUrls: ['./residential-ff-load.component.scss'],
    standalone: false
})
export class ResidentialFfLoadComponent {
  @Input() response: any = {};
  panelOpenState: boolean = false;
}
