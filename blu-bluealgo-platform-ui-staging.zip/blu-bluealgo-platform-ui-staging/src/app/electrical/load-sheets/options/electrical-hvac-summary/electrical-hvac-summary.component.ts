import { Component, Input, Output, EventEmitter } from '@angular/core';

@Component({
    selector: 'app-electrical-hvac-summary',
    templateUrl: './electrical-hvac-summary.component.html',
    styleUrls: ['./electrical-hvac-summary.component.scss'],
    standalone: false
})
export class ElectricalHvacSummaryComponent {
  @Input() response: any = {};
  @Output() responseChange = new EventEmitter<any>();

 onUpdate() {
    
    
    return this.responseChange.emit(this.response);
  } 
}
