import { Component, Input} from '@angular/core';



@Component({
    selector: 'app-apartment-load-details',
    templateUrl: './apartment-load-details.component.html',
    styleUrls: ['./apartment-load-details.component.scss'],
    standalone: false
})
export class ApartmentLoadDetailsComponent{
  @Input() response: any = {};
 

  tableDataPairList: any [] = [
    {header: 'Description', key: 'description', input: true},
    {header: 'Floor', key: 'floor', input: true},
    {header: 'Unit', key: 'unit', input: true},
    {header: 'Unit Carpet Area (sqm)', key: 'unit_carpet_area_sqm', input: true},
    {header: 'Unit Carpet Area (sqft)', key: 'unit_carpet_area_sqft', input: false},
    {header: 'Apartment Quantity', key: 'apartment_quantity', input: false},
    {header: 'As per MSEDCL 75w/sqm', key: 'as_per_MSEDCL_72w_per_sqm', input: false},
    {header: 'Connected Load (kw)', key: 'connected_load_kw', input: false},
    {header: 'Diversity Factor', key: 'diversity_factor', input: false},
    {header: 'Demand Load (kw)', key: 'demand_load_in_kw', input: false},
  ];
  protected readonly isNaN = isNaN;
  add_more() {
  // Ensure response and table_data exist
  if (!this.response) {
    this.response = {};
  }

  if (!Array.isArray(this.response.table_data)) {
    this.response.table_data = [];
  }

  // Add new item
  if (this.response.table_data.length > 0) {
    const lastItem = this.response.table_data[this.response.table_data.length - 1];
    this.response.table_data.push({ ...lastItem });
  } else {
    this.response.table_data.push({
      "apartment_quantity": 0,
      "as_per_MSEDCL_72w_per_sqm": 0,
      "connected_load_kw": 0,
      "demand_load_in_kw": 0,
      "description": "",
      "diversity_factor": 2,
      "floor": 0,
      "unit": 0,
      "unit_carpet_area_sqft": 0,
      "unit_carpet_area_sqm": 0
    });
  }
}

remove(index: number) {
    
      this.response.table_data.splice(index, 1);
    
  }
make_totals(key: any) {
  let total = 0;

  for (let row of this.response.table_data) {
    if (row[key] !== undefined && !isNaN(row[key])) {
      total += Number(row[key]);
    }
  }

  return total;
}

}

