import { Component, Input } from '@angular/core';

@Component({
    selector: 'app-retail-stair',
    templateUrl: './retail-stair.component.html',
    styleUrls: ['./retail-stair.component.scss'],
    standalone: false
})
export class RetailStairComponent {
  @Input() response: any = {};

  tableDataPairList: any [] = [
    {header: 'Area (Nos)', key: 'area', input: true},
    {header: 'No of Floors (Nos)', key: 'no_floors', input: true}, 
    {header: 'No of Staircases (W)', key: 'no_staircases', input: true},
    {header: 'Light Fixture Wattage (kW)', key: 'light_fixture_wattage', input: false},
    {header: 'Connected Load (kW)', key: 'connected_load', input: false},
    {header: 'DF (kW)', key: 'd_f', input: true},
    {header: 'Demand Load (kW)', key: 'demand_load', input: false},
    {header: 'Emergency Load (kW)', key: 'emergency_load', input: false},
  ];
  protected readonly isNaN = isNaN;

  add_more() {
    try {
      if (!this.response.table_data) {
        this.response.table_data = [];
      }
    } catch (e) {
      this.response.table_data = [];
    }
    if (this.response.table_data.length > 0) {
        const lastItem = this.response.table_data[this.response.table_data.length - 1];
        this.response.table_data.push({...lastItem});
      }
      else {
      this.response.table_data = [{
        "area": "",
        "connected_load": 0,
        "d_f": 1,
        "demand_load": 0,
        "emergency_load": 0,
        "light_fixture_wattage": 0,
        "no_floors": 0,
        "no_staircases": 0
      }];
    }
  }
  remove(index: number) {
    
      this.response.table_data.splice(index, 1);
    
  }
}
