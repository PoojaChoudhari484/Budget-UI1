import {Component, Input} from '@angular/core';

@Component({
  selector: 'app-cooling-tower',
  templateUrl: './cooling-tower.component.html',
  styleUrls: ['./cooling-tower.component.scss']
})
export class CoolingTowerComponent {

  @Input() response: any = {};

}
