import { Component, Input } from '@angular/core';

@Component({
    selector: 'app-ta-gf-and-podium',
    templateUrl: './ta-gf-and-podium.component.html',
    styleUrls: ['./ta-gf-and-podium.component.scss'],
    standalone: false
})
export class TaGfAndPodiumComponent {
  @Input() response: any = {};

  tableDataPairList: any [] = [
    {header: 'Area', key: 'type', input: true},
    {header: 'Area (Sq.mtr)', key: 'area_m', input: true},
    {header: 'Area (Sq.ft)', key: 'area_ft', input: false},
    {header: 'Lightning (W/sqft)', key: 'lighting_w_sqft', input: false},
    {header: 'Power (W/sqft)', key: 'power_w_sqft', input: false},
    {header: 'Lightning (kw)', key: 'lighting_kw', input: false},
    {header: 'Power (kw)', key: 'power_kw', input: false},
    {header: 'Connected Load (kW)', key: 'connected_load', input: false},
    {header: 'DF', key: 'd_f', input: true},
    {header: 'Demand Load Lighting (kW)', key: 'demand_load_lighting', input: false},
    {header: 'Demand Load Power (kW)', key: 'demand_load_power', input: false},
    {header: 'Emergency Load On Inverter (kW)', key: 'emergency_load_on_inverter', input: false},
    {header: 'HVAC (kw)', key: 'hvac_kw', input: false},
    {header: 'HVAC W (sqft)', key: 'hvac_w_sqft', input: false},
  ];
  protected readonly isNaN = isNaN;
  add_more() {
    try {
      if (!this.response.table_data) {
        this.response.table_data = [];
      }
    } catch (e) {
      this.response.table_data = [];
    }
    if (this.response.table_data.length > 0) {
      const lastItem = this.response.table_data[this.response.table_data.length - 1];
      this.response.table_data.push({...lastItem});
    }
     else
    {
      this.response.table_data = [{
      "area_ft": 0,
      "area_m": "0",
      "connected_load": 0,
      "d_f": 0,
      "demand_load_lighting": 0,
      "demand_load_power": 0,
      "emergency_load_on_inverter": 0,
      "hvac_kw": 0,
      "hvac_w_sqft": 0,
      "lighting_kw": 0,
      "lighting_w_sqft": 0,
      "power_kw": 0,
      "power_w_sqft": 0,
      "type": ""
    }]
    }
  }



   remove(index: number) {
    
      this.response.table_data.splice(index, 1);
    
  }
}
