import { Component, Input } from '@angular/core';

@Component({
    selector: 'app-phe-commercial',
    templateUrl: './phe-commercial.component.html',
    styleUrls: ['./phe-commercial.component.scss'],
    standalone: false
})
export class PheCommercialComponent {
  @Input() response: any = {};
  panelOpenState: boolean = false;
  protected readonly isNaN = isNaN;

  equipmentsPairList: any [] = [
    {header: 'KW Actual Per Pump', key: 'kw_actual_per_pump', input: false},
    {header: 'HP Actual Per Pump', key: 'hp_actual_per_pump', input: false},
    {header: 'KW Total', key: 'kw_total', input: false},
    {header: 'HP Total', key: 'hp_total', input: false},
    {header: 'CL', key: 'cl', input: false},
    {header: 'RL', key: 'rl', input: false}
  ];

  plumbingPairList: any [] = [
    {header: 'Type', key: 'type', input: false},
    {header: 'Location', key: 'location', input: false},
    {header: 'Quantity Working', key: 'quantity_working', input: false},
    {header: 'Quantity Standby', key: 'quantity_standby', input: false},
    {header: 'Discharge', key: 'discharge', input: false},
    {header: 'Head', key: 'head', input: false},
    {header: 'KW Per pump', key: 'kw_per_pump', input: false},
    {header: 'HP Per Pump', key: 'hp_per_pump', input: false},
  ];
}
