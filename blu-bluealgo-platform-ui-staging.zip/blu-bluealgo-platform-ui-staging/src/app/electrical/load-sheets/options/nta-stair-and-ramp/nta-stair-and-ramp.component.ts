import { Component, Input } from '@angular/core';

@Component({
    selector: 'app-nta-stair-and-ramp',
    templateUrl: './nta-stair-and-ramp.component.html',
    styleUrls: ['./nta-stair-and-ramp.component.scss'],
    standalone: false
})
export class NtaStairAndRampComponent {
  @Input() response: any = {};

  tableDataPairList: any [] = [
    {header: 'Area', key: 'area', input: true},
    {header: 'No of Floors (Nos)', key: 'no_floors', input: true},
    {header: 'No of Staircases (Nos)', key: 'no_staircases', input: true},
    {header: 'Light Fixture Wattage (W)', key: 'light_fixture_wattage', input: false},
    {header: 'Connected Load (kW)', key: 'connected_load', input: false},
    {header: 'Demand Load (kW)', key: 'demand_load', input: false},
    {header: 'DF', key: 'd_f', input: true},
    {header: 'Emergency Load', key: 'emergency_load', input: false},
  ];
  protected readonly isNaN = isNaN;

  add_more() {
    if (this.response.table_data.length > 0) {
      const lastItem = this.response.table_data[this.response.table_data.length - 1];
      this.response.table_data.push({...lastItem});
    }
    else
    {
      this.response.table_data = [{
      "area": "",
      "connected_load": 0,
      "d_f": 1,
      "demand_load": 0,
      "emergency_load": 0,
      "light_fixture_wattage": 0,
      "no_floors": 0,
      "no_staircases": 0
    }]
    }
  }
  
  
  
   remove(index: number) {
    
      this.response.table_data.splice(index, 1);
    
  }
}
