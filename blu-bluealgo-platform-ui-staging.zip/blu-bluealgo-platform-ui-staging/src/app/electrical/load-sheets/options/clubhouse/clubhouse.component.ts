import { Component, Input } from '@angular/core';

@Component({
    selector: 'app-clubhouse',
    templateUrl: './clubhouse.component.html',
    styleUrls: ['./clubhouse.component.scss'],
    standalone: false
})
export class ClubhouseComponent {
  @Input() response: any = {};

  tableDataPairList: any [] = [
    {header: 'Area', key: 'type', input: true},
    {header: 'Area (m)', key: 'area_m', input: true},
    {header: 'Area (ft)', key: 'area_ft', input: false},
    {header: 'Lightning (W/sqft)', key: 'lighting_w_sqft', input: true},
    {header: 'Power (W/sqft)', key: 'power_w_sqft', input: true},
    {header: 'Lightning (kw)', key: 'lighting_kw', input: false},
    {header: 'Power (kw)', key: 'power_kw', input: false},
    {header: 'Total Load', key: 'total_load', input: false},
    
  ];
  tableDataPairList2: any [] = [
    {header: 'Area', key: 'type', input: true},
    {header: 'No. of Units', key: 'no', input: true},
    {header: 'Load Per Unit (kW)', key: 'load_per_unit', input: true},
    
    {header: 'Total Load (kW)', key: 'total_load', input: false},
    
    
    
    
  ];
  protected readonly isNaN = isNaN;
  add_more() {
    if (this.response.table_data && this.response.table_data.length > 0) {
      const lastItem = this.response.table_data[this.response.table_data.length - 1];
      this.response.table_data.push({...lastItem});
    }
    else {
    this.response.table_data = [{
      type: '',
      area_m:0 ,
      area_ft:0,
      lighting_w_sqft: 0, 
      power_w_sqft:0,
      lighting_kw: 0,
      power_kw: 0,
      total_load: 0, //
      
    }];
  }
  }



   remove(index: number) {
    
      this.response.table_data.splice(index, 1);
    
  }
 
add_more2() {
  if (this.response.table_data2 && this.response.table_data2.length > 0) {
    const lastItem = this.response.table_data2[this.response.table_data2.length - 1];
    this.response.table_data2.push({...lastItem});
  }
  else {
    this.response.table_data2 = [{
      type: '',
      no: 0,
      load_per_unit: 0, 
      total_load: 0,
      
    }];
  }
}
    



   remove2(index: number) {
    
      this.response.table_data2.splice(index, 1);
    
  }

}
