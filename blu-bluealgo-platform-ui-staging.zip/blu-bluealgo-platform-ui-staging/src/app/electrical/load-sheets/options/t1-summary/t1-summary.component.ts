import {Component, Input, OnChanges, SimpleChanges} from '@angular/core';
import { LoadSheetsComponent } from '../../load-sheets.component';

interface ElectricalData {
  connected_load_per_apartment_ltr: number;
  connected_load_per_apartment_msedcl: number;
  demand_load_per_apartment_ltr: number;
  demand_load_per_apartment_msedcl: number;
  no_of_apartment_meters: number;
  no_of_apartments: number;
  total_connected_apartment_load_ltr: number;
  total_connected_apartment_load_msedcl: number;
  total_demand_apartment_load_ltr: number;
  total_demand_apartment_load_msedcl: number;

  gross_connected_load_ltr: number;
  gross_connected_load_msedcl: number;
  gross_demand_load_ltr: number;
  gross_meters: number;
  gross_no_of_apartments: number;
}

interface CommonAreaInterface {
  connected_load: number;
  demand_factor: number;
  dg_backup_load_fire: number;
  dg_backup_load_normal: number;
  lighting_demand_load: number;
  no_of_floor: number;
  power_demand_load: number;
  no_of_lifts: number;
}

interface ApartmentResponse {
  [key: string]: any;
}

interface commonAreaResponse {
  [key: string]: any;
}

@Component({
    selector: 'app-t1-summary',
    templateUrl: './t1-summary.component.html',
    styleUrls: ['./t1-summary.component.scss'],
    standalone: false
})
export class T1SummaryComponent implements OnChanges {
  @Input() response: any = {};
  panelOpenState: boolean = false;
  panelOpenStateSub: boolean = false;
  estimated_electrical_apartment_load: ApartmentResponse;
  common_area_load: commonAreaResponse;
  hvac_load: commonAreaResponse;
  phe_load: commonAreaResponse;
  othersCommonLoad: commonAreaResponse;




  inputJson: any = {
    electrical_load_for_common_area: {
      common_area_load: {},
      phe_load: {},
      lift_load: {},
      misc_elv: {},
      misc:{},
    },
  };

  protected readonly isNaN = isNaN;
  estimatedPairList: any [] = [
    {header: 'No of Apartments', key: 'no_of_apartments', input: false},
    {header: 'Connected Load Per Apartment (LTR) (kw)', key: 'connected_load_per_apartment_ltr', input: false},
    {
      header: 'Connected Load Per Apartment (As per Utility Company) (kw)',
      key: 'connected_load_per_apartment_msedcl',
      input: false
    },
    {header: 'No of Apartment Meters', key: 'no_of_apartment_meters', input: false},
    {header: 'Demand Load Per Apartment (LTR)', key: 'demand_load_per_apartment_ltr', input: false},
    {
      header: 'Demand Load Per Apartment (As per Utility Company) (kw)',
      key: 'demand_load_per_apartment_msedcl',
      input: false
    },
    {header: 'Total Connected Apartment Load (LTR) (kw)', key: 'total_connected_apartment_load_ltr', input: false},
    {
      header: 'Total Connected Apartment Load (As per Utility Company) (kw)',
      key: 'total_connected_apartment_load_msedcl',
      input: false
    },
    {header: 'Total Demand Apartment Load (LTR) (kw)', key: 'total_demand_apartment_load_ltr', input: false},
    {
      header: 'Total Demand Apartment Load (As per Utility Company) (kw)',
      key: 'total_demand_apartment_load_msedcl',
      input: false
    },
  ];

  commonAreaTablePairList: any [] = [
    {header: 'No of Floor', key: 'no_of_floor', type: 'input'},
    {header: 'Connected Load (kW)', key: 'connected_load', type: 'static'},
    {header: 'Demand Factor', key: 'demand_factor', type: 'input'},
    {header: 'Lighting Demand Load (kW)', key: 'lighting_demand_load', type: 'static'},
    {header: 'Power Demand Load (kW)', key: 'power_demand_load', type: 'static'},
    {header: 'DG Backup Load Normal (kW)', key: 'dg_backup_load_normal', type: 'static'},
    {header: 'DG Backup Load Fire (kW)', key: 'dg_backup_load_fire', type: 'static'}
  ];

  electricalLoadTablePairList: any [] = [
    {header: 'No of Lifts', key: 'no_of_floor', input: false},
    {header: 'Connected Load (kW)', key: 'connected_load', input: false},
    {header: 'Demand Factor', key: 'demand_factor', input: true},
    {header: 'Lighting Demand Load (kW)', key: 'lighting_demand_load', input: false},
    {header: 'Power Demand Load (kW)', key: 'power_demand_load', input: false},
    {header: 'DG Backup Load Normal (kW)', key: 'dg_backup_load_normal', input: false},
    {header: 'DG Backup Load Fire (kW)', key: 'dg_backup_load_fire', input: false}
  ];

  othersTablePairList: any [] = [
    {header: 'No of Floor', key: 'no_of_floor', type: 'static'},
    {header: 'Connected Load (kW)', key: 'connected_load', type: 'static'},
    {header: 'Demand Factor', key: 'demand_factor', type: 'input'},
    {header: 'Lighting Demand Load (kW)', key: 'lighting_demand_load', type: 'static'},
    {header: 'Power Demand Load (kW)', key: 'power_demand_load', type: 'static'},
    {header: 'DG Backup Load Normal (kW)', key: 'dg_backup_load_normal', type: 'checkbox'},
    {header: 'DG Backup Load Fire (kW)', key: 'dg_backup_load_fire', type: 'checkbox'}
  ];

  constructor() {}




  ngOnChanges(changes: SimpleChanges): void {
    if (changes['response'] && this.response) {
      if (typeof this.response === 'string') {
        this.response = JSON.parse(this.response);
      }

      const electricalData = this.response?.electrical_load_for_common_area;

      if (electricalData && typeof electricalData === 'object') {
        const commonAreaLoad = electricalData.common_area_load;

        if (commonAreaLoad) {
          for (const [key, value] of Object.entries(commonAreaLoad)) {
            const typedValue = value as { no_of_floor: number };
            this.inputJson.electrical_load_for_common_area.common_area_load[
              key
              ] = {
              no_of_floor: typedValue.no_of_floor,
            };
          }
        }

        if (electricalData.lift_load) {
          const typedLift = electricalData.lift_load as {
            connected_load: number;
            no_of_lifts: number;
          };
          this.inputJson.electrical_load_for_common_area.lift_load = {
            connected_load: typedLift.connected_load,
            no_of_lifts: typedLift.no_of_lifts,
          };
        }

        if (electricalData.misc_elv) {
          const typedMisc = electricalData.misc_elv as {
            connected_load: number;

          };
          this.inputJson.electrical_load_for_common_area.misc_elv = {
            connected_load: typedMisc.connected_load,
          };
        }
      }

      this.estimated_electrical_apartment_load =
        this.response?.estimated_electrical_apartment_load;
      this.common_area_load =
        this.response?.electrical_load_for_common_area?.common_area_load;
      this.hvac_load =
        this.response?.electrical_load_for_common_area?.hvac_load;
      this.phe_load = this.response?.electrical_load_for_common_area?.phe_load;

      this.othersCommonLoad ??= {};
      this.othersCommonLoad['Fire Booster Load'] =
        this.response?.electrical_load_for_common_area?.fire_booster_load;
      this.othersCommonLoad['Lift Load'] =
        this.response?.electrical_load_for_common_area?.lift_load;
      this.othersCommonLoad['ELV Load'] =
        this.response?.electrical_load_for_common_area?.misc_elv;
        this.othersCommonLoad['Misc'] =
        this.response?.electrical_load_for_common_area?.misc;
    }
  }

  get electricalCommonAreaData(): Record<string, any> {
    return this.inputJson?.electrical_load_for_common_area ?? {};
  }

  dataField(values: any): Record<string, any> {
    if (values && typeof values === 'object') {
      return values;
    }
    return {};
  }

  getValue(obj: any, key: string): any {
    return obj?.[key];
  }

  setValue(obj: any, key: string, value: any): void {
    if (obj) {
      obj[key] = value;
    }
  }

  getTotalsEstApartLoad(key: string): any {
    let returnValue: number = 0;
    if (this.estimated_electrical_apartment_load) {
      for (const [_, value] of Object.entries(this.estimated_electrical_apartment_load)) {
        if (_ !== 'totals') {
          const val = value?.[key];
          if (val === undefined || isNaN(Number(val))) {
            return '';
          }
          returnValue += Number(val);
        }
      }
    }
    return returnValue;
  }

  getTotalsCommonAreaLoad(key: string): any {
    let returnValue: number = 0;
    if (this.common_area_load) {
      for (const [_, value] of Object.entries(this.common_area_load)) {
        const val = value?.[key];
        if (val === undefined || isNaN(Number(val))) {
          return '';
        }
        returnValue += Number(val);
      }
    }
    return returnValue;
  }

  getTotalsHvacLoad(key: string): any {
    let returnValue: number = 0;
    if (this.hvac_load) {
      for (const [_, value] of Object.entries(this.hvac_load)) {
        const val = value?.[key];
        if (val === undefined || isNaN(Number(val))) {
          return '';
        }
        returnValue += Number(val);
      }
    }
    return returnValue;
  }

  getTotalsPheLoad(key: string): any {
    let returnValue: number = 0;
    if (this.phe_load) {
      for (const [_, value] of Object.entries(this.phe_load)) {
        const val = value?.[key];
        if (val === undefined || isNaN(Number(val))) {
          return '';
        }
        returnValue += Number(val);
      }
    }

    return returnValue;
  }

  getTotalsOthers(key: string): any {

    let returnValue: number = 0;
    if (this.phe_load) {
      for (const [_, value] of Object.entries(this.othersCommonLoad)) {
        const val = value?.[key];
        if (val === undefined || isNaN(Number(val))) {
          return '';
        }
        returnValue += Number(val);
      }
    }
    return returnValue;
  }

  onCheckboxChange(event: Event, sourceValue: any, target: any, targetKey: string): void {
    const isChecked = (event.target as HTMLInputElement).checked;
    target[targetKey] = 0;
    if (isChecked) {
      target[targetKey] = sourceValue;
    }
  }

  setPayload(): any {
    this.response.electrical_load_for_common_area.common_area_load = this.common_area_load;
    this.response.electrical_load_for_common_area.hvac_load = this.hvac_load;
    this.response.electrical_load_for_common_area.phe_load = this.phe_load;
    this.response.electrical_load_for_common_area.lift_load = this.othersCommonLoad['Lift Load'];
    this.response.electrical_load_for_common_area.misc_elv = this.othersCommonLoad['ELV Load'];
    this.response.electrical_load_for_common_area.misc = this.othersCommonLoad['Misc'];
    return this.response;
  }

}
