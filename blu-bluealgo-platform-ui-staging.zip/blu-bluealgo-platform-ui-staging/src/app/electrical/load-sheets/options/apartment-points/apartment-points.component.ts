import { Component, Input, Output, EventEmitter } from '@angular/core';

@Component({
    selector: 'app-apartment-points',
    templateUrl: './apartment-points.component.html',
    styleUrls: ['./apartment-points.component.scss'],
    standalone: false
})
export class ApartmentPointsComponent {
  @Input() response: any = {};
  @Output() responseChange = new EventEmitter<any>();

  protected readonly isNaN = isNaN;
  tableDataPairList: any [] = [
    {header: 'Description', key: 'Description', input: false},
    {header: 'CEILING LIGHT', key: 'CEILING LIGHT', input: false},
    {header: 'WALL BRACKET', key: 'WALL BRACKET', input: false}, 
    {header: 'MIRROR LIGHT', key: 'MIRROR LIGHT', input: false},
    {header: 'CHANDILIER', key: 'CHANDILIER', input: false},
    {header: 'CEILING FAN', key: 'CEILING FAN', input: false},
    {header: 'USB + TYPE C POINT', key: 'USB + TYPE C POINT', input: false},
    {header: '6A SOCKET', key: '6A SOCKET', input: false},
    {header: '16A SOCKET', key: '16A SOCKET', input: false}, 
    {header: 'SPLIT AC(20A SOCKET)', key: 'SPLIT AC(20A SOCKET)', input: false},
    
    {header: '16A GEYSER SOCKET', key: '16A GEYSER SOCKET', input: false},
    {header: 'EXHAUST FAN', key: 'EXHAUST FAN', input: false},
    {header: 'BELL BUZZER', key: 'BELL BUZZER', input: false},
     {header: 'VDP', key: 'VDP', input: false},
    {header: 'TEL', key: 'TEL', input: false}, 
    {header: 'TV', key: 'TV', input: false},
    {header: 'DATA', key: 'DATA', input: false},
  ];
    
    tableDataPairList4: any [] = [
    {header: 'Description', key: 'Description', input: false},
    {header: 'CL', key: 'CL', input: false}, 
    {header: 'WL', key: 'WL', input: false},
    {header: 'ML', key: 'ML', input: false},
    {header: 'CH', key: 'CH', input: false},
    {header: 'FAN', key: 'FAN', input: false},
    {header: 'USB', key: 'USB', input: false},
    {header: '6A SSO', key: '6A SSO', input: false},
    {header: '16A SSO', key: '16A SSO', input: false},
    
    {header: 'IDU', key:'IDU',input: false},
    {header: 'ODU', key:'ODU',input: false},

    {header: 'GEYSER SSO', key: 'GEYSER SSO', input: false},
    {header: 'EX. FAN', key: 'EX. FAN', input: false},
    {header: 'BELL', key: 'BELL', input: false},
    
  ];


  onUpdate() {
    
    
    return this.responseChange.emit(this.response);
  }
}
