import { Component, Input } from '@angular/core';

@Component({
    selector: 'app-nta-basement-gf-and-podium',
    templateUrl: './nta-basement-gf-and-podium.component.html',
    styleUrls: ['./nta-basement-gf-and-podium.component.scss'],
    standalone: false
})
export class NtaBasementGfAndPodiumComponent {
  @Input() response: any = {};

  tableDataPairList: any [] = [
    {header: 'Area', key: 'type', input: true},
    {header: 'Area (Sq.mtr)', key: 'area_m', input: true},
    {header: 'Area (Sq.ft)', key: 'area_ft', input: false},
    {header: 'Lightning (W/sqft)', key: 'lighting_w_sqft', input: false},
    {header: 'Power (W/sqft)', key: 'power_w_sqft', input: false},
    {header: 'Lightning (kw)', key: 'lighting_kw', input: false},
    {header: 'Power (kw)', key: 'power_kw', input: false},
    {header: 'Connected Load (kW)', key: 'connected_load', input: false},
    {header: 'DF', key: 'd_f', input: true},
    {header: 'Demand Load Lighting (kW)', key: 'demand_load_lighting', input: false},
    {header: 'Demand Load Power (kW)', key: 'demand_load_power', input: false},
    {header: 'Emergency Load On Inverter (kW)', key: 'emergency_load_on_inverter', input: false},
    
  ];
  tableDataPairList2: any [] = [
    {header: 'Area', key: 'type', input: true},
    {header: 'No.', key: 'no', input: true},
    {header: 'Connected Load (kW)', key: 'connected_load', input: true},
    {header: 'Demand Factor', key: 'd_f', input: true},
    {header: 'Total Connected Load (kW)', key: 'total_connected_load', input: false},
    
    
    {header: 'Demand Load Power (kW)', key: 'demand_load_power', input: false},
    {header: 'Emergency Load On Inverter (kW)', key: 'emergency_load_on_inverter', input: false},
    
  ];
  protected readonly isNaN = isNaN;
  add_more() {
    try {
      if (!this.response.table_data) {
        this.response.table_data = [];
      }
    } catch (e) {
      this.response.table_data = [];
    }
    if (this.response.table_data.length > 0) {
      const lastItem = this.response.table_data[this.response.table_data.length - 1];
      this.response.table_data.push({...lastItem});
    }
    else {
    this.response.table_data = [{
      "area_ft": 0,
      "area_m": 0,
      "connected_load": 0,
      "d_f": 0,
      "demand_load_lighting": 0,
      "demand_load_power": 0,
      "emergency_load_on_inverter": 0,
      "hvac_kw": 0,
      "hvac_w_sqft": 0,
      "lighting_kw": 0,
      "lighting_w_sqft": 0,
      "power_kw": 0,
      "power_w_sqft": 0,
      "type": ""
    }];
  }
  }



   remove(index: number) {
    
      this.response.table_data.splice(index, 1);
    
  }
 
add_more2() {
  try {
    if (!this.response.table_data2) {
      this.response.table_data2 = [];
    }
  } catch (e) {
    this.response.table_data2 = [];
  }
  if (this.response.table_data2 && this.response.table_data2.length > 0) {
    const lastItem = this.response.table_data2[this.response.table_data2.length - 1];
    this.response.table_data2.push({...lastItem});
  }
  else {
    this.response.table_data2 = [{
      type: '',
      no: 0,
      connected_load: 0, 
      total_connected_load: 0,
      demand_load_power: 0,
      emergency_load_on_inverter: 0
    }];
  }
}
    



   remove2(index: number) {
    
      this.response.table_data2.splice(index, 1);
    
  }

}
