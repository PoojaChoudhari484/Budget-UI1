import { Component, Input, Output, EventEmitter } from '@angular/core';

@Component({
    selector: 'app-retail-summary',
    templateUrl: './retail-summary.component.html',
    styleUrls: ['./retail-summary.component.scss'],
    standalone: false
})
export class RetailSummaryComponent {
  @Input() response: any = {};
  @Output() responseChange = new EventEmitter<any>();

  protected readonly isNaN = isNaN;
  
  // Array to store the order of keys
   keyOrder: string[] = [
  'Sr.No.',
  'Description', 
  'No. of Floor',
  'Connected Load',
  'Demand Factor',
  'Lighting Demand Load',
  'Power Demand Load', 
  'DG Back up Load (Normal Mode)',
  'DG Back up Load (Fire Mode)'
];
keyOrder2: string[] = [
  'Sr.No.',
  'Description', 
  "Shop Area (sqm)",
    "Connected Load (kW)",
    "No of Retail meters"
  
];
 
getKeys(): string[] {
  if (this.response?.data?.length) {
    // Store key order if not already stored
    if (this.keyOrder.length === 0) {
      this.keyOrder = Object.keys(this.response.data[0]);
    }
    return this.keyOrder;
  }
  return [];
}

formatValue(value: any): string {
  if (value === null || value === undefined || value === '') {
    return '-';
  }
  return isNaN(value) ? value : parseFloat(value).toFixed(2);
}
  onUpdate() {
    return this.responseChange.emit(this.response);
  }
}
