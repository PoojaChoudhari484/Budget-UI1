import { Component, Input } from '@angular/core';

@Component({
    selector: 'app-retail-load',
    templateUrl: './retail-load.component.html',
    styleUrls: ['./retail-load.component.scss'],
    standalone: false
})
export class RetailLoadComponent {
  @Input() response: any = {};

  tableDataPairList: any [] = [
    {header: 'Description', key: 'description', input: true}, 
    {header: 'Area (sq.m )', key: 'area', input: true},
    {header: 'Units', key: 'units', input: true}, 
    {header: 'DF', key: 'demand_factor', input: true},
    {header: 'MSEDCL Watt per Sq.Mtr.', key: 'msedcl_watt', input: true},     
    {header: 'Connected Load (kW)', key: 'connected_load', input: false},
    
    
  ];
  protected readonly isNaN = isNaN;

  add_more() {
  if (this.response.table_data && this.response.table_data.length > 0) {
    const lastItem = this.response.table_data[this.response.table_data.length - 1];
    this.response.table_data.push({...lastItem});
  }
  else {
    this.response.table_data = [{
      "area": "",
      "connected_load": 0,
      "demand_factor": 0,
      "description": "Retail 1",
      "msedcl_watt": "0",
      "units": "0"
    }];
  }
}
  remove(index: number) {
    
      this.response.table_data.splice(index, 1);
    
  }
}
