import { Component, Input, Output, EventEmitter } from '@angular/core';

@Component({
    selector: 'app-electrical-firefighter-summary',
    templateUrl: './electrical-firefighter-summary.component.html',
    styleUrls: ['./electrical-firefighter-summary.component.scss'],
    standalone: false
})
export class ElectricalFirefighterSummaryComponent {
  @Input() response: any = {};
  @Output() responseChange = new EventEmitter<any>();

 onUpdate() {
    
    
    return this.responseChange.emit(this.response);
  } 
}
