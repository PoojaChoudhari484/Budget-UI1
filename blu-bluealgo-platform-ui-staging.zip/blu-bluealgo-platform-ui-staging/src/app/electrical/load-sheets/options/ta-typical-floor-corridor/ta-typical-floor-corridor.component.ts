import { Component, Input } from '@angular/core';

@Component({
    selector: 'app-ta-typical-floor-corridor',
    templateUrl: './ta-typical-floor-corridor.component.html',
    styleUrls: ['./ta-typical-floor-corridor.component.scss'],
    standalone: false
})
export class TaTypicalFloorCorridorComponent {
  @Input() response: any = {};

  tableDataPairList: any [] = [
    {header: 'Area', key: 'type', input: true},
    {header: 'Area (Sq.mtr)', key: 'area_m', input: true},
    {header: 'Area (Sq.ft)', key: 'area_ft', input: false},
    {header: 'Lightning (W/sqft)', key: 'lighting_w_sqft', input: false},
    {header: 'Power (W/sqft)', key: 'power_w_sqft', input: false},
    {header: 'Lightning (kw)', key: 'lighting_kw', input: false},
    {header: 'Power (kw)', key: 'power_kw', input: false},
    {header: 'Connected Load (kw)', key: 'connected_load', input: false},
    {header: 'DF', key: 'd_f', input: true},
    {header: 'Demand Load Lighting (kw)', key: 'demand_load_lighting', input: false},
    {header: 'Demand Load Power (kw)', key: 'demand_load_power', input: false},
    {header: 'Emergency Load On Inverter (kw)', key: 'emergency_load_on_inverter', input: false},
    {header: 'HVAC (kw)', key: 'hvac_kw', input: false},
    {header: 'HVAC W (sqft)', key: 'hvac_w_sqft', input: false},
  ];
  protected readonly isNaN = isNaN;
  add_more() {
    if (this.response.table_data.length > 0) {
      const lastItem = this.response.table_data[this.response.table_data.length - 1];
      this.response.table_data.push({...lastItem});
    }
    else {
    this.response.table_data = [{
      "area": "",
      "connected_load": 0,
      "d_f": 1,
      "demand_load": 0,
      "emergency_load": 0,
      "light_fixture_wattage": 0,
      "no_floors": 0,
      "no_staircases": 0
    }];
  }
  }



   remove(index: number) {
    
      this.response.table_data.splice(index, 1);
    
  }
}
