import { Component, EventEmitter, Input, Output } from '@angular/core';
import { valueOrDefault } from 'chart.js/helpers';

@Component({
    selector: 'app-commercial-typical-corridor',
    templateUrl: './commercial-typical-corridor.component.html',
    styleUrls: ['./commercial-typical-corridor.component.scss'],
    standalone: false
})
export class CommercialTypicalCorridorComponent {
  @Input() response: any = {};

  tableDataPairList: any [] = [
    {header: 'Description', key: 'type', input: false},
    {header: 'Area (m)', key: 'area_m', input: true},
    {header: 'Area (ft)', key: 'area_ft', input: false},
    {header: 'Lightning w (sqft)', key: 'lighting_w_sqft', input: false},
    {header: 'Power w (sqft)', key: 'power_w_sqft', input: false},
    {header: 'HVAC W (sqft)', key: 'hvac_w_sqft', input: false},
    {header: 'Lightning (kw)', key: 'lighting_kw', input: false},
    {header: 'Power (kw)', key: 'power_kw', input: false},
    {header: 'HVAC (kw)', key: 'hvac_kw', input: false},
    {header: 'Connected Load', key: 'connected_load', input: false},
    {header: 'DF', key: 'd_f', input: true},
    {header: 'Demand Load Lighting', key: 'demand_load_lighting', input: false},
    {header: 'Demand Load Power', key: 'demand_load_power', input: false},
    {header: 'Emergency Load On Inverter', key: 'emergency_load_on_inverter', input: false},
  ];
  protected readonly isNaN = isNaN;
}
