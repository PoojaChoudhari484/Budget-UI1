import { Component, Input } from '@angular/core';

@Component({
    selector: 'app-commercial-stair',
    templateUrl: './commercial-stair.component.html',
    styleUrls: ['./commercial-stair.component.scss'],
    standalone: false
})
export class CommercialStairComponent {
  @Input() response: any = {};

  tableDataPairList: any [] = [
    {header: 'Area', key: 'area', input: false},
    {header: 'No of Floors', key: 'no_floors', input: true},
    {header: 'No of Staircases', key: 'no_staircases', input: true},
    {header: 'Light Fixture Wattage', key: 'light_fixture_wattage', input: false},
    {header: 'Connected Load', key: 'connected_load', input: false},
    {header: 'DF', key: 'd_f', input: true},
    {header: 'Demand Load', key: 'demand_load', input: false},
    {header: 'Emergency Load', key: 'emergency_load', input: false},
  ];
  protected readonly isNaN = isNaN;
}
