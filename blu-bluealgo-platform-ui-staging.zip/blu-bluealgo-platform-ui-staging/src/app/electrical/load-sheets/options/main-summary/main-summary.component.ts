import { Component, Input, Output, EventEmitter } from '@angular/core';

@Component({
    selector: 'app-main-summary',
    templateUrl: './main-summary.component.html',
    styleUrls: ['./main-summary.component.scss'],
    standalone: false
})
export class MainSummaryComponent {

  @Input() response: any = {};
  @Output() responseChange = new EventEmitter<any>();

  protected readonly isNaN = isNaN;
  
  // Array to store the order of keys
  keyOrder: string[] = [
  'Sr.No.',
  'Description', 
  'No. of Floor',
  'Connected Load',
  'Demand Factor',
  'Lighting Demand Load',
  'Power Demand Load', 
  'DG Back up Load (Normal Mode)',
  'DG Back up Load (Fire Mode)'
];
keyOrder2: string[] = [
  "Sr.No.",
    "Description",
    "Total load to be sanctioned",
    "Load after DF",
    "Normal Mode",
    "Fire Mode"
  
];
 
getKeys(): string[] {
   {
      this.keyOrder = Object.keys(this.response);
    }
    return this.keyOrder;
  }
  


formatValue(value: any): string {
  if (value === null || value === undefined || value === '') {
    return '-';
  }
  return isNaN(value) ? value : parseFloat(value).toFixed(2);
}
  onUpdate() {
    return this.responseChange.emit(this.response);
  }
}
