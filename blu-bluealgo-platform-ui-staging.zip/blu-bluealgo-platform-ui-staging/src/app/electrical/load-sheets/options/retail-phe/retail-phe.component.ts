import { Component, Input } from '@angular/core';

@Component({
    selector: 'app-retail-phe',
    templateUrl: './retail-phe.component.html',
    styleUrls: ['./retail-phe.component.scss'],
    standalone: false
})
export class RetailPheComponent {
  @Input() response: any = {};
  panelOpenState: boolean = false;

  protected readonly isNaN = isNaN;
  tableDataPairList: any [] = [
    {header: 'KW Actual Per Pump', key: 'kw_actual_per_pump', input: false},
    {header: 'HP Actual Per Pump', key: 'hp_actual_per_pump', input: false},
    {header: 'KW Total', key: 'kw_total', input: false},
    {header: 'HP Total', key: 'hp_total', input: false},
    {header: 'CL', key: 'cl', input: false},
    {header: 'RL', key: 'rl', input: false}
  ];
}
