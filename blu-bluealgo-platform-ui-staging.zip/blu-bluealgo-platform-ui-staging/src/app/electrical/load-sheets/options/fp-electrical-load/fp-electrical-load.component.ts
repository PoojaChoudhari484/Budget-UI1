import {Component, Input} from '@angular/core';

@Component({
  selector: 'app-fp-electrical-load',
  templateUrl: './fp-electrical-load.component.html',
  styleUrls: ['./fp-electrical-load.component.scss']
})
export class FpElectricalLoadComponent {
  @Input() response: any = {};
  panelOpenState: boolean = false;
}
