import {AfterViewInit, Component, Input, OnInit} from '@angular/core';

@Component({
    selector: 'app-commercial-ff',
    templateUrl: './commercial-ff.component.html',
    styleUrls: ['./commercial-ff.component.scss'],
    standalone: false
})
export class CommercialFfComponent implements OnInit {
  @Input() response: any = {};

  tableDataPairList: any [] = [
    {header: 'Type', key: 'type', input: false},
    {header: 'Location', key: 'location', input: false},
    {header: 'Quantity Working', key: 'quantity_working', input: true},
    {header: 'Quantity Standby', key: 'quantity_standby', input: true},
    {header: 'Discharge', key: 'discharge', input: true},
    {header: 'Head', key: 'head', input: true},
    {header: 'Per Pump (kw)', key: 'per_pump_kw', input: true},
    {header: 'Per Pump (hp)', key: 'per_pump_hp', input: true},
    {header: 'Load', key: 'load', input: true}
  ];

  constructor() {}

  ngOnInit(): void {}

  protected readonly isNaN = isNaN;
}
