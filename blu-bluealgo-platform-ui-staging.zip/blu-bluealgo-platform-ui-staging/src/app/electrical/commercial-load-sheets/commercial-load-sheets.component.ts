import {Component, OnInit, ViewChild} from '@angular/core';
import {FpElectricalLoadComponent} from "./options/fp-electrical-load/fp-electrical-load.component";
import {CoolingTowerComponent} from "./options/cooling-tower/cooling-tower.component";
import {LocalApiService} from "../../core/services/local-api.service";
import {OfficeLoadComponent} from "./options/office-load/office-load.component";
import {PlElectricalLoadComponent} from "./options/pl-electrical-load/pl-electrical-load.component";
import {PrimaryPumpComponent} from "./options/primary-pump/primary-pump.component";
import {CommonLightingPowerComponent} from "./options/common-lighting-power/common-lighting-power.component";
import {SummaryCommercialLoadComponent} from "./options/summary-commercial-load/summary-commercial-load.component";
import { WaterCooledChillerComponent } from './options/water-cooled-chiller/water-cooled-chiller.component';
import { EquipmentsComponent } from './options/equipments/equipments.component';
import {CalculusCommonService} from "../../core/services/calculus-common.service";

@Component({
    selector: 'app-commercial-load-sheets',
    templateUrl: './commercial-load-sheets.component.html',
    styleUrls: ['./commercial-load-sheets.component.scss'],
    standalone: false
})
export class CommercialLoadSheetsComponent implements OnInit {

  @ViewChild(FpElectricalLoadComponent) fpElectricalLoad: FpElectricalLoadComponent;
  @ViewChild(CoolingTowerComponent) coolingTower: CoolingTowerComponent;
  @ViewChild(OfficeLoadComponent) officeLoad: OfficeLoadComponent;
  @ViewChild(PlElectricalLoadComponent) plElectricalLoad: PlElectricalLoadComponent;
  @ViewChild(PrimaryPumpComponent) primaryPump: PrimaryPumpComponent;
  @ViewChild(CommonLightingPowerComponent) commonLightingPower: CommonLightingPowerComponent;
  @ViewChild(SummaryCommercialLoadComponent) summaryCommercialLoad: SummaryCommercialLoadComponent;
  @ViewChild(WaterCooledChillerComponent) waterCooledChiller: WaterCooledChillerComponent;
  @ViewChild(EquipmentsComponent) equipments : EquipmentsComponent;
  

  activeOption: any = 'fp_electrical_load';
  response: any = {};

  constructor(
    private apiService: LocalApiService,
    private calculusCommonService: CalculusCommonService
  ) {
  }

  ngOnInit(): void {
    this.getResponse();
  }

  getResponse() {
    console.log('response')
    this.response = {};
    let payload: any = {};
    this.apiService.post<any>(this.activeOption, payload).subscribe(response => {
      this.response = response;
      console.log(response);
    })
  }

  submit() {
    let payload = {};
    if (this.activeOption === 'fp_electrical_load') payload = this.fpElectricalLoad.response;
    else if (this.activeOption === 'cooling_tower') payload = this.coolingTower.response;
    else if (this.activeOption === 'office_load') payload = this.officeLoad.response;
    else if (this.activeOption === 'pl_electrical_load') payload = this.plElectricalLoad.response;
    else if (this.activeOption === 'primary_pump') payload = this.primaryPump.response;
    else if (this.activeOption === 'water_cooled_chiller') payload = this.waterCooledChiller.response;
    else if (this.activeOption === 'common_lighting_power') payload = this.commonLightingPower.response;
    else if (this.activeOption === 'summary_commercial_load') payload = this.summaryCommercialLoad.response;
    else if (this.activeOption === 'equipments') payload = this.equipments.response;
    console.log(payload);

    this.apiService.post<any>(this.activeOption, payload).subscribe(response => {
      this.response = response;
    })
  }
   get_summary() {
    const projectDetailsString = sessionStorage.getItem('PROJECTDETAILS');

    let projectName = '';
    let projectType = '';
    let documentVersion = '';
    let date = '';

    if (projectDetailsString) {
      const projectDetails = JSON.parse(projectDetailsString);
      projectName = projectDetails.queryParams.projectName;
      projectType = projectDetails.queryParams.projectType;
      documentVersion = projectDetails.queryParams.documentVersion;
      date = projectDetails.queryParams.date;
    }

    const payload = {
      project_name: projectName,
      project_type: projectType,
      document_version: documentVersion,
      
      sub_module_name: 'electrical_commercial_load_sheets',
    }

    this.calculusCommonService.getReport(payload);
  }


}
