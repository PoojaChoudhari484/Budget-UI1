import { Component, Input } from '@angular/core';

@Component({
    selector: 'app-summary-commercial-load',
    templateUrl: './summary-commercial-load.component.html',
    styleUrls: ['./summary-commercial-load.component.scss'],
    standalone: false
})
export class SummaryCommercialLoadComponent {
  @Input() response: any = {};

  tableDataPairList: any [] = [
    {header: 'Description', key: 'description', input: true},
    
    {header: 'Diversity Factor', key: 'diversity_factor_normal', input: true},
    {header: 'Connected Load Normal(kW)', key: 'connected_load_kw_normal', input: true},
    {header: 'Maximum Demand Load Normal(kW)', key: 'max_demand_load_kw_normal', input: false},
    
    {header: 'Connected Load Mains Failure(kW)', key: 'connected_load_kw_main_failure', input: false},
    {header: 'Maximum Demand Load Mains Failure(kW)', key: 'max_demand_load_kw_main_failure', input: false},
    {header: 'Connected Load Fire(kW)', key: 'connected_load_kw_fire', input: false},
    {header: 'Maximum Demand Load Fire(kW)', key: 'max_demand_load_kw_fire', input: false},
    
    
  ];
 
  protected readonly isNaN = isNaN;
  add_more(maindata:any) {
    alert(maindata);
  if (this.response[maindata] && this.response[maindata].length > 0) {
      const lastItem = this.response[maindata][this.response[maindata].length - 1];
      this.response[maindata].push({...lastItem});
    }
    else {
    this.response.table_data2 = [{
      description: '',
      diversity_factor_normal: 0,
      connected_load_kw_normal: 0, 
      max_demand_load_kw_normal: 0,
      connected_load_kw_main_failure: 0, 
      max_demand_load_kw_main_failure: 0,
      connected_load_kw_fire: 0, 
      max_demand_load_kw_fire: 0,
      
    }];
  }
  }

getTotalForPair(maindata:any,key:any)
{
  let total = 0;
  if (this.response[maindata] && this.response[maindata].length > 0) {
    this.response[maindata].forEach((item:any) => {
      total += parseFloat(item[key]);
    });
  }
  return total;
}


   remove(index: number,maindata:any) {
    
    if (this.response[maindata].length > 1) {
      this.response[maindata].splice(index, 1);
    }
  }
 

    



}