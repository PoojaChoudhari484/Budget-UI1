import {Component, Input} from '@angular/core';

@Component({
    selector: 'app-equipments',
    templateUrl: './equipments.component.html',
    styleUrls: ['./equipments.component.scss'],
    standalone: false
})
export class EquipmentsComponent {

  @Input() response: any = {};

  tableDataPairList: any [] = [
    {header: 'Description', key: 'description', input: false},
    {header: 'Connected Load (kW)', key: 'connected_load', input: false},
    {header: 'Demand Load (kW)', key: 'demand_load', input: false},
    {header: 'Demand Load at Diversity 80%', key: 'demand_load_at_diversity_80', input: false},
    {header: 'Demand Load at Diversity 95%', key: 'demand_load_at_diversity_95', input: false}, 
    
    {header: 'Required Transformer Capacity', key: 'required_transformer_capacity', input: false},
    {header: 'Transformer Rating in KVA', key: 'transformer_rating', input: true},
    {header: 'Transformer Required', key: 'transformer_required', input: false},
    {header: 'Demand Load Mains Failure (kW)', key: 'demand_load_mains_failure', input: false},
    {header: 'Demand Load Fire (kW)', key: 'demand_load_fire', input: false},
    {header: 'Demand Load Power Factor 80%', key: 'demand_load_power_factor_80', input: false},
    {header: 'Required DG Capacity', key: 'required_dg_capacity', input: false},
    {header: 'DG Set Rating', key: 'dg_set_rating', input: true},
    {header: 'DG Required', key: 'dg_required', input: false},  ];
add_more() {
    if (this.response.data.length > 0) {
      const lastItem = this.response.data[this.response.data.length - 1];
      this.response.data.push({...lastItem});
    }
  }



   remove(index: number) {
    if (this.response.data.length > 1) {
      this.response.data.splice(index, 1);
    }
  }

  protected readonly isNaN = isNaN;
}
