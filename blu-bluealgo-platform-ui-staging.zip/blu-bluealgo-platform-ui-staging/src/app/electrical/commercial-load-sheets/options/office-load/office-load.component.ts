import {Component, Input} from '@angular/core';

@Component({
    selector: 'app-office-load',
    templateUrl: './office-load.component.html',
    styleUrls: ['./office-load.component.scss'],
    standalone: false
})
export class OfficeLoadComponent {
  @Input() response: any = {};

  tableDataPairList: any [] = [
    {header: 'SL', key: 'sl', input: false},
    {header: 'Floor', key: 'floor', input: true},
    {header: 'Area Description', key: 'area_description', input: true},
    {header: 'Carpet Area (Sq.Ft)', key: 'carpet_area_sqft', input: true},
    {header: 'VA/Sq.Ft', key: 'va_per_sqft', input: true},
    {header: 'W/Sq.Ft', key: 'w_per_sqft', input: false},
    {header: 'Total (KW)', key: 'total_kw', input: false},
    {header: 'DF', key: 'd_f', input: true},
    {header: 'DL (KW)', key: 'dl_kw', input: false},
  ];
  protected readonly isNaN = isNaN;
  add_more() {
    

    if (this.response.table_data.length > 0) {
      const lastItem = this.response.table_data[this.response.table_data.length - 1];
      this.response.table_data.push({...lastItem});
    }
  }



   remove(index: number) {
    if (this.response.table_data.length > 1) {
      this.response.table_data.splice(index, 1);
    }
  }

}
