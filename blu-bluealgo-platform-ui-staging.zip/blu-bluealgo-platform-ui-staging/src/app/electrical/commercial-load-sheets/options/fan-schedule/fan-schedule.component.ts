import {Component, Input} from '@angular/core';

@Component({
    selector: 'app-fan-schedule',
    templateUrl: './fan-schedule.component.html',
    styleUrls: ['./fan-schedule.component.scss'],
    standalone: false
})
export class FanScheduleComponent {
  @Input() response: any = {};
}
