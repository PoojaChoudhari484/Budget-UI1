import {Component, Input} from '@angular/core';

@Component({
    selector: 'app-fp-electrical-load',
    templateUrl: './fp-electrical-load.component.html',
    styleUrls: ['./fp-electrical-load.component.scss'],
    standalone: false
})
export class FpElectricalLoadComponent {
  @Input() response: any = {};
  panelOpenState: boolean = false;

  tableDataPairList: any [] = [
    {header: 'Description', key: 'type', input: false},
    {header: 'Flow (LPS)', key: 'flow', input: false},
    {header: 'Max Head (Meter)', key: 'max_head', input: false},
    {header: 'Calculated (HP)', key: 'calculated_hp', input: false},
    {header: 'Calculated (KW)', key: 'calculated_kw', input: false},
    {header: 'Selected (HP)', key: 'selected_hp', input: false},
    {header: 'Selected (KW)', key: 'selected_kw', input: false},
    {header: 'Working', key: 'working_quantity', input: false},
    {header: 'Standby', key: 'standby_quantity', input: false},
    {header: 'Connected Load (KW)', key: 'connected_load_kw', input: false},
    {header: 'Demand Load Normal (KW)', key: 'demand_load_kw_normal', input: true},
    {header: 'Demand Fire (KW)', key: 'demand_load_kw_fire', input: true},
  ];
  protected readonly isNaN = isNaN;
  shuffle_val(val:any,key:any,rep:any,indo:any)
  {

  
   if(val=true)
   {
    this.response['table_data'][indo][key] = rep;
    return rep
   }
   else
   {
    this.response['table_data'][indo][key] = 0;
    return 0
   }
  }
}
