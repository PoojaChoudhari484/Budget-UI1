import {Component, Input} from '@angular/core';

@Component({
    selector: 'app-pl-electrical-load',
    templateUrl: './pl-electrical-load.component.html',
    styleUrls: ['./pl-electrical-load.component.scss'],
    standalone: false
})
export class PlElectricalLoadComponent {
  @Input() response: any = {};
  panelOpenState: boolean = false;

  tableDataPairList: any [] = [
    {header: 'Description', key: 'Description', input: false},
    {header: 'Flow (LPS)', key: 'flow', input: false},
    {header: 'Max Head (Meter)', key: 'max_head', input: false},
    {header: 'Calculated (HP)', key: 'calculated_hp', input: false},
    {header: 'Calculated (KW)', key: 'calculated_kw', input: false},
    {header: 'Selected (HP)', key: 'selected_hp', input: false},
    {header: 'Selected (KW)', key: 'selected_kw', input: false},
    {header: 'Working', key: 'quantity_working', input: false},
    {header: 'Standby', key: 'quantity_standby', input: false},
    {header: 'Connected Load (KW)', key: 'connected_load_kw', input: false},
    {header: 'Demand Load (KW)', key: 'demand_load_kw', input: false}
  ];

  Misc_connected_load: number = 0;
  Misc_demand_load: number = 0;
  misc_list = ["OWC","WTP","STP","Misc"]
  protected readonly isNaN = isNaN;

}
