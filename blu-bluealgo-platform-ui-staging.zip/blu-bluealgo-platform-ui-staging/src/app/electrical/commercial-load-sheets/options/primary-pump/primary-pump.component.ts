import { Component, Input } from '@angular/core';

@Component({
    selector: 'app-primary-pump',
    templateUrl: './primary-pump.component.html',
    styleUrls: ['./primary-pump.component.scss'],
    standalone: false
})
export class PrimaryPumpComponent {
  @Input() response: any = {};

  tableDataPairList: any [] = [
    {header: 'Equipment Ref No', key: 'Description', input: true},
    {header: 'Quantity', key: 'quantity', input: true},
    {header: 'Water Flow Rate (GPM)', key: 'water_flow_rate', input: true},
    {header: 'Pump Head (Mtrs)', key: 'pump_head', input: true},
    {header: 'Maximum Speed (RPM)', key: 'maximum_speed', input: true},
    {header: 'Efficiency (%)', key: 'efficiency', input: true},
    {header: 'Breaking KW (kw)', key: 'breaking_kw', input: false},
    {header: 'Power (kW)', key: 'power', input: true},
    
    
  ];
  tableDataPairList2: any [] = [
    {header: 'Equipment Ref No', key: 'Description', input: true},
    {header: 'Quantity', key: 'quantity', input: true},
    {header: 'Water Flow Rate (GPM)', key: 'water_flow_rate', input: true},
    {header: 'Pump Head (Mtrs)', key: 'pump_head', input: true},
    {header: 'Maximum Speed (RPM)', key: 'maximum_speed', input: true},
    {header: 'Efficiency (%)', key: 'efficiency', input: true},
    {header: 'Breaking KW (kw)', key: 'breaking_kw', input: false},
    {header: 'Power (kW)', key: 'power', input: true},
    
  ];
  protected readonly isNaN = isNaN;
  add_more() {
    try {
      if (!this.response.primary_variable_chilled_water_pump) {
        this.response.primary_variable_chilled_water_pump = [];
      }
    } catch (error) {
      this.response.primary_variable_chilled_water_pump = [];
    }
    if (this.response.primary_variable_chilled_water_pump.length > 0) {
      const lastItem = this.response.primary_variable_chilled_water_pump[this.response.primary_variable_chilled_water_pump.length - 1];
      this.response.primary_variable_chilled_water_pump.push({...lastItem});
    }
    else {
    this.response.condenser_water_pump = [{
      "Description": "",
      "breaking_kw": 0,
      "effeciency": 0,
      "efficiency": "0",
      "electric_connection": "0",
      "location": "",
      "maximum_speed": "0",
      "pump_head": "0",
      "quantity": "1 Working",
      "speed_control": "Single",
      "starter_type": "Star Delta",
      "type": "Horizontal End Suction",
      "water_flow_rate": 0
    }];
  }
  }



   remove(index: number) {
    if (this.response.primary_variable_chilled_water_pump.length > 1) {
      this.response.primary_variable_chilled_water_pump.splice(index, 1);
    }
  }
 
add_more2() {
  try {
    if (!this.response.condenser_water_pump) {
      this.response.condenser_water_pump = [];
    }
  } catch (error) {
    this.response.condenser_water_pump = [];
  }
  if (this.response.condenser_water_pump && this.response.condenser_water_pump.length > 0) {
    const lastItem = this.response.condenser_water_pump[this.response.condenser_water_pump.length - 1];
    this.response.condenser_water_pump.push({...lastItem});
  }
  else {
    this.response.condenser_water_pump = [{
      "Description": "CWP-TF-01",
      "breaking_kw": 89.34177985920002,
      "effeciency": 0.75,
      "efficiency": "2",
      "electric_connection": "415/3/50",
      "location": "HVAC Plant Room-TF",
      "maximum_speed": "1463",
      "pump_head": "66",
      "quantity": "1 Working",
      "speed_control": "Single",
      "starter_type": "Star Delta",
      "type": "Horizontal End Suction",
      "water_flow_rate": 1350
    }];
  }
}
    



   remove2(index: number) {
    if (this.response.condenser_water_pump.length > 1) {
      this.response.condenser_water_pump.splice(index, 1);
    }
  }

}
