import {Component, Input} from '@angular/core';

@Component({
    selector: 'app-water-cooled-chiller',
    templateUrl: './water-cooled-chiller.component.html',
    styleUrls: ['./water-cooled-chiller.component.scss'],
    standalone: false
})
export class WaterCooledChillerComponent {
  @Input() response: any = {};
textInputs = ['equipment_ref_no', 'location', 'cooling_capacity_tr', 'quantity', 'type',  'refrigerant', 'evaporator_entering_water_temp_c', 'evaporator_leaving_water_temp_c', 'evaporator_flow_rate_gpm', 'evaporator_pressure_drop_mtrs', 'evaporator_fouling_factor', 'condenser_entering_water_temp_c', 'condenser_leaving_water_temp_c', 'condenser_flow_rate_gpm', 'condenser_pressure_drop_mtrs', 'condenser_fouling_factor', 'kw_per_unit', 'power_supply', 'remark'];
   tableDataPairList: any [] = [
    
{header: 'Equipment Ref No', key: 'equipment_ref_no', input: true},
{header: 'Location', key: 'location', input: true}, 
{header: 'Cooling Capacity (TR)', key: 'cooling_capacity_tr', input: true},
{header: 'Quantity (Nos.)', key: 'quantity', input: true},
{header: 'Type', key: 'type', input: true},
{header: 'IKW/TR', key: 'ikw_per_tr', input: true},
{header: 'Refrigerant', key: 'refrigerant', input: true},
{header: 'Evaporator Entering Water Temp (°C)', key: 'evaporator_entering_water_temp_c', input: true},
{header: 'Evaporator Leaving Water Temp (°C)', key: 'evaporator_leaving_water_temp_c', input: true},
{header: 'Evaporator Flow Rate (GPM)', key: 'evaporator_flow_rate_gpm', input: true},
{header: 'Evaporator Pressure Drop (mtrs)', key: 'evaporator_pressure_drop_mtrs', input: true},
{header: 'Evaporator Fouling Factor (ft2 h 0F / Btu)', key: 'evaporator_fouling_factor', input: true},
{header: 'Condenser Entering Water Temp (°C)', key: 'condenser_entering_water_temp_c', input: true},
{header: 'Condenser Leaving Water Temp (°C)', key: 'condenser_leaving_water_temp_c', input: true},
{header: 'Condenser Flow Rate (GPM)', key: 'condenser_flow_rate_gpm', input: true},
{header: 'Condenser Pressure Drop (mtrs)', key: 'condenser_pressure_drop_mtrs', input: true},
{header: 'Condenser Fouling Factor (ft2 h 0F / Btu)', key: 'condenser_fouling_factor', input: true},
{header: 'KiloWatt per Unit', key: 'kw_per_unit', input: true},
{header: 'Power Supply (V/Ø/Hz)', key: 'power_supply', input: true},
{header: 'Remark', key: 'remark', input: true}  ];
  protected readonly isNaN = isNaN;
  add_more() {
    if (this.response.table_data.length > 0) {
      const lastItem = this.response.table_data[this.response.table_data.length - 1];
      this.response.table_data.push({...lastItem});
    }
  }



   remove(index: number) {
    if (this.response.table_data.length > 1) {
      this.response.table_data.splice(index, 1);
    }
  }
}
