import {Component, Input, OnChanges, SimpleChanges} from '@angular/core';

export interface Item {
  "Description": any,
  "area": any,
  "area_description": any,
  "bua": any,
  "hvac_load_fire": any,
  "hvac_load_mains_faliure": any,
  "hvac_load_normal": any,
  "light_fire": any,
  "light_mains_faliure": any,
  "light_normal": any,
  "light_w_per_sqft": any,
  "raw_power_fire": any,
  "raw_power_mains_faliure": any,
  "raw_power_normal": any,
  "raw_power_w_per_sqft": any,
  "total_connected_fire": any,
  "total_connected_mains_failure": any,
  "total_connected_normal": any,
}

export interface ResponseMap {
  [key: string]: any;
}

@Component({
    selector: 'app-common-lighting-power',
    templateUrl: './common-lighting-power.component.html',
    styleUrls: ['./common-lighting-power.component.scss'],
    standalone: false
})
export class CommonLightingPowerComponent {

  @Input() response: ResponseMap = {};

  // tableDataList: { key: string; value: any[] }[] = [];
  // objects: { key: string; value: any}[] = [];

  // ngOnChanges(changes: SimpleChanges): void {
  //   for (const [key, value] of Object.entries(this.response)) {
  //     if (Array.isArray(value)) {
  //       this.tableDataList.push({ key, value });
  //     } else {
  //       this.objects.push({ key, value });
  //     }
  //   }
  //
  //   console.log(this.tableDataList)
  //   console.log(this.objects)
  // }
getGroupTotal(groupKey: string, field: string): number 
 {
  let total = 0;
  if (this.response[groupKey] && this.response[groupKey].length > 0) {
    this.response[groupKey].forEach((item:any) => {
      total += parseFloat(item[field]);
    });
  }
  return total;
}
replaceunderscore(key: any) {
  return key
    .replace(/_/g, ' ')
    .replace(/\w\S*/g, (txt: string) => txt.charAt(0).toUpperCase() + txt.substr(1).toLowerCase());
}
removeRow(key: string, index: number) {
  if (Array.isArray(this.response[key])) {
    this.response[key].splice(index, 1);
    if (this.response[key].length === 0) {
      delete this.response[key]; // remove key if array becomes empty
    }
  }
}

// To remove the entire key
removeGroup(key: string) {
  delete this.response[key];
}
addRow(key: string) {
  if (Array.isArray(this.response[key]) && this.response[key].length > 0) {
    const lastItem = { ...this.response[key][this.response[key].length - 1] };
    this.response[key].push(lastItem);
  }
}
addGroupFrom(keyToClone: string) {
  const newKey = prompt('Enter name for the new group:');
  if (newKey) {
    const uniqueKey = this.generateUniqueKey(newKey);
    // Copy only first item from source array
    const firstItem = { ...this.response[keyToClone][0] };
    this.response[uniqueKey] = [firstItem];
    // Insert new key after keyToClone
    const entries = Object.entries(this.response);
    const index = entries.findIndex(([key]) => key === keyToClone);
    const newEntries = [
      ...entries.slice(0, index + 1),
      [uniqueKey, this.response[uniqueKey]],
      ...entries.slice(index + 1)
    ];
    this.response = Object.fromEntries(newEntries);
  }
}
addDefault() {
  const newKey = prompt('Enter name for the new group:');
  if (newKey) {
    const uniqueKey = this.generateUniqueKey(newKey);
    const defaultItem = {
      "Description": "",
      "area": 0,
      "area_description": "",
      "bua": 0,
      "hvac_load_fire": 0,
      "hvac_load_mains_faliure": 0, 
      "hvac_load_normal": 0,
      "light_fire": 0,
      "light_mains_faliure": 0,
      "light_normal": 0,
      "light_w_per_sqft": 0,
      "raw_power_fire": 0,
      "raw_power_mains_faliure": 0,
      "raw_power_normal": 0,
      "raw_power_w_per_sqft": 0,
      "total_connected_fire": 0,
      "total_connected_mains_failure": 0,
      "total_connected_normal": 0
    };
    this.response[uniqueKey] = [defaultItem];
    // Insert new key at end
    const entries = Object.entries(this.response);
    const newEntries = [
      ...entries,
      [uniqueKey, this.response[uniqueKey]]
    ];
    this.response = Object.fromEntries(newEntries);
  }
}
generateUniqueKey(baseKey: string): string {
  let counter = 1;
  let uniqueKey = baseKey;
  while (this.response.hasOwnProperty(uniqueKey)) {
    uniqueKey = `${baseKey} ${counter}`;
    counter++;
  }
  return uniqueKey;
}

  protected readonly Array = Array;
}
