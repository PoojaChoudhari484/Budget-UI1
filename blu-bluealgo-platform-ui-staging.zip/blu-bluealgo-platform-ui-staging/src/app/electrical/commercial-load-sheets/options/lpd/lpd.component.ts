import {Component, Input} from '@angular/core';

@Component({
    selector: 'app-lpd',
    templateUrl: './lpd.component.html',
    styleUrls: ['./lpd.component.scss'],
    standalone: false
})
export class LpdComponent {
  @Input() response: any = {};

  tableDataPairList: any [] = [
    {header: 'SL', key: 'Sr. No.', input: false},
    {header: 'Description', key: 'Description', input: false},
    {header: 'LPD', key: 'LPD ', input: false},
    {header: 'Power Load Watts/Sq. Ft.', key: 'Power Load Watts/Sq. Ft.', input: false},
    {header: 'UPS Load Watts/Sq. Ft.', key: 'UPS Load Watts/Sq. Ft.', input: false},
  ];

  protected readonly isNaN = isNaN;
}
