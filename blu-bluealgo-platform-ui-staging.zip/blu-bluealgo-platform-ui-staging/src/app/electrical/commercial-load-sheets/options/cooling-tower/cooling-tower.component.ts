import {Component, Input} from '@angular/core';

@Component({
    selector: 'app-cooling-tower',
    templateUrl: './cooling-tower.component.html',
    styleUrls: ['./cooling-tower.component.scss'],
    standalone: false
})
export class CoolingTowerComponent {

  @Input() response: any = {};

  tableDataPairList: any [] = [
    {header: 'Reference No', key: 'ref_no', input: true},
    {header: 'Location', key: 'location', input: true},
    {header: 'Description', key: 'type', input: true},
    {header: 'Cells (Nos.)', key: 'cells', input: true},
    {header: 'Quantity (Nos.)', key: 'quantity', input: true},
    {header: 'Water Flow Rate (GPM)', key: 'water_flow_rate', input: true},
    {header: 'Entering Water Temp (°C)', key: 'entering_water_temp', input: true},
    {header: 'Leaving Water Temp (°C)', key: 'leaving_water_temp', input: true},
    {header: 'Entering Air Wet Bulb Temp (°C)', key: 'entering_air_wet_bulb_temp', input: true},
    {header: 'Heat Rejection Capacity (KW)', key: 'heat_rejection_capacity', input: true},
    {header: 'Power (KW)', key: 'power_kw', input: true},
    {header: 'Speed Control', key: 'speed_control', input: true},
    {header: 'Electrical Connection (V/Ø/Hz)', key: 'electrical_connection', input: true},
  ];
add_more() {
    if (this.response.table_data.length > 0) {
      const lastItem = this.response.table_data[this.response.table_data.length - 1];
      this.response.table_data.push({...lastItem});
    }
  }



   remove(index: number) {
    if (this.response.table_data.length > 1) {
      this.response.table_data.splice(index, 1);
    }
  }

  protected readonly isNaN = isNaN;
}
