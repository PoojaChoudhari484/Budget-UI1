import {NgModule} from '@angular/core';
import {CommonModule} from '@angular/common';
import {ElectricalRoutingModule} from './electrical-routing.module';
import {LoadSheetsComponent} from './load-sheets/load-sheets.component';
import {FormsModule, ReactiveFormsModule} from "@angular/forms";
import {NgChartsModule} from "ng2-charts";
import {RouterModule} from "@angular/router";
import {MatIconModule} from "@angular/material/icon";
import { BrowserModule } from '@angular/platform-browser';
import { BrowserAnimationsModule } from '@angular/platform-browser/animations';
import { MatProgressBarModule } from '@angular/material/progress-bar';
import {MatButtonModule} from "@angular/material/button";
import {MatAngularModule} from "../mat-angular/mat-angular.module";
import {HighchartsChartModule} from "highcharts-angular";
import {MatExpansionModule} from "@angular/material/expansion";
import { CommercialFfComponent } from './load-sheets/options/commercial-ff/commercial-ff.component';
import { CommercialTypicalCorridorComponent } from './load-sheets/options/commercial-typical-corridor/commercial-typical-corridor.component';
import { CommercialStairComponent } from './load-sheets/options/commercial-stair/commercial-stair.component';
import { RetailStairComponent } from './load-sheets/options/retail-stair/retail-stair.component';
import { NtaStairAndRampComponent } from './load-sheets/options/nta-stair-and-ramp/nta-stair-and-ramp.component';
import { TaStairComponent } from './load-sheets/options/ta-stair/ta-stair.component';
import { TaTypicalRefugeFloorComponent } from './load-sheets/options/ta-typical-refuge-floor/ta-typical-refuge-floor.component';
import { TaGfAndPodiumComponent } from './load-sheets/options/ta-gf-and-podium/ta-gf-and-podium.component';
import { NtaBasementGfAndPodiumComponent } from './load-sheets/options/nta-basement-gf-and-podium/nta-basement-gf-and-podium.component';
import { CommercialAndRetailBasementsComponent } from './load-sheets/options/commercial-and-retail-basements/commercial-and-retail-basements.component';
import { TaTypicalFloorCorridorComponent } from './load-sheets/options/ta-typical-floor-corridor/ta-typical-floor-corridor.component';
import { PheCommercialComponent } from './load-sheets/options/phe-commercial/phe-commercial.component';
import { RetailPheComponent } from './load-sheets/options/retail-phe/retail-phe.component';
import { PheResidentialComponent } from './load-sheets/options/phe-residential/phe-residential.component';
import { ApartmentLoadDetailsComponent } from './load-sheets/options/apartment-load-details/apartment-load-details.component';
import { ResidentialFfLoadComponent } from './load-sheets/options/residential-ff-load/residential-ff-load.component';
import {MatTabsModule} from "@angular/material/tabs";
import { T1SummaryComponent } from './load-sheets/options/t1-summary/t1-summary.component';
import { ApartmentPointsComponent } from './load-sheets/options/apartment-points/apartment-points.component';
import { FpElectricalLoadComponent } from './commercial-load-sheets/options/fp-electrical-load/fp-electrical-load.component';
import { CoolingTowerComponent } from './commercial-load-sheets/options/cooling-tower/cooling-tower.component';
import { CommercialLoadSheetsComponent } from './commercial-load-sheets/commercial-load-sheets.component';
import { WaterCooledChillerComponent } from './commercial-load-sheets/options/water-cooled-chiller/water-cooled-chiller.component';
import { OfficeLoadComponent } from './commercial-load-sheets/options/office-load/office-load.component';
import { PlElectricalLoadComponent } from './commercial-load-sheets/options/pl-electrical-load/pl-electrical-load.component';
import { PrimaryPumpComponent } from './commercial-load-sheets/options/primary-pump/primary-pump.component';
import { LpdComponent } from './commercial-load-sheets/options/lpd/lpd.component';
import { FanScheduleComponent } from './commercial-load-sheets/options/fan-schedule/fan-schedule.component';
import { CommonLightingPowerComponent } from './commercial-load-sheets/options/common-lighting-power/common-lighting-power.component';
import { SummaryCommercialLoadComponent } from './commercial-load-sheets/options/summary-commercial-load/summary-commercial-load.component';
import { ElectricalProjectDetailsComponent } from './electrical-project-details/electrical-project-details.component';
import { ElectricalSubPageComponent } from './electrical-sub-page/electrical-sub-page.component';
import { SharedCCModule } from '../shared-cc/shared-cc.module';
import { DecimalFormatPipe } from './pipes/decimal-format.pipe';
import { ElectricalPheSummaryComponent } from './load-sheets/options/electrical-phe-summary/electrical-phe-summary.component';
import { ElectricalFirefighterSummaryComponent } from './load-sheets/options/electrical-firefighter-summary/electrical-firefighter-summary.component';
import { ElectricalHvacSummaryComponent } from './load-sheets/options/electrical-hvac-summary/electrical-hvac-summary.component';
import { HsdComponent } from './hsd/hsd.component';
import { KvarComponent } from './kvar/kvar.component';
import { HtCablesComponent } from './ht-cables/ht-cables.component';
import { UpsComponent } from './ups/ups.component'; 
import { EmergencyLightingComponent } from './ups/tabs/emergency_lighting/emergency-lighting.component';
import { ElvLoadComponent } from './ups/tabs/elv-load/elv-load.component';
import { BusductComponent } from './busduct/busduct.component';
import { VdComponent } from './vd/vd.component';
import { RetailSummaryComponent } from './load-sheets/options/retail-summary/retail-summary.component';
import { RetailLoadComponent } from './load-sheets/options/retail-load/retail-load.component';
import { MainSummaryComponent } from './load-sheets/options/main-summary/main-summary.component';
import { ClubhouseComponent } from './load-sheets/options/clubhouse/clubhouse.component';
import { EquipmentsComponent } from './commercial-load-sheets/options/equipments/equipments.component';




@NgModule({
  declarations: [
    LoadSheetsComponent,
    CommercialFfComponent,
    CommercialTypicalCorridorComponent,
    CommercialStairComponent,
    RetailStairComponent,
    NtaStairAndRampComponent,
    TaStairComponent,
    TaTypicalRefugeFloorComponent,
    TaGfAndPodiumComponent,
    NtaBasementGfAndPodiumComponent,
    CommercialAndRetailBasementsComponent,
    TaTypicalFloorCorridorComponent,
    PheCommercialComponent,
    RetailPheComponent,
    RetailLoadComponent,
    PheResidentialComponent,
    ApartmentLoadDetailsComponent,
    ResidentialFfLoadComponent,
    ElectricalPheSummaryComponent,
    ElectricalFirefighterSummaryComponent,
    ElectricalHvacSummaryComponent,
    RetailSummaryComponent,
    T1SummaryComponent,
    ApartmentPointsComponent,
    FpElectricalLoadComponent,
    CoolingTowerComponent,
    CommercialLoadSheetsComponent,
    WaterCooledChillerComponent,
    OfficeLoadComponent,
    PlElectricalLoadComponent,
    PrimaryPumpComponent,
    LpdComponent,
    FanScheduleComponent,
    CommonLightingPowerComponent,
    SummaryCommercialLoadComponent,
    ElectricalProjectDetailsComponent,
    ElectricalSubPageComponent,
    HsdComponent,
    KvarComponent,
    HtCablesComponent ,
    DecimalFormatPipe,
    UpsComponent,
    BusductComponent,
    EmergencyLightingComponent,
    ElvLoadComponent,
    VdComponent,
    MainSummaryComponent,
    ClubhouseComponent,
    EquipmentsComponent,
   
  ],
  exports: [
    DecimalFormatPipe
  ],
  imports: [
    CommonModule,
    ElectricalRoutingModule,
    SharedCCModule,
    FormsModule,
    NgChartsModule,
    RouterModule,
    MatIconModule,
    MatButtonModule,
    BrowserModule,
    BrowserAnimationsModule,
    MatProgressBarModule,
    MatAngularModule,
    HighchartsChartModule,
    ReactiveFormsModule,
    MatExpansionModule,
    MatTabsModule
  ]
})
export class ElectricalModule {
}
