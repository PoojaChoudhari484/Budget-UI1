import {Component, EventEmitter, OnInit, Output} from '@angular/core';
import { InputSummary } from 'src/app/shared/entities/input-summary';
import { LocalApiService } from 'src/app/core/services/local-api.service';
import { CalculusCommonService } from 'src/app/core/services/calculus-common.service';


export interface Payload {
  "description": string,
  "dg_rating": number,
  "no_of_dg_sets": number,
  "fuel_consumption": number,
  "no_of_hours": number,
    


  "isNew"?: boolean
}

@Component({
    selector: 'app-hsd-summary',
    templateUrl: './hsd.component.html',
    styleUrls: ['./hsd.component.scss'],
    standalone: false
})
export class HsdComponent implements OnInit {

  inputSummaries: InputSummary[] = [];
  selectedInputSummary: any | null = null;
  showInput = false;
  @Output() moveToTab = new EventEmitter<string>();
  inputDropdownArrowSrc = 'assets/images/icons/down_arrow.svg';
  summaryResponse: any = {};
  payload: Payload;
  description: string = '$new'

  constructor(
    private apiService: LocalApiService,
    private calculusCommonService: CalculusCommonService,
  ) {
  }

  ngOnInit(): void {
    this.getRetailResponse();
  }

  getRetailResponse() {
    this.apiService.post('hsd', {}).subscribe(res => {
      console.log(res);
      this.summaryResponse = res;
      this.collectInputSummary();
    })
  }
deleteSummaryItem(i:any) {
    
  
    this.toggleInput(null)
    this.apiService.post('delete_hsd', {'index':i}).subscribe((res: any) => {
      this.summaryResponse = res;
      
      this.collectInputSummary();

    })
  }
  collectInputSummary() {
    this.inputSummaries = [];
    if (this.summaryResponse?.data?.length > 0) {
      this.summaryResponse?.data?.forEach((retail: any, i: number) => {
        let inputSummary: InputSummary = new InputSummary(retail.description, '',
          'assets/images/icons/enterprise.svg', true);
        this.inputSummaries.push(inputSummary);
      })
    }
  }

  toggleInput(summary: any) {
    this.showInput = !this.showInput;
    this.selectedInputSummary = this.showInput ? summary : null;
    if (this.showInput) {
      this.inputDropdownArrowSrc = 'assets/images/icons/up_arrow.svg';
    } else {
      this.summaryResponse.data = this.summaryResponse.data?.filter((s: any) => !s.isNew);
      this.inputDropdownArrowSrc = 'assets/images/icons/down_arrow.svg';
    }
    this.initInputObj();
  }

  initInputObj() {
    let findObj: any = this.summaryResponse?.data?.find((f: any) => f?.description === this.selectedInputSummary?.name);

    if (findObj) {
      if (findObj.description === this.description) findObj.description = '';
      this.payload = {
        description: findObj?.description ?? '',
        dg_rating: findObj?.dg_rating ?? 0,
        no_of_dg_sets: findObj?.no_of_dg_sets ?? 0,
        fuel_consumption : findObj?.fuel_consumption ?? 0,
        no_of_hours : findObj?.no_of_hours ?? 0,
        
      }
    }
  }

  addMore() {
    let newObj: Payload = {
      description: this.description,
      dg_rating: 0,
      no_of_dg_sets: 0,
      fuel_consumption: 0,
      no_of_hours: 0,
      
      isNew: true
    }
    this.summaryResponse.data.push(newObj);
    this.toggleInput({name: this.description})
  }

  onInputChange() {
    this.apiService.post('hsd', this.payload).subscribe((res: any) => {
      this.summaryResponse = res;
      this.collectInputSummary();
    })
  }

  getInfo(buttonElement: HTMLElement) {
    this.calculusCommonService.openInfoPopUp(buttonElement, 'phe_summary');
  }

}
