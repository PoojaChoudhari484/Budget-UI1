import {Component, EventEmitter, OnInit, Output} from '@angular/core';
import { InputSummary } from 'src/app/shared/entities/input-summary';
import { LocalApiService } from 'src/app/core/services/local-api.service';
import { CalculusCommonService } from 'src/app/core/services/calculus-common.service';
import { range } from 'rxjs';


export interface Payload {
"floor": any;
"three_bhk_load": any;
"four_bhk_load": any;
"four_five_bhk_load": any;
"other_load": any;
    


  "isNew"?: boolean
}

@Component({
    selector: 'app-busduct',
    templateUrl: './busduct.component.html',
    styleUrls: ['./busduct.component.scss'],
    standalone: false
})
export class BusductComponent implements OnInit {

  inputSummaries: InputSummary[] = [];
  selectedInputSummary: any | null = null;
  showInput = false;
  @Output() moveToTab = new EventEmitter<string>();
  inputDropdownArrowSrc = 'assets/images/icons/down_arrow.svg';
  summaryResponse: any = {};
  payload: Payload;
  description: string = '$new'
  no_of_floors: any;
  no_of_flats : any;
  no_of_risers : any;
  // Add array to store flat variables
flatConfigs: any[] = [];
riserRanges: any[] = [];


// Method to generate flat variables based on no_of_flats
storeFlatConfigs(value:any,index:any) {
//this.flatConfigs.push(value);
this.getBusductResponse();
}
  

// Call this method after setting no_of_flats


// Update variables when no_of_flats changes
  key: any;


  constructor(
    private apiService: LocalApiService,
    private calculusCommonService: CalculusCommonService,
  ) {
  }

  ngOnInit(): void {
    this.getRetailResponse();
   
  }

  getRetailResponse() {
    this.apiService.post('busduct', {}).subscribe(res => {
      
      this.summaryResponse = res;
      this.collectInputSummary();
      this.no_of_floors = this.summaryResponse?.no_of_floors ?? 0;
      this.no_of_flats = this.summaryResponse?.no_of_flats ?? 0;
      this.flatConfigs = this.summaryResponse?.configs ?? [];
      this.riserRanges = this.summaryResponse?.riser_ranges ?? [];
      this.no_of_risers = this.summaryResponse?.no_of_risers ?? 0;
    })
  }
  getLoadingPerc(perc:any)
  {const paya = {
      "loading_percent":perc

      
    }
    this.apiService.post('busduct', paya).subscribe(res => {
      console.log(res);
      this.summaryResponse = res;
      this.collectInputSummary();
    })
  }

 
  getBusductResponse() {
    const paya = {
      "no_of_floors":this.no_of_floors,
      "no_of_flats":this.no_of_flats,
      "no_of_risers":this.no_of_risers,
      "riser_ranges":this.riserRanges,
      "configs":this.flatConfigs,

      
    }
    this.apiService.post('busduct', paya).subscribe(res => {
      console.log(res);
      this.summaryResponse = res;
      this.collectInputSummary();
    })
  }
getRowSpan(val: any, main_index: any,total_floors:any): number {
  console.log('getRowSpan input:', { val, main_index });
  const current_range = this.summaryResponse["riser_ranges"][val];
  console.log('current_range:', current_range);
  let totalSpan = 0;

  if (!current_range) {
    console.log('No current range found, returning 1');
    return 1;
  }

  let commaSplit = current_range.split(',');
  console.log('commaSplit:', commaSplit);
  let main_end = 1
  // If commaSplit works (length > 1)
  if (commaSplit.length > 1) {
    for (let i = 0; i < commaSplit.length; i++) {
      
      let range = commaSplit[i].split('-');
      
      const start = parseInt(range[0]);
      let end = parseInt(range[1]);
      if (i === commaSplit.length -1)
      {
        end = 1
      }
      if (start === main_index)
      {
        return start-end+1
      }
        
    }
  } else {
    // fallback: try splitting directly by "-"
    let dashSplit = current_range.split('-');
    console.log('dashSplit:', dashSplit);
    
      const start = parseInt(dashSplit[0]);
      const end = parseInt(dashSplit[1]);
      if (start === main_index)
      {
        return total_floors;
      }
  }

  return totalSpan || 1; // fallback if parsing fails
}
emptyCheck(val: any, main_index: any,total_floors:any): boolean {
  
  const current_range = this.summaryResponse["riser_ranges"][val];
  console.log('current_range:', current_range);
  let totalSpan = 0;

  if (!current_range) {
    console.log('No current range found, returning 1');
    return true;
  }

  let commaSplit = current_range.split(',');
  
  
  // If commaSplit works (length > 1)
  if (commaSplit.length > 1) {
    let main_start = 0
    for (let i = 0; i < commaSplit.length; i++) {
      console.log('Processing comma-separated part:', commaSplit[i]);
      let range = commaSplit[i].split('-');
      
      const start = parseInt(range[0]);
      if(i === 0){
        main_start = start;
      }
      const end = parseInt(range[1]);
      
        
    }
    if (main_index > main_start)
    {
      return true;
    }

  }   
  else{ // fallback: try splitting directly by "-"
    let dashSplit = current_range.split('-');
    console.log('dashSplit:', dashSplit);
    
      const start = parseInt(dashSplit[0]);
      const end = parseInt(dashSplit[1]);
      if (main_index > start )
      {
        return true;
      }
  }

  return false; // fallback if parsing fails
}

  collectInputSummary() {
    this.inputSummaries = [];
    if (this.summaryResponse?.data?.length > 0) {
      this.summaryResponse?.data?.forEach((retail: any, i: number) => {
        let inputSummary: InputSummary = new InputSummary(retail.description, '',
          'assets/images/icons/enterprise.svg', true);
        this.inputSummaries.push(inputSummary);
      })
    }
  }

  toggleInput(summary: any) {
    this.showInput = !this.showInput;
    this.selectedInputSummary = this.showInput ? summary : null;
    if (this.showInput) {
      this.inputDropdownArrowSrc = 'assets/images/icons/up_arrow.svg';
    } else {
      this.summaryResponse.data = this.summaryResponse.data?.filter((s: any) => !s.isNew);
      this.inputDropdownArrowSrc = 'assets/images/icons/down_arrow.svg';
    }
    this.initInputObj();
  }

  initInputObj() {
    let findObj: any = this.summaryResponse?.data?.find((f: any) => f?.description === this.selectedInputSummary?.name);

    if (findObj) {
      if (findObj.description === this.description) findObj.description = '';
      this.payload = {
        floor: findObj?.floor ?? '',
        three_bhk_load: findObj?.three_bhk_load ?? 0,
        four_bhk_load: findObj?.four_bhk_load ?? 0,
        four_five_bhk_load : findObj?.four_five_bhk_load ?? 0,
        other_load : findObj?.other_load ?? 0,
        
      }
    }
  }

  addMore() {
    let newObj: Payload = {
      floor: '',
      three_bhk_load: 0,
      four_bhk_load: 0,
      four_five_bhk_load: 0,
      other_load: 0,
      
      isNew: true
    }
    this.summaryResponse.data.push(newObj);
    this.toggleInput({name: this.description})
  }

  onInputChange(lambda: any) {
    this.apiService.post('busduct', lambda).subscribe((res: any) => {
      this.summaryResponse = res;
      this.collectInputSummary();
    })
  }
 getCheckboxResponse(floor:any,flat:any,event:boolean)
 {
  const lambda = {
    "check_floor": floor,
    "check_flat": flat,
    "check_value": event
  }
  this.apiService.post('busduct', lambda).subscribe((res: any) => {
    this.summaryResponse = res;
    this.collectInputSummary();
  })
 }

   
  getInfo(buttonElement: HTMLElement) {
    this.calculusCommonService.openInfoPopUp(buttonElement, 'phe_summary');
  }

}
