import { Component, OnInit } from '@angular/core';
import { LocalApiService } from 'src/app/core/services/local-api.service';
import { CalculusCommonService } from 'src/app/core/services/calculus-common.service';

@Component({
    selector: 'app-vd',
    templateUrl: './vd.component.html',
    styleUrls: ['./vd.component.scss'],
    standalone: false
})
export class VdComponent implements OnInit {
  input = {
    actual_mva: null,
    base_mva: null,
    base_kv: null,
    z_act_initial : null,
    recieved_voltage_initial : null,
    desc_1: ''
 
}
  responseData: any = {};
  descriptionKeys: string[] = [];
  sortColumn: string = '';
sortDirection: 'asc' | 'desc' = 'asc';
  editableFields: string[] = ['description', 'from_text', 'to_text', 'cb_current', 'load', 'mtr', 'run', 'position', 'ca', 'cg', 'ci', 'cf','location'];  headerMapping: { [key: string]: any } = {
  "description": "Description",
    "from_text": "From",
    "to_text": "To",
    "location":"Location",
    "load": "Load",
    "cb_current": "CB Current",
    "resistance": "Resistance",
    "reactance": "Reactance",
    "z_act_per_m": "Z Act per m",



    "mtr": "MTR",
    "run": "Run",
    "tot_run": "Total Run",

    "position": "Position",
    "current_carry_capacity_single": "Current Carry Capacity Single",
    "current_capacity_cables": "Current Capacity Cables",

    "ca": "Ca",
    "cg": "Cg",
    "ci": "Ci",
    "cf": "Cf",

    "actual_current_capacity": "Actual Current Capacity",
    "cable_selection": "Cable Selection",
    "phi": "Phi",
    "z_act": "Z Act",
    "z_pu": "Z PU",
    "tot_z_pu": "Total Z PU",
    "i_pu": "I PU",

    "i_act": "I Act",
    "sc_kva": "SC kVA",
    "perc_v_drop": "% V Drop",
    "recieved_voltage": "Received Voltage",
    "cumulative_voltage_drop": "Cumulative Voltage Drop",
    "earthstrip_cross_section_cu": "Earthstrip Cross Section Cu",
    "suggested_strips": "Suggested Strips",
    "line_active_power_loss": "Line Active Power Loss",
    "perc_active_power_loss": "% Active Power Loss",
    "one_sec_fault_withstand_cap": "One Sec Fault Withstand Cap",
    "voltage_drop_condition": "Voltage Drop Condition",

    
    "load_current": "Load Current",

}; 
 newArrayKey: string = '';
  arrayExistsWarning: boolean = false;
  to_dropdown:any =  [];
Object: any;

  constructor(
    private apiService: LocalApiService,
    private calculusCommonService: CalculusCommonService,
  ) { }

  ngOnInit(): void {
    this.submitFormEmpty();
  }
// Show overlay
showLoader() {
  const overlay = document.querySelector<HTMLElement>(".overlay");
  if (overlay) {
    overlay.style.display = "flex";
  }
}

// Hide overlay
hideLoader() {
  const overlay = document.querySelector<HTMLElement>(".overlay");
  if (overlay) {
    overlay.style.display = "none";
  }
}

  submitForm() {
    this.showLoader();
    this.apiService.post('vd', this.input).subscribe((res: any) => {
      console.log('Initial response:', res);
      this.handleResponse(res);
      this.input.actual_mva = res.actual_mva;
      this.input.base_mva = res.base_mva;
      this.input.base_kv = res.base_kv;
      this.input.z_act_initial = res.z_act_initial;
        this.input.recieved_voltage_initial = res.recieved_voltage_initial;
      this.input.desc_1 = res.desc_1;
      this.to_dropdown = this.dropEmpty(res.new_dropdown);
      this.hideLoader();
    });
  }
deleteDescription(key:any)
{
  this.showLoader();
this.apiService.post('vd', {"desc_key":key}).subscribe((res: any) => {
      
      this.handleResponse(res);
      this.input.actual_mva = res.actual_mva;
      this.input.base_mva = res.base_mva;
      this.input.base_kv = res.base_kv;
      this.input.z_act_initial = res?.z_act_initial;
        this.input.recieved_voltage_initial = res?.recieved_voltage_initial;
      this.input.desc_1 = res?.descriptions[0];
      this.to_dropdown = this.dropEmpty(res.new_dropdown) || [];
      this.hideLoader();
    });
}
  submitFormEmpty() {
    this.showLoader();
    this.apiService.post('vd', {}).subscribe((res: any) => {
      console.log('Empty response:', res);
      this.handleResponse(res);
      this.input.actual_mva = res.actual_mva;
      this.input.base_mva = res.base_mva;
      this.input.base_kv = res.base_kv;
      this.input.z_act_initial = res?.z_act_initial;
        this.input.recieved_voltage_initial = res?.recieved_voltage_initial;
      this.input.desc_1 = res?.descriptions?.[0] || ''; 
    this.to_dropdown = this.dropEmpty(res.new_dropdown);
    this.hideLoader();
     });
  }
  

  submit_rows(row:any,index:any)
  {
    row["row_serial"] = index;
    this.showLoader();
    this.apiService.post('vd', row).subscribe((res: any) => {
      
      this.handleResponse(res);
      this.input.actual_mva = res.actual_mva;
      this.input.base_mva = res.base_mva;
      this.input.base_kv = res.base_kv;
      this.input.z_act_initial = res.z_act_initial;
        this.input.recieved_voltage_initial = res.recieved_voltage_initial;
        
      this.input.desc_1 = res.desc_1;
      this.to_dropdown = this.dropEmpty(res.new_dropdown);
      this.hideLoader()
    });
  }
  

  handleResponse(res: any) {
    this.responseData = res || {};

    // Extract descriptionKeys from descriptions
    const keysFromDescriptions = Array.isArray(res?.descriptions) ? res.descriptions : [];

    // Ensure each key exists in responseData and is an array
    keysFromDescriptions.forEach((key: string) => {
      if (!Array.isArray(this.responseData[key])) {
        this.responseData[key] = [];
      }
    });

    this.descriptionKeys = keysFromDescriptions;
  }

  objectKeys(obj: any): string[] {
    return Object.keys(obj);
  }

  isArray(val: any): boolean {
    return Array.isArray(val);
  }

  isObjectArray(arr: any[]): boolean {
    return arr.length > 0 && typeof arr[0] === 'object' && !Array.isArray(arr[0]);
  }

getColumns(arr: any[]): string[] {
  if (!arr || arr.length === 0 || typeof arr[0] !== 'object') return [];

  const dataKeys = Object.keys(arr[0]);

  const customOrder = Object.keys(this.headerMapping);

  // Return only the keys present in both data and headerMapping, in the custom order
  const ordered = customOrder.filter(key => dataKeys.includes(key));

  // Optionally include any extra keys not in headerMapping (dynamic fields)
  const remaining = dataKeys.filter(key => !customOrder.includes(key));

  return [...ordered, ...remaining];
}


  createObjectArray() {
    const key = this.newArrayKey.trim();

    if (!key || this.responseData.hasOwnProperty(key)) {
      this.arrayExistsWarning = true;
      return;
    }

    this.arrayExistsWarning = false;

    this.responseData[key] = [
      {
          "actual_current_capacity": 0,
          "ca": 1,
          "cable_selection": 0,
          "cb_current": 0,
          "cf": 1,
          "cg": 1,
          "ci": 1,
          "cumulative_voltage_drop": 0,
          "current_capacity_cables": 0,
          "current_carry_capacity_single": 0,
          "description": "",
          "earthstrip_cross_section_cu": 0,
          "from_text": "",
          "i_act": 0,
          "i_pu": 0,
          "line_active_power_loss": 0,
          "load": 0,
          "load_current": 0,
          "main_description": key,
          "location":'',
          "mtr": 0,
          "one_sec_fault_withstand_cap": 0,
          "perc_active_power_loss": 0,
          "perc_v_drop": 0,
          "phi": 0,
          "position": "",
          "reactance": 0,
          "recieved_voltage": 0,
          "resistance": 0,
          "run": 0,
          "sc_kva": 0,
          "suggested_strips": "",
          "to_text": "",
          "tot_run": 0,
          "tot_z_pu": 0,
          "voltage_drop_condition": 0,
          "z_act": 0,
          "z_act_per_m": 0,
          "z_pu": 0
        }
    ];

    if (!this.descriptionKeys.includes(key)) {
      this.descriptionKeys.push(key);
    }

    if (Array.isArray(this.responseData.descriptions)) {
      this.responseData.descriptions.push(key);
    } else {
      this.responseData.descriptions = [key];
    }

    this.newArrayKey = '';
    this.showLoader();
    this.apiService.post('update_vd', this.responseData).subscribe(res => {
        console.log('After add row:', res);
        this.responseData = res;
        this.input.actual_mva = this.responseData.actual_mva;
        this.input.base_mva = this.responseData.base_mva;
        this.input.base_kv = this.responseData.base_kv;
        this.input.z_act_initial = this.responseData.z_act_initial;
        this.input.recieved_voltage_initial = this.responseData.recieved_voltage_initial;
        this.input.desc_1 = this.responseData.desc_1;
        this.to_dropdown = this.dropEmpty(this.responseData.new_dropdown);
        this.hideLoader();
      });
  }
sortData(key: string, column: string): void {
  if (!this.responseData[key]) return;

  // Toggle sort direction
  if (this.sortColumn === column) {
    this.sortDirection = this.sortDirection === 'asc' ? 'desc' : 'asc';
  } else {
    this.sortColumn = column;
    this.sortDirection = 'asc';
  }

  const direction = this.sortDirection === 'asc' ? 1 : -1;

  this.responseData[key].sort((a: any, b: any) => {
    const valueA = a[column];
    const valueB = b[column];

    // Handle undefined or null values
    if (valueA == null && valueB != null) return -1 * direction;
    if (valueA != null && valueB == null) return 1 * direction;
    if (valueA == null && valueB == null) return 0;

    // Use localeCompare for strings
    if (typeof valueA === 'string' && typeof valueB === 'string') {
      return valueA.localeCompare(valueB) * direction;
    }

    // Default numeric comparison
    return (valueA > valueB ? 1 : valueA < valueB ? -1 : 0) * direction;
  });
}
  addRow(key: string) {
    if (Array.isArray(this.responseData[key])) {
      let emptyRow: any = {};

      // if (this.responseData[key].length > 0) {
      //   const first = this.responseData[key][0];
      //   for (const col of Object.keys(first)) {
      //     emptyRow[col] = typeof first[col] === 'number' ? 0 : col === 'main_description'?  first[col] : '';
      //   }
      // } else {
        emptyRow = {
          "actual_current_capacity": 0,
          "ca": 1,
          "cable_selection": 0,
          "cb_current": 0,
          "cf": 1,
          "cg": 1,
          "ci": 1,
          "cumulative_voltage_drop": 0,
          "current_capacity_cables": 0,
          "current_carry_capacity_single": 0,
          "description": "",
          "location":'',
          "earthstrip_cross_section_cu": 0,
          "from_text": "",
          "i_act": 0,
          "i_pu": 0,
          "line_active_power_loss": 0,
          "load": 0,
          "load_current": 0,
          "main_description": key,
          "mtr": 0,
          "one_sec_fault_withstand_cap": 0,
          "perc_active_power_loss": 0,
          "perc_v_drop": 0,
          "phi": 0,
          "position": "In Air",
          "reactance": 0,
          "recieved_voltage": 0,
          "resistance": 0,
          "run": 0,
          "sc_kva": 0,
          "suggested_strips": "",
          "to_text": "",
          "tot_run": 0,
          "tot_z_pu": 0,
          "voltage_drop_condition": 0,
          "z_act": 0,
          "z_act_per_m": 0,
          "z_pu": 0
        };
      

      this.responseData[key].push(emptyRow);
        this.showLoader();
      this.apiService.post('update_vd', this.responseData).subscribe(res => {
        console.log('After add row:', res);
        this.responseData = res;
        this.input.actual_mva = this.responseData.actual_mva;
        this.input.base_mva = this.responseData.base_mva;
        this.input.base_kv = this.responseData.base_kv;
        this.input.z_act_initial = this.responseData.z_act_initial;
        this.input.recieved_voltage_initial = this.responseData.recieved_voltage_initial;
        this.input.desc_1 = this.responseData.desc_1;
        this.to_dropdown = this.dropEmpty(this.responseData.new_dropdown);
        this.hideLoader();
      });
    }
  }

  deleteRow(key: string, index: number) {
    if (Array.isArray(this.responseData[key])) {
      this.responseData[key].splice(index, 1);
      this.showLoader();
      this.apiService.post('update_vd', this.responseData).subscribe(res => {
        console.log('After delete row:', res);
        this.responseData = res;
        this.input.actual_mva = this.responseData.actual_mva;
        this.input.base_mva = this.responseData.base_mva;
        this.input.base_kv = this.responseData.base_kv;
        this.input.z_act_initial = this.responseData.z_act_initial;
        this.input.recieved_voltage_initial = this.responseData.recieved_voltage_initial;
        this.input.desc_1 = this.responseData.desc_1;
        this.to_dropdown = this.dropEmpty(this.responseData.new_dropdown);
        this.hideLoader();
      });
    }
  }

  dropEmpty(data: any[]) {
    let newData = [];
    for (let x of data) {
      if (x !== "") {
        newData.push(x);
      }
    }
    return newData;
  }
check_to_dropdown_len()
{
  try
  {
  if(this.to_dropdown.length > 0)
  {
    console.log("TRUE")
  return true;
  }
  else
  {
  console.log("TRUEasdadasd")
  return false;
  }
}

catch
{
  console.log("THIS IS AN ERROR")
  return false;
}
}
}


