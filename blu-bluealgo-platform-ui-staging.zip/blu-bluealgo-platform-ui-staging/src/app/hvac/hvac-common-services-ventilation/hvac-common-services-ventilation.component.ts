import { Component, EventEmitter, Input, OnInit, Output } from '@angular/core';
import { Summary } from 'src/app/core/models/Summary.model';
import { LocalApiService } from 'src/app/core/services/local-api.service';
import * as Highcharts from 'highcharts';
import 'highcharts/highcharts-3d';
import { HttpClient } from '@angular/common/http';
import { ActivatedRoute } from '@angular/router';
import {CalculusCommonService} from "../../core/services/calculus-common.service";

@Component({
    selector: 'app-hvac-common-services-ventilation',
    templateUrl: './hvac-common-services-ventilation.component.html',
    styleUrls: ['./hvac-common-services-ventilation.component.scss'],
    standalone: false
})
export class HvacCommonServicesVentilationComponent implements OnInit {
  public commonServicesInputs = [
    {
      name: 'OWC',
      value: '',
      icon: 'assets/images/icons/enterprise.svg',
    },
    {
      name: 'Transformer',
      value: '',
      icon: 'assets/images/icons/enterprise.svg',
    },
    {
      name: 'Pump room',
      value: '',
      icon: 'assets/images/icons/enterprise.svg',
    },
    {
      name: 'Meter room',
      value: '',
      icon: 'assets/images/icons/enterprise.svg',
    },
    {
      name: 'Misc',
      value: '',
      icon: 'assets/images/icons/enterprise.svg',
    },
  ];

  @Output() moveToTab = new EventEmitter<string>();

  public summaryText = 'Summary - A';
  public summaryType = 'A';
  public showInputA = false;
  public showInputB = false;
  public selectedInputASummary: Summary | null = null;
  public selectedInputBSummary: Summary | null = null;

  public showInputASummary = true;
  public showInputBSummary = false;
  public showInput = false;

  public activeButtonId: string | null = 'tab-input-a';
  public inputDropdownArrowSrc = 'assets/images/icons/down_arrow.svg';
  public unitTypes: string[] = ['LPD', 'KLD'];
  public selectedUnit: string = 'LPD';
  public flushingWaterRequired = 6;

  highChartOptions: Highcharts.Options;
  Highcharts = Highcharts;

  public item_data: string = 'Core 01, 02 Service Lift Lobby';
  public area: number = 0;
  public height: number = 0;
  public airflow_acph: number = 0;
  public ex_fan_qty: number = 0;
  public fresh_air: number = 0;
  public shaft_velocity: number = 0;
  public louver_velocity: number = 0;
  public fa_fan_qty: number = 0;
  public remarks: string = '';

  public showTable1Summary = true;
  public showTable1 = false;
  public selectedTable1Summary: Summary | any;

  commonServicesInputSummaries: any;

  hvacMakeupResponse: any;
  liftLobbyMainResponse: any;
  commonServicesMainResponse: any;

  table1State = {
    owc: {
      service: 'OWC',
      area: 0,
      height: 0,
      airflow_acph: 0,
      ex_fan_qty: 0,
      fresh_air: 0,
      fa_fan_qty: 0,
      shaft_velocity: 0,
      louver_velocity: 0,
      remarks: '',
    },

    transformer: {
      service: 'Transformer',
      area: 0,
      height: 0,
      airflow_acph: 0,
      ex_fan_qty: 0,
      fresh_air: 0,
      fa_fan_qty: 0,
      shaft_velocity: 0,
      louver_velocity: 0,
      remarks: '',
    },

    pump_room: {
      service: 'Pump room',
      area: 0,
      height: 0,
      airflow_acph: 0,
      ex_fan_qty: 0,
      fresh_air: 0,
      fa_fan_qty: 0,
      shaft_velocity: 0,
      louver_velocity: 0,
      remarks: '',
    },

    meter_room: {
      service: 'Meter room',
      area: 0,
      height: 0,
      airflow_acph: 0,
      ex_fan_qty: 0,
      fresh_air: 0,
      fa_fan_qty: 0,
      shaft_velocity: 0,
      louver_velocity: 0,
      remarks: '',
    },
    misc: {
      service: 'Misc',
      area: 0,
      height: 0,
      airflow_acph: 0,
      ex_fan_qty: 0,
      fresh_air: 0,
      fa_fan_qty: 0,
      shaft_velocity: 0,
      louver_velocity: 0,
      remarks: '',
    },

    // miscellaneous: {
    //   service: "Miscellaneous",
    //   area: 0,
    //   height: 0,
    //   airflow_acph: 0,
    //   ex_fan_qty: 0,
    //   fresh_air: 0,
    //   fa_fan_qty: 0,
    //   remarks: ''
    // }
  } as any;
  project_name: string;
  project_id: string;
  project_date: string;
  sub_module_name: string;

  public constructor(
    private apiService: LocalApiService,
    private http: HttpClient,
    private activatedRoute: ActivatedRoute,
    private calculusCommonService: CalculusCommonService,
  ) {
    this.initializeHighChart();
  }

  ngOnInit(): void {
    this.project_name = 'Centrona';
    this.project_id = '1';
    this.project_date = '2021-09-01';
    this.sub_module_name = 'common_service_ventilation';

    this.commonServicesInputSummaries = this.updateCommonServicesInputSummaries(
      null,
      this.commonServicesInputs,
    );
    this.apiService.post<any>('common_service', null).subscribe(
      (response) => {
        this.commonServicesMainResponse = response;
        this.table1State.owc = response.OWC;
        this.table1State.transformer = response.Transformer;
        this.table1State.pump_room = response['Pump room'];
        this.table1State.meter_room = response['Meter room'];
        this.table1State.misc = response['Misc'];

        this.commonServicesInputSummaries =
          this.updateCommonServicesInputSummaries(
            response,
            this.commonServicesInputSummaries,
          );

        this.initializeHighChart();
      },
      (error) => {
        console.error('API Error:', error);
      },
    );
  }

  initializeHighChart(): void {
    let airQuantity = null;
    let exhaustFanCapacity = null;
    let freshAirFanCapacity = null;

    if (this.selectedTable1Summary?.name == 'OWC') {
      airQuantity =
        this.commonServicesMainResponse?.['OWC']?.air_quantity_cfm ?? 0;
      exhaustFanCapacity =
        this.commonServicesMainResponse?.['OWC']?.exhaust_fan_capacity ?? 0;
      freshAirFanCapacity =
        this.commonServicesMainResponse?.['OWC']?.fresh_air_fan_capacity ?? 0;
    }
    if (this.selectedTable1Summary?.name == 'Transformer') {
      airQuantity =
        this.commonServicesMainResponse?.['Transformer']?.air_quantity_cfm ?? 0;
      exhaustFanCapacity =
        this.commonServicesMainResponse?.['Transformer']
          ?.exhaust_fan_capacity ?? 0;
      freshAirFanCapacity =
        this.commonServicesMainResponse?.['Transformer']
          ?.fresh_air_fan_capacity ?? 0;
    }
    if (this.selectedTable1Summary?.name == 'Pump room') {
      airQuantity =
        this.commonServicesMainResponse?.['Pump room']?.air_quantity_cfm ?? 0;
      exhaustFanCapacity =
        this.commonServicesMainResponse?.['Pump room']?.exhaust_fan_capacity ??
        0;
      freshAirFanCapacity =
        this.commonServicesMainResponse?.['Pump room']
          ?.fresh_air_fan_capacity ?? 0;
    }
    if (this.selectedTable1Summary?.name == 'Meter room') {
      airQuantity =
        this.commonServicesMainResponse?.['Meter room']?.air_quantity_cfm ?? 0;
      exhaustFanCapacity =
        this.commonServicesMainResponse?.['Meter room']?.exhaust_fan_capacity ??
        0;
      freshAirFanCapacity =
        this.commonServicesMainResponse?.['Meter room']
          ?.fresh_air_fan_capacity ?? 0;
    }
    if (this.selectedTable1Summary?.name == 'Misc') {
      airQuantity =
        this.commonServicesMainResponse?.['Misc']?.air_quantity_cfm ?? 0;
      exhaustFanCapacity =
        this.commonServicesMainResponse?.['Misc']?.exhaust_fan_capacity ?? 0;
      freshAirFanCapacity =
        this.commonServicesMainResponse?.['Misc']?.fresh_air_fan_capacity ?? 0;
    }

    airQuantity = Number(airQuantity);
    exhaustFanCapacity = Number(exhaustFanCapacity);
    freshAirFanCapacity = Number(freshAirFanCapacity);

    this.highChartOptions = {
      chart: {
        marginTop: 45,
        type: 'pie',
        backgroundColor: 'transparent',
        options3d: {
          enabled: true,
          alpha: 55,
          beta: 0,
        },
      },
      title: {
        text: '',
      },
      legend: {
        enabled: true,
        align: 'center',
        verticalAlign: 'top',
        y: 0,
        itemStyle: {
          color: '#333',
        },
      },
      plotOptions: {
        pie: {
          minSize: 0, // Ensures even small values are visible
          ignoreHiddenPoint: false, // Ensures small values are not ignored
          showInLegend: true,
          // colors: ['#19FB8B', '#FF645B'],
          innerSize: 90,
          depth: 40,
          dataLabels: {
            enabled: false,
            format: '{point.name}: {point.percentage:.1f}%',
            style: {
              color: 'white',
              fontWeight: 'bold',
            },
          },
        },
      },
      series: [
        {
          type: 'pie',
          // name: 'Waste',
          data: [
            { name: `Air Quantity (CFM)`, y: airQuantity },
            { name: `Exhaust fan Capacity`, y: exhaustFanCapacity },
            { name: `Fresh air fan Capacity`, y: freshAirFanCapacity },
          ],
          tooltip: {
            pointFormat: '{point.name}: {point.percentage:.1f}%',
          },
        },
      ],
      credits: {
        enabled: false,
      },
    };
  }

  getButtonClasses(id: string) {
    if (this.activeButtonId === id) {
      return {
        'bg-white': true,
        'py-[7px]': true,
        'text-[#1D40AB]': true,
        'text-[#000000]': false,
      };
    } else {
      return {
        'bg-white': false,
        'py-[7px]': false,
        'text-[#1D40AB]': false,
        'text-[#7F7E7E]': true,
      };
    }
  }

  updateApartmentSummaries(response: any, summaryToUpdate: any) {
    const keyMap: { [key: string]: string } = {
      '4 BHK Occupants': '4BHK',
      '3 BHK Occupants': '3BHK',
      '2 BHK Occupants': '2BHK',
      '1 BHK Occupants': '1BHK',
      Studio: 'Studio',
      Drivers: 'Drivers',
      Visitors: 'Visitors',
      'Support Staff': 'Support Staff',
    };

    return summaryToUpdate.map((item: { name: string | number }) => {
      const key = keyMap[item.name];

      if (response && response[key]) {
        const details = response[key];
        return {
          ...item,
          value: key,
          domesticLPD: details['Domestic (LPD)'] || 0,
          flushingLPD: details['Flushing (LPD)'] || 0,
          grossWaterDemand: details['Gross Water Demand'] || 0,
          totalPopulation: details['Total Population'] || 0,
          noOfUnits: details['no_of_units'] || 0,
        };
      }

      return {
        ...item,
        value: '0 LPD',
        'Domestic (LPD)': 0,
        'Flushing (LPD)': 0,
        'Gross Water Demand': 0,
        'Total Population': 0,
        no_of_units: 0,
      };
    });
  }

  updateInputBSummaries(response: any, summaryToUpdate: any) {
    const keyMap: { [key: string]: string } = {
      'Swimming Pool': 'Swimming Pool',
      Landscape: 'Landscape',
      Clubhouse: 'Clubhouse',
    };

    return summaryToUpdate.map((item: { name: string | number }) => {
      const key = keyMap[item.name];

      if (response && response[key]) {
        const details = response[key];
        return {
          ...item,
          value: key,
          domesticLPD: details['Domestic (LPD)'] || 0,
          totalVolume: details['Total Volume'] || 0,
          domesticWaterRequired: details['domestic_water_required'] || 0,
          flushingWaterLPD: details['Flushing (LPD)'] || 0,
          flushingWaterRequired: details['flushing_water_required'] || 0,
          grossWaterDemand: details['Gross Water Demand'] || 0,
        };
      }

      return {
        ...item,
        value: '0 LPD',
        'Domestic (LPD)': 0,
        'Total Volume': 0,
        domestic_water_required: 0,
        flushing_water_required: 0,
      };
    });
  }

  getSpecificSummaryData(data: any, key: string) {
    const extractedData = {
      [key]: data[key],
      'Grand Totals': data['Grand Totals'],
      'Sub Totals A': data['Sub Totals A'],
      'Sub Totals B': data['Sub Totals B'],
    };
    Object.keys(extractedData).forEach((k) => {
      if (extractedData[k] === undefined) {
        delete extractedData[k];
      }
    });

    return extractedData;
  }

  moveNext(): void {
    this.moveToTab.emit('hvac-makeup');
  }

  toggleTable1(summary: any) {
    this.showTable1 = !this.showTable1;
    this.selectedTable1Summary = this.showTable1 ? summary : null;

    if (this.selectedTable1Summary) {
      if (this.selectedTable1Summary?.name == 'OWC') {
        this.area = this.table1State.owc.area;
        this.height = this.table1State.owc.height;
        this.airflow_acph = this.table1State.owc.airflow_acph;
        this.ex_fan_qty = this.table1State.owc.ex_fan_qty;
        this.fresh_air = this.table1State.owc.fresh_air;
        this.fa_fan_qty = this.table1State.owc.fa_fan_qty;
        this.remarks = this.table1State.owc.remarks;
        this.shaft_velocity = this.table1State.owc.shaft_velocity;
        this.louver_velocity = this.table1State.owc.louver_velocity;
      }

      if (this.selectedTable1Summary?.name == 'Transformer') {
        this.area = this.table1State.transformer.area;
        this.height = this.table1State.transformer.height;
        this.airflow_acph = this.table1State.transformer.airflow_acph;
        this.ex_fan_qty = this.table1State.transformer.ex_fan_qty;
        this.fresh_air = this.table1State.transformer.fresh_air;
        this.fa_fan_qty = this.table1State.transformer.fa_fan_qty;
        this.remarks = this.table1State.transformer.remarks;
        this.shaft_velocity = this.table1State.transformer.shaft_velocity;
        this.louver_velocity = this.table1State.transformer.louver_velocity;
      }

      if (this.selectedTable1Summary?.name == 'Pump room') {
        this.area = this.table1State.pump_room.area;
        this.height = this.table1State.pump_room.height;
        this.airflow_acph = this.table1State.pump_room.airflow_acph;
        this.ex_fan_qty = this.table1State.pump_room.ex_fan_qty;
        this.fresh_air = this.table1State.pump_room.fresh_air;
        this.fa_fan_qty = this.table1State.pump_room.fa_fan_qty;
        this.remarks = this.table1State.pump_room.remarks;
        this.shaft_velocity = this.table1State.pump_room.shaft_velocity;
        this.louver_velocity = this.table1State.pump_room.louver_velocity;
      }

      if (this.selectedTable1Summary?.name == 'Meter room') {
        this.area = this.table1State.meter_room.area;
        this.height = this.table1State.meter_room.height;
        this.airflow_acph = this.table1State.meter_room.airflow_acph;
        this.ex_fan_qty = this.table1State.meter_room.ex_fan_qty;
        this.fresh_air = this.table1State.meter_room.fresh_air;
        this.fa_fan_qty = this.table1State.meter_room.fa_fan_qty;
        this.remarks = this.table1State.meter_room.remarks;
        this.shaft_velocity = this.table1State.meter_room.shaft_velocity;
        this.louver_velocity = this.table1State.meter_room.louver_velocity;
      }

      if (this.selectedTable1Summary?.name == 'Misc') {
        this.area = this.table1State.misc.area;
        this.height = this.table1State.misc.height;
        this.airflow_acph = this.table1State.misc.airflow_acph;
        this.ex_fan_qty = this.table1State.misc.ex_fan_qty;
        this.fresh_air = this.table1State.misc.fresh_air;
        this.fa_fan_qty = this.table1State.misc.fa_fan_qty;
        this.remarks = this.table1State.misc.remarks;
        this.shaft_velocity = this.table1State.misc.shaft_velocity;
        this.louver_velocity = this.table1State.misc.louver_velocity;
      }

      if (this.selectedTable1Summary?.name == 'Miscellaneous') {
        this.area = this.table1State.miscellaneous.area;
        this.height = this.table1State.miscellaneous.height;
        this.airflow_acph = this.table1State.miscellaneous.airflow_acph;
        this.ex_fan_qty = this.table1State.miscellaneous.ex_fan_qty;
        this.fresh_air = this.table1State.miscellaneous.fresh_air;
        this.fa_fan_qty = this.table1State.miscellaneous.fa_fan_qty;
        this.remarks = this.table1State.miscellaneous.remarks;
        this.shaft_velocity = this.table1State.miscellaneous.shaft_velocity;
        this.louver_velocity = this.table1State.miscellaneous.louver_velocity;
      }

      this.initializeHighChart();
    }

    if (this.showTable1) {
      this.inputDropdownArrowSrc = 'assets/images/icons/up_arrow.svg';
      this.summaryText = '';
      // this.onInputBChange();
    } else {
      this.inputDropdownArrowSrc = 'assets/images/icons/down_arrow.svg';
      this.summaryText = 'Summary - B';
    }
    this.initializeHighChart();
  }

  updateCommonServicesInputSummaries(response: any, summaryToUpdate: any) {
    const keyMap: { [key: string]: string } = {
      OWC: 'OWC',
      Transformer: 'Transformer',
      'Pump room': 'Pump room',
      'Meter room': 'Meter room',
      Misc: 'Misc',
    };

    return summaryToUpdate.map((item: { name: string | number }) => {
      const key = keyMap[item.name];

      const inputDetails = response?.[key];

      if (response) {
        const value = response[key];

        return {
          ...item,
          value: value?.area,
          area: inputDetails?.area,
          height: inputDetails?.height,
          airflow_acph: inputDetails?.airflow_acph,
          ex_fan_qty: inputDetails?.ex_fan_qty,
          fresh_air: inputDetails?.fresh_air,
          fa_fan_qty: inputDetails?.fa_fan_qty,
          remarks: inputDetails?.remarks,
          louver_velocity: inputDetails?.louver_velocity,
          shaft_velocity: inputDetails?.shaft_velocity,
        };
      }

      return {
        ...item,
        value: '0',
        area: 0,
        height: 0,
        airflow_acph: 0,
        ex_fan_qty: 0,
        fresh_air: 0,
        fa_fan_qty: 0,
        louver_velocity: 0,
        shaft_velocity: 0,
        remarks: '',
      };
    });
  }

  onCommonServicesVentInputChange() {
    if (this.selectedTable1Summary?.name === 'OWC') {
      // this.table1State.owc.service = 'OWC';
      this.table1State.owc.area = this.area;
      this.table1State.owc.height = this.height;
      this.table1State.owc.airflow_acph = this.airflow_acph;
      this.table1State.owc.ex_fan_qty = this.ex_fan_qty;
      this.table1State.owc.fresh_air = this.fresh_air;
      this.table1State.owc.fa_fan_qty = this.fa_fan_qty;
      this.table1State.owc.remarks = this.remarks;
      this.table1State.owc.louver_velocity = this.louver_velocity;
      this.table1State.owc.shaft_velocity = this.shaft_velocity;
    }

    if (this.selectedTable1Summary?.name === 'Transformer') {
      // this.table1State.transformer.service = 'Transformer';
      this.table1State.transformer.area = this.area;
      this.table1State.transformer.height = this.height;
      this.table1State.transformer.airflow_acph = this.airflow_acph;
      this.table1State.transformer.ex_fan_qty = this.ex_fan_qty;
      this.table1State.transformer.fresh_air = this.fresh_air;
      this.table1State.transformer.fa_fan_qty = this.fa_fan_qty;
      this.table1State.transformer.remarks = this.remarks;
      this.table1State.transformer.louver_velocity = this.louver_velocity;
      this.table1State.transformer.shaft_velocity = this.shaft_velocity;
    }

    if (this.selectedTable1Summary?.name === 'Pump room') {
      // this.table1State.pump_room.service = 'Pump room';
      this.table1State.pump_room.area = this.area;
      this.table1State.pump_room.height = this.height;
      this.table1State.pump_room.airflow_acph = this.airflow_acph;
      this.table1State.pump_room.ex_fan_qty = this.ex_fan_qty;
      this.table1State.pump_room.fresh_air = this.fresh_air;
      this.table1State.pump_room.fa_fan_qty = this.fa_fan_qty;
      this.table1State.pump_room.remarks = this.remarks;
      this.table1State.pump_room.louver_velocity = this.louver_velocity;
      this.table1State.pump_room.shaft_velocity = this.shaft_velocity;
    }

    if (this.selectedTable1Summary?.name === 'Meter room') {
      // this.table1State.meter_room.service = 'Meter room';
      this.table1State.meter_room.area = this.area;
      this.table1State.meter_room.height = this.height;
      this.table1State.meter_room.airflow_acph = this.airflow_acph;
      this.table1State.meter_room.ex_fan_qty = this.ex_fan_qty;
      this.table1State.meter_room.fresh_air = this.fresh_air;
      this.table1State.meter_room.fa_fan_qty = this.fa_fan_qty;
      this.table1State.meter_room.remarks = this.remarks;
      this.table1State.meter_room.louver_velocity = this.louver_velocity;
      this.table1State.meter_room.shaft_velocity = this.shaft_velocity;
    }

    if (this.selectedTable1Summary?.name === 'Misc') {
      // this.table1State.meter_room.service = 'Misc';
      this.table1State.misc.area = this.area;
      this.table1State.misc.height = this.height;
      this.table1State.misc.airflow_acph = this.airflow_acph;
      this.table1State.misc.ex_fan_qty = this.ex_fan_qty;
      this.table1State.misc.fresh_air = this.fresh_air;
      this.table1State.misc.fa_fan_qty = this.fa_fan_qty;
      this.table1State.misc.remarks = this.remarks;
      this.table1State.misc.louver_velocity = this.louver_velocity;
      this.table1State.misc.shaft_velocity = this.shaft_velocity;
    }

    // if (this.selectedTable1Summary?.name === 'Miscellaneous') {
    //   // this.table1State.miscellaneous.service = 'Miscellaneous';
    //   this.table1State.miscellaneous.area = this.area;
    //   this.table1State.miscellaneous.height = this.height;
    //   this.table1State.miscellaneous.airflow_acph = this.airflow_acph;
    //   this.table1State.miscellaneous.ex_fan_qty = this.ex_fan_qty;
    //   this.table1State.miscellaneous.fresh_air = this.fresh_air;
    //   this.table1State.miscellaneous.fa_fan_qty = this.fa_fan_qty;
    //   this.table1State.miscellaneous.remarks = this.remarks;
    // }

    // Validate all fields before proceeding
    // if (!this.areAllFieldsFilled()) {
    //   // console.error('Validation Error: All fields must be filled before making the API call.');
    //   return;
    // }

    const payload = {
      inputs: [
        this.table1State.owc,
        this.table1State.transformer,
        this.table1State.pump_room,
        this.table1State.meter_room,
        this.table1State.misc,
        // this.table1State.miscellaneous
      ],
    };

    this.apiService.post<any>('common_service', payload).subscribe(
      (response) => {
        this.commonServicesMainResponse = response;

        this.commonServicesInputSummaries =
          this.updateCommonServicesInputSummaries(
            response,
            this.commonServicesInputSummaries,
          );

        this.initializeHighChart();
      },
      (error) => {
        console.error('API Error:', error);
      },
    );
  }

  areAllFieldsFilled(): boolean {
    const services = Object.values(this.table1State);

    return services.every(
      (service: any) =>
        service.area !== 0 &&
        service.height !== 0 &&
        service.airflow_acph !== 0 &&
        service.ex_fan_qty !== 0 &&
        service.fresh_air !== 0 &&
        service.fa_fan_qty !== 0 &&
        service.service !== '' &&
        service.shaft_velocity != 0 &&
        service.louver_velocity != 0,
    );
  }

  submit() {
    const projectDetailsString = sessionStorage.getItem('PROJECTDETAILS');

    let projectName = '';
    let projectType = '';
    let documentVersion = '';
    let date = '';

    if (projectDetailsString) {
      const projectDetails = JSON.parse(projectDetailsString);
      projectName = projectDetails.queryParams.projectName;
      projectType = projectDetails.queryParams.projectType;
      documentVersion = projectDetails.queryParams.documentVersion;
      date = projectDetails.queryParams.date;
    }

    const payload = {
      project_name: projectName,
      project_type: projectType,
      document_version: documentVersion,
      project_date: date || this.project_date,
      project_id: this.project_id,
      sub_module_name: this.sub_module_name,
    };
    this.calculusCommonService.getReport(payload);
  }
}
