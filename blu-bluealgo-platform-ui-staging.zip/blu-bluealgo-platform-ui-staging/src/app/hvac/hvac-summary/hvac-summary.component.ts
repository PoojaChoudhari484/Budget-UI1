import {Component, EventEmitter, OnInit, Output} from '@angular/core';
import { InputSummary } from 'src/app/shared/entities/input-summary';
import { LocalApiService } from 'src/app/core/services/local-api.service';
import { CalculusCommonService } from 'src/app/core/services/calculus-common.service';


export interface Payload {
  "description": string,
  "working_no": number,
  "standby_no": number,
  "static_pressure": number,
  "effeciency": number,
  "selected_flow" : number,


  "isNew"?: boolean
}

@Component({
    selector: 'app-hvac-summary',
    templateUrl: './hvac-summary.component.html',
    styleUrls: ['./hvac-summary.component.scss'],
    standalone: false
})
export class HvacSummaryComponent implements OnInit {

  inputSummaries: InputSummary[] = [];
  selectedInputSummary: any | null = null;
  showInput = false;
  @Output() moveToTab = new EventEmitter<string>();
  inputDropdownArrowSrc = 'assets/images/icons/down_arrow.svg';
  summaryResponse: any = {};
  payload: Payload;
  description: string = '$new'

  project_name: string;
  project_id: string;
  project_date: string;
  sub_module_name: string;

  constructor(
    private apiService: LocalApiService,
    private calculusCommonService: CalculusCommonService,
  ) {
  }

  ngOnInit(): void {
    this.project_name = 'Centrona';
    this.project_id = '1';
    this.project_date = '2021-09-01';
    this.sub_module_name = 'hvac_summary';

    this.getRetailResponse();
  }

  getRetailResponse() {
    this.apiService.post('hvac_summary', {}).subscribe(res => {
      console.log(res);
      this.summaryResponse = res;
      this.collectInputSummary();
    })
  }
deleteSummaryItem(item: any) {
    this.toggleInput(item);
    this.apiService.post('delete_summary_hvac', item).subscribe((res: any) => {
      this.summaryResponse = res;

      this.collectInputSummary();

    })
  }
  collectInputSummary() {
    this.inputSummaries = [];
    if (this.summaryResponse?.data?.length > 0) {
      this.summaryResponse?.data?.forEach((retail: any, i: number) => {
        let inputSummary: InputSummary = new InputSummary(retail.description, '',
          'assets/images/icons/enterprise.svg', true);
        this.inputSummaries.push(inputSummary);
      })
    }
  }

  toggleInput(summary: any) {
    this.showInput = !this.showInput;
    this.selectedInputSummary = this.showInput ? summary : null;
    if (this.showInput) {
      this.inputDropdownArrowSrc = 'assets/images/icons/up_arrow.svg';
    } else {
      this.summaryResponse.data = this.summaryResponse.data?.filter((s: any) => !s.isNew);
      this.inputDropdownArrowSrc = 'assets/images/icons/down_arrow.svg';
    }
    this.initInputObj();
  }

  initInputObj() {
    let findObj: any = this.summaryResponse?.data?.find((f: any) => f?.description === this.selectedInputSummary?.name);

    if (findObj) {
      if (findObj.description === this.description) findObj.description = '';
      this.payload = {
        description: findObj?.description ?? '',
        standby_no: findObj?.standby_no ?? 0,
        working_no: findObj?.working_no ?? 0,
        static_pressure : findObj?.static_pressure ?? 0,
        effeciency : findObj?.effeciency ?? 0,
        selected_flow : findObj?.selected_flow ?? 0
      }
    }
  }

  addMore() {
    let newObj: Payload = {
      description: this.description,
      standby_no: 0,
      working_no: 0,
      static_pressure: 0,
      effeciency: 0,
      selected_flow: 0,
      isNew: true
    }
    this.summaryResponse.data.push(newObj);
    this.toggleInput({name: this.description})
  }

  onInputChange() {
    this.apiService.post('hvac_summary', this.payload).subscribe((res: any) => {
      this.summaryResponse = res;
      this.collectInputSummary();
    })
  }

  getInfo(buttonElement: HTMLElement) {
    this.calculusCommonService.openInfoPopUp(buttonElement, 'phe_summary');
  }

  submit() {
    const projectDetailsString = sessionStorage.getItem('PROJECTDETAILS');

    let projectName = '';
    let projectType = '';
    let documentVersion = '';
    let date = '';

    if (projectDetailsString) {
      const projectDetails = JSON.parse(projectDetailsString);
      projectName = projectDetails.queryParams.projectName;
      projectType = projectDetails.queryParams.projectType;
      documentVersion = projectDetails.queryParams.documentVersion;
      date = projectDetails.queryParams.date;
    }

    const payload = {
      project_name: projectName,
      project_type: projectType,
      document_version: documentVersion,
      project_date: date || this.project_date,
      project_id: this.project_id,
      sub_module_name: this.sub_module_name,
    };
    this.calculusCommonService.getReport(payload);
  }

}
