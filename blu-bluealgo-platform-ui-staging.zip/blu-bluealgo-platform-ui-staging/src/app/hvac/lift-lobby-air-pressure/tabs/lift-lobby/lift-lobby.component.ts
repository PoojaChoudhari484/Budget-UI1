import {Component, EventEmitter, OnInit, Output} from '@angular/core';
import {Summary} from "../../../../core/models/Summary.model";
import {LocalApiService} from "../../../../core/services/local-api.service";
import { HttpClient } from "@angular/common/http";
import {ActivatedRoute} from "@angular/router";
import * as Highcharts from 'highcharts';
import 'highcharts/highcharts-3d';
import {InputSummary} from "../../../../shared/entities/input-summary";
import {TabStateService} from "../../../service/tab-state.service";

@Component({
    selector: 'app-lift-lobby',
    templateUrl: './lift-lobby.component.html',
    styleUrls: ['./lift-lobby.component.scss'],
    standalone: false
})
export class LiftLobbyComponent implements OnInit {

  FloosLeakage: Array<any> = [
    {value: '0.0000066 - Tight', code: 0.0000066},
    {value: '0.000052 - Average', code: 0.000052},
    {value: '0.00017 - Loose', code: 0.00017},
  ];
  WallLeakage: Array<any> = [
    {value: '0.000014 - Tight', code: 0.000014},
    {value: '0.00011 - Average', code: 0.00011},
    {value: '0.00035 - Loose', code: 0.00035},
  ];
  liftLobbyInputs = [
    {
      name: 'Single Leaf Door 1 (Open)',
      value: '',
      icon: 'assets/images/icons/enterprise.svg',
    },
    {
      name: 'Single Leaf Door 2 (Open)',
      value: '',
      icon: 'assets/images/icons/enterprise.svg',
    },
    {
      name: 'Double Leaf Door 1 (Open)',
      value: '',
      icon: 'assets/images/icons/enterprise.svg',
    },
    {
      name: 'Double Leaf Door 2 (Open)',
      value: '',
      icon: 'assets/images/icons/enterprise.svg',
    },
    {
      name: 'Door Schedule',
      value: '',
      icon: '',
    },
    {
      name: 'Single Leaf Door 1',
      value: '',
      icon: 'assets/images/icons/enterprise.svg',
    },
    {
      name: 'Single Leaf Door 2',
      value: '',
      icon: 'assets/images/icons/enterprise.svg',
    },
    {
      name: 'Double Leaf Door 1',
      value: '',
      icon: 'assets/images/icons/enterprise.svg',
    },
    {
      name: 'Double Leaf Door 2',
      value: '',
      icon: 'assets/images/icons/enterprise.svg',
    },
  ];

  @Output() moveToTab = new EventEmitter<number>();

  summaryText = 'Summary - A';
  summaryType = 'A';
  showInputA = false;
  showInputB = false;
  selectedInputASummary: Summary | null = null;
  selectedInputBSummary: Summary | null = null;

  showInputASummary = true;
  showInputBSummary = false;
  showInput = false;

  activeButtonId: string | null = 'tab-input-a';
  inputDropdownArrowSrc = 'assets/images/icons/down_arrow.svg';
  unitTypes: string[] = ['LPD', 'KLD'];
  selectedUnit: string = 'LPD';
  flushingWaterRequired = 6;

  highChartOptions: Highcharts.Options;
  Highcharts = Highcharts;
  hvacMakeupResponse: any;
  liftLobbyMainResponse: any;
  item_data: string = '';
  floor_area: number = 0;
  perimeter: number = 0;
  slab_to_slab_height: number = 0;
  wall_leakage_factor: number = 0;
  floor_leakage_factor: number = 0;
  factor_safety_leakage_area: number = 0;
  required_pressure_differential: number = 0;

  single_leaf_door1_width: number = 0;
  single_leaf_door1_height: number = 0;
  no_single_leaf_door1_closed: number = 0;

  single_leaf_door2_width: number = 0;
  single_leaf_door2_height: number = 0;
  no_single_leaf_door2_closed: number = 0;

  double_leaf_door1_width: number = 0;
  double_leaf_door1_height: number = 0;
  no_double_leaf_door1_closed: number = 0;

  double_leaf_door2_width: number = 0;
  double_leaf_door2_height: number = 0;
  no_double_leaf_door2_closed: number = 0;

  open_single_leaf_door1_no: number = 0;
  open_single_leaf_door1_msec: number = 0;

  open_single_leaf_door2_no: number = 0;
  open_single_leaf_door2_msec: number = 0;

  open_double_leaf_door1_no: number = 0;
  open_double_leaf_door1_msec: number = 0;

  open_double_leaf_door2_no: number = 0;
  open_double_leaf_door2_msec: number = 0;

  showTable1Summary = true;
  showTable1 = false;
  selectedTable1Summary: Summary | any;

  liftLobbyInputSummaries: any;

  projectName: string = '';
  projectType: string = '';
  documentVersion: string = '';
  date: string = '';
  inputSummariesMain: any[] = [];
  isAddMore: boolean = false;
  selectedInputSummary: any | null = null;
  previous_location = '';

  constructor(
    private apiService: LocalApiService,
    private http: HttpClient,
    private activatedRoute: ActivatedRoute,
    private tabService: TabStateService
  ) {
    this.initializeHighChart();
  }

  ngOnInit(): void {

    this.activatedRoute.queryParams.subscribe((params) => {
      this.projectName = params['projectName'];
      this.projectType = params['projectType'];
      this.documentVersion = params['documentVersion'];
      this.date = params['date'];
    });
    if (!this.projectName) {
      const projectDetailsString = sessionStorage.getItem('PROJECTDETAILS');
      if (projectDetailsString) {
        const projectDetails = JSON.parse(projectDetailsString);
        this.projectName = projectDetails.queryParams.projectName;
        this.projectType = projectDetails.queryParams.projectType;
        this.documentVersion = projectDetails.queryParams.documentVersion;
        this.date = projectDetails.queryParams.date;
      }
    }
    this.liftLobbyInputSummaries = this.updateLiftLobbyInputSummaries(
      null,
      this.liftLobbyInputs,
    );

    this.apiService.post<any>('lift_lobby_table', null).subscribe(
      (response) => {
        this.hvacMakeupResponse = response;
        this.liftLobbyMainResponse = response;

        this.collectInputSummary();
      },
      (error) => {
        console.error('API Error:', error);
      },
    );
  }

  collectInputSummary() {
    this.inputSummariesMain = [];
    for (const [key, value] of Object.entries(this.liftLobbyMainResponse)) {
      let inputSummary: InputSummary = new InputSummary(key, 'N/A',
        'assets/images/icons/enterprise.svg', true);
      this.inputSummariesMain.push(inputSummary);
    }
  }

  toggleInputMain(summary: any) {
    this.showInput = !this.showInput;
    this.selectedInputSummary = this.showInput ? summary : null;
    if (this.showInput) {
      this.liftLobbyMainResponse = this.hvacMakeupResponse;
      this.inputDropdownArrowSrc = 'assets/images/icons/up_arrow.svg';
    } else {
      this.isAddMore = false;
      this.inputDropdownArrowSrc = 'assets/images/icons/down_arrow.svg';
      this.liftLobbyMainResponse = {};
    }
    this.updateInputSummaries();
  }

  updateInputSummaries() {
    this.previous_location = this.selectedInputSummary?.name;

    const data = this.liftLobbyMainResponse?.[this.selectedInputSummary?.name];
    if (data) {
      this.item_data = this.selectedInputSummary?.name;

      this.floor_area = data?.floor_area;
      this.perimeter = data?.perimeter;
      this.slab_to_slab_height = data?.slab_to_slab_height;
      this.wall_leakage_factor = data?.wall_leakage_factor;
      this.floor_leakage_factor = data?.floor_leakage_factor;
      this.factor_safety_leakage_area = data?.factor_safety_leakage_area;
      this.required_pressure_differential = data?.required_pressure_differential;
      this.single_leaf_door1_width = data?.door_schedule?.single_leaf_door1_width;
      this.single_leaf_door1_height = data?.door_schedule?.single_leaf_door1_height;
      this.no_single_leaf_door1_closed = data?.door_schedule?.no_single_leaf_door1_closed;
      this.single_leaf_door2_width = data?.door_schedule?.single_leaf_door2_width;
      this.single_leaf_door2_height = data?.door_schedule?.single_leaf_door2_height;
      this.no_single_leaf_door2_closed = data?.door_schedule?.no_single_leaf_door2_closed;
      this.double_leaf_door1_width = data?.door_schedule?.double_leaf_door1_width;
      this.double_leaf_door1_height = data?.door_schedule?.double_leaf_door1_height;
      this.no_double_leaf_door1_closed = data?.door_schedule?.no_double_leaf_door1_closed;
      this.double_leaf_door2_width = data?.door_schedule?.double_leaf_door2_width;
      this.double_leaf_door2_height = data?.door_schedule?.double_leaf_door2_height;
      this.no_double_leaf_door2_closed = data?.door_schedule?.no_double_leaf_door2_closed;
      this.open_single_leaf_door1_no = data?.open_single_leaf_door1_no;
      this.open_single_leaf_door1_msec = data?.open_single_leaf_door1_msec;
      this.open_single_leaf_door2_no = data?.open_single_leaf_door2_no;
      this.open_single_leaf_door2_msec = data?.open_single_leaf_door2_msec;
      this.open_double_leaf_door1_no = data?.open_double_leaf_door1_no;
      this.open_double_leaf_door1_msec = data?.open_double_leaf_door1_msec;
      this.open_double_leaf_door2_no = data?.open_double_leaf_door2_no;
      this.open_double_leaf_door2_msec = data?.open_double_leaf_door2_msec;


      // keys.forEach((key) => {
      //   (this as any)[key] = data[key] ?? 0;
      // });
    }

    this.initializeHighChart();
    // this.initDoorValue();
  }

  // updateInputSummaries() {
  //   // Map response values to fields
  //   const data = this.liftLobbyMainResponse?.[this.selectedInputSummary?.name];
  //   if (data) {
  //     this.item_data = this.selectedInputSummary?.name;
  //     const keys = [
  //       'floor_area',
  //       'perimeter',
  //       'slab_to_slab_height',
  //       'wall_leakage_factor',
  //       'floor_leakage_factor',
  //       'factor_safety_leakage_area',
  //       'required_pressure_differential',
  //       'single_leaf_door1_width',
  //       'single_leaf_door1_height',
  //       'no_single_leaf_door1_closed',
  //       'single_leaf_door2_width',
  //       'single_leaf_door2_height',
  //       'no_single_leaf_door2_closed',
  //       'double_leaf_door1_width',
  //       'double_leaf_door1_height',
  //       'no_double_leaf_door1_closed',
  //       'double_leaf_door2_width',
  //       'double_leaf_door2_height',
  //       'no_double_leaf_door2_closed',
  //       'open_single_leaf_door1_no',
  //       'open_single_leaf_door1_msec',
  //       'open_single_leaf_door2_no',
  //       'open_single_leaf_door2_msec',
  //       'open_double_leaf_door1_no',
  //       'open_double_leaf_door1_msec',
  //       'open_double_leaf_door2_no',
  //       'open_double_leaf_door2_msec',
  //     ];
  //
  //     keys.forEach((key) => {
  //       (this as any)[key] = data[key] ?? 0;
  //     });
  //   }
  //
  //   this.initializeHighChart();
  //   // this.initDoorValue();
  // }

  addMore() {
    this.previous_location = '';
    this.showInput = true;
    this.isAddMore = true;

    this.item_data = '';
    this.floor_area = 0;
    this.perimeter = 0;
    this.slab_to_slab_height = 0;
    this.wall_leakage_factor = 0;
    this.floor_leakage_factor = 0;
    this.factor_safety_leakage_area = 0;
    this.required_pressure_differential = 0;
    this.single_leaf_door1_width = 0;
    this.single_leaf_door1_height = 0;
    this.no_single_leaf_door1_closed = 0;
    this.single_leaf_door2_width = 0;
    this.single_leaf_door2_height = 0;
    this.no_single_leaf_door2_closed = 0;
    this.double_leaf_door1_width = 0;
    this.double_leaf_door1_height = 0;
    this.no_double_leaf_door1_closed = 0;
    this.double_leaf_door2_width = 0;
    this.double_leaf_door2_height = 0;
    this.no_double_leaf_door2_closed = 0;
    this.open_single_leaf_door1_no = 0;
    this.open_single_leaf_door1_msec = 0;
    this.open_single_leaf_door2_no = 0;
    this.open_single_leaf_door2_msec = 0;
    this.open_double_leaf_door1_no = 0;
    this.open_double_leaf_door1_msec = 0;
    this.open_double_leaf_door2_no = 0;
    this.open_double_leaf_door2_msec = 0;
  }

  initializeHighChart(): void {
    // this.item_data = this.selectedInputSummary?.name;

    let airFlowThroughLeakage =
      this.liftLobbyMainResponse?.[this.item_data]?.airflow_through_leakage ??
      0;
    let airFlowThroughOpenDoor =
      this.liftLobbyMainResponse?.[this.item_data]?.airflow_open_doors ?? 0;
    let totalRequiredAirflow =
      this.liftLobbyMainResponse?.[this.item_data]
        ?.total_required_airflow_mps ?? 0;
    let totalRequiredAirflowCFM =
      this.liftLobbyMainResponse?.[this.item_data]
        ?.total_required_airflow_cfm ?? 0;

    airFlowThroughLeakage = Number(airFlowThroughLeakage);
    airFlowThroughOpenDoor = Number(airFlowThroughOpenDoor);
    totalRequiredAirflow = Number(totalRequiredAirflow);
    totalRequiredAirflowCFM = Number(totalRequiredAirflowCFM);

    this.highChartOptions = {
      chart: {
        marginTop: 45,
        type: 'pie',
        backgroundColor: 'transparent',
        options3d: {
          enabled: true,
          alpha: 55,
          beta: 0,
        },
      },
      title: {
        text: '',
      },
      legend: {
        enabled: true,
        align: 'center',
        verticalAlign: 'top',
        y: 0,
        itemStyle: {
          color: '#333',
        },
      },
      plotOptions: {
        pie: {
          minSize: 0, // Ensures even small values are visible
          ignoreHiddenPoint: false, // Ensures small values are not ignored
          showInLegend: true,
          // colors: ['#19FB8B', '#FF645B'],
          innerSize: 90,
          depth: 40,
          dataLabels: {
            enabled: false,
            format: '{point.name}: {point.percentage:.1f}%',
            style: {
              color: 'white',
              fontWeight: 'bold',
            },
          },
        },
      },
      series: [
        {
          type: 'pie',
          // name: 'Waste',
          data: [
            {name: `Airflow Through Leakage (Ql)`, y: airFlowThroughLeakage},
            {
              name: `Airflow Through Open Doors (Qod)`,
              y: airFlowThroughOpenDoor,
            },
            {
              name: `Total Required Airflow(Ql + Qod)`,
              y: totalRequiredAirflow,
            },
            {name: `Total Required Airflow(CFM)`, y: totalRequiredAirflowCFM},
          ],
          tooltip: {
            pointFormat: '{point.name}: {point.percentage:.1f}%',
          },
        },
      ],
      credits: {
        enabled: false,
      },
    };
  }

  toggleTable1(summary: any) {
    this.showTable1 = !this.showTable1;
    this.selectedTable1Summary = this.showTable1 ? summary : null;
    if (this.selectedTable1Summary) {
    }
    if (this.showTable1) {
      this.inputDropdownArrowSrc = 'assets/images/icons/up_arrow.svg';
      this.summaryText = '';
      // this.initDoorValue();
    } else {
      this.inputDropdownArrowSrc = 'assets/images/icons/down_arrow.svg';
      this.summaryText = 'Summary - B';
    }
    this.initializeHighChart();
  }

  // initDoorValue() {
  //   const data = this.liftLobbyMainResponse[this.selectedInputSummary?.name];
  //   this.open_single_leaf_door1_no = this.open_single_leaf_door1_no ?? data?.open_single_leaf_door1_no;
  //   this.open_single_leaf_door2_no = this.open_single_leaf_door2_no ?? data?.open_single_leaf_door2_no;
  //   this.open_double_leaf_door1_no = this.open_double_leaf_door1_no ?? data?.open_double_leaf_door1_no;
  //   this.open_double_leaf_door2_no = this.open_double_leaf_door2_no ?? data?.open_double_leaf_door2_no;
  //
  //   this.single_leaf_door1_width = this.single_leaf_door1_width ?? data?.door_schedule?.single_leaf_door1_width;
  //   this.single_leaf_door1_height = this.single_leaf_door1_height ?? data?.door_schedule?.single_leaf_door1_height;
  //   this.no_single_leaf_door1_closed = this.no_single_leaf_door1_closed ?? data?.door_schedule?.no_single_leaf_door1_closed;
  //
  //   this.single_leaf_door2_width = this.single_leaf_door2_width ?? data?.door_schedule?.single_leaf_door2_width;
  //   this.single_leaf_door2_height = this.single_leaf_door2_height ?? data?.door_schedule?.single_leaf_door2_height;
  //   this.no_single_leaf_door2_closed = this.no_single_leaf_door2_closed ?? data?.door_schedule?.no_single_leaf_door2_closed;
  //
  //   this.double_leaf_door1_width = this.double_leaf_door1_width ?? data?.door_schedule?.double_leaf_door1_width;
  //   this.double_leaf_door1_height = this.double_leaf_door1_height ?? data?.door_schedule?.double_leaf_door1_height;
  //   this.no_double_leaf_door1_closed = this.no_double_leaf_door1_closed ?? data?.door_schedule?.no_double_leaf_door1_closed;
  //
  //   this.double_leaf_door2_width = this.double_leaf_door2_width ?? data?.door_schedule?.double_leaf_door2_width;
  //   this.double_leaf_door2_height = this.double_leaf_door2_height ?? data?.door_schedule?.double_leaf_door2_height;
  //   this.no_double_leaf_door2_closed = this.no_double_leaf_door2_closed ?? data?.door_schedule?.no_double_leaf_door2_closed;
  // }

  updateLiftLobbyInputSummaries(response: any, summaryToUpdate: any) {
    const keyMap: { [key: string]: string } = {
      'Single Leaf Door 1 (Open)': 'Single Leaf Door 1 (Open)',
      'Single Leaf Door 2 (Open)': 'Single Leaf Door 2 (Open)',
      'Double Leaf Door 1 (Open)': 'Double Leaf Door 1 (Open)',
      'Double Leaf Door 2 (Open)': 'Double Leaf Door 2 (Open)',
      'Single Leaf Door 1': 'Single Leaf Door 1',
      'Single Leaf Door 2': 'Single Leaf Door 2',
      'Double Leaf Door 1': 'Double Leaf Door 1',
      'Double Leaf Door 2': 'Double Leaf Door 2',
    };

    return summaryToUpdate.map((item: { name: string | number }) => {
      const key = keyMap[item.name];

      // Find the matching input details
      const inputDetails = response?.inputs?.find(
        (input: any) => input.flow_fixture === key,
      );

      if (response) {
        const value = response.water_usage[key];

        return {
          ...item,
          value: value?.water_usage,
          daily_use: inputDetails.daily_use,
          igbc: inputDetails.igbc,
          usage_time: inputDetails.usage_time,
          operational_days: response?.op_days,
        };
      }

      return {
        ...item,
        value: '0',
        'Domestic (LPD)': 0,
        'Flushing (LPD)': 0,
        'Gross Water Demand': 0,
        'Total Population': 0,
        no_of_units: 0,
        daily_use: 0,
        igbc: 0,
        usage_time: 0,
        operational_days: 0,
      };
    });
  }

  deleteSummaryItem(item: any) {
    this.toggleInputMain(item);
    this.apiService.post('delete_lift_lobby', {
      item_data: item?.name
    }).subscribe((response: any) => {
      this.hvacMakeupResponse = response;
      this.liftLobbyMainResponse = response;
      this.collectInputSummary();
      this.isAddMore = false;
      this.tabService.changeLobby();
    })
  }

  onLiftLobbyInputChange() {
    const name = this.item_data;
    const payload: any = {
      inputs: [
        {
          item_data: this.item_data,
          floor_area: this.floor_area,
          perimeter: this.perimeter,
          slab_to_slab_height: this.slab_to_slab_height,
          wall_leakage_factor: Number(this.wall_leakage_factor),
          floor_leakage_factor: Number(this.floor_leakage_factor),
          factor_safety_leakage_area: this.factor_safety_leakage_area,
          required_pressure_differential: this.required_pressure_differential,

          single_leaf_door1_width: this.single_leaf_door1_width,
          single_leaf_door1_height: this.single_leaf_door1_height,
          no_single_leaf_door1_closed: this.no_single_leaf_door1_closed,

          single_leaf_door2_width: this.single_leaf_door2_width,
          single_leaf_door2_height: this.single_leaf_door2_height,
          no_single_leaf_door2_closed: this.no_single_leaf_door2_closed,

          double_leaf_door1_width: this.double_leaf_door1_width,
          double_leaf_door1_height: this.double_leaf_door1_height,
          no_double_leaf_door1_closed: this.no_double_leaf_door1_closed,

          double_leaf_door2_width: this.double_leaf_door2_width,
          double_leaf_door2_height: this.double_leaf_door2_height,
          no_double_leaf_door2_closed: this.no_double_leaf_door2_closed,

          open_single_leaf_door1_no: this.open_single_leaf_door1_no,
          open_single_leaf_door1_msec: this.open_single_leaf_door1_msec,
          open_single_leaf_door2_no: this.open_single_leaf_door2_no,
          open_single_leaf_door2_msec: this.open_single_leaf_door2_msec,

          open_double_leaf_door1_no: this.open_double_leaf_door1_no,
          open_double_leaf_door1_msec: this.open_double_leaf_door1_msec,
          open_double_leaf_door2_no: this.open_double_leaf_door2_no,
          open_double_leaf_door2_msec: this.open_double_leaf_door2_msec,
        },
      ],
    };

    if (this.previous_location) {
      if (this.previous_location.trim() != payload?.item_data?.trim()) {
        payload.inputs[0].previous_location = this.previous_location;
      }
    }

    this.apiService.post<any>('lift_lobby_table', payload).subscribe(
      (response) => {
        this.hvacMakeupResponse = response;
        this.liftLobbyMainResponse = response;

        this.collectInputSummary();
        this.initializeHighChart();
        this.tabService.changeLobby();

        if (this.selectedInputSummary == null) {
          let obj: any = {};
          obj.name = name;
          this.selectedInputSummary = {...obj}
        }
        this.updateInputSummaries();
      },
      (error) => {
        console.error('API Error:', error);
      },
    );
  }

  submit() {
    const payload = {
      project_name: this.projectName,
      project_type: this.projectType,
      document_version: this.documentVersion,
      project_date: this.date,
      project_id: '1',
      sub_module_name: 'lift_lobby',
    };

    const url = `https://dev-designcalculus.bluealgo.com/reports_page`;
    this.http
      .post(url, payload, {
        params: {isWithoutBase: 'yes'},
        responseType: 'text',
      })
      .subscribe((response) => {
        window.location.href = url;
      });
  }

  moveNext(): void {
    this.moveToTab.emit(1);
  }

}
