import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { StaircaseComponent } from './staircase-air-pressure/tabs/staircase/staircase.component';
import { HvacSummaryComponent } from './hvac-summary/hvac-summary.component';
import { FormsModule } from '@angular/forms';
import { LiftWellComponent } from './liftwell-air-pressure/tabs/lift-well/lift-well.component';
import { HighchartsChartModule } from 'highcharts-angular';
import { BasementVentilationComponent } from './basement-ventilation/basement-ventilation.component';
import { ProjectDetailsComponent } from './project-details/project-details.component';
import { HvacSubPageComponent } from './hvac-sub-page/hvac-sub-page.component';
import { SharedCCModule } from '../shared-cc/shared-cc.module';
import { BrowserModule } from '@angular/platform-browser';
import { BrowserAnimationsModule } from '@angular/platform-browser/animations';
import { MatProgressBarModule } from '@angular/material/progress-bar';
import { MatAngularModule } from '../mat-angular/mat-angular.module';
import { AirPressureDropComponent } from './air-pressure-drop/air-pressure-drop.component';
import {ElectricalModule} from "../electrical/electrical.module";
import {NgSelectModule} from "@ng-select/ng-select";
import { ExpansionTankComponent } from './expansion-tank/expansion-tank.component';
import { StaircaseAirPressureComponent } from './staircase-air-pressure/staircase-air-pressure.component';
import {MatTabsModule} from "@angular/material/tabs";
import { StairAirPressureComponent } from './staircase-air-pressure/tabs/stair-air-pressure/stair-air-pressure.component';
import { LiftwellAirPressureComponent } from './liftwell-air-pressure/liftwell-air-pressure.component';
import { LiftAirPressureComponent } from './liftwell-air-pressure/tabs/lift-air-pressure/lift-air-pressure.component';
import { LiftLobbyAirPressureComponent } from './lift-lobby-air-pressure/lift-lobby-air-pressure.component';
import { LobbyAirPressureComponent } from './lift-lobby-air-pressure/tabs/lobby-air-pressure/lobby-air-pressure.component';
import {IgbcModule} from "../igbc/igbc.module";
import { LiftLobbyComponent } from './lift-lobby-air-pressure/tabs/lift-lobby/lift-lobby.component';
import {
  HvacCommonServicesVentilationComponent
} from "./hvac-common-services-ventilation/hvac-common-services-ventilation.component";

@NgModule({
  declarations: [
    StaircaseComponent,
    LiftWellComponent,
    HvacSummaryComponent,
    BasementVentilationComponent,
    ProjectDetailsComponent,
    HvacSubPageComponent,
    AirPressureDropComponent,
    ExpansionTankComponent,
    StaircaseAirPressureComponent,
    StairAirPressureComponent,
    LiftwellAirPressureComponent,
    LiftAirPressureComponent,
    LiftLobbyAirPressureComponent,
    LobbyAirPressureComponent,
    LiftLobbyComponent,
    HvacCommonServicesVentilationComponent
  ],
  imports: [CommonModule, FormsModule, SharedCCModule, MatAngularModule, HighchartsChartModule, BrowserModule,
    BrowserAnimationsModule,
    MatProgressBarModule, ElectricalModule, NgSelectModule, MatTabsModule, IgbcModule],
})
export class HvacModule {}
