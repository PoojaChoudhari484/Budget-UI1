import {ChangeDetectorRef, Component, EventEmitter, OnInit, Output} from '@angular/core';
import {InputSummary} from "../../../../shared/entities/input-summary";
import {LocalApiService} from "../../../../core/services/local-api.service";
import {CalculusCommonService} from "../../../../core/services/calculus-common.service";
import {TabStateService} from "../../../service/tab-state.service";
import {HttpClient} from "@angular/common/http";
import {ActivatedRoute} from "@angular/router";


export interface additionalPayload {
  location: string,
  pressure: number
  liftwell_location: string
}

@Component({
    selector: 'app-lift-air-pressure',
    templateUrl: './lift-air-pressure.component.html',
    styleUrls: ['./lift-air-pressure.component.scss'],
    standalone: false
})
export class LiftAirPressureComponent implements OnInit {


  tableDataPairList: any [] = [
    {header: 'Location', key: 'location', unit: undefined, isShow: undefined},
    {header: 'Type of Duct', key: 'type_of_duct', unit: undefined, isShow: undefined},
    {header: 'Tag', key: 'tag', unit: undefined, isShow: undefined},

    {header: 'Duct Width 1', key: 'duct_width_mm1', unit: 'mm', isShow: undefined},
    {header: 'Duct Height 1', key: 'duct_height_mm1', unit: 'mm', isShow: undefined},
    {header: 'Duct Width 2', key: 'duct_width_mm2', unit: 'mm', isShow: undefined},
    {header: 'Duct Height 2', key: 'duct_height_mm2', unit: 'mm', isShow: undefined},

    {header: 'Duct Width 1', key: 'duct_width_inch1', unit: 'inch', isShow: undefined},
    {header: 'Duct Height 1', key: 'duct_height_inch1', unit: 'inch', isShow: undefined},
    {header: 'Duct Width 2', key: 'duct_width_inch2', unit: 'inch', isShow: undefined},
    {header: 'Duct Height 2', key: 'duct_height_inch2', unit: 'inch', isShow: undefined},

    {header: 'Air Quantity', key: 'air_quantity_cfm', unit: 'cfm', isShow: undefined},
    {header: 'Length', key: 'length_m', unit: 'm', isShow: undefined},
    {header: 'Length', key: 'length_ft', unit: 'ft', isShow: undefined},
    {header: 'Air Velocity', key: 'air_velocity_fpm', unit: 'fpm', isShow: undefined},
    {header: 'Friction Loss/100 ft of Equivalent Length', key: 'friction_loss', unit: 'wg', isShow: undefined},
    {header: 'Fitting Number', key: 'fitting_number', unit: undefined, isShow: undefined},
    {
      header: 'Reducer Tee Or Fittings In Line',
      key: 'reducer_tee_or_fittings_in_line',
      unit: undefined,
      isShow: undefined
    },
    {header: 'Velocity Pressure Hv1', key: 'velocity_pressure_hv1_in_wg', unit: 'wg', isShow: undefined},
    {header: 'Velocity Pressure Hv2', key: 'velocity_pressure_hv2_in_wg', unit: 'wg', isShow: undefined},
    {header: 'Equivalent Length of Elbows', key: 'equivalent_length_of_elbows_ft', unit: 'ft', isShow: undefined},

    {header: 'Friction Drop in VCD', key: 'friction_drop_in_vcd', unit: undefined, isShow: true},
    {header: 'Friction Drop Motorised Damper', key: 'friction_drop_motorised_damper', unit: undefined, isShow: true},
    {header: 'Friction Drop Fire Damper', key: 'friction_drop_fire_damper', unit: undefined, isShow: true},
    {header: 'Friction Drop Tee', key: 'friction_drop_tee', unit: undefined, isShow: true},
    {header: 'Friction Drop Reducer', key: 'friction_drop_reducer', unit: undefined, isShow: true},
    {header: 'Static Regain Expander', key: 'static_regain_expander', unit: undefined, isShow: true},
    {header: 'Equilen 30deg Elbow', key: 'equilen_30deg_elbow', unit: undefined, isShow: true},
    {header: 'Equilen 45deg Elbow', key: 'equilen_45deg_elbow', unit: undefined, isShow: true},
    {header: 'Equilen 60deg Elbow', key: 'equilen_60deg_elbow', unit: undefined, isShow: true},
    {header: 'Equilen 90deg Elbow', key: 'equilen_90deg_elbow', unit: undefined, isShow: true},
    {header: 'Equilen 30deg Elbow Dup', key: 'equilen_30deg_elbow_dup', unit: undefined, isShow: true},
    {header: 'Equilen 45deg Elbow Dup', key: 'equilen_45deg_elbow_dup', unit: undefined, isShow: true},
    {header: 'Equilen 60deg Elbow Dup', key: 'equilen_60deg_elbow_dup', unit: undefined, isShow: true},
    {header: 'Equilen 90deg Elbow Dup', key: 'equilen_90deg_elbow_dup', unit: undefined, isShow: true},
    {header: 'Equilen Len of Rec Square Elbow', key: 'equi_len_of_rec_square_elbow', unit: undefined, isShow: true},
    {
      header: 'Equilen Len of Rec Square Elbow Dup',
      key: 'equi_len_of_rec_square_elbow_dup',
      unit: undefined,
      isShow: true
    },

    {header: 'Vc Damper', key: 'vc_damper', unit: undefined, isShow: true},
    {header: 'Motorised Damper', key: 'motorised_damper', unit: undefined, isShow: true},
    {header: 'Fire Damper', key: 'fire_damper', unit: undefined, isShow: true},
    {header: 'Tee', key: 'tee', unit: undefined, isShow: true},
    {header: 'Reducer', key: 'reducer', unit: undefined, isShow: true},
    {header: 'Expander', key: 'expander', unit: undefined, isShow: true},

    {header: 'Elbow 30deg Same Plane', key: 'elbow_30deg_same_plane', unit: undefined, isShow: true},
    {header: 'Elbow 45deg Same Plane', key: 'elbow_45deg_same_plane', unit: undefined, isShow: true},
    {header: 'Elbow 60deg Same Plane', key: 'elbow_60deg_same_plane', unit: undefined, isShow: true},
    {header: 'Elbow 90deg Same Plane', key: 'elbow_90deg_same_plane', unit: undefined, isShow: true},
    {header: 'Equilen 30deg Plane Changed', key: 'equilen_30deg_plane_changed', unit: undefined, isShow: true},
    {header: 'Equilen 45deg Plane Changed', key: 'equilen_45deg_plane_changed', unit: undefined, isShow: true},
    {header: 'Equilen 60deg Plane Changed', key: 'equilen_60deg_plane_changed', unit: undefined, isShow: true},
    {header: 'Equilen 90deg Plane Changed', key: 'equilen_90deg_plane_changed', unit: undefined, isShow: true},
    {header: 'Rec Square Elbow Same Plane', key: 'rec_square_elbow_same_plane', unit: undefined, isShow: true},
    {header: 'Rec Square Elbow Plane Changed', key: 'rec_square_elbow_plane_changed', unit: undefined, isShow: true},

    {header: 'No of Vanes', key: 'no_of_vanes', unit: undefined, isShow: true},
    {header: 'R/D', key: 'rd', unit: undefined, isShow: true},
    {header: 'W/D Or Number of Vanes', key: 'wd_or_number_of_vanes', unit: undefined, isShow: true},
    {header: 'Final L/D', key: 'final_ld', unit: undefined, isShow: true},
    {header: 'L/D Unvaned', key: 'ld_unvaned', unit: undefined, isShow: true},
    {header: 'L/D Vaned', key: 'ld_vaned', unit: undefined, isShow: true},
    {
      header: 'Pressure Loss In Elbows Reducers Tree Vcd A',
      key: 'pressure_loss_in_elbows_reducers_tree_vcd_a_wg',
      unit: 'wg',
      isShow: undefined
    },

    {header: 'Straight Duct Pressure Loss B', key: 'straight_duct_pressure_loss_b_wg', unit: 'wg', isShow: undefined},
    {header: 'Remarks', key: 'remarks', unit: undefined, isShow: undefined},

    {header: 'Interior Surface Roughness', key: 'interior_surface_roughness_feet', unit: 'feet', isShow: true},
    {
      header: 'Equivalent Duct Diameter Rect Duct',
      key: 'equivalent_duct_diameter_rect_duct_inch',
      unit: 'inch',
      isShow: true
    },
    {header: 'Pressure Drop', key: 'pressure_drop_ich', unit: 'in/100', isShow: true},

    {header: 'Absolute Roughness', key: 'absolute_roughness_feet', unit: 'feet', isShow: true},
    {header: 'Hydraulic Diameter', key: 'hydraulic_diameter_inch', unit: 'inch', isShow: true},
    {header: 'Reynolds Number', key: 'reynolds_number', unit: undefined, isShow: true},
    {header: 'F', key: 'f', unit: undefined, isShow: true},
    {header: 'Final F', key: 'final_f', unit: undefined, isShow: true},
    {header: 'Pressure Drop', key: 'pressure_drop_inch', unit: 'inch/100', isShow: true},

    {header: 'Unknown Data1', key: 'unknown_data1', unit: undefined, isShow: true},
    {header: 'Unknown Data2', key: 'unknown_data2', unit: undefined, isShow: true},
  ];
  highlightColumns: string[] = ['pressure_loss_in_elbows_reducers_tree_vcd_a_wg', 'straight_duct_pressure_loss_b_wg'];
  response: any = {};
  summaryResponse: any [] = [];
  additionalResponse: any[] = [];
  payload: any = {
    duct_width_mm1: 0,
    duct_height_mm1: 0,
    location: '',
    type_of_duct: '',
    duct_width_mm2: 0,
    duct_height_mm2: 0,
    air_quantity_cfm: 0,
    length_m: 0,
    fitting_number: 0,
    reducer_tee_or_fittings_in_line: 0,
    tee: 0,
    reducer: 0,
    rec_square_elbow_same_plane: 0,
    rec_square_elbow_plane_changed: 0,
    vc_damper: 0,
    motorised_damper: 0,
    fire_damper: 0,
    interior_surface_roughness_feet: 0,
    absolute_roughness_feet: 0,
    liftwell_location: '',
  }
  additionalPayload: additionalPayload;
  isNaN = isNaN;
  inputSummaries: InputSummary[] = [];
  inputSummariesNormal: InputSummary[] = [];
  inputSummariesAdditional: InputSummary[] = [];
  selectedInputSummary: any | null = null;
  selectedInputSummaryChild: any | null = null;
  selectedInputSummaryAdditional: any | null = null;
  showInput = false;
  showInputChild = false;
  isAddMoreNormal = false;
  isAddMoreAdditional = false;
  isShowAdditional = false;
  @Output() moveToTab = new EventEmitter<number>();
  inputDropdownArrowSrc = 'assets/images/icons/down_arrow.svg';
  inputDropdownArrowSrcChild = 'assets/images/icons/down_arrow.svg';
  fittingNumberOptions = [
    {label: '1. Straight', index: 1},
    {label: '2. VC Damper', index: 2},
    {label: '3. Motorised Damper', index: 3},
    {label: '4. Fire Damper', index: 4},
    {label: '5. Tee', index: 5},
    {label: '6. Reducer', index: 6},
    {label: '7. Expander', index: 7},
    {label: '8. 30 degree Elbow Same Plane', index: 8},
    {label: '9. 45 degree Elbow Same Plane', index: 9},
    {label: '10. 60 degree Elbow Same Plane', index: 10},
    {label: '11. 90 degree Elbow Same Plane', index: 11},
    {label: '12. 30 degree Elbow Plane Changed', index: 12},
    {label: '13. 45 degree Elbow Plane Changed', index: 13},
    {label: '14. 60 degree Elbow Plane Changed', index: 14},
    {label: '15. 90 degree Elbow Plane Changed', index: 15},
    {label: '16. Rec Square Elbow Same Plane', index: 16},
    {label: '17. Rec Square Elbow Plane Changed', index: 17}
  ];
  ductWidthUnit1: string = 'mm';
  ductWidthUnit2: string = 'mm';
  ductHeightUnit1: string = 'mm';
  ductHeightUnit2: string = 'mm';
  lengthUnit: string = 'm';
  ductWidth1mm: number = 0;
  ductWidth2mm: number = 0;
  ductHeight1mm: number = 0;
  ductHeight2mm: number = 0;
  lengthM: number = 0;
  ductWidth1: number = 0;
  ductWidth2: number = 0;
  ductHeight1: number = 0;
  ductHeight2: number = 0;
  length: number = 0;
  mmToInch = 1 / 25.4;
  inchToMm = 25.4;
  ftToM = 0.3048;
  mToFt = 1 / this.ftToM;
  safetyFactor: number = 0;
  hiddenCollection: Map<string, number[]> = new Map();
  selectedUnit: string = 'wg';
  previous_location: string = '';
  project_name: string;
  project_id: string;
  project_date: string;
  sub_module_name: string;

  constructor(
    private api: LocalApiService,
    private calculusCommonService: CalculusCommonService,
    private cd: ChangeDetectorRef,
    private tabService: TabStateService,
    private http: HttpClient,
    private activatedRoute: ActivatedRoute,

  ) {
  }

  ngOnInit(): void {
    this.project_name = 'Centrona';
    this.project_id = '1';
    this.project_date = '2021-09-01';
    this.sub_module_name = 'lift_well';

    this.getResponse();
    this.tabService.tabChange$.subscribe(() => {
      this.getResponse();
    });
  }

  private getResponse() {
    this.api.post('liftwell_air_pressure', null).subscribe((res: any) => {
      console.log(res)
      this.response = res;
      this.collectInputSummary();
    })
  }

  collectInputSummary() {
    this.inputSummaries = [];

    for (const [key, value] of Object.entries(this.response)) {
      let inputSummary: InputSummary = new InputSummary(key, 'N/A',
        'assets/images/icons/enterprise.svg', true);
      this.inputSummaries.push(inputSummary);
      const val: any = value;
    }
    this.cd.detectChanges();
  }

  collectChildInputSummary() {
    this.inputSummariesNormal = [];
    this.inputSummariesAdditional = [];

    this.summaryResponse = [];
    this.additionalResponse = [];

    const val: any = this.response?.[this.selectedInputSummary?.name];
    val?.air_pressure_locations?.forEach((retail: any, i: number) => {
      let inputSummary: InputSummary = new InputSummary(retail.location, 'N/A',
        'assets/images/icons/enterprise.svg', true);
      this.inputSummariesNormal.push(inputSummary);
    })

    val?.additional_component_data?.forEach((retail: any, i: number) => {
      let inputSummary: InputSummary = new InputSummary(retail.location, 'N/A',
        'assets/images/icons/enterprise.svg', true);
      this.inputSummariesAdditional.push(inputSummary);
    })

    val?.air_pressure_locations?.forEach((air: any, i: number) => {
      this.summaryResponse.push(air);
    })

    val?.additional_component_data?.forEach((air: any, i: number) => {
      this.additionalResponse.push(air);
    })

  }

  onFittingChange(value: any) {
    if (value) {
      this.payload.reducer_tee_or_fittings_in_line = value?.label;
    }
  }

  toggleInputChild(summary: any, type?: string) {
    this.showInputChild = !this.showInputChild;
    this.selectedInputSummaryChild = this.showInputChild ? summary : null;
    if (this.showInputChild) {
      if (type === 'additional') this.isShowAdditional = true;
      else this.isShowAdditional = false;
      this.inputDropdownArrowSrcChild = 'assets/images/icons/up_arrow.svg';
    } else {
      this.isShowAdditional = false;
      this.isAddMoreNormal = false;
      this.isAddMoreAdditional = false;
      this.inputDropdownArrowSrcChild = 'assets/images/icons/down_arrow.svg';
    }

    this.initInputObj(type);
  }

  initInputObj(type?: string) {

    if (type === 'additional') {
      let findObj: any = this.additionalResponse?.find((f: any) => f?.location === this.selectedInputSummaryChild?.name);

      this.additionalPayload = {
        location: findObj?.location ?? '',
        pressure: findObj?.pressure ?? 0,
        liftwell_location: this.selectedInputSummary?.name
      }
      if (this.additionalPayload.location) {
        this.previous_location = this.additionalPayload.location;
      }

    } else {
      let findObj: any = this.response?.[this.selectedInputSummary?.name]?.air_pressure_locations?.find((f: any) => f.location === this.selectedInputSummaryChild?.name);

      // if (findObj.location === 'this.location') findObj.location = '';
      this.payload = {
        duct_width_mm1: findObj?.duct_width_mm1 ?? 0,
        duct_height_mm1: findObj?.duct_height_mm1 ?? 0,
        location: findObj?.location ?? '',
        type_of_duct: findObj?.type_of_duct ?? '',
        duct_width_mm2: findObj?.duct_width_mm2 ?? 0,
        duct_height_mm2: findObj?.duct_height_mm2 ?? 0,
        air_quantity_cfm: findObj?.air_quantity_cfm ?? 0,
        length_m: findObj?.length_m ?? 0,
        fitting_number: findObj?.fitting_number ?? 0,
        reducer_tee_or_fittings_in_line: findObj?.reducer_tee_or_fittings_in_line ?? 0,
        tee: findObj?.tee ?? 0,
        reducer: findObj?.reducer ?? 0,
        rec_square_elbow_same_plane: findObj?.rec_square_elbow_same_plane ?? 0,
        rec_square_elbow_plane_changed: findObj?.rec_square_elbow_plane_changed ?? 0,
        vc_damper: findObj?.vc_damper ?? 0,
        motorised_damper: findObj?.motorised_damper ?? 0,
        fire_damper: findObj?.fire_damper ?? 0,
        interior_surface_roughness_feet: findObj?.interior_surface_roughness_feet ?? 0,
        absolute_roughness_feet: findObj?.absolute_roughness_feet ?? 0,
        liftwell_location: this.selectedInputSummary?.name ?? ''
      }
      this.ductWidth1 = findObj?.duct_width_mm1 ?? 0;
      this.ductWidth2 = findObj?.duct_width_mm2 ?? 0;
      this.ductHeight1 = findObj?.duct_height_mm1 ?? 0;
      this.ductHeight2 = findObj?.duct_height_mm2 ?? 0;
      this.length = findObj?.length_m ?? 0;

      if (this.payload.location) {
        this.previous_location = this.payload.location;
      }
    }
  }

  toggleInput(summary: any) {
    this.showInput = !this.showInput;
    this.selectedInputSummary = this.showInput ? summary : null;
    if (this.showInput) {
      // this.collectChildInput();
      this.safetyFactor = this.response?.[this.selectedInputSummary?.name]?.safety_factor;
      this.inputDropdownArrowSrc = 'assets/images/icons/up_arrow.svg';
    } else {
      // if (this.isAdditional) {
      //   this.additionalResponse = this.additionalResponse?.filter((s: any) => !s.isNew);
      // } else {
      //   this.summaryResponse.data = this.summaryResponse.data?.filter((s: any) => !s.isNew);
      // }
      this.isAddMoreNormal = false;
      this.isAddMoreAdditional = false;
      this.inputDropdownArrowSrc = 'assets/images/icons/down_arrow.svg';
    }
    this.collectChildInputSummary();
    // this.initInputObj();

  }

  addMore(type: string) {
    this.showInputChild = true;
    this.previous_location = '';
    if (type === 'additional') {
      this.isAddMoreAdditional = true;
      this.additionalPayload = {
        location: '',
        pressure: 0,
        liftwell_location: this.selectedInputSummary?.name
      }
    } else {
      this.isAddMoreNormal = true;
      this.payload = {
        duct_width_mm1: 0,
        duct_height_mm1: 0,
        location: '',
        type_of_duct: '',
        duct_width_mm2: 0,
        duct_height_mm2: 0,
        air_quantity_cfm: 0,
        length_m: 0,
        fitting_number: 0,
        reducer_tee_or_fittings_in_line: 0,
        tee: 0.35,
        reducer: 1.04,
        rec_square_elbow_same_plane: 15,
        rec_square_elbow_plane_changed: 15,
        vc_damper: 1.20,
        motorised_damper: 0.52,
        fire_damper: 0.52,
        interior_surface_roughness_feet: 0,
        absolute_roughness_feet: 0.0005,
        liftwell_location: this.selectedInputSummary?.name
      }
      this.ductWidth1 = 0;
      this.ductWidth2 = 0;
      this.ductHeight1 = 0;
      this.ductHeight2 = 0;
      this.length = 0;
    }
  }

  deleteSummaryItem(item: any, type: string) {

    // this.toggleInputChild(item, type);

    if (type === 'additional') {
      let payload = {
        location: item?.name,
        liftwell_location: this.selectedInputSummary?.name,
      }

      this.api.post('delete_liftwell_additional_component', payload).subscribe((res: any) => {
        this.response = res;
        // this.additionalResponse = [];
        // this.response?.[this.selectedInputSummary?.name]?.additional_component_data?.forEach((air: any, i: number) => {
        //   this.additionalResponse.push(air);
        // })
        this.collectInputSummary();
        this.collectChildInputSummary();
      })
    } else {
      let findObj: any = this.response?.[this.selectedInputSummary?.name]?.air_pressure_locations?.find((f: any) => f.location === item?.name);

      let payload = {
        location: item?.name,
        type_of_duct: findObj?.type_of_duct,
        liftwell_location: this.selectedInputSummary?.name,
      }

      this.api.post('delete_liftwell_air_pressure', payload).subscribe((res: any) => {
        this.response = res;
        this.collectInputSummary();
        this.collectChildInputSummary();
      })
    }
  }

  setPayload(): any {
    let payload: any;
    if (this.isAddMoreAdditional) {
      payload = {
        additional_components: [
          {
            location: this.additionalPayload?.location,
            pressure: this.additionalPayload?.pressure
          }],
        liftwell_location: this.selectedInputSummary?.name
      }
      if (this.previous_location) {
        if (this.previous_location.trim() != this.additionalPayload?.location.trim()) {
          payload.previous_location = this.previous_location;
        }
      }

    } else {
      let ductWidth1 = 0;
      if (this.ductWidthUnit1 === 'mm') {
        ductWidth1 = this.ductWidth1;
      } else {
        if (!this.ductWidth1mm) ductWidth1 = (this.ductWidth1 ?? 0) * this.inchToMm;
        else ductWidth1 = this.ductWidth1mm;
      }

      let ductHeight1 = 0;
      if (this.ductHeightUnit1 === 'mm') {
        ductHeight1 = this.ductHeight1;
      } else {
        if (!this.ductHeight1mm) ductHeight1 = (this.ductHeight1 ?? 0) * this.inchToMm;
        else ductHeight1 = this.ductHeight1mm;
      }

      let ductWidth2 = 0;
      if (this.ductWidthUnit2 === 'mm') {
        ductWidth2 = this.ductWidth2;
      } else {
        if (!this.ductWidth2mm) ductWidth2 = (this.ductWidth2 ?? 0) * this.inchToMm;
        else ductWidth2 = this.ductWidth2mm;
      }

      let ductHeight2 = 0;
      if (this.ductHeightUnit2 === 'mm') {
        ductHeight2 = this.ductHeight2;
      } else {
        if (!this.ductHeight2mm) ductHeight2 = (this.ductHeight2 ?? 0) * this.inchToMm;
        else ductHeight2 = this.ductHeight2mm;
      }

      let length = 0;
      if (this.lengthUnit === 'm') {
        length = this.length;
      } else {
        if (!this.lengthM) length = (this.length ?? 0) * this.inchToMm;
        else length = this.lengthM;
      }

      payload = {
        duct_width_mm1: ductWidth1,
        duct_height_mm1: ductHeight1,
        location: this.payload?.location ?? '',
        type_of_duct: this.payload?.type_of_duct ?? '',
        duct_width_mm2: ductWidth2,
        duct_height_mm2: ductHeight2,
        air_quantity_cfm: this.payload?.air_quantity_cfm ?? 0,
        length_m: length,
        fitting_number: this.payload?.fitting_number ?? 0,
        reducer_tee_or_fittings_in_line: this.payload?.reducer_tee_or_fittings_in_line ?? '',
        tee: this.payload?.tee ?? 0,
        reducer: this.payload?.reducer ?? 0,
        rec_square_elbow_same_plane: this.payload?.rec_square_elbow_same_plane ?? 0,
        rec_square_elbow_plane_changed: this.payload?.rec_square_elbow_plane_changed ?? 0,
        vc_damper: this.payload?.vc_damper ?? 0,
        motorised_damper: this.payload?.motorised_damper ?? 0,
        fire_damper: this.payload?.fire_damper ?? 0,
        interior_surface_roughness_feet: this.payload?.interior_surface_roughness_feet ?? 0,
        absolute_roughness_feet: this.payload?.absolute_roughness_feet ?? 0,
        liftwell_location: this.payload?.liftwell_location ?? '',
      }

      if (this.previous_location) {
        if (this.previous_location.trim() != this.payload?.location.trim()) {
          payload.previous_location = this.previous_location;
        }
      }
    }

    return payload;
  }

  onInputChange() {
    if (this.isAddMoreAdditional) {
      let additionalPayload = this.setPayload();
      this.api.post('liftwell_additional_components', additionalPayload)?.subscribe((res: any) => {
        // this.additionalResponse = res;
        this.response = res;
        // this.additionalResponse = [];
        // this.response?.[this.selectedInputSummary?.name]?.additional_component_data?.forEach((air: any, i: number) => {
        //   this.additionalResponse.push(air);
        // })
        this.collectInputSummary();
        this.collectChildInputSummary();
      })
    } else {
      let airPayload = this.setPayload();
      this.api.post('liftwell_air_pressure', airPayload).subscribe((res: any) => {
        this.response = res;
        this.collectInputSummary();
        this.collectChildInputSummary();
      })
    }
  }

  getInfo(buttonElement: HTMLElement) {
    this.calculusCommonService.openInfoPopUp(buttonElement, 'phe_summary');
  }

  // dropdownValueSetByType(type: string) {
  //
  //   if (type === 'ductWidthUnit1') {
  //     if (this.ductWidthUnit1 === 'mm') {
  //       this.ductWidth1 = (this.ductWidth1 ?? 0) * this.inchToMm;
  //     } else {
  //       this.ductWidth1 = (this.ductWidth1 ?? 0) * this.mmToInch;
  //     }
  //   } else if (type === 'ductWidthUnit2') {
  //     if (this.ductWidthUnit2 === 'mm') {
  //       this.ductWidth2 = (this.ductWidth2 ?? 0) * this.inchToMm;
  //     } else {
  //       this.ductWidth2 = (this.ductWidth2 ?? 0) * this.mmToInch;
  //     }
  //   } else if (type === 'ductHeightUnit1') {
  //     if (this.ductHeightUnit1 === 'mm') {
  //       this.ductHeight1 = (this.ductHeight1 ?? 0) * this.inchToMm;
  //     } else {
  //       this.ductHeight1 = (this.ductHeight1 ?? 0) * this.mmToInch;
  //     }
  //   } else if (type === 'ductHeightUnit2') {
  //     if (this.ductHeightUnit2 === 'mm') {
  //       this.ductHeight2 = (this.ductHeight2 ?? 0) * this.inchToMm;
  //     } else {
  //       this.ductHeight2 = (this.ductHeight2 ?? 0) * this.mmToInch;
  //     }
  //
  //   } else if (type === 'lengthUnit') {
  //     if (this.lengthUnit === 'm') {
  //       this.length = (this.length ?? 0) * this.ftToM;
  //     } else {
  //       this.length = (this.length ?? 0) * this.mToFt;
  //     }
  //   }
  // }

  dropdownValueSetByType(type: string) {

    if (type === 'ductWidthUnit1') {
      if (this.ductWidthUnit1 === 'mm') {
        if (!this.ductWidth1mm) this.ductWidth1 = (this.ductWidth1 ?? 0) * this.inchToMm;
        else this.ductWidth1 = this.ductWidth1mm;
      } else {
        this.ductWidth1mm = this.ductWidth1;
        this.ductWidth1 = (this.ductWidth1 ?? 0) * this.mmToInch;
      }
    } else if (type === 'ductWidthUnit2') {
      if (this.ductWidthUnit2 === 'mm') {
        if (!this.ductWidth2mm) this.ductWidth2 = (this.ductWidth2 ?? 0) * this.inchToMm;
        else this.ductWidth2 = this.ductWidth2mm;
      } else {
        this.ductWidth2mm = this.ductWidth2;
        this.ductWidth2 = (this.ductWidth2 ?? 0) * this.mmToInch;
      }
    } else if (type === 'ductHeightUnit1') {
      if (this.ductHeightUnit1 === 'mm') {
        if (!this.ductHeight1mm) this.ductHeight1 = (this.ductHeight1 ?? 0) * this.inchToMm;
        else this.ductHeight1 = this.ductHeight1mm;
      } else {
        this.ductHeight1mm = this.ductHeight1;
        this.ductHeight1 = (this.ductHeight1 ?? 0) * this.mmToInch;
      }
    } else if (type === 'ductHeightUnit2') {
      if (this.ductHeightUnit2 === 'mm') {
        if (!this.ductHeight2mm) this.ductHeight2 = (this.ductHeight2 ?? 0) * this.inchToMm;
        else this.ductHeight2 = this.ductHeight2mm;
      } else {
        this.ductHeight2mm = this.ductHeight2;
        this.ductHeight2 = (this.ductHeight2 ?? 0) * this.mmToInch;
      }

    } else if (type === 'lengthUnit') {
      if (this.lengthUnit === 'm') {
        if (!this.lengthM) this.length = (this.length ?? 0) * this.ftToM;
        else this.length = this.lengthM;
      } else {
        this.lengthM = this.length;
        this.length = (this.length ?? 0) * this.mToFt;
      }
    }
  }

  isFirstInLineGroup(index: number): boolean {
    const current = this.tableDataPairList?.[index];
    if (!current?.isShow) return false;
    if (index === 0) return true;
    const prev = this.tableDataPairList?.[index - 1];
    return !prev?.isShow;
  }

  toggleShowHide(startIndex: number, show: boolean): void {
    const groupKey = `group-${startIndex}`;

    if (!show) {
      const hiddenIndexes: number[] = [];
      for (let i = startIndex; i < this.tableDataPairList.length; i++) {
        const item = this.tableDataPairList[i];
        if (!item.isShow) break;
        item.isShow = show;
        if (!show) {
          hiddenIndexes.push(i);
        }
      }
      this.hiddenCollection.set(groupKey, hiddenIndexes);
    } else {
      let indexes = this.hiddenCollection.get(groupKey);
      indexes?.forEach(index => {
        this.tableDataPairList[index].isShow = show;
      })
      this.hiddenCollection.delete(groupKey);
    }
    this.cd.detectChanges();
  }

  isIndexHidden(i: number): boolean {
    let group: string = '-' + i?.toString();
    for (let key of this.hiddenCollection?.keys()) {
      if (key?.endsWith(group)) {
        return true;
      }
    }
    return false;
  }

  submitSafety() {
    let payload = {
      safety_factor: this.safetyFactor,
      liftwell_location: this.selectedInputSummary?.name
    }
    this.api.post('liftwell_safety_factor', payload).subscribe((res: any) => {
      this.response = res;
      this.collectChildInputSummary();
      // this.collectChildInputSummary();
    })
  }

  onChangeOptionValue(type: string) {
    if (type === 'ductWidthUnit1' && this.ductWidthUnit1 === 'inch') this.ductWidth1mm = 0;
    if (type === 'ductWidthUnit2' && this.ductWidthUnit2 === 'inch') this.ductWidth2mm = 0;
    if (type === 'ductHeightUnit1' && this.ductHeightUnit1 === 'inch') this.ductHeight1mm = 0;
    if (type === 'ductHeightUnit2' && this.ductHeightUnit2 === 'inch') this.ductHeight2mm = 0;
    if (type === 'lengthUnit' && this.lengthUnit === 'ft') this.lengthM = 0;
  }

  submit() {
    const projectDetailsString = sessionStorage.getItem('PROJECTDETAILS');

    let projectName = '';
    let projectType = '';
    let documentVersion = '';
    let date = '';

    if (projectDetailsString) {
      const projectDetails = JSON.parse(projectDetailsString);
      projectName = projectDetails.queryParams.projectName;
      projectType = projectDetails.queryParams.projectType;
      documentVersion = projectDetails.queryParams.documentVersion;
      date = projectDetails.queryParams.date;
    }

    const payload = {
      project_name: projectName,
      project_type: projectType,
      document_version: documentVersion,
      project_date: date || this.project_date,
      project_id: this.project_id,
      sub_module_name: this.sub_module_name,
    };
    this.calculusCommonService.getReport(payload);
  }

  moveNext(): void {
    this.moveToTab.emit(0);
  }

}
