import {Component, EventEmitter, OnInit, Output} from '@angular/core';
import {Summary} from '../../../../core/models/Summary.model';
import {LocalApiService} from '../../../../core/services/local-api.service';
import { HttpClient } from '@angular/common/http';
import {debounceTime, Subject} from 'rxjs';
import {ActivatedRoute} from '@angular/router';
import {InputSummary} from "../../../../shared/entities/input-summary";
import {TabStateService} from "../../../service/tab-state.service";

@Component({
    selector: 'app-lift-well',
    templateUrl: './lift-well.component.html',
    styleUrls: ['./lift-well.component.scss'],
    standalone: false
})
export class LiftWellComponent implements OnInit {
  inputSummaries: any[] = [
    {
      id: 1,
      name: 'Liftwell Dimension',
      value: '',
      icon: 'assets/images/icons/enterprise.svg',
    },
    {
      id: 2,
      name: 'Door Dimension',
      value: '',
      icon: 'assets/images/icons/enterprise.svg',
    },
  ];

  symbol = '@';
  public showInput = false;
  public count: number = 0;
  public selectedInputSummary: any | null = null;
  public organicWaste: number = 40;
  public inOrganicWaste: number = 100 - this.organicWaste;
  public residentialRefuge: number = 0;
  public organicWastePercentages: number[] = [40, 70];
  public inputResponse: any = {};
  @Output() moveToTab = new EventEmitter<number>();

  public donutChartLabels = ['Organic Waste', 'Inorganic Waste'];
  public inputDropdownArrowSrc = 'assets/images/icons/down_arrow.svg';
  public summaryText = 'Summary - A';
  public summaryType = 'A';
  public showInputA = false;
  public showInputB = false;
  public units: number = 0;
  public people: number;
  public area: number = 0;
  public pools: number;
  public results: any = [];
  public selectedInputASummary: any | null = null;
  public selectedInputBSummary: Summary | null = null;
  public mainResponse: any = {};
  public globalVar: any = {};
  public inputAResponse: any = {};
  public inputBResponse: any = {};
  public supportStaffs: number[] = [0, 10, 15, 20];
  private inputSubject = new Subject<any>();
  public showInputASummary = true;
  public showInputBSummary = false;
  public isDoorDimention = false;
  public donutChartType = 'doughnut';

  public activeButtonId: string | null = 'tab-input-a';
  public selectedApartment: { name: string; value: string } | null = null;
  public unitTypes: string[] = ['LPD', 'KLD'];
  public selectedUnit: string = 'LPD';
  public flushingWaterRequired = 6;
  public apartmentSummaries = [
    {
      id: 1,
      name: 'Location',
      value: '',
      icon: 'assets/images/icons/enterprise.svg',
    },
    {
      id: 2,
      name: 'B2 floor to B1 ceiling',
      value: '',
      icon: 'assets/images/icons/enterprise.svg',
    },
    {
      id: 3,
      name: 'B1 CEILING - Terrace',
      value: '',
      icon: 'assets/images/icons/enterprise.svg',
    },
  ];

  public inputBSummaries = [
    {
      id: 1,
      name: 'Location',
      value: 'Location',
      icon: 'assets/images/icons/swimming_pool.svg',
    },
    {
      id: 2,
      name: 'B2 floor to B1 ceiling',
      value: 'B2 floor to B1 ceiling',
      icon: 'assets/images/icons/landscape.svg',
    },
    {
      id: 3,
      name: 'B1 CEILING - Terrace',
      value: 'B1 CEILING - Terrace',
      icon: 'assets/images/icons/club_house.svg',
    },
  ];

  formData = {
    location: '',
    lift_dim_l_m: 0,
    lift_dim_l_ft: 0,
    lift_dim_w_m: 0,
    lift_dim_w_ft: 0,
    lift_dim_h_m: 0,
    lift_dim_h_ft: 0,
    door_dimension_w_m: 0,
    door_dimension_w_ft: 0,
    door_dimension_h_m: 0,
    door_dimension_h_ft: 0,
    total_no_landings: 0,
    pressure_diff_pa: 0,
    pressure_diff_inches: 0,
    door_open: 0,
    wall_sqft: 0,
    floor_sqft: 0,
    ceilings_sqft: 0,
    door_frame: 0,

    apartmentName: '',
    pipeSection: '1',
    waterFlowRate: 0,
    waterFlowUnit: 'm', // Default unit
    internalPipeDiameter: 0,
    internalPipeUnit: 'm', // Default unit
    length: 0,
    wall: 0,
    floor: 0,
    ceiling: 0,
    doorFrame: 0,
    doorOpen: 0,
    doorCrackage: 0,
    pressureDifference: 0,
    lengthUnit: 'm', // Default unit
    doorDimentionlengthUnit: 'm',
    totalUnit: 'sq.ft',
    doorDimentionwidthUnit: 'm',
    doorDimentionLengthUnit: 'm',
    pressureDrop: 40,
    totalPressureDrop: 60,
    liftwellLengthUnit: 'm',
    liftwellHeightUnit: 'm',
    liftwellWidthUnit: 'm',
    doorDimentionHeightUnit: 'm',
    liftwellheightUnit: 'm',
    pressureDifferenceUnit: 'pa',
    totalLanding: 0,
    doorDimention: {
      width: 0,
      height: 0,
      length: 0,
    },
    liftWellDimention: {
      width: 0,
      height: 0,
      length: 0,
    },

    valveType: '',
    quantity: 0,
  };

  public projectName: string = '';
  public projectType: string = '';
  public documentVersion: string = '';
  public date: string = '';
  inputSummariesMain: any[] = [];
  isAddMore: boolean = false;
  previous_location = '';

  public constructor(
    private apiService: LocalApiService,
    private http: HttpClient,
    private activatedRoute: ActivatedRoute,
    private tabService: TabStateService
  ) {
  }

  ngOnInit(): void {
    this.activatedRoute.queryParams.subscribe((params) => {
      this.projectName = params['projectName'];
      this.projectType = params['projectType'];
      this.documentVersion = params['documentVersion'];
      this.date = params['date'];
    });
    if (!this.projectName) {
      const projectDetailsString = sessionStorage.getItem('PROJECTDETAILS');
      if (projectDetailsString) {
        const projectDetails = JSON.parse(projectDetailsString);
        this.projectName = projectDetails.queryParams.projectName;
        this.projectType = projectDetails.queryParams.projectType;
        this.documentVersion = projectDetails.queryParams.documentVersion;
        this.date = projectDetails.queryParams.date;
      }
    }
    const tabs = document.querySelectorAll<HTMLElement>('[data-tabs-target]');
    const tabContents =
      document.querySelectorAll<HTMLElement>("[role='tabpanel']");
    this.apiService.post('liftwell_table', null).subscribe({
      next: (response: any) => {
        this.inputResponse = response;
        console.log(this.inputResponse);
        this.collectInputSummary();
        // this.updateApartmentSummaries();
      },
      error: (error) => {
        console.error('API Error:', error);
      },
    });
    // Listen for input changes, but only send API calls after 500ms of inactivity
    this.inputSubject.pipe(debounceTime(1000)).subscribe((value) => {
      this.sendApiRequest();
    });
    tabs.forEach((tab) => {
      tab.addEventListener('click', () => {
        // Remove active states from all tabs and hide all content
        tabs.forEach((t) =>
          t.classList.remove(
            'border-blue-500',
            'text-blue-600',
            'dark:text-blue-500',
            'border-[#1D40AB]',
            'text-[#1D40AB]',
          ),
        );
        tabContents.forEach((content) => content.classList.add('hidden'));

        // Add active state to the clicked tab and show corresponding content
        tab.classList.add(
          'border-blue-500',
          'text-blue-600',
          'dark:text-blue-500',
          'border-b-2',
        );
        const targetSelector = tab.getAttribute('data-tabs-target');

        // Check if targetSelector is non-null before using it
        if (targetSelector) {
          const target = document.querySelector<HTMLElement>(targetSelector);
          if (target) {
            target.classList.remove('hidden');
          }
        }
      });
    });
  }

  collectInputSummary() {
    this.inputSummariesMain = [];
    for (const [key, value] of Object.entries(this.inputResponse)) {
      let inputSummary: InputSummary = new InputSummary(key, 'N/A',
        'assets/images/icons/enterprise.svg', true);
      this.inputSummariesMain.push(inputSummary);
    }
  }

  addItem(e: Event, id: number, targetArray: any): void {
    e.stopPropagation();
    const index = targetArray.findIndex((item: any) => item.id === id);
    if (index !== -1) {
      const newItem = {...targetArray[index]};
      const baseName = newItem.name.replace(/\s\d+$/, ''); // Remove the last space and number (e.g., " 2")
      const similarItems = targetArray.filter((item: any) =>
        item.name.startsWith(baseName),
      );
      const highestNumber = similarItems.reduce((max: any, item: any) => {
        const numberMatch = item.name.match(/\s(\d+)$/);
        const number = numberMatch ? parseInt(numberMatch[1], 10) : 0;
        return Math.max(max, number);
      }, 0);

      const nextNumber = highestNumber + 1;
      newItem.name = `${baseName} ${nextNumber}`;
      newItem.value = '';
      targetArray.splice(index + 1, 0, newItem);
      this.updateIds(targetArray);
    }
  }

  removeItem(event: MouseEvent, id: number, targetArray: any): void {
    event.stopPropagation(); // Prevents the parent click handler from firing
    const index = targetArray.findIndex((item: any) => item['id'] === id);
    if (index !== -1) {
      targetArray.splice(index, 1);
      this.updateIds(targetArray);
    }
  }

  private updateIds(targetArray: any): void {
    targetArray.forEach((item: any, idx: any) => {
      item['id'] = idx + 1;
    });
  }

  onInputBChange() {
    console.log(this.formData);
  }

  // Method to handle input changes dynamically
  onInputAChange(value: any, e: any): void {
    if (value < 0) {
      e.target.value = '0'; // Prevent negative input
      return;
    }

    // Push the latest value to the Subject, triggering debounce logic
    this.inputSubject.next(value);
  }

  deleteSummaryItem(item: any) {
    this.toggleInputMain(item);
    // this.initInputObj();

    this.apiService.post('delete_liftwell_table', {
      location: item?.name
    }).subscribe((res: any) => {
      this.inputResponse = res;
      this.collectInputSummary();
      this.tabService.changeTab();
      this.isAddMore = false;
    })
  }

  sendApiRequest(): void {
    let fittingValve: any = {type: '', quantity: 0};
    if (this.formData.valveType && this.formData.quantity) {
      fittingValve.type = this.formData.valveType;
      fittingValve.quantity = this.formData.quantity;
    }
    let payload: any = {
      location: this.formData.location,
      inputs: [
        {
          lift_dim_l_m:
            this.formData.liftwellLengthUnit == 'm'
              ? this.formData.liftWellDimention.length
              : 0,
          lift_dim_l_ft:
            this.formData.liftwellLengthUnit == 'ft'
              ? this.formData.liftWellDimention.length
              : 0,
          lift_dim_w_m:
            this.formData.liftwellWidthUnit == 'm'
              ? this.formData.liftWellDimention.width
              : 0,
          lift_dim_w_ft:
            this.formData.liftwellWidthUnit == 'ft'
              ? this.formData.liftWellDimention.width
              : 0,
          lift_dim_h_m:
            this.formData.liftwellHeightUnit == 'm'
              ? this.formData.liftWellDimention.height
              : 0,
          lift_dim_h_ft:
            this.formData.liftwellHeightUnit == 'ft'
              ? this.formData.liftWellDimention.height
              : 0,
          door_dimension_w_m:
            this.formData.doorDimentionwidthUnit == 'm'
              ? this.formData.doorDimention.width
              : 0,
          door_dimension_w_ft:
            this.formData.doorDimentionwidthUnit == 'ft'
              ? this.formData.doorDimention.width
              : 0,
          door_dimension_h_m:
            this.formData.doorDimentionHeightUnit == 'm'
              ? this.formData.doorDimention.height
              : 0,
          door_dimension_h_ft:
            this.formData.doorDimentionHeightUnit == 'ft'
              ? this.formData.doorDimention.height
              : 0,
          total_no_landings: this.formData.totalLanding,
          pressure_diff_pa:
            this.formData.pressureDifferenceUnit == 'pa'
              ? this.formData.pressureDifference
              : 0,
          pressure_diff_inches:
            this.formData.pressureDifferenceUnit == 'in'
              ? this.formData.pressureDifference
              : 0,
          door_open: this.formData.doorOpen,
          wall_sqft: this.formData.wall,
          floor_sqft: this.formData.floor,
          ceilings_sqft: this.formData.ceiling,
          door_frame: this.formData.doorFrame,
        }
      ]
    }

    if (this.previous_location) {
      if (this.previous_location.trim() != payload?.location?.trim()) {
        payload.inputs[0].previous_location = this.previous_location;
      }
    }

    this.apiService.post('liftwell_table', payload).subscribe({
      next: (response: any) => {
        this.inputResponse = response;
        console.log(this.inputResponse);
        this.collectInputSummary();
        this.tabService.changeTab();

        if (this.selectedInputSummary == null) {
          let obj: any = {};
          obj.name = this.formData.location;
          this.selectedInputSummary = {...obj}
        }
        this.updateApartmentSummaries();
      },
      error: (error) => {
        console.error('API Error:', error);
      },
    });
  }

  onSave() {
    let payload: any = [];
    let fittingValve: any = {type: '', quantity: 0};
    if (this.formData.valveType && this.formData.quantity) {
      fittingValve.type = this.formData.valveType;
      fittingValve.quantity = this.formData.quantity;
    }
    let data = {
      type: 'Hydrant(High zone)',
      location: this.formData.location,
      pipe_section: this.formData.pipeSection,
      parameters: {
        water_flow_rate: this.formData.waterFlowRate,
        internal_pipe_diameter: this.formData.internalPipeDiameter,
        length: this.formData.length,
        fitting_valve:
          fittingValve.type && fittingValve.quantity ? fittingValve : {},
      },
    };
    payload[0] = data;
    this.apiService.post('get_pressure', payload).subscribe({
      next: (response: any) => {
        this.inputResponse = response;
        // this.inputSummaries = this.updateApartmentSummaries(
        //   response.results,
        //   this.inputSummaries,
        // );
        this.results = response.results;
        this.globalVar = response['global variables'];
        console.log(this.inputSummaries);
      },
      error: (error) => {
        console.error('API Error:', error);
      },
    });
  }

  updateApartmentSummaries() {
    this.previous_location = this.selectedInputSummary?.name;

    const obj: any = this.inputResponse?.[this.selectedInputSummary?.name];

    this.formData.location = this.selectedInputSummary?.name ?? 'N/A';
    this.formData.liftWellDimention.length = this.formData.liftwellLengthUnit == 'm'
      ? obj?.lift_dimensions.lift_dim_l_m : obj?.lift_dimensions.lift_dim_l_ft;
    this.formData.liftWellDimention.width = this.formData.liftwellWidthUnit == 'm'
      ? obj?.lift_dimensions.lift_dim_w_m : obj?.lift_dimensions.lift_dim_w_ft;
    this.formData.liftWellDimention.height = this.formData.liftwellHeightUnit == 'm'
      ? obj?.lift_dimensions.lift_dim_h_m : obj?.lift_dimensions.lift_dim_h_ft;
    this.formData.doorDimention.width = this.formData.doorDimentionwidthUnit == 'm'
      ? obj?.door_dimensions.door_dimension_w_m : obj?.door_dimensions.door_dimension_w_ft;
    this.formData.doorDimention.height = this.formData.doorDimentionHeightUnit == 'm'
      ? obj?.door_dimensions.door_dimension_h_m : obj?.door_dimensions.door_dimension_h_ft;
    this.formData.totalLanding = obj?.total_no_landings.total_no_landings;
    this.formData.pressureDifference = this.formData.pressureDifferenceUnit == 'in'
      ? obj?.['pressure_diff']['pressure_diff_inches'] : obj?.['pressure_diff']['pressure_diff_pa'];
    this.formData.doorOpen = obj?.['doors_open']['door_open'];
    this.formData.doorCrackage = obj?.['doors_crackage']['door_crackage'];
    this.formData.wall = obj?.['leakage_calculation']['wall_sqft'];
    this.formData.floor = obj?.['leakage_calculation']['floor_sqft'];
    this.formData.ceiling = obj?.['leakage_calculation']['ceilings_sqft'];
    this.formData.doorFrame = obj?.['leakage_calculation']['door_frame'];
  }

  onUnitChange(type: string) {
    const mToFt = 3.28084;
    const ftToM = 0.3048;

    const inToPa = 249.08891;

    if (type === 'doorDimentionwidthUnit') {
      if (this.formData.doorDimentionwidthUnit === 'm') {
        this.formData.doorDimention.width = (this.formData.doorDimention.width ?? 0) * ftToM;
      } else {
        this.formData.doorDimention.width = (this.formData.doorDimention.width ?? 0) * mToFt;
      }
    } else if (type === 'doorDimentionHeightUnit') {
      if (this.formData.doorDimentionHeightUnit === 'm') {
        this.formData.doorDimention.height = (this.formData.doorDimention.height ?? 0) * ftToM;
      } else {
        this.formData.doorDimention.height = (this.formData.doorDimention.height ?? 0) * mToFt;
      }
    } else if (type === 'liftwellLengthUnit') {
      if (this.formData.liftwellLengthUnit === 'm') {
        this.formData.liftWellDimention.length = (this.formData.liftWellDimention.length ?? 0) * ftToM;
      } else {
        this.formData.liftWellDimention.length = (this.formData.liftWellDimention.length ?? 0) * mToFt;
      }
    } else if (type === 'liftwellWidthUnit') {
      if (this.formData.liftwellWidthUnit === 'm') {
        this.formData.liftWellDimention.width = (this.formData.liftWellDimention.width ?? 0) * ftToM;
      } else {
        this.formData.liftWellDimention.width = (this.formData.liftWellDimention.width ?? 0) * mToFt;
      }

    } else if (type === 'liftwellHeightUnit') {
      if (this.formData.liftwellHeightUnit === 'm') {
        this.formData.liftWellDimention.height = (this.formData.liftWellDimention.height ?? 0) * ftToM;
      } else {
        this.formData.liftWellDimention.height = (this.formData.liftWellDimention.height ?? 0) * mToFt;
      }
    } else if (this.formData.pressureDifferenceUnit === 'in') {
      this.formData.pressureDifference = (this.formData.pressureDifference ?? 0) / inToPa;
    } else {
      this.formData.pressureDifference = (this.formData.pressureDifference ?? 0) * inToPa;
    }
  }

  addMore() {
    this.previous_location = '';
    this.showInput = true;
    this.isAddMore = true;

    this.formData.location = "";
    this.formData.lift_dim_l_m = 0;
    this.formData.lift_dim_l_ft = 0;
    this.formData.lift_dim_w_m = 0;
    this.formData.lift_dim_w_ft = 0;
    this.formData.lift_dim_h_m = 0;
    this.formData.lift_dim_h_ft = 0;
    this.formData.door_dimension_w_m = 0;
    this.formData.door_dimension_w_ft = 0;
    this.formData.door_dimension_h_m = 0;
    this.formData.door_dimension_h_ft = 0;
    this.formData.total_no_landings = 0;
    this.formData.pressure_diff_pa = 0;
    this.formData.pressure_diff_inches = 0;
    this.formData.door_open = 0;
    this.formData.wall_sqft = 0;
    this.formData.floor_sqft = 0;
    this.formData.ceilings_sqft = 0;
    this.formData.door_frame = 0;


    this.formData.doorDimentionwidthUnit = 'm';
    this.formData.doorDimentionHeightUnit = 'm';
    this.formData.liftwellLengthUnit = 'm';
    this.formData.liftwellWidthUnit = 'm';
    this.formData.liftwellHeightUnit = 'm';
    this.formData.pressureDifferenceUnit = 'pa';
  }

  toggleInputA(summary: any) {
    this.showInputA = !this.showInputA;
    this.isDoorDimention = summary.name == 'Door Dimension' ? true : false;
    this.selectedInputASummary = this.showInputA ? summary : null;

    // this.formData.type= "Hydrant(High zone)",
    // this.formData.location = summary?.name;
    this.formData.pipeSection = summary?.pipe_section;
    this.formData.waterFlowRate = summary?.parameters?.water_flow_rate;
    this.formData.internalPipeDiameter = summary?.parameters?.internal_pipe_diameter;
    this.formData.length = summary?.parameters?.length;

    if (this.selectedInputASummary) {
      this.units =
        this.inputAResponse[this.selectedInputASummary!.value]?.[
          'no_of_units'
          ] ??
        this.mainResponse[this.selectedInputASummary!.value]?.['no_of_units'];
    }
    if (this.showInputA) {
      this.inputDropdownArrowSrc = 'assets/images/icons/up_arrow.svg';
      this.summaryText = 'Apartment Size';
      // this.onInputAChange();
    } else {
      this.inputDropdownArrowSrc = 'assets/images/icons/down_arrow.svg';
      this.summaryText = 'Summary - A';
    }
  }

  toggleInputMain(summary: any) {
    this.showInput = !this.showInput;
    this.selectedInputSummary = this.showInput ? summary : null;
    if (this.showInput) {
      this.inputDropdownArrowSrc = 'assets/images/icons/up_arrow.svg';
    } else {
      this.isAddMore = false;
      this.inputDropdownArrowSrc = 'assets/images/icons/down_arrow.svg';
    }
    this.updateApartmentSummaries();
  }

  toggleInputsSummary(id: string) {
    this.activeButtonId = this.activeButtonId === id ? null : id;
    if (this.activeButtonId?.includes('-a')) {
      this.showInputASummary = true;
      this.showInputBSummary = false;
      this.summaryText = 'Summary - A';
      this.summaryType = 'A';
    } else if (this.activeButtonId?.includes('-b')) {
      this.showInputBSummary = true;
      this.showInputASummary = false;
      this.summaryText = 'Summary - B';
      this.summaryType = 'B';
    } else {
      return;
    }
  }

  getButtonClasses(id: string) {
    if (this.activeButtonId === id) {
      return {
        'bg-white': true,
        'py-[7px]': true,
        'text-[#1D40AB]': true,
        'text-[#000000]': false,
      };
    } else {
      return {
        'bg-white': false,
        'py-[7px]': false,
        'text-[#1D40AB]': false,
        'text-[#7F7E7E]': true,
      };
    }
  }

  validateResidentialRefuge(residentialRefuge: number) {
    if (residentialRefuge < 0.3) {
      this.residentialRefuge = 0.3;
      return 0.3;
    } else if (residentialRefuge > 0.6) {
      this.residentialRefuge = 0.6;
      return 0.6;
    }
    return residentialRefuge;
  }

  submit() {
    const payload = {
      project_name: this.projectName,
      project_type: this.projectType,
      document_version: this.documentVersion,
      project_date: this.date,
      project_id: '1',
      sub_module_name: 'lift_well',
    };

    const url = `https://dev-designcalculus.bluealgo.com/reports_page`;
    this.http
      .post(url, payload, {
        params: {isWithoutBase: 'yes'},
        responseType: 'text',
      })
      .subscribe((response) => {
        window.location.href = url;
      });
  }

  moveNext(): void {
    this.moveToTab.emit(1);
  }
}
