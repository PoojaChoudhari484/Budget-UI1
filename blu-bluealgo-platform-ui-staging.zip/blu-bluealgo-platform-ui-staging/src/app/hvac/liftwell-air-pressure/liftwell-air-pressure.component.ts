import {Component, EventEmitter, OnInit, Output} from '@angular/core';
import {ActivatedRoute} from "@angular/router";

@Component({
    selector: 'app-liftwell-air-pressure',
    templateUrl: './liftwell-air-pressure.component.html',
    styleUrls: ['./liftwell-air-pressure.component.scss'],
    standalone: false
})
export class LiftwellAirPressureComponent implements OnInit {

  @Output() moveToTab = new EventEmitter<string>();
  projectName: string = '';
  projectType: string = '';
  documentVersion: string = '';
  date: string = '';
  public types: string[] = [];
  public activeTab: string = 'transfer-pump-discharge';
  selectedTabIndex: number = 0;

  constructor(private activatedRoute: ActivatedRoute) {}

  ngOnInit(): void {
    this.activatedRoute.queryParams.subscribe((params) => {
      this.projectName = params['projectName'];
      this.projectType = params['projectType'];
      this.documentVersion = params['documentVersion'];
      this.date = params['date'];
    });
  }

  setActiveTabParent(tab: string): void {
    this.activeTab = tab;
  }

  setActiveTab(tabIndex: number): void {
    this.selectedTabIndex = tabIndex;
  }

}
