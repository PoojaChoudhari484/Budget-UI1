import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { ModuleService } from 'src/app/services/module.service';

@Component({
    selector: 'app-hvac-sub-page',
    templateUrl: './hvac-sub-page.component.html',
    styleUrls: ['./hvac-sub-page.component.scss'],
    standalone: false
})
export class HvacSubPageComponent {

  modules: string[] = [
      "Stair Case",
      "Lift Well",
      "Lift Lobby",
      "Common Service Ventilation",
      "Basement Ventilation",
      "Common Service STP",
      "Common Service DG",
      "Air Pressure",
     "Expansion Tank",
      "Summary"
  ];

  constructor(
    private router: Router,
    private moduleService: ModuleService,
  ) {}

  ngOnInit(): void {

  }

   goTo(module: string) {
   const moduleRouteMap: { [key: string]: string } = {
      "Stair Case": '/hvac/stair-case',
      "Lift Well": '/hvac/lift-well',
      "Lift Lobby": '/hvac/lift-lobby',
      "Common Service Ventilation": '/hvac/common-service-ventilation',
      "Basement Ventilation": '/hvac/basement-ventilation',
      "Common Service STP": '/hvac/common-service-stp',
      "Common Service DG": '/hvac/common-service-dg',
      "Air Pressure": '/hvac/air-pressure',
      "Summary":'/hvac/hvac-summary',
      "Expansion Tank":'/hvac/expansion-tank',
    };

    this.moduleService.updateSelectedSubModule(module);
     this.router.navigate([moduleRouteMap[module]],
  JSON.parse(sessionStorage.getItem('PROJECTDETAILS') || '{}'));
  }
}
