import { ComponentFixture, TestBed } from '@angular/core/testing';

import { HvacSubPageComponent } from './hvac-sub-page.component';

describe('HvacSubPageComponent', () => {
  let component: HvacSubPageComponent;
  let fixture: ComponentFixture<HvacSubPageComponent>;

  beforeEach(() => {
    TestBed.configureTestingModule({
      declarations: [HvacSubPageComponent]
    });
    fixture = TestBed.createComponent(HvacSubPageComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
