import {Component, EventEmitter, OnInit, Output} from '@angular/core';
import {InputSummary} from "../../shared/entities/input-summary";
import {LocalApiService} from "../../core/services/local-api.service";
import {CalculusCommonService} from "../../core/services/calculus-common.service";

@Component({
    selector: 'app-expansion-tank',
    templateUrl: './expansion-tank.component.html',
    styleUrls: ['./expansion-tank.component.scss'],
    standalone: false
})
export class ExpansionTankComponent implements OnInit {

  pipes: string [] = ['20MM','25MM', '32MM', '40MM', '50MM', '65MM',
    '80MM', '100MM','125MM', '150MM', '200MM', '250MM', '300MM','350MM','400MM', '450MM','500MM'];
  inputSummaries: InputSummary[] = [];
  selectedInputSummary: any | null = null;
  showInput = false;
  @Output() moveToTab = new EventEmitter<string>();
  inputDropdownArrowSrc = 'assets/images/icons/down_arrow.svg';
  response: any = {};
submittedResponse: any = null;
  payload = {
    pipe_data: [
      {
        pipe_size: "",
        length: 0
      }
    ],
    max_temp: 0,
    initial_temp: 0,
    static: 0
  }

  activeTab: string = 'tab-input-a'; // default Input Value tab
  length: number = 0;
  project_name: string;
  project_id: string;
  project_date: string;
  sub_module_name: string;

  constructor(
    private apiService: LocalApiService,
    private calculusCommonService: CalculusCommonService,
  ) {

    this.pipes.forEach((pipe: any, i: number) => {
      let inputSummary: InputSummary = new InputSummary(pipe, 'N/A',
        'assets/images/icons/enterprise.svg', true);
      this.inputSummaries.push(inputSummary);
    })
  }

  ngOnInit(): void {
    this.project_name = 'Centrona';
    this.project_id = '1';
    this.project_date = '2021-09-01';
    this.sub_module_name = 'expansion_tank';

    this.getResponse();
  }

  getResponse() {
    this.apiService.post('expansion_tank', {}).subscribe(res => {
      console.log(res);
      this.response = res;

      this.payload.max_temp = this.response?.max_temp ?? 0;
      this.payload.initial_temp = this.response?.initial_temp ?? 0;
      this.payload.static = this.response?.static ?? 0;
    })
  }
  toggleInputsSummary(tab: string) {
  this.activeTab = tab;
}

  getButtonClasses(tab: string): any {
  return {
    'bg-white text-[#1D40AB] font-semibold': this.activeTab === tab, // active tab styling
    'bg-transparent text-[#000000]': this.activeTab !== tab          // inactive tab styling
  };
}

  toggleInput(summary: any) {
    this.showInput = !this.showInput;
    this.selectedInputSummary = this.showInput ? summary : null;
    if (this.showInput) {
      this.inputDropdownArrowSrc = 'assets/images/icons/up_arrow.svg';
    } else {
      this.inputDropdownArrowSrc = 'assets/images/icons/down_arrow.svg';
    }
    this.initInputObj();
  }

  initInputObj() {
    let findObj: any = this.response?.pipe_data?.find((f: any) => f?.pipe_size === this.selectedInputSummary?.name);
    // this.payload.max_temp = this.response?.max_temp ?? 0;
    // this.payload.initial_temp = this.response?.initial_temp ?? 0;
    // this.payload.static = this.response?.static ?? 0;
    this.length = findObj?.length
  }

  setPayload(): any {

    let payload: any;
    if (this.showInput) {
      payload = {
        pipe_data: [
          {
            pipe_size: this.selectedInputSummary?.name ?? '',
            length: this.length ?? 0
          }
        ]
      }
    } else {
      payload = {
        max_temp: this.payload?.max_temp ?? 0,
        initial_temp: this.payload?.initial_temp ?? 0,
        static: this.payload?.static ?? 0
      }
    }
    return payload;
  }

  onInputChange() {
    let payload = this.setPayload();
    this.apiService.post('expansion_tank', payload).subscribe((res: any) => {
      this.response = res;
    })
  }

  onSubmit() {
  const payload = this.setPayload();

  this.apiService.post('expansion_tank', payload).subscribe((res: any) => {
    this.submittedResponse = res;   // New calculation
    this.activeTab = 'tab-input-b'; // After Submit Calculation
  });
}

  getInfo(buttonElement: HTMLElement) {
    this.calculusCommonService.openInfoPopUp(buttonElement, 'phe_summary');
  }

  submit() {
    const projectDetailsString = sessionStorage.getItem('PROJECTDETAILS');

    let projectName = '';
    let projectType = '';
    let documentVersion = '';
    let date = '';

    if (projectDetailsString) {
      const projectDetails = JSON.parse(projectDetailsString);
      projectName = projectDetails.queryParams.projectName;
      projectType = projectDetails.queryParams.projectType;
      documentVersion = projectDetails.queryParams.documentVersion;
      date = projectDetails.queryParams.date;
    }

    const payload = {
      project_name: projectName,
      project_type: projectType,
      document_version: documentVersion,
      project_date: date || this.project_date,
      project_id: this.project_id,
      sub_module_name: this.sub_module_name,
    };
    this.calculusCommonService.getReport(payload);
  }

}
