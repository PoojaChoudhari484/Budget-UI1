import { Component, EventEmitter, Input, OnInit, Output } from '@angular/core';
import { Summary } from 'src/app/core/models/Summary.model';
import { LocalApiService } from 'src/app/core/services/local-api.service';
import * as Highcharts from 'highcharts';
import 'highcharts/highcharts-3d';
import { ActivatedRoute } from '@angular/router';
import {CalculusCommonService} from "../../core/services/calculus-common.service";

@Component({
    selector: 'app-basement-ventilation',
    templateUrl: './basement-ventilation.component.html',
    styleUrls: ['./basement-ventilation.component.scss'],
    standalone: false
})
export class BasementVentilationComponent {
  public commonServicesInputs = [
    {
      name: 'Zone 1 - Basement 1',
      value: '',
      icon: 'assets/images/icons/enterprise.svg',
      key: 'basement1_zone1'
    },
    {
      name: 'Zone 1 - Basement 2',
      value: '',
      icon: 'assets/images/icons/enterprise.svg',
      key: 'basement2_zone1'
    },
    {
      name: 'Zone 1 - Basement 3',
      value: '',
      icon: 'assets/images/icons/enterprise.svg',
      key: 'basement3_zone1'
    },
    {
      name: 'Zone 2 - Basement 1',
      value: '',
      icon: 'assets/images/icons/enterprise.svg',
      key: 'basement1_zone2'
    },
    {
      name: 'Zone 2 - Basement 2',
      value: '',
      icon: 'assets/images/icons/enterprise.svg',
      key: 'basement2_zone2'
    },
    {
      name: 'Zone 2 - Basement 3',
      value: '',
      icon: 'assets/images/icons/enterprise.svg',
      key: 'basement3_zone2'
    },
  ];

  @Output() moveToTab = new EventEmitter<string>();

  public summaryText = 'Summary - A';
  public summaryType = 'A';
  public showInputA = false;
  public showInputB = false;
  public selectedInputASummary: Summary | null = null;
  public selectedInputBSummary: Summary | null = null;

  public showInputASummary = true;
  public showInputBSummary = false;
  public showInput = false;

  public activeButtonId: string | null = 'tab-input-a';
  public inputDropdownArrowSrc = 'assets/images/icons/down_arrow.svg';
  public unitTypes: string[] = ['LPD', 'KLD'];
  public selectedUnit: string = 'LPD';
  public flushingWaterRequired = 6;

  highChartOptions: Highcharts.Options;
  Highcharts = Highcharts;

  public item_data: string = 'Core 01, 02 Service Lift Lobby';
  public area: number = 0;

  public height: number = 0;
  public airflow_acph: number = 0;
  public airflow_fire_acph: number = 0;
  public ex_fan_quantity: number = 0;
  public airflow_normal_acph: number = 0;
  public ex_fan_qty: number = 0;
  public fresh_shift_tag: string = '';
  public fa_fan_quantity: number = 0;
  public fresh_air: number = 0;
  public fa_fan_qty: number = 0;
  public remarks: string = '';
  public zone: string = '';
  public floor: string = '';

  public showTable1Summary = true;
  public showTable1 = false;
  public selectedTable1Summary: Summary | any;

  commonServicesInputSummaries: any;

  hvacMakeupResponse: any;
  liftLobbyMainResponse: any;
  commonServicesMainResponse: any;

  table1State = {
    zone1_basement1: {
      // service: "Zone 1 - Basement 1",
      area: 0,
      height: 0,
      airflow_normal_acph: 0,
      airflow_fire_acph: 0,
      ex_fan_quantity: 0,
      fresh_shift_tag: '',
      fa_fan_quantity: 0,
      floor: 'Basement 1',
      zone: 'Zone1',
    },
    zone1_basement2: {
      // service: "Zone 1 - Basement 1",
      area: 0,
      height: 0,
      airflow_normal_acph: 0,
      airflow_fire_acph: 0,
      ex_fan_quantity: 0,
      fresh_shift_tag: '',
      fa_fan_quantity: 0,
      floor: 'Basement 2',
      zone: 'Zone1',
    },
    zone1_basement3: {
      // service: "Zone 1 - Basement 1",
      area: 0,
      height: 0,
      airflow_normal_acph: 0,
      airflow_fire_acph: 0,
      ex_fan_quantity: 0,
      fresh_shift_tag: '',
      fa_fan_quantity: 0,
      floor: 'Basement 3',
      zone: 'Zone1',
    },
    zone2_basement1: {
      // service: "Zone 1 - Basement 1",
      area: 0,
      height: 0,
      airflow_normal_acph: 0,
      airflow_fire_acph: 0,
      ex_fan_quantity: 0,
      fresh_shift_tag: '',
      fa_fan_quantity: 0,
      floor: 'Basement 1',
      zone: 'Zone2',
    },
    zone2_basement2: {
      // service: "Zone 1 - Basement 1",
      area: 0,
      height: 0,
      airflow_normal_acph: 0,
      airflow_fire_acph: 0,
      ex_fan_quantity: 0,
      fresh_shift_tag: '',
      fa_fan_quantity: 0,
      floor: 'Basement 2',
      zone: 'Zone2',
    },
    zone2_basement3: {
      // service: "Zone 1 - Basement 1",
      area: 0,
      height: 0,
      airflow_normal_acph: 0,
      airflow_fire_acph: 0,
      ex_fan_quantity: 0,
      fresh_shift_tag: '',
      fa_fan_quantity: 0,
      floor: 'Basement 3',
      zone: 'Zone2',
    },
  } as any;
  project_name: string;
  project_id: string;
  project_date: string;
  sub_module_name: string;

  public constructor(private apiService: LocalApiService ,
                     private activatedRoute: ActivatedRoute,
                     private calculusCommonService: CalculusCommonService,

  ) {}

  ngOnInit(): void {
    this.project_name = 'Centrona';
    this.project_id = '1';
    this.project_date = '2021-09-01';
    this.sub_module_name = 'basement_ventilation';

    this.commonServicesInputSummaries = this.updateCommonServicesInputSummaries(
      null,
      this.commonServicesInputs,
    );
    this.apiService.post<any>('basement_table', null).subscribe(
      (response) => {
        this.commonServicesMainResponse = response;

        this.commonServicesInputSummaries =
          this.updateCommonServicesInputSummaries(
            response,
            this.commonServicesInputSummaries,
          );
      },
      (error) => {
        console.error('API Error:', error);
      },
    );
  }

  moveNext(): void {
    this.moveToTab.emit('hvac-makeup');
  }

  toggleTable1(summary: any) {
    this.showTable1 = !this.showTable1;
    this.selectedTable1Summary = this.showTable1 ? summary : null;

    if (this.selectedTable1Summary) {
      let findObj = this.commonServicesInputSummaries?.find((f: any) => f.name === this.selectedTable1Summary?.name);
      if (this.selectedTable1Summary?.name == 'Zone 1 - Basement 1') {
        this.area = findObj.area;
        this.height = findObj.height;
        this.airflow_normal_acph = findObj.airflow_normal_acph;
        this.airflow_fire_acph = findObj.airflow_fire_acph;
        this.ex_fan_quantity = findObj.ex_fan_quantity;
        this.fa_fan_quantity = findObj.fa_fan_quantity;
        this.fresh_shift_tag = findObj.fresh_shift_tag;
        this.floor = 'Basement 1';
        this.zone = 'Zone1';
      }
      if (this.selectedTable1Summary?.name == 'Zone 1 - Basement 2') {
        // this.area = this.table1State.zone1_basement2.area;
        // this.height = this.table1State.zone1_basement2.height;
        // this.airflow_normal_acph =
        //   this.table1State.zone1_basement2.airflow_normal_acph;
        // this.airflow_fire_acph =
        //   this.table1State.zone1_basement2.airflow_fire_acph;
        // this.ex_fan_quantity = this.table1State.zone1_basement2.ex_fan_quantity;
        // this.fresh_shift_tag = this.table1State.zone1_basement2.fresh_shift_tag;
        // this.fa_fan_quantity = this.table1State.zone1_basement2.fa_fan_quantity;
        this.area = findObj.area;
        this.height = findObj.height;
        this.airflow_normal_acph = findObj.airflow_normal_acph;
        this.airflow_fire_acph = findObj.airflow_fire_acph;
        this.ex_fan_quantity = findObj.ex_fan_quantity;
        this.fa_fan_quantity = findObj.fa_fan_quantity;
        this.fresh_shift_tag = findObj.fresh_shift_tag;
        this.floor = 'Basement 2';
        this.zone = 'Zone1';
      }
      if (this.selectedTable1Summary?.name == 'Zone 1 - Basement 3') {
        // this.area = this.table1State.zone1_basement3.area;
        // this.height = this.table1State.zone1_basement3.height;
        // this.airflow_normal_acph =
        //   this.table1State.zone1_basement3.airflow_normal_acph;
        // this.airflow_fire_acph =
        //   this.table1State.zone1_basement3.airflow_fire_acph;
        // this.ex_fan_quantity = this.table1State.zone1_basement3.ex_fan_quantity;
        // this.fresh_shift_tag = this.table1State.zone1_basement3.fresh_shift_tag;
        // this.fa_fan_quantity = this.table1State.zone1_basement3.fa_fan_quantity;
        this.area = findObj.area;
        this.height = findObj.height;
        this.airflow_normal_acph = findObj.airflow_normal_acph;
        this.airflow_fire_acph = findObj.airflow_fire_acph;
        this.ex_fan_quantity = findObj.ex_fan_quantity;
        this.fa_fan_quantity = findObj.fa_fan_quantity;
        this.fresh_shift_tag = findObj.fresh_shift_tag;
        this.floor = 'Basement 3';
        this.zone = 'Zone1';
      }
      if (this.selectedTable1Summary?.name == 'Zone 2 - Basement 1') {
        // this.area = this.table1State.zone2_basement1.area;
        // this.height = this.table1State.zone2_basement1.height;
        // this.airflow_normal_acph =
        //   this.table1State.zone2_basement1.airflow_normal_acph;
        // this.airflow_fire_acph =
        //   this.table1State.zone2_basement1.airflow_fire_acph;
        // this.ex_fan_quantity = this.table1State.zone2_basement1.ex_fan_quantity;
        // this.fresh_shift_tag = this.table1State.zone2_basement1.fresh_shift_tag;
        // this.fa_fan_quantity = this.table1State.zone2_basement1.fa_fan_quantity;
        this.area = findObj.area;
        this.height = findObj.height;
        this.airflow_normal_acph = findObj.airflow_normal_acph;
        this.airflow_fire_acph = findObj.airflow_fire_acph;
        this.ex_fan_quantity = findObj.ex_fan_quantity;
        this.fa_fan_quantity = findObj.fa_fan_quantity;
        this.fresh_shift_tag = findObj.fresh_shift_tag;
        this.floor = 'Basement 1';
        this.zone = 'Zone2';
      }
      if (this.selectedTable1Summary?.name == 'Zone 2 - Basement 2') {
        // this.area = this.table1State.zone2_basement2.area;
        // this.height = this.table1State.zone2_basement2.height;
        // this.airflow_normal_acph =
        //   this.table1State.zone2_basement2.airflow_normal_acph;
        // this.airflow_fire_acph =
        //   this.table1State.zone2_basement2.airflow_fire_acph;
        // this.ex_fan_quantity = this.table1State.zone2_basement2.ex_fan_quantity;
        // this.fresh_shift_tag = this.table1State.zone2_basement2.fresh_shift_tag;
        // this.fa_fan_quantity = this.table1State.zone2_basement2.fa_fan_quantity;
        this.area = findObj.area;
        this.height = findObj.height;
        this.airflow_normal_acph = findObj.airflow_normal_acph;
        this.airflow_fire_acph = findObj.airflow_fire_acph;
        this.ex_fan_quantity = findObj.ex_fan_quantity;
        this.fa_fan_quantity = findObj.fa_fan_quantity;
        this.fresh_shift_tag = findObj.fresh_shift_tag;
        this.floor = 'Basement 2';
        this.zone = 'Zone2';
      }
      if (this.selectedTable1Summary?.name == 'Zone 2 - Basement 3') {
        // this.area = this.table1State.zone2_basement3.area;
        // this.height = this.table1State.zone2_basement3.height;
        // this.airflow_normal_acph =
        //   this.table1State.zone2_basement3.airflow_normal_acph;
        // this.airflow_fire_acph =
        //   this.table1State.zone2_basement3.airflow_fire_acph;
        // this.ex_fan_quantity = this.table1State.zone2_basement3.ex_fan_quantity;
        // this.fresh_shift_tag = this.table1State.zone2_basement3.fresh_shift_tag;
        // this.fa_fan_quantity = this.table1State.zone2_basement3.fa_fan_quantity;
        this.area = findObj.area;
        this.height = findObj.height;
        this.airflow_normal_acph = findObj.airflow_normal_acph;
        this.airflow_fire_acph = findObj.airflow_fire_acph;
        this.ex_fan_quantity = findObj.ex_fan_quantity;
        this.fa_fan_quantity = findObj.fa_fan_quantity;
        this.fresh_shift_tag = findObj.fresh_shift_tag;
        this.floor = 'Basement 3';
        this.zone = 'Zone2';
      }
    }

    if (this.showTable1) {
      this.inputDropdownArrowSrc = 'assets/images/icons/up_arrow.svg';
      this.summaryText = '';
      // this.onInputBChange();
    } else {
      this.inputDropdownArrowSrc = 'assets/images/icons/down_arrow.svg';
      this.summaryText = 'Summary - B';
    }
  }

  updateCommonServicesInputSummaries(response: any, summaryToUpdate: any) {
    const keyMap: { [key: string]: string } = {
      'Zone 1 - Basement 1': 'basement1_zone1',
      'Zone 1 - Basement 2': 'basement2_zone1',
      'Zone 1 - Basement 3': 'basement3_zone1',
      'Zone 2 - Basement 1': 'basement1_zone2',
      'Zone 2 - Basement 2': 'basement2_zone2',
      'Zone 2 - Basement 3': 'basement3_zone2',

      // 'basement1_zone1': 'basement1_zone1',
      // 'basement1_zone2': 'basement1_zone2',
      // 'basement2_zone1': 'basement2_zone1',
      // 'basement2_zone2': 'basement2_zone2',
      // 'basement3_zone1': 'basement3_zone1',
      // 'basement3_zone2': 'basement3_zone2',
    };

    return summaryToUpdate.map((item: { name: string | number }) => {
      const key = keyMap[item.name];

      const inputDetails = response?.[key];

      if (response) {
        const value = response[key];

        return {
          ...item,
          value: value?.area,
          area: inputDetails?.area,
          height: inputDetails?.height,
          airflow_normal_acph: inputDetails?.airflow_normal_acph,
          airflow_fire_acph: inputDetails?.airflow_fire_acph,
          ex_fan_quantity: inputDetails?.ex_fan_quantity,
          fa_fan_quantity: inputDetails?.fa_fan_quantity,
          fresh_shift_tag: inputDetails?.fresh_shift_tag,
          remarks: inputDetails?.remarks,
        };
      }

      return {
        ...item,
        value: '0',
        area: 0,
        height: 0,
        airflow_normal_acph: 0,
        airflow_fire_acph: 0,
        ex_fan_quantity: 0,
        fa_fan_quantity: 0,
        fresh_shift_tag: '',
        remarks: '',
      };
    });
  }

  onCommonServicesVentInputChange() {
    if (this.selectedTable1Summary?.name === 'Zone 1 - Basement 1') {
      // this.table1State.owc.service = 'OWC';
      this.table1State.zone1_basement1.floor = 'Basement 1';
      this.table1State.zone1_basement1.zone = 'Zone1';
      this.table1State.zone1_basement1.area = this.area;
      this.table1State.zone1_basement1.height = this.height;
      this.table1State.zone1_basement1.airflow_normal_acph =
        this.airflow_normal_acph;
      this.table1State.zone1_basement1.airflow_fire_acph =
        this.airflow_fire_acph;
      this.table1State.zone1_basement1.ex_fan_quantity = this.ex_fan_quantity;
      this.table1State.zone1_basement1.fresh_shift_tag = this.fresh_shift_tag;
      this.table1State.zone1_basement1.fa_fan_quantity = this.fa_fan_quantity;
    }
    if (this.selectedTable1Summary?.name === 'Zone 1 - Basement 2') {
      // this.table1State.owc.service = 'OWC';
      this.table1State.zone1_basement2.floor = 'Basement2';
      this.table1State.zone1_basement2.zone = 'Zone1';
      this.table1State.zone1_basement2.area = this.area;
      this.table1State.zone1_basement2.height = this.height;
      this.table1State.zone1_basement2.airflow_normal_acph =
        this.airflow_normal_acph;
      this.table1State.zone1_basement2.airflow_fire_acph =
        this.airflow_fire_acph;
      this.table1State.zone1_basement2.ex_fan_quantity = this.ex_fan_quantity;
      this.table1State.zone1_basement2.fresh_shift_tag = this.fresh_shift_tag;
      this.table1State.zone1_basement2.fa_fan_quantity = this.fa_fan_quantity;
    }
    if (this.selectedTable1Summary?.name === 'Zone 1 - Basement 3') {
      // this.table1State.owc.service = 'OWC';
      this.table1State.zone1_basement3.floor = 'Basement 3';
      this.table1State.zone1_basement3.zone = 'Zone1';
      this.table1State.zone1_basement3.area = this.area;
      this.table1State.zone1_basement3.height = this.height;
      this.table1State.zone1_basement3.airflow_normal_acph =
        this.airflow_normal_acph;
      this.table1State.zone1_basement3.airflow_fire_acph =
        this.airflow_fire_acph;
      this.table1State.zone1_basement3.ex_fan_quantity = this.ex_fan_quantity;
      this.table1State.zone1_basement3.fresh_shift_tag = this.fresh_shift_tag;
      this.table1State.zone1_basement3.fa_fan_quantity = this.fa_fan_quantity;
    }
    if (this.selectedTable1Summary?.name === 'Zone 2 - Basement 1') {
      // this.table1State.owc.service = 'OWC';
      this.table1State.zone2_basement1.floor = 'Basement 1';
      this.table1State.zone2_basement1.zone = 'Zone2';
      this.table1State.zone2_basement1.area = this.area;
      this.table1State.zone2_basement1.height = this.height;
      this.table1State.zone2_basement1.airflow_normal_acph =
        this.airflow_normal_acph;
      this.table1State.zone2_basement1.airflow_fire_acph =
        this.airflow_fire_acph;
      this.table1State.zone2_basement1.ex_fan_quantity = this.ex_fan_quantity;
      this.table1State.zone2_basement1.fresh_shift_tag = this.fresh_shift_tag;
      this.table1State.zone2_basement1.fa_fan_quantity = this.fa_fan_quantity;
    }
    if (this.selectedTable1Summary?.name === 'Zone 2 - Basement 2') {
      // this.table1State.owc.service = 'OWC';
      this.table1State.zone2_basement2.floor = 'Basement 2';
      this.table1State.zone2_basement2.zone = 'Zone2';
      this.table1State.zone2_basement2.area = this.area;
      this.table1State.zone2_basement2.height = this.height;
      this.table1State.zone2_basement2.airflow_normal_acph =
        this.airflow_normal_acph;
      this.table1State.zone2_basement2.airflow_fire_acph =
        this.airflow_fire_acph;
      this.table1State.zone2_basement2.ex_fan_quantity = this.ex_fan_quantity;
      this.table1State.zone2_basement2.fresh_shift_tag = this.fresh_shift_tag;
      this.table1State.zone2_basement2.fa_fan_quantity = this.fa_fan_quantity;
    }
    if (this.selectedTable1Summary?.name === 'Zone 2 - Basement 3') {
      // this.table1State.owc.service = 'OWC';
      this.table1State.zone2_basement3.floor = 'Basement 3';
      this.table1State.zone2_basement3.zone = 'Zone2';
      this.table1State.zone2_basement3.area = this.area;
      this.table1State.zone2_basement3.height = this.height;
      this.table1State.zone2_basement3.airflow_normal_acph =
        this.airflow_normal_acph;
      this.table1State.zone2_basement3.airflow_fire_acph =
        this.airflow_fire_acph;
      this.table1State.zone2_basement3.ex_fan_quantity = this.ex_fan_quantity;
      this.table1State.zone2_basement3.fresh_shift_tag = this.fresh_shift_tag;
      this.table1State.zone2_basement3.fa_fan_quantity = this.fa_fan_quantity;
    }

    // Validate all fields before proceeding
    // if (!this.areAllFieldsFilled()) {
    //   // console.error('Validation Error: All fields must be filled before making the API call.');
    //   return;
    // }

    const payload = {
      inputs: [
        this.table1State.zone1_basement1,
        this.table1State.zone1_basement2,
        this.table1State.zone1_basement3,
        this.table1State.zone2_basement1,
        this.table1State.zone2_basement2,
        this.table1State.zone2_basement3,
      ],
    };

    this.apiService.post<any>('basement_table', payload).subscribe(
      (response) => {
        this.commonServicesMainResponse = response;
        console.log(
          'Common Services Main Response: ',
          this.commonServicesMainResponse,
        );
        this.commonServicesInputSummaries =
          this.updateCommonServicesInputSummaries(
            response,
            this.commonServicesInputSummaries,
          );
      },
      (error) => {
        console.error('API Error:', error);
      },
    );
  }

  areAllFieldsFilled(): boolean {
    const services = Object.values(this.table1State);

    return services.every(
      (service: any) =>
        service.area !== 0 &&
        service.height !== 0 &&
        service.airflow_acph !== 0 &&
        service.ex_fan_qty !== 0 &&
        service.fresh_air !== 0 &&
        service.fa_fan_qty !== 0 &&
        service.service !== '',
    );
  }

  submit() {
    const projectDetailsString = sessionStorage.getItem('PROJECTDETAILS');

    let projectName = '';
    let projectType = '';
    let documentVersion = '';
    let date = '';

    if (projectDetailsString) {
      const projectDetails = JSON.parse(projectDetailsString);
      projectName = projectDetails.queryParams.projectName;
      projectType = projectDetails.queryParams.projectType;
      documentVersion = projectDetails.queryParams.documentVersion;
      date = projectDetails.queryParams.date;
    }

    const payload = {
      project_name: projectName,
      project_type: projectType,
      document_version: documentVersion,
      project_date: date || this.project_date,
      project_id: this.project_id,
      sub_module_name: this.sub_module_name,
    };
    this.calculusCommonService.getReport(payload);
  }
}
