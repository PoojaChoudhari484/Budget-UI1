import {NgModule} from '@angular/core';
import {RouterModule, Routes} from '@angular/router';
import {
  HvacCommonServicesVentilationComponent
} from './hvac-common-services-ventilation/hvac-common-services-ventilation.component';
import {BasementVentilationComponent} from './basement-ventilation/basement-ventilation.component';
import {CommonServiceStpComponent} from '../igbc/common-service-stp/common-service-stp.component';
import {CommonServiceDgComponent} from '../igbc/common-service-dg/common-service-dg.component';
import {ProjectDetailsComponent} from './project-details/project-details.component';
import {HvacSummaryComponent} from './hvac-summary/hvac-summary.component';
import {HvacSubPageComponent} from './hvac-sub-page/hvac-sub-page.component';
import {AirPressureDropComponent} from "./air-pressure-drop/air-pressure-drop.component";
import {ExpansionTankComponent} from "./expansion-tank/expansion-tank.component";
import {StaircaseAirPressureComponent} from "./staircase-air-pressure/staircase-air-pressure.component";
import {LiftwellAirPressureComponent} from "./liftwell-air-pressure/liftwell-air-pressure.component";
import {LiftLobbyAirPressureComponent} from "./lift-lobby-air-pressure/lift-lobby-air-pressure.component";

const routes: Routes = [
  {
    path: '',
    children: [
      {path: '', redirectTo: 'stair-case', pathMatch: 'full'},
      {path: 'stair-case', component: StaircaseAirPressureComponent},
      {path: 'lift-well', component: LiftwellAirPressureComponent},
      {path: 'lift-lobby', component: LiftLobbyAirPressureComponent},
      {
        path: 'common-service-ventilation',
        component: HvacCommonServicesVentilationComponent,
      },
      {path: 'common-service-stp', component: CommonServiceStpComponent},
      {path: 'common-service-dg', component: CommonServiceDgComponent},
      {path: 'air-pressure', component: AirPressureDropComponent},
      {path: 'basement-ventilation', component: BasementVentilationComponent},
      {path: 'project-details', component: ProjectDetailsComponent},
      {path: 'design-calculus-submodules', component: HvacSubPageComponent},
      {path: 'hvac-summary', component: HvacSummaryComponent},
      {path: 'expansion-tank', component: ExpansionTankComponent},
    ],
  },
];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule],
})
export class HvacRoutingModule {
}
