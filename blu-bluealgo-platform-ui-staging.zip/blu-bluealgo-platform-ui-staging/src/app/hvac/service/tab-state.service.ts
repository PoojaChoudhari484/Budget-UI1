import { Injectable } from '@angular/core';
import {BehaviorSubject, Subject} from "rxjs";

@Injectable({
  providedIn: 'root'
})
export class TabStateService {

  constructor() { }

  private tabChangeSubject = new Subject<void>();
  tabChange$ = this.tabChangeSubject.asObservable();

  changeTab() {
    this.tabChangeSubject.next();
  }

  private staircaseChangeSubject = new Subject<void>();
  staircaseChange$ = this.staircaseChangeSubject.asObservable();

  changeStaircase() {
    this.staircaseChangeSubject.next();
  }

  private lobbyChangeSubject = new Subject<void>();
  lobbyChange$ = this.lobbyChangeSubject.asObservable();

  changeLobby() {
    this.lobbyChangeSubject.next();
  }

}
