import { Component, OnInit, TemplateRef, ViewChild } from '@angular/core';
import { VersionApiService } from '../core/services/version-api.service';
import { MatDialog } from '@angular/material/dialog';
import { take } from 'rxjs';
import { LocalStorageService } from '../core/services/local-storage.service';
import { DatePipe } from '@angular/common';

@Component({
    selector: 'app-clause-history',
    templateUrl: './clause-history.component.html',
    styleUrls: ['./clause-history.component.scss'],
    standalone: false
})
export class ClauseHistoryComponent implements OnInit {
  columns: {
    id: string;
    title: string;
    actions: boolean;
    template: any;
    isSortable: boolean;
  }[] = [];

  childColumns: {
    id: string;
    title: string;
    actions: boolean;
    template: any;
    isSortable: boolean;
  }[] = [];

  info: any[] = [];
  childInfo: any[] = [];

  @ViewChild('more', { static: true }) more!: TemplateRef<any>;
  @ViewChild('filePath', { static: true }) filePath!: TemplateRef<any>;
  @ViewChild('prmsDialogTemplate') prmsDialogTemplate!: TemplateRef<any>;

  constructor(
    private versionApi: VersionApiService,
    public dialog: MatDialog,
    private localStorageService: LocalStorageService,
    private datePipe: DatePipe,
  ) {}

  ngOnInit(): void {
    this.columns = [
      {
        id: 'id',
        title: 'ID',
        actions: false,
        template: '',
        isSortable: false,
      },
      {
        id: 'clausename',
        title: 'Clause Name',
        actions: false,
        template: '',
        isSortable: false,
      },
      {
        id: 'level',
        title: 'Level',
        actions: false,
        template: '',
        isSortable: false,
      },
      {
        id: '',
        title: 'View More',
        actions: true,
        template: this.more,
        isSortable: false,
      },
    ];

    this.childColumns = [
      {
        id: 'clausename',
        title: 'Clause Name',
        actions: false,
        template: '',
        isSortable: false,
      },
      {
        id: 'docVersion',
        title: 'Version',
        actions: false,
        template: '',
        isSortable: false,
      },
      {
        id: 'updatedBy',
        title: 'Updated By',
        actions: false,
        template: '',
        isSortable: false,
      },
      {
        id: 'updatedDate',
        title: 'Updated Date',
        actions: false,
        template: '',
        isSortable: false,
      },
      {
        id: '',
        title: 'File Path',
        actions: true,
        template: this.filePath,
        isSortable: false,
      },
    ];
    this.getClauseHistory();
  }

  async moreInfo(row: any, index: number) {
    const response: any = await this.versionApi.getChildClauseHistory(row.id);
    this.childInfo = this.extractClauseDetails(response);

    const dialogRef = this.dialog.open(this.prmsDialogTemplate, {
      panelClass: 'extend-services-dialog-container',
      width: 'auto',
      height: 'auto',
      autoFocus: false,
      restoreFocus: false,
      disableClose: true,
    });

    dialogRef
      .afterClosed()
      .pipe(take(1))
      .subscribe((result) => {
        console.log('The dialog was closed');
        // handle dialog close if necessary
      });
  }

  private extractClauseDetails(model: any[]) {
    return model.map((item) => ({
      docVersion: item.data.docVersion,
      fileBucketPath: item.data.fileBucketPath,
      clausename: item.data.clausename,
      updatedBy: item.created_by,
      updatedDate: this.datePipe.transform(item.at_date, 'dd-MM-yyyy'),
    }));
  }

  closeDialog(): void {
    this.dialog.closeAll();
  }

  async getClauseHistory() {
    const customerId = this.localStorageService.getMasterId();
    const response: any = await this.versionApi.getClauseHistory(customerId);
    if (response) {
      this.info = this.MapClause(response.Allclauses);
    }
  }

  private MapClause(Allclauses: any[]) {
    let result: any[] = [];
    Allclauses.forEach((element) => {
      if (element.languages) {
        result.push({
          id: element.languages.English.Id,
          clausename: element.clausename,
          level: element.languages.English.level,
        });

        if (
          element.languages.English.child &&
          element.languages.English.child.length > 0
        ) {
          this.addChildrenToResult(element.languages.English.child, result);
        }
      }
    });
    return result;
  }

  private addChildrenToResult(children: any[], result: any[]) {
    children.forEach((child: any) => {
      result.push({
        id: child.Id,
        clausename: child.clausename,
        level: child.level,
      });
      if (child.child && child.child.length > 0) {
        this.addChildrenToResult(child.child, result);
      }
    });
  }
}
