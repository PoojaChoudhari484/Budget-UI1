import { NgModule } from '@angular/core';
import { CommonModule, DatePipe } from '@angular/common';

import { ClauseHistoryRoutingModule } from './clause-history-routing.module';
import { ClauseHistoryComponent } from './clause-history.component';
import { VersionApiService } from '../core/services/version-api.service';
import { ReusableTableModule } from '../shared/table/table.module';
import { MatAngularModule } from '../mat-angular/mat-angular.module';

@NgModule({
  declarations: [ClauseHistoryComponent],
  providers: [VersionApiService, DatePipe],
  imports: [
    CommonModule,
    ClauseHistoryRoutingModule,
    ReusableTableModule,
    MatAngularModule,
  ],
})
export class ClauseHistoryModule {}
