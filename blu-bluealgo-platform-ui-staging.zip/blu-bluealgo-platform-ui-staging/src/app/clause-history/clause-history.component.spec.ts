import { ComponentFixture, TestBed } from '@angular/core/testing';

import { ClauseHistoryComponent } from './clause-history.component';

describe('ClauseHistoryComponent', () => {
  let component: ClauseHistoryComponent;
  let fixture: ComponentFixture<ClauseHistoryComponent>;

  beforeEach(() => {
    TestBed.configureTestingModule({
      declarations: [ClauseHistoryComponent],
    });
    fixture = TestBed.createComponent(ClauseHistoryComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
