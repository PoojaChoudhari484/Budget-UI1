import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';

import { EventLogsRoutingModule } from './event-logs-routing.module';
import { EventLogsComponent } from './event-logs.component';
import { ReusableTableModule } from '../shared/table/table.module';
import { VersionApiService } from '../core/services/version-api.service';

@NgModule({
  declarations: [EventLogsComponent],
  providers: [VersionApiService],
  imports: [CommonModule, EventLogsRoutingModule, ReusableTableModule],
})
export class EventLogsModule {}
