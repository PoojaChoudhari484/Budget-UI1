import { Component, OnInit, TemplateRef, ViewChild } from '@angular/core';
import { VersionApiService } from '../core/services/version-api.service';
import { MatDialog } from '@angular/material/dialog';
import { SmartformConfigDialogService } from '../smartformconfig/services/smartform-config-dialog.service';
import { LocalStorageService } from '../core/services/local-storage.service';

@Component({
    selector: 'app-event-logs',
    templateUrl: './event-logs.component.html',
    styleUrls: ['./event-logs.component.scss'],
    standalone: false
})
export class EventLogsComponent implements OnInit {
  columns: {
    id: string;
    title: string;
    actions: boolean;
    template: any;
    isSortable: boolean;
  }[] = [];

  info: any[] = [];

  @ViewChild('more', { static: true }) more!: TemplateRef<any>;

  constructor(
    private versionApi: VersionApiService,
    public dialog: MatDialog,
    protected smartformConfigDialogService: SmartformConfigDialogService,
    private localStorageService: LocalStorageService,
  ) {}

  ngOnInit(): void {
    this.columns = [
      {
        id: 'message',
        title: 'Event',
        actions: false,
        template: '',
        isSortable: false,
      },
      {
        id: 'doc_version',
        title: 'Doc Version',
        actions: false,
        template: '',
        isSortable: false,
      },
      {
        id: 'at_date',
        title: 'At Date',
        actions: false,
        template: '',
        isSortable: false,
      },
      {
        id: '',
        title: 'PRMS',
        actions: true,
        template: this.more,
        isSortable: false,
      },
    ];
    this.getEventLogs();
  }

  // region JsonEditor
  openJsonViewer(json: string, label: string) {
    if (json) {
      let validJson = this.smartformConfigDialogService.isJsonString(json);
      json = validJson ? validJson : {};
    }
    this.smartformConfigDialogService
      .openJsonViewer(this.dialog, `${label}`, json, json, true)
      .subscribe((result) => {
        if (result?.value && result?.key) {
          console.log('result', result);
        }
      });
  }

  closeDialog(): void {
    this.dialog.closeAll();
  }

  async getEventLogs() {
    const customerId = this.localStorageService.getMasterId();
    const response: any = await this.versionApi.getEventLogs(customerId);
    if (response) {
      this.info = response.loFmpLogs;
    }
  }
}
