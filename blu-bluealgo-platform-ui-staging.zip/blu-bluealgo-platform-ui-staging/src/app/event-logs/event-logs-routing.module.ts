import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { EventLogsComponent } from './event-logs.component';

const routes: Routes = [{ path: '', component: EventLogsComponent }];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule],
})
export class EventLogsRoutingModule {}
