# bluealgoPlatformUI
New Bluealgo Enterpeise UI 


# Blue Algo FE

This project was generated with [Angular CLI](https://github.com/angular/angular-cli) version 16.2.0.

# Setup
```
Angular Version: 16.2.0
Node Verion: 18.16.0
Npm Version: 9.5.1

******************* USE FULL COMMANDS ******************* 
npm install
npm prepare => must run this command
npm format

npm start => to run project on your system
npm build => to create a production build for prod environment
```

## Development server

Run `npm start` for a dev server. Navigate to `http://localhost:4200/`. The application will automatically reload if you change any of the source files.

## Code scaffolding

Run `ng generate component component-name` to generate a new component. You can also use `ng generate directive|pipe|service|class|guard|interface|enum|module`.

## Build

Run `npm build` to build the project. The build artifacts will be stored in the `dist/` directory.

## Running unit tests

Run `npm test` to execute the unit tests via [Karma](https://karma-runner.github.io).

## Running end-to-end tests

Run `ng e2e` to execute the end-to-end tests via a platform of your choice. To use this command, you need to first add a package that implements end-to-end testing capabilities.

## Further help

To get more help on the Angular CLI use `ng help` or go check out the [Angular CLI Overview and Command Reference](https://angular.io/cli) page.
